from core.seeders.base import run_group

GROUP = "country"


def run() -> dict:
    return run_group(GROUP)
