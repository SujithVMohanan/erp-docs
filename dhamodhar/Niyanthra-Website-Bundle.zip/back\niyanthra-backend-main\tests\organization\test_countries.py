from django.test import TestCase
from rest_framework.test import APIClient

from apps.location.models import Country
from apps.organization.models import Industry, Organization
from apps.users.models import Users
from core.utils.tokens import (
    issue_registration_token,
    issue_tokens,
)

PASSWORD = "ValidPassw0rd!"


class CountryApiTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.admin = Users.objects.create_user(
            email="admin@example.com",
            password=PASSWORD,
            username="adminuser",
            phone_number="+15551110001",
            is_admin=True,
        )
        tokens = issue_tokens(self.admin)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")

    def _create(self, **overrides):
        payload = {
            "name": "Testland",
            "code": "TL",
            "iso3": "TLD",
            "phone_code": "+999",
            "currency_code": "TST",
        }
        payload.update(overrides)
        return self.client.post("/api/organization/create-country/", payload, format="json")

    def test_create_country(self):
        response = self._create()
        self.assertEqual(response.status_code, 201)
        data = response.data["data"]
        self.assertEqual(data["code"], "TL")
        self.assertEqual(data["name"], "Testland")
        self.assertTrue(data["is_active"])
        self.assertTrue(data["uid"])
        self.assertNotIn("id", data)

    def test_duplicate_code(self):
        self._create()
        response = self._create(name="Other")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data.get("code"), "COUNTRY_CODE_EXISTS")

    def test_list_countries(self):
        self._create()
        response = self.client.get("/api/organization/get-countries/")
        self.assertEqual(response.status_code, 200)
        self.assertGreaterEqual(response.data["data"]["count"], 1)

    def test_update_country(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.put(
            "/api/organization/update-country/",
            {
                "uid": uid,
                "name": "Testland Updated",
                "code": "TL",
                "iso3": "TLD",
                "phone_code": "+998",
                "currency_code": "TST",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["data"]["name"], "Testland Updated")
        self.assertEqual(response.data["data"]["phone_code"], "+998")

    def test_toggle_country_active_status(self):
        created = self._create()
        uid = created.data["data"]["uid"]

        inactive = self.client.post(
            "/api/organization/inactive-active-countries/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(inactive.status_code, 200)
        self.assertFalse(inactive.data["data"][0]["is_active"])
        self.assertFalse(Country.objects.get(code="TL").is_active)

        listed = self.client.get("/api/organization/get-countries/?is_active=false&code=TL")
        self.assertEqual(listed.data["data"]["count"], 1)

        active = self.client.post(
            "/api/organization/inactive-active-countries/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(active.status_code, 200)
        self.assertTrue(active.data["data"][0]["is_active"])
        self.assertTrue(Country.objects.get(code="TL").is_active)

    def test_delete_country(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.delete(
            "/api/organization/delete-countries/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Country.objects.filter(code="TL").exists())

    def test_delete_country_in_use(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        country = Country.objects.get(code="TL")
        industry = Industry.objects.create(name="Retail", code="retail")
        organization = Organization.objects.create(
            name="Group",
            code="GRP1",
            country=country,
        )
        organization.industries.add(industry)
        response = self.client.delete(
            "/api/organization/delete-countries/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data.get("code"), "COUNTRY_IN_USE")
        self.assertTrue(Country.objects.filter(code="TL").exists())

    def test_pending_user_cannot_list(self):
        pending = Users.objects.create_user(
            email="pending@example.com",
            password=PASSWORD,
        )
        token = issue_registration_token(pending)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {token['access']}")
        response = self.client.get("/api/organization/get-countries/")
        self.assertEqual(response.status_code, 403)

    def test_non_admin_cannot_create(self):
        member = Users.objects.create_user(
            email="member@example.com",
            password=PASSWORD,
            username="memberuser",
            phone_number="+15551110002",
        )
        tokens = issue_tokens(member)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")
        response = self._create()
        self.assertEqual(response.status_code, 403)
