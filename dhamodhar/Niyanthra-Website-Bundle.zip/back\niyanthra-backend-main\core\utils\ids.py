"""Encode/decode internal PKs for APIs. Never send raw integer ids."""

from typing import Any

from django.core.signing import (
    BadSignature,
    dumps,
    loads,
)

_SALT = "niyanthra.resource-id"


def encode_id(value: Any) -> str:
    if value is None:
        return ""
    return dumps(value, salt=_SALT)


def decode_id(encoded: str) -> Any:
    if not encoded:
        raise ValueError("Missing id.")
    try:
        return loads(encoded, salt=_SALT)
    except BadSignature as exc:
        raise ValueError("Invalid id.") from exc
