from django.db import IntegrityError
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.organization.repository import CountryRepository
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class CountryService:
    @staticmethod
    def _decode_uid(uid: str) -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({"uid": ["Invalid country id."]})
        if not isinstance(decoded, int):
            raise ValidationError({"uid": ["Invalid country id."]})
        return decoded

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        country_ids = []
        for uid in uids:
            try:
                decoded = decode_id(uid)
            except ValueError:
                raise ValidationError({"uids": ["One or more country ids are invalid."]})
            if not isinstance(decoded, int):
                raise ValidationError({"uids": ["One or more country ids are invalid."]})
            country_ids.append(decoded)
        return list(dict.fromkeys(country_ids))

    @staticmethod
    def get_countries(*, validated_data: dict):
        country_id = None
        uid        = validated_data.get("uid")
        if uid:
            country_id = [CountryService._decode_uid(uid)]

        return CountryRepository.list_countries(
            country_id    = country_id,
            code          = validated_data.get("code"),
            name          = validated_data.get("name"),
            is_active     = validated_data.get("is_active"),
        )

    @staticmethod
    def create_country(*, validated_data: dict):
        code = validated_data["code"]
        if CountryRepository.get_code_conflict(code=code):
            raise AuthValidationError(
                {"code": ["This country code already exists."]},
                code="COUNTRY_CODE_EXISTS",
            )
        try:
            return CountryRepository.create_country(
                name          = validated_data["name"],
                code          = code,
                iso3          = validated_data.get("iso3"),
                phone_code    = validated_data.get("phone_code"),
                currency_code = validated_data.get("currency_code"),
            )
        
        except IntegrityError:
            raise AuthValidationError(
                {"code": ["This country code already exists."]},
                code="COUNTRY_CODE_EXISTS",
            ) from None

    @staticmethod
    def update_country(*, validated_data: dict):
        country = CountryRepository.get_by_id(
            CountryService._decode_uid(validated_data["uid"])
        )
        if country is None:
            raise NotFound("Country not found.")

        code = validated_data["code"]
        if CountryRepository.get_code_conflict(code=code, exclude_id=country.pk):
            raise AuthValidationError(
                {"code": ["This country code already exists."]},
                code="COUNTRY_CODE_EXISTS",
            )
        try:
            return CountryRepository.update_country(
                country       = country,
                name          = validated_data["name"],
                code          = code,
                iso3          = validated_data.get("iso3"),
                phone_code    = validated_data.get("phone_code"),
                currency_code = validated_data.get("currency_code"),
            )
        except IntegrityError:
            raise AuthValidationError(
                {"code": ["This country code already exists."]},
                code="COUNTRY_CODE_EXISTS",
            ) from None

    @staticmethod
    def delete_countries(*, validated_data: dict) -> dict:

        country_ids = CountryService._decode_uids(validated_data["uids"])

        if CountryRepository.countries_in_use(country_ids):
            raise AuthValidationError(
                {"uids": ["Cannot delete: one or more countries are in use."]},
                code="COUNTRY_IN_USE",
            )
        
        deleted = CountryRepository.soft_delete_by_ids(country_ids)
        if not deleted:
            raise NotFound("Country not found.")
        return {"deleted": deleted}

    @staticmethod
    def toggle_countries(*, validated_data: dict):
        country_ids = CountryService._decode_uids(validated_data["uids"])
        updated     = CountryRepository.toggle_active_by_ids(country_ids)
        if not updated:
            raise NotFound("Country not found.")
        
        return CountryRepository.list_countries(country_id=country_ids)
