from rest_framework import serializers


class CreateStateSerializer(serializers.Serializer):
    name        = serializers.CharField(max_length=150, trim_whitespace=True)
    code        = serializers.CharField(max_length=20, trim_whitespace=True)
    country_uid = serializers.CharField(trim_whitespace=True)
    is_active   = serializers.BooleanField(required=False, default=True)

    def validate_code(self, value):
        normalized = value.strip().upper()
        if not normalized:
            raise serializers.ValidationError("This field may not be blank.")
        return normalized

    def validate_name(self, value):
        normalized = value.strip()
        if not normalized:
            raise serializers.ValidationError("This field may not be blank.")
        return normalized


class UpdateStateSerializer(CreateStateSerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetStatesQuerySerializer(serializers.Serializer):
    uid         = serializers.CharField(required=False, allow_blank=True)
    country_uid = serializers.CharField(required=False, allow_blank=True)
    code        = serializers.CharField(required=False, allow_blank=True, max_length=20)
    name        = serializers.CharField(required=False, allow_blank=True, max_length=150)
    is_active   = serializers.BooleanField(required=False, allow_null=True)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["country_uid"] = (attrs.get("country_uid") or "").strip() or None
        attrs["code"] = (attrs.get("code") or "").strip().upper() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        if "is_active" not in attrs:
            attrs["is_active"] = None
        return attrs


class StateUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique = []
        seen = set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one state.")
        return unique


class CreateLocationSerializer(serializers.Serializer):
    country_uid      = serializers.CharField(trim_whitespace=True)
    state_uid        = serializers.CharField(
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )
    city             = serializers.CharField(max_length=100, trim_whitespace=True)
    postal_code      = serializers.CharField(
        max_length=20,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )
    address_line_1   = serializers.CharField(max_length=255, trim_whitespace=True)
    address_line_2   = serializers.CharField(
        max_length=255,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )
    latitude         = serializers.DecimalField(
        max_digits=10,
        decimal_places=7,
        required=False,
        allow_null=True,
    )
    longitude        = serializers.DecimalField(
        max_digits=10,
        decimal_places=7,
        required=False,
        allow_null=True,
    )
    place_id         = serializers.CharField(
        max_length=255,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )
    formatted_address = serializers.CharField(
        max_length=500,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )

    def validate(self, attrs):
        attrs["state_uid"] = (attrs.get("state_uid") or "").strip() or None
        attrs["postal_code"] = (attrs.get("postal_code") or "").strip()
        attrs["address_line_2"] = (attrs.get("address_line_2") or "").strip()
        attrs["place_id"] = (attrs.get("place_id") or "").strip()
        attrs["formatted_address"] = (attrs.get("formatted_address") or "").strip()
        return attrs


class UpdateLocationSerializer(CreateLocationSerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetLocationsQuerySerializer(serializers.Serializer):
    uid         = serializers.CharField(required=False, allow_blank=True)
    country_uid = serializers.CharField(required=False, allow_blank=True)
    state_uid   = serializers.CharField(required=False, allow_blank=True)
    city        = serializers.CharField(required=False, allow_blank=True, max_length=100)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["country_uid"] = (attrs.get("country_uid") or "").strip() or None
        attrs["state_uid"] = (attrs.get("state_uid") or "").strip() or None
        attrs["city"] = (attrs.get("city") or "").strip() or None
        return attrs


class LocationUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique = []
        seen = set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one location.")
        return unique
