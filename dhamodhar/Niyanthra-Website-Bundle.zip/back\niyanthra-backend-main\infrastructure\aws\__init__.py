"""AWS Secrets Manager and S3. Not domain apps."""

from infrastructure.aws.secrets import SecretsManagerClient

__all__ = [
    "SecretsManagerClient",
]
