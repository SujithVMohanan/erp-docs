from django.db import IntegrityError
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.location.repository import StateRepository
from apps.organization.repository import CountryRepository
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class StateService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})
        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})
        return decoded

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        return list(
            dict.fromkeys(
                StateService._decode_uid(uid, field="uids")
                for uid in uids
            )
        )

    @staticmethod
    def get_states(*, validated_data: dict):
        state_id = None
        country_id = None

        if validated_data.get("uid"):
            state_id = [StateService._decode_uid(validated_data["uid"])]

        if validated_data.get("country_uid"):
            country_id = StateService._decode_uid(
                validated_data["country_uid"],
                field="country_uid",
            )

        return StateRepository.list_states(
            state_id=state_id,
            country_id=country_id,
            code=validated_data.get("code"),
            name=validated_data.get("name"),
            is_active=validated_data.get("is_active"),
        )

    @staticmethod
    def create_state(*, validated_data: dict):
        country_id = StateService._decode_uid(
            validated_data["country_uid"],
            field="country_uid",
        )
        if CountryRepository.get_by_id(country_id) is None:
            raise AuthValidationError(
                {"country_uid": ["Country not found."]},
                code="COUNTRY_NOT_FOUND",
            )

        code = validated_data["code"]
        if StateRepository.get_code_conflict(
            country_id=country_id,
            code=code,
        ):
            raise AuthValidationError(
                {"code": ["This state code already exists for the country."]},
                code="STATE_CODE_EXISTS",
            )

        try:
            state = StateRepository.create_state(
                country_id=country_id,
                name=validated_data["name"],
                code=code,
                is_active=validated_data.get("is_active", True),
            )
        except IntegrityError:
            raise AuthValidationError(
                {"code": ["This state code already exists for the country."]},
                code="STATE_CODE_EXISTS",
            ) from None

        return StateRepository.get_by_id(state.pk)

    @staticmethod
    def update_state(*, validated_data: dict):
        state = StateRepository.get_by_id(
            StateService._decode_uid(validated_data["uid"])
        )
        if state is None:
            raise NotFound("State not found.")

        country_id = StateService._decode_uid(
            validated_data["country_uid"],
            field="country_uid",
        )
        if CountryRepository.get_by_id(country_id) is None:
            raise AuthValidationError(
                {"country_uid": ["Country not found."]},
                code="COUNTRY_NOT_FOUND",
            )

        code = validated_data["code"]
        if StateRepository.get_code_conflict(
            country_id=country_id,
            code=code,
            exclude_id=state.pk,
        ):
            raise AuthValidationError(
                {"code": ["This state code already exists for the country."]},
                code="STATE_CODE_EXISTS",
            )

        try:
            StateRepository.update_state(
                state=state,
                country_id=country_id,
                name=validated_data["name"],
                code=code,
                is_active=validated_data.get("is_active", state.is_active),
            )
        except IntegrityError:
            raise AuthValidationError(
                {"code": ["This state code already exists for the country."]},
                code="STATE_CODE_EXISTS",
            ) from None

        return StateRepository.get_by_id(state.pk)

    @staticmethod
    def delete_states(*, validated_data: dict) -> dict:
        state_ids = StateService._decode_uids(validated_data["uids"])
        deleted = StateRepository.soft_delete_by_ids(state_ids)
        if not deleted:
            raise NotFound("State not found.")
        return {"deleted": deleted}

    @staticmethod
    def toggle_states(*, validated_data: dict):
        state_ids = StateService._decode_uids(validated_data["uids"])
        updated = StateRepository.toggle_active_by_ids(state_ids)
        if not updated:
            raise NotFound("State not found.")
        return StateRepository.list_states(state_id=state_ids)
