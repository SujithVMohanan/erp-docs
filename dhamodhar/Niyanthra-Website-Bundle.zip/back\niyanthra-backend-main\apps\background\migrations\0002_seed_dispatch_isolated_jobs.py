from django.db import migrations


def seed_dispatch_isolated_jobs(apps, schema_editor):
    PeriodicTask = apps.get_model("background", "PeriodicTask")
    PeriodicTask.objects.update_or_create(
        code="dispatch_isolated_jobs",
        defaults={
            "name": "Dispatch Isolated Jobs",
            "task_path": "background.dispatch_isolated_jobs",
            "is_enabled": True,
            "interval_seconds": 60,
            "max_workers": 5,
            "queue_status": "idle",
            "description": (
                "Claims PENDING isolated DB provision jobs and runs "
                "them with a bounded thread pool."
            ),
        },
    )


def unseed_dispatch_isolated_jobs(apps, schema_editor):
    PeriodicTask = apps.get_model("background", "PeriodicTask")
    PeriodicTask.objects.filter(code="dispatch_isolated_jobs").delete()


class Migration(migrations.Migration):

    dependencies = [
        ("background", "0001_initial_periodic_task_and_jobs"),
    ]

    operations = [
        migrations.RunPython(
            seed_dispatch_isolated_jobs,
            unseed_dispatch_isolated_jobs,
        ),
    ]
