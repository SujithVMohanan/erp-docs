"""Safe cache helpers with Redis/backend degradation."""

from core.cache.safe_cache import SafeCache

__all__ = [
    "SafeCache",
]
