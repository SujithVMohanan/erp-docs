from apps.tenant.models import Tenant
from apps.tenant.services.provisioners.base import BaseTenantProvisioner


class SiloTenantProvisioner(BaseTenantProvisioner):
    """Dedicated server and database require DevOps. Stay PENDING until activated."""

    def provision(self, *, tenant: Tenant) -> Tenant:
        return tenant
