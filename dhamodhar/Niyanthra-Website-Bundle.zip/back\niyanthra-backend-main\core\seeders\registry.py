from pathlib import Path

from django.conf import settings


# Ordered fixture stems under core/seeders/fixtures/ (without .json).
INITIAL_FIXTURES = (
    "001_countries",
    "002_indian_states",
    "003_industries",
    "004_company_types",
    "005_business_types",
    "006_tax_types",
    "007_tax_components",
    "008_tax_rates",
    "009_tax_rate_components",
    "010_timezones",
    "011_permissions",
    "012_periodic_tasks",
    "013_modules",
)

# Single-group aliases → fixture stems.
SEED_GROUPS = {
    "country": ("001_countries",),
    "state": ("002_indian_states",),
    "industry": ("003_industries",),
    "company_type": ("004_company_types",),
    "business_type": ("005_business_types",),
    "tax": (
        "006_tax_types",
        "007_tax_components",
        "008_tax_rates",
        "009_tax_rate_components",
    ),
    "timezone": ("010_timezones",),
    "permission": ("011_permissions",),
    "periodic_task": ("012_periodic_tasks",),
    "module": ("013_modules",),
}


def fixture_dir() -> Path:
    configured = getattr(settings, "SEEDERS_FIXTURE_DIR", None)
    if configured:
        return Path(configured)
    return Path(__file__).resolve().parent / "fixtures"


def fixture_path(stem: str) -> Path:
    return fixture_dir() / f"{stem}.json"
