from core.seeders.management.commands._seed_base import SeedGroupCommand
from core.seeders.module import run


class Command(SeedGroupCommand):
    help = "Seed Module catalog. Safe to run multiple times."
    group_label = "Module"
    seeder_run = staticmethod(run)
