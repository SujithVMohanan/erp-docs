from apps.tenant.models import Tenant
from apps.tenant.services.provisioners.base import BaseTenantProvisioner
from apps.tenant.services.provisioners.isolated import IsolatedTenantProvisioner
from apps.tenant.services.provisioners.shared import SharedTenantProvisioner
from apps.tenant.services.provisioners.silo import SiloTenantProvisioner

PROVISIONERS: dict[str, BaseTenantProvisioner] = {
    Tenant.TenantType.SHARED: SharedTenantProvisioner(),
    Tenant.TenantType.ISOLATED: IsolatedTenantProvisioner(),
    Tenant.TenantType.SILO: SiloTenantProvisioner(),
}


def get_provisioner(tenant_type: str) -> BaseTenantProvisioner:
    provisioner = PROVISIONERS.get(tenant_type)

    if provisioner is None:
        raise ValueError(f"Unsupported tenant type: {tenant_type}")

    return provisioner
