from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated

from apps.sales.schemas import GetSalesApiSchema
from apps.sales.serializers import (
    CreateSaleSerializer,
    GetSalesQuerySerializer,
    SaleUidsSerializer,
    UpdateSaleSerializer,
)
from apps.sales.services.sale_service import SaleService
from core.pagination import RestPagination
from core.permissions import (
    HasMembershipAccess,
    IsWorkspaceAuthenticated,
)
from core.responses import ResponseInfo
from core.utils.exceptions import ExceptionHandler
from core.tenant.workspace import workspace_scope_from_request


class SaleBaseApiView:

    response_schema = GetSalesApiSchema
    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
        IsWorkspaceAuthenticated,
    ]

    def __init__(self, **kwargs):
        self.response_format = ResponseInfo().response
        super().__init__(**kwargs)

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class GetSalesApiView(SaleBaseApiView, generics.ListAPIView):

    serializer_class = GetSalesApiSchema
    query_serializer_class = GetSalesQuerySerializer
    pagination_class = RestPagination

    @swagger_auto_schema(
        tags=["Sales"],
        manual_parameters=[
            openapi.Parameter(
                "uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "invoice_number",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "customer_name",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "sale_date",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
                format=openapi.FORMAT_DATE,
            ),
        ],
        operation_summary="Get sales",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self, *args, **kwargs):
        query = self.query_serializer_class(
            data=self.request.query_params,
        )
        query.is_valid(raise_exception=True)
        scope = workspace_scope_from_request(self.request)
        return SaleService.get_sales(
            scope=scope,
            validated_data=query.validated_data,
        )


class CreateSaleApiView(SaleBaseApiView, generics.CreateAPIView):

    serializer_class = CreateSaleSerializer

    @swagger_auto_schema(
        request_body=CreateSaleSerializer,
        operation_summary="Create sale",
        tags=["Sales"],
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)

            scope = workspace_scope_from_request(request)
            sale = SaleService.create_sale(
                scope=scope,
                validated_data=serializer.validated_data,
            )
            return ResponseInfo.created(
                self.response_schema(sale).data,
                message="Sale created successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateSaleApiView(SaleBaseApiView, generics.UpdateAPIView):

    serializer_class = UpdateSaleSerializer

    @swagger_auto_schema(
        request_body=UpdateSaleSerializer,
        operation_summary="Update sale",
        tags=["Sales"],
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)

            scope = workspace_scope_from_request(request)
            sale = SaleService.update_sale(
                scope=scope,
                validated_data=serializer.validated_data,
            )
            return ResponseInfo.ok(
                self.response_schema(sale).data,
                message="Sale updated successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteSalesApiView(SaleBaseApiView, generics.GenericAPIView):

    serializer_class = SaleUidsSerializer

    @swagger_auto_schema(
        request_body=SaleUidsSerializer,
        operation_summary="Delete sales",
        tags=["Sales"],
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)

            scope = workspace_scope_from_request(request)
            result = SaleService.delete_sales(
                scope=scope,
                validated_data=serializer.validated_data,
            )
            return ResponseInfo.ok(
                result,
                message="Sale(s) deleted successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)
