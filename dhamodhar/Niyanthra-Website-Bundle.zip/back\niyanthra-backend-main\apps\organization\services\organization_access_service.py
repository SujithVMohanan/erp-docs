from django.db.models import Exists, OuterRef
from rest_framework.exceptions import ValidationError

from apps.company.models import Branch, Company
from apps.organization.models import OrganizationMembership
from core.utils.ids import decode_id


class OrganizationAccessService:
    """One-query checks for an active organization membership."""

    @staticmethod
    def allows(*, user_id: int, target: str, source: str, field: str, request) -> bool:
        if target == "actor":
            return OrganizationAccessService._any(user_id)
        if target == "company_list":
            return OrganizationAccessService._company_list(user_id, request)
        if target == "branch_list":
            return OrganizationAccessService._branch_list(user_id, request)

        ids = OrganizationAccessService._ids(request, source, field)
        if not ids:
            return True
        if target == "organization":
            return OrganizationAccessService._organizations(user_id, ids)
        if target == "company":
            return OrganizationAccessService._companies(user_id, ids)
        if target == "branch":
            return OrganizationAccessService._branches(user_id, ids)
        return False

    @staticmethod
    def _company_list(user_id: int, request) -> bool:
        organization_uid = str(request.query_params.get("organization_uid") or "").strip()
        if organization_uid:
            return OrganizationAccessService._organizations(
                user_id,
                OrganizationAccessService._decode([organization_uid], "organization_uid"),
            )
        company_uid = str(request.query_params.get("uid") or "").strip()
        if company_uid:
            return OrganizationAccessService._companies(
                user_id,
                OrganizationAccessService._decode([company_uid], "uid"),
            )
        return OrganizationAccessService._any(user_id)

    @staticmethod
    def _branch_list(user_id: int, request) -> bool:
        company_uid = str(request.query_params.get("company_uid") or "").strip()
        if company_uid:
            return OrganizationAccessService._companies(
                user_id,
                OrganizationAccessService._decode([company_uid], "company_uid"),
            )
        branch_uid = str(request.query_params.get("uid") or "").strip()
        if branch_uid:
            return OrganizationAccessService._branches(
                user_id,
                OrganizationAccessService._decode([branch_uid], "uid"),
            )
        return OrganizationAccessService._any(user_id)

    @staticmethod
    def _any(user_id: int) -> bool:
        return OrganizationMembership.objects.filter(
            user_id=user_id,
            is_active=True,
            organization__is_active=True,
        ).exists()

    @staticmethod
    def _organizations(user_id: int, organization_ids: list[int]) -> bool:
        found = set(
            OrganizationMembership.objects.filter(
                user_id=user_id,
                is_active=True,
                organization_id__in=organization_ids,
                organization__is_active=True,
            ).values_list("organization_id", flat=True)
        )
        return set(organization_ids) <= found

    @staticmethod
    def _companies(user_id: int, company_ids: list[int]) -> bool:
        rows = list(
            Company.objects.filter(pk__in=company_ids).annotate(
                allowed=Exists(OrganizationAccessService._membership(user_id)),
            ).values_list("pk", "allowed")
        )
        if not rows:
            return True
        return all(is_allowed for _, is_allowed in rows)

    @staticmethod
    def _branches(user_id: int, branch_ids: list[int]) -> bool:
        rows = list(
            Branch.objects.filter(pk__in=branch_ids).annotate(
                allowed=Exists(
                    OrganizationMembership.objects.filter(
                        user_id=user_id,
                        is_active=True,
                        organization__is_active=True,
                        organization_id=OuterRef("company__organization_id"),
                    )
                ),
            ).values_list("pk", "allowed")
        )
        if not rows:
            return True
        return all(is_allowed for _, is_allowed in rows)

    @staticmethod
    def _membership(user_id: int):
        return OrganizationMembership.objects.filter(
            user_id=user_id,
            is_active=True,
            organization__is_active=True,
            organization_id=OuterRef("organization_id"),
        )

    @staticmethod
    def _ids(request, source: str, field: str) -> list[int]:
        if source == "query":
            raw = request.query_params.get(field)
            values = [raw] if raw else []
        else:
            data = getattr(request, "data", None) or {}
            raw = data.get(field)
            if isinstance(raw, (list, tuple)):
                values = list(raw)
            elif raw:
                values = [raw]
            else:
                values = []
        return OrganizationAccessService._decode(values, field)

    @staticmethod
    def _decode(values, field: str) -> list[int]:
        ids = []
        for raw in values:
            text = str(raw or "").strip()
            if not text:
                continue
            try:
                decoded = decode_id(text)
            except ValueError:
                raise ValidationError({field: ["Invalid id."]}) from None
            if not isinstance(decoded, int):
                raise ValidationError({field: ["Invalid id."]})
            ids.append(decoded)
        return ids
