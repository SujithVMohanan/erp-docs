from django.urls import path

from apps.inventory.views import (
    AdjustStockApiView,
    CreateProductApiView,
    DeleteProductsApiView,
    GetProductsApiView,
    GetStockApiView,
    GetStockDocumentsApiView,
    GetStockLedgerApiView,
    GetUnitsApiView,
    GetWarehousesApiView,
    ImportInventoryApiView,
    ReceiveStockApiView,
    TransferStockApiView,
    UpdateProductApiView,
    UpdateWarehouseApiView,
)

app_name = "inventory"

urlpatterns = [
    path("get-units/", GetUnitsApiView.as_view(), name="get-units"),
    path("get-products/", GetProductsApiView.as_view(), name="get-products"),
    path("create-product/", CreateProductApiView.as_view(), name="create-product"),
    path("update-product/", UpdateProductApiView.as_view(), name="update-product"),
    path("delete-products/", DeleteProductsApiView.as_view(), name="delete-products"),
    path("get-warehouses/", GetWarehousesApiView.as_view(), name="get-warehouses"),
    path("update-warehouse/", UpdateWarehouseApiView.as_view(), name="update-warehouse"),
    path("get-stock/", GetStockApiView.as_view(), name="get-stock"),
    path("get-stock-documents/", GetStockDocumentsApiView.as_view(), name="get-stock-documents"),
    path("get-stock-ledger/", GetStockLedgerApiView.as_view(), name="get-stock-ledger"),
    path("receive-stock/", ReceiveStockApiView.as_view(), name="receive-stock"),
    path("adjust-stock/", AdjustStockApiView.as_view(), name="adjust-stock"),
    path("transfer-stock/", TransferStockApiView.as_view(), name="transfer-stock"),
    path("import-inventory/", ImportInventoryApiView.as_view(), name="import-inventory"),
]
