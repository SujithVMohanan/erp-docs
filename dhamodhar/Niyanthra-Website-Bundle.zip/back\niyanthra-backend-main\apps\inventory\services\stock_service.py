from dataclasses import dataclass
from datetime import date
from decimal import Decimal, ROUND_HALF_UP

from django.db import IntegrityError, transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from apps.company.models import TaxRate
from apps.inventory.models import (
    Product,
    StockDocument,
    StockDocumentLine,
    StockLedger,
    StockSummary,
    Warehouse,
)
from apps.inventory.repository import InventoryRepository
from apps.inventory.services.scope import (
    decode_uid,
    workspace_context,
)
from apps.inventory.services.warehouse_service import WarehouseService
from apps.inventory.units import DEFAULT_UNIT, UNIT_CODES
from core.exceptions.auth import AuthValidationError
from core.tenant.context import require_current_tenant
from core.tenant.workspace import WorkspaceScope
from infrastructure.database.context import get_current_db_alias


_QUANT = Decimal("0.0001")
_ZERO = Decimal("0.0000")

_PREFIX = {
    StockDocument.DocType.OPENING: "OPN",
    StockDocument.DocType.RECEIPT: "RCP",
    StockDocument.DocType.ADJUSTMENT: "ADJ",
    StockDocument.DocType.TRANSFER: "TRF",
}

_AVERAGED = {
    StockDocument.DocType.OPENING,
    StockDocument.DocType.RECEIPT,
    StockDocument.DocType.ADJUSTMENT,
}


def money(value) -> Decimal:
    return Decimal(value).quantize(
        _QUANT,
        rounding=ROUND_HALF_UP,
    )


def name_key(value: str) -> str:
    return " ".join((value or "").split()).lower()


@dataclass
class PostLine:
    product_id: int
    warehouse_id: int
    quantity: Decimal
    direction: str
    unit_cost: Decimal
    movement: str
    average: bool


class StockError(AuthValidationError):
    pass


def _error(
    field: str,
    message: str,
    code: str,
) -> AuthValidationError:
    return AuthValidationError(
        {field: [message]},
        code=code,
    )


class StockService:

    @staticmethod
    def list_stock(
        *,
        scope: WorkspaceScope,
        validated_data: dict,
    ):
        product_id = None
        warehouse_id = None

        with workspace_context(scope):
            if validated_data.get("product_uid"):
                product_id = decode_uid(
                    validated_data["product_uid"],
                    field="product_uid",
                )

            if validated_data.get("warehouse_uid"):
                warehouse_id = decode_uid(
                    validated_data["warehouse_uid"],
                    field="warehouse_uid",
                )

            elif validated_data.get("branch_uid"):
                warehouse = StockService._warehouse(
                    scope,
                    branch_id=decode_uid(
                        validated_data["branch_uid"],
                        field="branch_uid",
                    ),
                    required=False,
                )
                warehouse_id = warehouse.pk if warehouse else -1

            return InventoryRepository.list_stock(
                product_id=product_id,
                warehouse_id=warehouse_id,
            )

    @staticmethod
    def list_documents(
        *,
        scope: WorkspaceScope,
        validated_data: dict,
    ):
        document_ids = None

        with workspace_context(scope):
            if validated_data.get("uid"):
                document_ids = [
                    decode_uid(
                        validated_data["uid"],
                        field="uid",
                    )
                ]

            return InventoryRepository.list_documents(
                document_ids=document_ids,
                doc_type=validated_data.get("doc_type"),
                doc_number=validated_data.get("doc_number"),
                date_from=validated_data.get("date_from"),
                date_to=validated_data.get("date_to"),
            )

    @staticmethod
    def list_ledger(
        *,
        scope: WorkspaceScope,
        validated_data: dict,
    ):
        product_id = None
        warehouse_id = None

        with workspace_context(scope):
            if validated_data.get("product_uid"):
                product_id = decode_uid(
                    validated_data["product_uid"],
                    field="product_uid",
                )

            if validated_data.get("warehouse_uid"):
                warehouse_id = decode_uid(
                    validated_data["warehouse_uid"],
                    field="warehouse_uid",
                )

            return InventoryRepository.list_ledger(
                product_id=product_id,
                warehouse_id=warehouse_id,
                doc_type=validated_data.get("doc_type"),
                date_from=validated_data.get("date_from"),
                date_to=validated_data.get("date_to"),
            )

    @staticmethod
    def receive(
        *,
        scope: WorkspaceScope,
        validated_data: dict,
    ) -> StockDocument:
        with workspace_context(scope):
            warehouse = StockService.resolve_warehouse(
                scope,
                branch_uid=validated_data.get("branch_uid"),
            )

            payload = StockService._with_product_ids(
                validated_data["lines"]
            )
            products = StockService._products_for_lines(payload)

            lines = StockService._inbound_lines(
                payload,
                products=products,
                warehouse_id=warehouse.pk,
                movement=StockLedger.Movement.RECEIPT,
                average=True,
            )

            return StockService.post(
                doc_type=StockDocument.DocType.RECEIPT,
                warehouse=warehouse,
                lines=lines,
                products=products,
                client_ref=validated_data.get("client_ref"),
                notes=validated_data.get("notes") or "",
            )

    @staticmethod
    def adjust(
        *,
        scope: WorkspaceScope,
        validated_data: dict,
    ) -> StockDocument:
        with workspace_context(scope):
            warehouse = StockService.resolve_warehouse(
                scope,
                branch_uid=validated_data.get("branch_uid"),
            )

            payload = StockService._with_product_ids(
                validated_data["lines"]
            )
            products = StockService._products_for_lines(payload)

            specs = []

            for line in payload:
                product = products[line["product_id"]]
                quantity = money(line["quantity"])

                if quantity == 0:
                    continue

                direction = (
                    StockDocumentLine.Direction.IN
                    if quantity > 0
                    else StockDocumentLine.Direction.OUT
                )

                specs.append(
                    PostLine(
                        product_id=product.pk,
                        warehouse_id=warehouse.pk,
                        quantity=abs(quantity),
                        direction=direction,
                        unit_cost=product.cost_price,
                        movement=StockLedger.Movement.ADJUSTMENT,
                        average=quantity > 0,
                    )
                )

            if not specs:
                raise _error(
                    "lines",
                    "Enter a quantity.",
                    "INSUFFICIENT_STOCK",
                )

            return StockService.post(
                doc_type=StockDocument.DocType.ADJUSTMENT,
                warehouse=warehouse,
                lines=specs,
                products=products,
                client_ref=validated_data.get("client_ref"),
                notes=validated_data.get("notes") or "",
            )

    @staticmethod
    def transfer(
        *,
        scope: WorkspaceScope,
        validated_data: dict,
    ) -> StockDocument:
        with workspace_context(scope):
            source = StockService.resolve_warehouse(
                scope,
                branch_uid=validated_data.get("branch_uid"),
            )

            destination = StockService.resolve_warehouse(
                scope,
                branch_uid=validated_data["to_branch_uid"],
            )

            if source.pk == destination.pk:
                raise _error(
                    "to_branch_uid",
                    "Choose a different branch.",
                    "WAREHOUSE_NOT_FOUND",
                )

            payload = StockService._with_product_ids(
                validated_data["lines"]
            )
            products = StockService._products_for_lines(payload)

            specs = []

            for line in payload:
                product = products[line["product_id"]]
                quantity = money(line["quantity"])
                cost = product.cost_price

                specs.append(
                    PostLine(
                        product_id=product.pk,
                        warehouse_id=source.pk,
                        quantity=quantity,
                        direction=StockDocumentLine.Direction.OUT,
                        unit_cost=cost,
                        movement=StockLedger.Movement.TRANSFER_OUT,
                        average=False,
                    )
                )

                specs.append(
                    PostLine(
                        product_id=product.pk,
                        warehouse_id=destination.pk,
                        quantity=quantity,
                        direction=StockDocumentLine.Direction.IN,
                        unit_cost=cost,
                        movement=StockLedger.Movement.TRANSFER_IN,
                        average=False,
                    )
                )

            return StockService.post(
                doc_type=StockDocument.DocType.TRANSFER,
                warehouse=source,
                to_warehouse=destination,
                lines=specs,
                products=products,
                client_ref=validated_data.get("client_ref"),
                notes=validated_data.get("notes") or "",
            )

    @staticmethod
    def post_opening(
        *,
        warehouse: Warehouse,
        lines: list[PostLine],
        notes: str = "",
        client_ref: str | None = None,
        products: dict | None = None,
    ) -> StockDocument | None:
        if not lines:
            return None

        return StockService.post(
            doc_type=StockDocument.DocType.OPENING,
            warehouse=warehouse,
            lines=lines,
            notes=notes,
            client_ref=client_ref,
            products=products,
        )

    @staticmethod
    def post(
        *,
        doc_type: str,
        warehouse: Warehouse,
        lines: list[PostLine],
        to_warehouse: Warehouse | None = None,
        client_ref: str | None = None,
        notes: str = "",
        doc_date: date | None = None,
        products: dict | None = None,
    ) -> StockDocument:
        alias = get_current_db_alias()

        if not alias:
            raise ValidationError(
                {"detail": ["Tenant database is not selected."]}
            )

        client_ref = (client_ref or "").strip() or None
        last_error = None

        for _attempt in range(3):
            try:
                with transaction.atomic(using=alias):
                    if client_ref:
                        existing = (
                            InventoryRepository
                            .document_by_client_ref(client_ref)
                        )

                        if existing is not None:
                            existing._replayed = True
                            return existing

                    document = StockService._write_document(
                        doc_type=doc_type,
                        warehouse=warehouse,
                        to_warehouse=to_warehouse,
                        lines=lines,
                        products=products,
                        client_ref=client_ref,
                        notes=notes,
                        doc_date=doc_date or timezone.localdate(),
                    )

                    document._replayed = False
                    return document

            except IntegrityError as exc:
                last_error = exc

                if client_ref:
                    existing = (
                        InventoryRepository
                        .document_by_client_ref(client_ref)
                    )

                    if existing is not None:
                        existing._replayed = True
                        return existing

        raise _error(
            "doc_number",
            "Stock document could not be posted.",
            "INSUFFICIENT_STOCK",
        ) from last_error

    @staticmethod
    def reserve(
        *,
        scope: WorkspaceScope,
        warehouse: Warehouse,
        product: Product,
        quantity,
    ) -> None:
        StockService._reserved_delta(
            scope=scope,
            warehouse=warehouse,
            product=product,
            quantity=money(quantity),
            movement=StockLedger.Movement.RESERVE,
        )

    @staticmethod
    def release(
        *,
        scope: WorkspaceScope,
        warehouse: Warehouse,
        product: Product,
        quantity,
    ) -> None:
        StockService._reserved_delta(
            scope=scope,
            warehouse=warehouse,
            product=product,
            quantity=-money(quantity),
            movement=StockLedger.Movement.RELEASE,
        )

    @staticmethod
    def issue(
        *,
        scope: WorkspaceScope,
        warehouse: Warehouse,
        product: Product,
        quantity,
    ) -> None:
        quantity = money(quantity)
        alias = get_current_db_alias()

        with workspace_context(scope):
            with transaction.atomic(using=alias):
                summary = StockService._lock_one(
                    warehouse.pk,
                    product.pk,
                )

                if (
                    summary.qty_reserved < quantity
                    or summary.qty_on_hand < quantity
                ):
                    raise _error(
                        "quantity",
                        "Not enough stock.",
                        "INSUFFICIENT_STOCK",
                    )

                summary.qty_reserved = money(
                    summary.qty_reserved - quantity
                )
                summary.qty_on_hand = money(
                    summary.qty_on_hand - quantity
                )
                summary.updated_at = timezone.now()

                summary.save(
                    update_fields=[
                        "qty_reserved",
                        "qty_on_hand",
                        "updated_at",
                    ]
                )

                StockLedger.objects.create(
                    company_id=scope.company_id,
                    product_id=product.pk,
                    warehouse_id=warehouse.pk,
                    movement=StockLedger.Movement.ISSUE,
                    qty_delta=-quantity,
                    qty_on_hand_after=summary.qty_on_hand,
                    unit_cost=product.cost_price,
                    occurred_at=timezone.now(),
                )

    @staticmethod
    def resolve_warehouse(
        scope: WorkspaceScope,
        *,
        branch_uid: str | None,
    ) -> Warehouse:
        branch_id = None

        if branch_uid:
            branch_id = decode_uid(
                branch_uid,
                field="branch_uid",
            )

        warehouse = StockService._warehouse(
            scope,
            branch_id=branch_id,
            required=True,
        )

        if warehouse.status != "ACTIVE":
            raise _error(
                "branch_uid",
                "Warehouse is inactive.",
                "WAREHOUSE_NOT_FOUND",
            )

        return warehouse

    @staticmethod
    def opening_line(
        *,
        product: Product,
        warehouse_id: int,
        quantity,
        unit_cost,
    ) -> PostLine:
        cost = money(
            unit_cost
            if unit_cost is not None
            else product.cost_price
        )

        return PostLine(
            product_id=product.pk,
            warehouse_id=warehouse_id,
            quantity=money(quantity),
            direction=StockDocumentLine.Direction.IN,
            unit_cost=cost,
            movement=StockLedger.Movement.OPENING,
            average=True,
        )

    @staticmethod
    def _warehouse(
        scope: WorkspaceScope,
        *,
        branch_id: int | None,
        required: bool,
    ):
        if branch_id is None:
            branch_id = scope.branch_id

        if branch_id is None:
            branch_ids = InventoryRepository.active_branch_ids(
                scope.company_id
            )

            if len(branch_ids) != 1:
                if required:
                    raise _error(
                        "branch_uid",
                        "Select a branch.",
                        "BRANCH_REQUIRED",
                    )

                return None

            branch_id = branch_ids[0]

        elif (
            branch_id != scope.branch_id
            and not InventoryRepository.branch_in_company(
                branch_id=branch_id,
                company_id=scope.company_id,
            )
        ):
            raise _error(
                "branch_uid",
                "Warehouse not found.",
                "WAREHOUSE_NOT_FOUND",
            )

        warehouse = InventoryRepository.warehouse_for_branch(
            branch_id
        )

        if warehouse is None:
            WarehouseService.sync_current()
            warehouse = InventoryRepository.warehouse_for_branch(
                branch_id
            )

        if warehouse is None and required:
            raise _error(
                "branch_uid",
                "Warehouse not found.",
                "WAREHOUSE_NOT_FOUND",
            )

        return warehouse

    @staticmethod
    def _with_product_ids(
        lines: list[dict],
    ) -> list[dict]:
        decoded = []
        seen = set()

        for line in lines:
            item = dict(line)
            product_id = item.get("product_id")

            if product_id is None:
                product_id = decode_uid(
                    item["product_uid"],
                    field="product_uid",
                )
                item["product_id"] = product_id

            if product_id in seen:
                raise _error(
                    "product_uid",
                    "This product is repeated.",
                    "PRODUCT_NOT_FOUND",
                )

            seen.add(product_id)
            decoded.append(item)

        return decoded

    @staticmethod
    def _products_for_lines(
        lines: list[dict],
    ) -> dict[int, Product]:
        product_ids = [
            line["product_id"]
            for line in lines
        ]

        products = InventoryRepository.products_by_ids(
            product_ids
        )

        missing = [
            product_id
            for product_id in product_ids
            if product_id not in products
        ]

        if missing:
            raise _error(
                "product_uid",
                "Product not found.",
                "PRODUCT_NOT_FOUND",
            )

        for product in products.values():
            if not product.is_active:
                raise _error(
                    "product_uid",
                    "Product is inactive.",
                    "PRODUCT_NOT_FOUND",
                )

            if not product.track_stock:
                raise _error(
                    "product_uid",
                    "This product does not track stock.",
                    "STOCK_NOT_TRACKED",
                )

        return products

    @staticmethod
    def _inbound_lines(
        lines,
        *,
        products,
        warehouse_id: int,
        movement: str,
        average: bool,
    ) -> list[PostLine]:
        specs = []

        for line in lines:
            product = products[line["product_id"]]
            cost = line.get("unit_cost")

            specs.append(
                PostLine(
                    product_id=product.pk,
                    warehouse_id=warehouse_id,
                    quantity=money(line["quantity"]),
                    direction=StockDocumentLine.Direction.IN,
                    unit_cost=money(
                        cost
                        if cost is not None
                        else product.cost_price
                    ),
                    movement=movement,
                    average=average,
                )
            )

        return specs

    @staticmethod
    def _write_document(
        *,
        doc_type,
        warehouse,
        to_warehouse,
        lines,
        products,
        client_ref,
        notes,
        doc_date,
    ) -> StockDocument:
        identity = require_current_tenant()

        if products is None:
            products = InventoryRepository.products_by_ids(
                list(
                    {
                        line.product_id
                        for line in lines
                    }
                )
            )

        pairs = [
            (line.warehouse_id, line.product_id)
            for line in lines
        ]

        summaries = StockService._lock_summaries(
            pairs,
            company_id=identity.company_id,
        )

        now = timezone.now()
        ledger_rows = []
        line_rows = []
        changed_summaries = {}
        changed_products = {}

        ordered_lines = sorted(
            lines,
            key=lambda line: (
                line.product_id,
                line.warehouse_id,
            ),
        )

        for spec in ordered_lines:
            product = products.get(spec.product_id)

            if (
                product is None
                or not product.track_stock
                or not product.is_active
            ):
                raise _error(
                    "product_uid",
                    "Product not found.",
                    "PRODUCT_NOT_FOUND",
                )

            summary = summaries[
                (spec.warehouse_id, spec.product_id)
            ]

            delta = (
                spec.quantity
                if spec.direction == StockDocumentLine.Direction.IN
                else -spec.quantity
            )

            new_quantity = money(
                summary.qty_on_hand + delta
            )

            if new_quantity < 0:
                raise _error(
                    "quantity",
                    "Not enough stock.",
                    "INSUFFICIENT_STOCK",
                )

            if (
                spec.average
                and spec.direction == StockDocumentLine.Direction.IN
                and doc_type in _AVERAGED
                and new_quantity > 0
            ):
                product.cost_price = money(
                    (
                        (
                            summary.qty_on_hand
                            * product.cost_price
                        )
                        + (
                            spec.quantity
                            * spec.unit_cost
                        )
                    )
                    / new_quantity
                )

                product.updated_at = now
                changed_products[product.pk] = product

            summary.qty_on_hand = new_quantity
            summary.updated_at = now

            changed_summaries[
                summary.pk
                or (spec.warehouse_id, spec.product_id)
            ] = summary

            ledger_rows.append(
                {
                    "spec": spec,
                    "qty_delta": delta,
                    "qty_on_hand_after": new_quantity,
                }
            )

        document = StockDocument.objects.create(
            company_id=identity.company_id,
            doc_type=doc_type,
            doc_number=InventoryRepository.next_doc_number(
                doc_type,
                _PREFIX[doc_type],
            ),
            client_ref=client_ref,
            doc_date=doc_date,
            status=StockDocument.Status.POSTED,
            warehouse=warehouse,
            to_warehouse=to_warehouse,
            notes=notes or "",
        )

        for spec in lines:
            line_rows.append(
                StockDocumentLine(
                    company_id=identity.company_id,
                    document=document,
                    product_id=spec.product_id,
                    quantity=spec.quantity,
                    direction=spec.direction,
                    unit_cost=spec.unit_cost,
                )
            )

        StockDocumentLine.objects.bulk_create(
            line_rows,
            batch_size=500,
        )

        for line in line_rows:
            line.product = products[line.product_id]

        document._prefetched_objects_cache = {
            "lines": line_rows
        }

        StockLedger.objects.bulk_create(
            [
                StockLedger(
                    company_id=identity.company_id,
                    product_id=row["spec"].product_id,
                    warehouse_id=row["spec"].warehouse_id,
                    document=document,
                    movement=row["spec"].movement,
                    qty_delta=row["qty_delta"],
                    qty_on_hand_after=row["qty_on_hand_after"],
                    unit_cost=row["spec"].unit_cost,
                    occurred_at=now,
                )
                for row in ledger_rows
            ],
            batch_size=500,
        )

        if changed_summaries:
            StockSummary.objects.bulk_update(
                list(changed_summaries.values()),
                [
                    "qty_on_hand",
                    "updated_at",
                ],
                batch_size=500,
            )

        if changed_products:
            Product.objects.bulk_update(
                list(changed_products.values()),
                [
                    "cost_price",
                    "updated_at",
                ],
                batch_size=500,
            )

        return document

    @staticmethod
    def _lock_summaries(
        pairs,
        *,
        company_id: int,
    ) -> dict[tuple[int, int], StockSummary]:
        unique_pairs = list(dict.fromkeys(pairs))

        warehouse_ids = {
            warehouse_id
            for warehouse_id, _ in unique_pairs
        }

        product_ids = {
            product_id
            for _, product_id in unique_pairs
        }

        found = {
            (row.warehouse_id, row.product_id): row
            for row in (
                StockSummary.objects
                .filter(
                    warehouse_id__in=warehouse_ids,
                    product_id__in=product_ids,
                )
                .select_for_update()
                .order_by(
                    "product_id",
                    "warehouse_id",
                )
            )
        }

        missing = [
            StockSummary(
                company_id=company_id,
                warehouse_id=warehouse_id,
                product_id=product_id,
                qty_on_hand=_ZERO,
                qty_reserved=_ZERO,
            )
            for warehouse_id, product_id in unique_pairs
            if (warehouse_id, product_id) not in found
        ]

        if missing:
            StockSummary.objects.bulk_create(
                missing,
                batch_size=500,
            )

            found = {
                (row.warehouse_id, row.product_id): row
                for row in (
                    StockSummary.objects
                    .filter(
                        warehouse_id__in=warehouse_ids,
                        product_id__in=product_ids,
                    )
                    .select_for_update()
                    .order_by(
                        "product_id",
                        "warehouse_id",
                    )
                )
            }

        return found

    @staticmethod
    def _lock_one(
        warehouse_id: int,
        product_id: int,
    ) -> StockSummary:
        identity = require_current_tenant()

        summaries = StockService._lock_summaries(
            [(warehouse_id, product_id)],
            company_id=identity.company_id,
        )

        return summaries[
            (warehouse_id, product_id)
        ]

    @staticmethod
    def _reserved_delta(
        *,
        scope,
        warehouse,
        product,
        quantity: Decimal,
        movement: str,
    ) -> None:
        alias = get_current_db_alias()

        with workspace_context(scope):
            with transaction.atomic(using=alias):
                summary = StockService._lock_one(
                    warehouse.pk,
                    product.pk,
                )

                new_reserved = money(
                    summary.qty_reserved + quantity
                )

                if (
                    new_reserved < 0
                    or (
                        summary.qty_on_hand
                        - new_reserved
                    ) < 0
                ):
                    raise _error(
                        "quantity",
                        "Not enough stock.",
                        "INSUFFICIENT_STOCK",
                    )

                summary.qty_reserved = new_reserved
                summary.updated_at = timezone.now()

                summary.save(
                    update_fields=[
                        "qty_reserved",
                        "updated_at",
                    ]
                )

                StockLedger.objects.create(
                    company_id=scope.company_id,
                    product_id=product.pk,
                    warehouse_id=warehouse.pk,
                    movement=movement,
                    qty_delta=quantity,
                    qty_on_hand_after=summary.qty_on_hand,
                    unit_cost=product.cost_price,
                    occurred_at=timezone.now(),
                )


def tax_snapshot(
    tax_rate_id: int | None,
) -> tuple[int | None, Decimal]:
    if not tax_rate_id:
        return None, _ZERO

    rate = (
        TaxRate.objects
        .filter(pk=tax_rate_id)
        .only("id", "rate")
        .first()
    )

    if rate is None:
        raise _error(
            "tax_rate_uid",
            "Tax rate not found.",
            "TAX_RATE_NOT_FOUND",
        )

    return rate.pk, money(rate.rate or 0)


def normalize_unit(value: str | None) -> str:
    code = (
        (value or DEFAULT_UNIT).strip().upper()
        or DEFAULT_UNIT
    )

    if code not in UNIT_CODES:
        raise _error(
            "uom_code",
            "Unknown unit.",
            "VALIDATION_ERROR",
        )

    return code


def company_code(company_id: int) -> str:
    from apps.company.models import Company

    code = (
        Company.objects
        .filter(pk=company_id)
        .values_list("code", flat=True)
        .first()
        or "SKU"
    )

    return str(code).strip().upper() or "SKU"


def next_sku(
    company_code_value: str,
    taken: set[str],
) -> str:
    prefix = f"{company_code_value}-"
    sequence = 0

    for sku in taken:
        if not sku.startswith(prefix):
            continue

        suffix = sku[len(prefix):]

        if suffix.isdigit():
            sequence = max(
                sequence,
                int(suffix),
            )

    while True:
        sequence += 1
        sku = f"{prefix}{sequence:05d}"

        if sku not in taken:
            taken.add(sku)
            return sku