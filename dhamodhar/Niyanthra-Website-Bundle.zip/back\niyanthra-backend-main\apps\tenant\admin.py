from django.contrib import admin

from .models import Tenant, TenantDatabase


@admin.register(Tenant)
class TenantAdmin(admin.ModelAdmin):
	list_display = ("name", "slug", "tenant_type", "db_alias", "is_active", "deleted_at")
	list_filter = ("tenant_type", "is_active")
	search_fields = ("name", "slug", "db_alias", "celery_queue")


@admin.register(TenantDatabase)
class TenantDatabaseAdmin(admin.ModelAdmin):
	list_display = ("tenant", "period", "db_alias", "is_active", "is_current", "deleted_at")
	list_filter = ("is_active", "is_current")
	search_fields = ("tenant__name", "tenant__slug", "period", "db_alias")
