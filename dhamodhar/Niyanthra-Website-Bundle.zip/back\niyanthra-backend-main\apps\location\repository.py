from django.db.models import (
    BooleanField,
    Case,
    Q,
    Value,
    When,
)
from django.utils import timezone

from apps.location.models import (
    Country,
    Location,
    State,
)


class StateRepository:

    @staticmethod
    def upsert(
        *,
        public_id,
        country: Country,
        code: str,
        name: str,
        is_active: bool = True,
    ) -> tuple[State, bool]:
        normalized_code = code.strip().upper()
        state = State.all_objects.filter(
            country_id=country.pk,
            code=normalized_code,
        ).first()
        if state is None:
            state = State(
                public_id=public_id,
                country=country,
                code=normalized_code,
                name=name,
                is_active=is_active,
            )
            state.save()
            return state, True

        state.name = name
        state.is_active = is_active
        state.deleted_at = None
        state.save(
            update_fields=[
                "name",
                "is_active",
                "deleted_at",
                "updated_at",
            ]
        )
        return state, False

    @staticmethod
    def _base_queryset():
        return (
            State.objects
            .select_related("country")
            .only(
                "id",
                "public_id",
                "name",
                "code",
                "is_active",
                "created_at",
                "updated_at",
                "country_id",
                "country__id",
                "country__public_id",
                "country__name",
                "country__code",
            )
        )

    @staticmethod
    def list_states(
        *,
        state_id=None,
        country_id=None,
        code=None,
        name=None,
        is_active=None,
    ):
        filters = Q()

        if state_id is not None:
            ids = (
                state_id
                if isinstance(state_id, (list, tuple, set))
                else [state_id]
            )
            filters &= Q(id__in=ids)

        if country_id is not None:
            filters &= Q(country_id=country_id)

        if code:
            filters &= Q(code=code.strip().upper())

        if name:
            filters &= Q(name__icontains=name)

        if is_active is not None:
            filters &= Q(is_active=is_active)

        return StateRepository._base_queryset().filter(filters)

    @staticmethod
    def get_by_id(state_id: int) -> State | None:
        return StateRepository._base_queryset().filter(pk=state_id).first()

    @staticmethod
    def get_code_conflict(
        *,
        country_id: int,
        code: str,
        exclude_id: int | None = None,
    ) -> State | None:
        queryset = State.objects.filter(
            country_id=country_id,
            code=code.strip().upper(),
        )
        if exclude_id is not None:
            queryset = queryset.exclude(pk=exclude_id)
        return queryset.first()

    @staticmethod
    def create_state(
        *,
        country_id: int,
        name: str,
        code: str,
        is_active: bool = True,
    ) -> State:
        return State.objects.create(
            country_id=country_id,
            name=name,
            code=code.strip().upper(),
            is_active=is_active,
        )

    @staticmethod
    def update_state(
        *,
        state: State,
        country_id: int,
        name: str,
        code: str,
        is_active: bool,
    ) -> State:
        state.country_id = country_id
        state.name = name
        state.code = code.strip().upper()
        state.is_active = is_active
        state.save(
            update_fields=[
                "country_id",
                "name",
                "code",
                "is_active",
                "updated_at",
            ]
        )
        return state

    @staticmethod
    def soft_delete_by_ids(state_ids: list[int]) -> int:
        if not state_ids:
            return 0
        count, _ = State.objects.filter(id__in=state_ids).delete()
        return count

    @staticmethod
    def toggle_active_by_ids(state_ids: list[int]) -> int:
        if not state_ids:
            return 0
        return State.objects.filter(id__in=state_ids).update(
            is_active=Case(
                When(is_active=True, then=Value(False)),
                default=Value(True),
                output_field=BooleanField(),
            ),
            updated_at=timezone.now(),
        )


class LocationRepository:

    @staticmethod
    def _base_queryset():
        return (
            Location.objects
            .select_related("country", "state")
            .only(
                "id",
                "public_id",
                "city",
                "postal_code",
                "address_line_1",
                "address_line_2",
                "latitude",
                "longitude",
                "place_id",
                "formatted_address",
                "created_at",
                "updated_at",
                "country_id",
                "country__id",
                "country__public_id",
                "country__name",
                "country__code",
                "state_id",
                "state__id",
                "state__public_id",
                "state__name",
                "state__code",
            )
        )

    @staticmethod
    def list_locations(
        *,
        location_id=None,
        country_id=None,
        state_id=None,
        city=None,
    ):
        filters = Q()

        if location_id is not None:
            ids = (
                location_id
                if isinstance(location_id, (list, tuple, set))
                else [location_id]
            )
            filters &= Q(id__in=ids)

        if country_id is not None:
            filters &= Q(country_id=country_id)

        if state_id is not None:
            filters &= Q(state_id=state_id)

        if city:
            filters &= Q(city__icontains=city)

        return LocationRepository._base_queryset().filter(filters)

    @staticmethod
    def get_by_id(location_id: int) -> Location | None:
        return (
            LocationRepository
            ._base_queryset()
            .filter(pk=location_id)
            .first()
        )

    @staticmethod
    def create_location(**fields) -> Location:
        return Location.objects.create(**fields)

    @staticmethod
    def update_location(*, location: Location, **fields) -> Location:
        for key, value in fields.items():
            setattr(location, key, value)
        update_fields = list(fields.keys()) + ["updated_at"]
        location.save(update_fields=update_fields)
        return location

    @staticmethod
    def delete_by_ids(location_ids: list[int]) -> int:
        if not location_ids:
            return 0
        count, _ = Location.objects.filter(id__in=location_ids).delete()
        return count
