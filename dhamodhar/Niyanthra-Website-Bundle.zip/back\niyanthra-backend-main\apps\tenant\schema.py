from rest_framework import serializers

from apps.tenant.models import Tenant
from core.utils.ids import encode_id


class GetTenantsApiSchema(serializers.ModelSerializer):
    uid                 = serializers.SerializerMethodField()
    is_ready            = serializers.SerializerMethodField()
    provisioning_status = serializers.CharField(read_only=True)
    provisioned_at      = serializers.DateTimeField(read_only=True, allow_null=True)

    class Meta:
        model = Tenant
        fields = [
            "uid",
            "public_id",
            "name",
            "slug",
            "tenant_type",
            "provisioning_status",
            "db_alias",
            "celery_queue",
            "is_active",
            "is_ready",
            "provisioned_at",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_is_ready(self, instance) -> bool:
        return instance.is_ready

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data
