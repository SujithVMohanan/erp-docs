from datetime import date
from decimal import Decimal

from django.db.models import Q
from django.conf import settings
from django.test import TestCase

from apps.sales.models import Sale
from core.tenant import (
    TenantContextError,
    clear_current_tenant,
    tenant_context,
)
from infrastructure.database.context import (
    clear_current_db_alias,
    set_current_db_alias,
)
from core.utils.ids import encode_id


class TenantAwareManagerTests(TestCase):

    databases = {"default", settings.SHARED_DB_ALIAS}

    def setUp(self):
        set_current_db_alias(settings.SHARED_DB_ALIAS)

    def tearDown(self):
        clear_current_tenant()
        clear_current_db_alias()

    def _create_via_unscoped(self, *, tenant_id, company_id, invoice):
        return Sale.all_objects.create(
            tenant_id=tenant_id,
            company_id=company_id,
            invoice_number=invoice,
            customer_name="Buyer",
            sale_date=date(2026, 1, 1),
            subtotal=Decimal("10.00"),
            tax_amount=Decimal("0.00"),
            discount_amount=Decimal("0.00"),
            total_amount=Decimal("10.00"),
        )

    def test_fail_closed_without_context(self):
        with self.assertRaises(TenantContextError):
            list(Sale.objects.all())

        with self.assertRaises(TenantContextError):
            Sale.objects.create(
                invoice_number="X",
                customer_name="Y",
                sale_date=date(2026, 1, 1),
                subtotal=Decimal("1.00"),
                total_amount=Decimal("1.00"),
            )

    def test_all_objects_unscoped(self):
        self._create_via_unscoped(
            tenant_id=1,
            company_id=10,
            invoice="U1",
        )
        self._create_via_unscoped(
            tenant_id=2,
            company_id=20,
            invoice="U2",
        )
        self.assertEqual(Sale.all_objects.count(), 2)

    def test_objects_auto_scopes_and_stamps(self):
        with tenant_context(tenant_id=1, company_id=10):
            sale = Sale.objects.create(
                invoice_number="T1",
                customer_name="A",
                sale_date=date(2026, 2, 1),
                subtotal=Decimal("5.00"),
                total_amount=Decimal("5.00"),
            )
            self.assertEqual(sale.tenant_id, 1)
            self.assertEqual(sale.company_id, 10)
            self.assertEqual(Sale.objects.count(), 1)

        with tenant_context(tenant_id=2, company_id=20):
            self.assertEqual(Sale.objects.count(), 0)

    def test_rejects_cross_tenant_filter(self):
        self._create_via_unscoped(
            tenant_id=1,
            company_id=10,
            invoice="F1",
        )
        with tenant_context(tenant_id=1, company_id=10):
            with self.assertRaises(TenantContextError):
                list(Sale.objects.filter(tenant_id=2))

            with self.assertRaises(TenantContextError):
                list(Sale.objects.filter(Q(tenant_id=2)))

    def test_rejects_cross_tenant_create(self):
        with tenant_context(tenant_id=1, company_id=10):
            with self.assertRaises(TenantContextError):
                Sale.objects.create(
                    tenant_id=2,
                    company_id=10,
                    invoice_number="BAD",
                    customer_name="X",
                    sale_date=date(2026, 1, 1),
                    subtotal=Decimal("1.00"),
                    total_amount=Decimal("1.00"),
                )

    def test_update_and_delete_scoped(self):
        foreign = self._create_via_unscoped(
            tenant_id=2,
            company_id=20,
            invoice="FOREIGN",
        )
        with tenant_context(tenant_id=1, company_id=10):
            Sale.objects.create(
                invoice_number="OWN",
                customer_name="A",
                sale_date=date(2026, 1, 1),
                subtotal=Decimal("1.00"),
                total_amount=Decimal("1.00"),
            )
            updated = Sale.objects.filter(
                invoice_number="OWN",
            ).update(customer_name="B")
            self.assertEqual(updated, 1)

            deleted, _ = Sale.objects.filter(
                invoice_number="OWN",
            ).delete()
            self.assertEqual(deleted, 1)

            self.assertEqual(
                Sale.objects.filter(pk=foreign.pk).count(),
                0,
            )

        self.assertTrue(
            Sale.all_objects.filter(pk=foreign.pk).exists()
        )

    def test_bulk_create_stamps_tenant(self):
        with tenant_context(tenant_id=5, company_id=50):
            Sale.objects.bulk_create(
                [
                    Sale(
                        invoice_number="B1",
                        customer_name="C",
                        sale_date=date(2026, 1, 1),
                        subtotal=Decimal("1.00"),
                        total_amount=Decimal("1.00"),
                    ),
                    Sale(
                        invoice_number="B2",
                        customer_name="C",
                        sale_date=date(2026, 1, 2),
                        subtotal=Decimal("2.00"),
                        total_amount=Decimal("2.00"),
                    ),
                ]
            )
            self.assertEqual(Sale.objects.count(), 2)
            self.assertTrue(
                all(s.tenant_id == 5 for s in Sale.objects.all())
            )

    def test_tenant_context_from_uid(self):
        uid = encode_id(99)
        with tenant_context(tenant_uid=uid, company_id=9):
            sale = Sale.objects.create(
                invoice_number="UID-1",
                customer_name="Z",
                sale_date=date(2026, 1, 1),
                subtotal=Decimal("1.00"),
                total_amount=Decimal("1.00"),
            )
            self.assertEqual(sale.tenant_id, 99)

    def test_instance_delete_rejects_foreign(self):
        foreign = self._create_via_unscoped(
            tenant_id=2,
            company_id=20,
            invoice="INST",
        )
        with tenant_context(tenant_id=1, company_id=10):
            with self.assertRaises(TenantContextError):
                foreign.delete()
