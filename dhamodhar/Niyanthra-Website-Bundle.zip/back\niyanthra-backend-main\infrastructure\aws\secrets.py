import json

import boto3
from django.conf import settings


class SecretsManagerClient:

    def __init__(self):
        kwargs = {
            "region_name": getattr(settings, "AWS_REGION", "ap-south-1"),
        }
        access_key = getattr(settings, "AWS_ACCESS_KEY_ID", "") or ""
        secret_key = getattr(settings, "AWS_SECRET_ACCESS_KEY", "") or ""

        if access_key and secret_key:
            kwargs["aws_access_key_id"] = access_key
            kwargs["aws_secret_access_key"] = secret_key

        self._client = boto3.client("secretsmanager", **kwargs)

    def get_secret_string(self, *, secret_id: str) -> str:
        response = self._client.get_secret_value(SecretId=secret_id)
        value = response.get("SecretString")

        if not value:
            raise ValueError(f"Secret '{secret_id}' has no SecretString.")

        return value

    def get_secret_dict(self, *, secret_id: str) -> dict:
        raw = self.get_secret_string(secret_id=secret_id)

        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"Secret '{secret_id}' is not valid JSON."
            ) from exc

        if not isinstance(data, dict):
            raise ValueError(f"Secret '{secret_id}' must be a JSON object.")

        return data
