from django.db.models import (
    BooleanField,
    Case,
    CharField,
    Count,
    Exists,
    IntegerField,
    OuterRef,
    Q,
    Subquery,
    Value,
    When,
)
from django.db.models.functions import Coalesce
from django.utils import timezone

from apps.company.models import (
    Branch,
    BranchMembership,
    BusinessType,
    Company,
    CompanyMembership,
    CompanyType,
)


class CompanyRepository:

    @staticmethod
    def _base_queryset():
        return (
            Company.objects
            .select_related(
                "organization",
                "timezone",
                "company_type",
            )
            .only(
                "id",
                "public_id",
                "name",
                "code",
                "legal_name",
                "is_active",
                "website",
                "logo",
                "registration_number",
                "created_at",
                "updated_at",
                "organization_id",
                "organization__id",
                "organization__public_id",
                "organization__name",
                "organization__code",
                "timezone_id",
                "timezone__id",
                "timezone__public_id",
                "timezone__name",
                "timezone__code",
                "timezone__utc_offset",
                "company_type_id",
                "company_type__id",
                "company_type__public_id",
                "company_type__name",
                "company_type__code",
            )
        )

    @staticmethod
    def list_companies(
        *,
        company_id=None,
        organization_id=None,
        code=None,
        name=None,
        is_active=None,
    ):
        queryset = CompanyRepository._base_queryset()

        if company_id is not None:
            company_ids = (
                company_id
                if isinstance(company_id, (list, tuple, set))
                else [company_id]
            )
            queryset = queryset.filter(id__in=company_ids)

        if organization_id is not None:
            queryset = queryset.filter(
                organization_id=organization_id
            )

        if code:
            queryset = queryset.filter(
                code=code.strip().upper()
            )

        if name:
            queryset = queryset.filter(
                name__icontains=name.strip()
            )

        if is_active is not None:
            queryset = queryset.filter(
                is_active=is_active
            )

        return queryset

    @staticmethod
    def get_by_id(company_id: int) -> Company | None:
        return (
            CompanyRepository
            ._base_queryset()
            .filter(pk=company_id)
            .first()
        )

    @staticmethod
    def get_code_conflict(
        *,
        code: str,
        organization_id: int,
        exclude_id: int | None = None,
    ) -> Company | None:
        queryset = Company.objects.filter(
            code=code.strip().upper(),
            organization_id=organization_id,
        )

        if exclude_id is not None:
            queryset = queryset.exclude(pk=exclude_id)

        return queryset.first()

    @staticmethod
    def create_company(
        *,
        organization_id: int,
        name: str,
        code: str,
        legal_name: str | None = None,
        website: str | None = None,
        logo=None,
        timezone_id: int | None = None,
        registration_number: str | None = None,
        company_type_id: int | None = None,
        is_active: bool = True,
    ) -> Company:
        return Company.objects.create(
            organization_id=organization_id,
            name=name,
            code=code.strip().upper() if code else code,
            legal_name=legal_name,
            website=website,
            logo=logo,
            timezone_id=timezone_id,
            registration_number=registration_number,
            company_type_id=company_type_id,
            is_active=is_active,
        )

    @staticmethod
    def update_company(*, company: Company, fields: dict) -> Company:
        if not fields:
            return company

        for name, value in fields.items():
            setattr(company, name, value)

        if fields.get("code"):
            company.code = fields["code"].strip().upper()

        company.save(
            update_fields=[
                *fields.keys(),
                "updated_at",
            ]
        )
        return company

    @staticmethod
    def soft_delete_by_ids(company_ids: list[int]) -> int:
        if not company_ids:
            return 0

        count, _ = Company.objects.filter(
            id__in=company_ids
        ).delete()

        return count

    @staticmethod
    def toggle_active_by_ids(company_ids: list[int]) -> int:
        if not company_ids:
            return 0

        return Company.objects.filter(
            id__in=company_ids
        ).update(
            is_active=Case(
                When(
                    is_active=True,
                    then=Value(False),
                ),
                default=Value(True),
                output_field=BooleanField(),
            ),
            updated_at=timezone.now(),
        )


    @staticmethod
    def update_tenant_for_company(
        *,
        company_id: int,
        tenant_id: int,
    ) -> int:
        return Company.objects.filter(
            id=company_id,
        ).update(
            tenant_id=tenant_id,
            updated_at=timezone.now(),
        )


    @staticmethod
    def list_accessible_companies_for_user(
        *,
        user_id: int,
        organization_id: int | None = None,
        company_id: int | None = None,
        name: str | None = None,
    ):
        
        from apps.company.models import CompanyMembership

        filters = Q(
            user_id=user_id,
            is_active=True,
            company__is_active=True,
        )
        if organization_id is not None:
            filters &= Q(company__organization_id=organization_id)
        if company_id is not None:
            filters &= Q(company_id=company_id)
        if name:
            filters &= Q(company__name__icontains=name)

        return (
            CompanyMembership.objects
            .filter(filters)
            .select_related(
                "company",
                "company__tenant",
                "company__organization",
            )
            .order_by("company__name")
        )

    @staticmethod
    def get_active_company_membership(*, user_id: int, company_id: int):
        from apps.company.models import CompanyMembership

        return (
            CompanyMembership.objects
            .filter(
                user_id=user_id,
                company_id=company_id,
                is_active=True,
                company__is_active=True,
            )
            .select_related('company', 'company__tenant')
            .first()
        )

    @staticmethod
    def user_has_company_access(
        *,
        user_id: int,
        company_id: int,
        is_admin: bool = False,
    ) -> bool:
        from apps.company.models import (
            BranchMembership,
            CompanyMembership,
        )
        from apps.organization.models import OrganizationMembership

        if is_admin and Company.objects.filter(
            pk=company_id,
            is_active=True,
        ).exists():
            return True

        if OrganizationMembership.objects.filter(
            user_id=user_id,
            role=OrganizationMembership.Role.OWNER,
            is_active=True,
            organization__is_active=True,
            organization__companies__pk=company_id,
            organization__companies__is_active=True,
        ).exists():
            return True

        if CompanyMembership.objects.filter(
            user_id=user_id,
            company_id=company_id,
            is_active=True,
            company__is_active=True,
        ).exists():
            return True

        return BranchMembership.objects.filter(
            user_id=user_id,
            branch__company_id=company_id,
            is_active=True,
            branch__company__is_active=True,
        ).exists()

    @staticmethod
    def visible_companies(
        *,
        user,
        organization_id: int | None = None,
        company_id: int | None = None,
        name: str | None = None,
    ):
        from apps.organization.models import OrganizationMembership

        filters = Q(is_active=True)
        if organization_id is not None:
            filters &= Q(organization_id=organization_id)
        if company_id is not None:
            filters &= Q(pk=company_id)
        if name:
            filters &= Q(name__icontains=name)

        queryset = Company.objects.filter(filters)
        if user.is_admin:
            return queryset.order_by("name")

        owned_organization_ids = OrganizationMembership.objects.filter(
            user_id=user.pk,
            role=OrganizationMembership.Role.OWNER,
            is_active=True,
            organization__is_active=True,
        ).values("organization_id")
        member_company_ids = CompanyMembership.objects.filter(
            user_id=user.pk,
            is_active=True,
            company__is_active=True,
        ).values("company_id")
        return queryset.filter(
            Q(organization_id__in=owned_organization_ids)
            | Q(pk__in=member_company_ids)
        ).order_by("name")

    @staticmethod
    def company_directory(*, user, organization_id: int | None = None, name: str | None = None):
        membership_role = CompanyMembership.objects.filter(
            company_id=OuterRef("pk"),
            user_id=user.pk,
            is_active=True,
        ).values("role")[:1]
        return (
            CompanyRepository.visible_companies(
                user=user,
                organization_id=organization_id,
                name=name,
            )
            .select_related("organization", "tenant")
            .annotate(
                branch_count=Coalesce(
                    Count(
                        "branches",
                        filter=Q(branches__deleted_at__isnull=True),
                        distinct=True,
                    ),
                    Value(0),
                    output_field=IntegerField(),
                ),
                membership_role=Subquery(
                    membership_role,
                    output_field=CharField(),
                ),
            )
        )

    @staticmethod
    def _member_company_queryset(*, user_id: int, company_id: int):
        company_membership = CompanyMembership.objects.filter(
            user_id=user_id,
            company_id=OuterRef("pk"),
            is_active=True,
        )
        branch_membership = BranchMembership.objects.filter(
            user_id=user_id,
            is_active=True,
            branch__company_id=OuterRef("pk"),
        )
        return Company.objects.filter(pk=company_id, is_active=True).filter(
            Q(Exists(company_membership)) | Q(Exists(branch_membership))
        )

    @staticmethod
    def get_company_for_member(*, user_id: int, company_id: int):
        return (
            CompanyRepository._member_company_queryset(
                user_id=user_id,
                company_id=company_id,
            )
            .select_related("tenant")
            .first()
        )

    @staticmethod
    def user_has_membership(*, user_id: int, company_id: int) -> bool:
        return CompanyRepository._member_company_queryset(
            user_id=user_id,
            company_id=company_id,
        ).exists()

    @staticmethod
    def member_company_ids(*, user_id: int, company_ids: list[int]) -> set[int]:
        if not company_ids:
            return set()
        company_membership = CompanyMembership.objects.filter(
            user_id=user_id,
            company_id=OuterRef("pk"),
            is_active=True,
        )
        branch_membership = BranchMembership.objects.filter(
            user_id=user_id,
            is_active=True,
            branch__company_id=OuterRef("pk"),
        )
        return set(
            Company.objects.filter(pk__in=company_ids, is_active=True)
            .filter(Q(Exists(company_membership)) | Q(Exists(branch_membership)))
            .values_list("pk", flat=True)
        )

    @staticmethod
    def resolve_workspace_company(
        *,
        user_id: int,
        company_id: int,
        is_superuser: bool = False,
    ):
        if is_superuser:
            return CompanyRepository.get_company_for_superuser(company_id=company_id)
        return CompanyRepository.get_company_for_member(
            user_id=user_id,
            company_id=company_id,
        )

    @staticmethod
    def get_company_for_superuser(*, company_id: int):
        return (
            Company.objects.select_related("tenant")
            .filter(pk=company_id)
            .first()
        )

    @staticmethod
    def get_company_with_tenant(*, company_id: int):
        return (
            Company.objects
            .select_related('tenant', 'organization')
            .filter(pk=company_id, is_active=True)
            .first()
        )

    @staticmethod
    def get_active_branch_for_company(
        *,
        user_id: int,
        company_id: int,
        branch_id: int,
    ):
        from apps.company.models import (
            Branch,
            BranchMembership,
        )

        # Company membership alone does not grant branch access.
        # Branch access requires an active BranchMembership for that branch.
        if not BranchMembership.objects.filter(
            user_id=user_id,
            branch_id=branch_id,
            is_active=True,
            branch__company_id=company_id,
            branch__status="ACTIVE",
            branch__company__is_active=True,
        ).exists():
            return None

        return (
            Branch.objects
            .filter(
                pk=branch_id,
                company_id=company_id,
                status="ACTIVE",
            )
            .first()
        )

    @staticmethod
    def superuser_list(
        *,
        organization_id: int | None = None,
        company_id: int | None = None,
        name: str | None = None,
    ):
        filters = Q()
        if organization_id is not None:
            filters &= Q(organization_id=organization_id)
        if company_id is not None:
            filters &= Q(pk=company_id)
        if name:
            filters &= Q(name__icontains=name)
        return (
            Company.objects.filter(filters)
            .only("id", "name")
            .order_by("name", "id")
        )

    @staticmethod
    def list_company_options(
        *,
        organization_id: int | None = None,
        company_id: int | None = None,
        name: str | None = None,
    ):
        filters = Q(is_active=True)
        if organization_id is not None:
            filters &= Q(organization_id=organization_id)
        if company_id is not None:
            filters &= Q(pk=company_id)
        if name:
            filters &= Q(name__icontains=name)
        return (
            Company.objects
            .filter(filters)
            .only("id", "name")
            .order_by("name")
        )

    @staticmethod
    def list_branch_options(
        *,
        company_id: int | None = None,
        branch_id: int | None = None,
        name: str | None = None,
    ):
        filters = Q(status="ACTIVE", company__is_active=True)
        if company_id is not None:
            filters &= Q(company_id=company_id)
        if branch_id is not None:
            filters &= Q(pk=branch_id)
        if name:
            filters &= Q(name__icontains=name)
        return (
            Branch.objects
            .filter(filters)
            .only("id", "name")
            .order_by("name")
        )

    @staticmethod
    def list_accessible_branches_for_company(
        *,
        user_id: int,
        company_id: int | None = None,
        branch_id: int | None = None,
        name: str | None = None,
    ):
        from apps.company.models import (
            Branch,
            BranchMembership,
        )

        filters = Q(
            user_id=user_id,
            is_active=True,
            branch__status="ACTIVE",
            branch__company__is_active=True,
        )
        if company_id is not None:
            filters &= Q(branch__company_id=company_id)
        if branch_id is not None:
            filters &= Q(branch_id=branch_id)
        if name:
            filters &= Q(branch__name__icontains=name)

        branch_ids = BranchMembership.objects.filter(filters).values_list(
            "branch_id",
            flat=True,
        )
        return Branch.objects.filter(id__in=branch_ids).only("id", "name").order_by("name")


class BranchRepository:

    @staticmethod
    def _base_queryset():
        return (
            Branch.objects
            .select_related("company")
            .only(
                "id",
                "public_id",
                "name",
                "code",
                "branch_type",
                "status",
                "email",
                "phone",
                "created_at",
                "updated_at",
                "company_id",
                "company__id",
                "company__public_id",
                "company__name",
                "company__code",
            )
        )

    @staticmethod
    def list_branches(
        *,
        branch_id=None,
        company_id=None,
        code=None,
        name=None,
        status=None,
    ):
        filters = Q()

        if branch_id is not None:
            ids = (
                branch_id
                if isinstance(branch_id, (list, tuple, set))
                else [branch_id]
            )
            filters &= Q(id__in=ids)

        if company_id is not None:
            filters &= Q(company_id=company_id)

        if code:
            filters &= Q(code=code.strip().upper())

        if name:
            filters &= Q(name__icontains=name.strip())

        if status:
            filters &= Q(status=status.strip().upper())

        return BranchRepository._base_queryset().filter(filters)

    @staticmethod
    def superuser_list(
        *,
        company_id: int | None = None,
        branch_id: int | None = None,
        name: str | None = None,
    ):
        filters = Q()
        if company_id is not None:
            filters &= Q(company_id=company_id)
        if branch_id is not None:
            filters &= Q(pk=branch_id)
        if name:
            filters &= Q(name__icontains=name)
        return (
            Branch.objects.filter(filters)
            .only("id", "name")
            .order_by("name", "id")
        )

    @staticmethod
    def get_by_id(branch_id: int) -> Branch | None:
        return (
            BranchRepository
            ._base_queryset()
            .filter(pk=branch_id)
            .first()
        )

    @staticmethod
    def get_code_conflict(
        *,
        code: str,
        company_id: int,
        exclude_id: int | None = None,
    ) -> Branch | None:
        queryset = Branch.objects.filter(
            code=code.strip().upper(),
            company_id=company_id,
        )
        if exclude_id is not None:
            queryset = queryset.exclude(pk=exclude_id)
        return queryset.first()

    @staticmethod
    def create_branch(
        *,
        company_id: int,
        name: str,
        code: str,
        branch_type: str | None = None,
        status: str = "ACTIVE",
        email: str | None = None,
        phone: str | None = None,
        created_by_id: int | None = None,
    ) -> Branch:
        return Branch.objects.create(
            company_id=company_id,
            name=name,
            code=code.strip().upper(),
            branch_type=branch_type,
            status=status,
            email=email,
            phone=phone,
            created_by_id=created_by_id,
        )

    @staticmethod
    def update_branch(
        *,
        branch: Branch,
        company_id: int,
        name: str,
        code: str,
        branch_type: str | None = None,
        status: str = "ACTIVE",
        email: str | None = None,
        phone: str | None = None,
    ) -> Branch:
        branch.company_id = company_id
        branch.name = name
        branch.code = code.strip().upper()
        branch.branch_type = branch_type
        branch.status = status
        branch.email = email
        branch.phone = phone
        branch.save(
            update_fields=[
                "company_id",
                "name",
                "code",
                "branch_type",
                "status",
                "email",
                "phone",
                "updated_at",
            ]
        )
        return branch

    @staticmethod
    def soft_delete_by_ids(branch_ids: list[int]) -> int:
        if not branch_ids:
            return 0
        count, _ = Branch.objects.filter(id__in=branch_ids).delete()
        return count

    @staticmethod
    def toggle_status_by_ids(branch_ids: list[int]) -> int:
        if not branch_ids:
            return 0
        return Branch.objects.filter(id__in=branch_ids).update(
            status=Case(
                When(status="ACTIVE", then=Value("INACTIVE")),
                default=Value("ACTIVE"),
                output_field=CharField(max_length=30),
            ),
            updated_at=timezone.now(),
        )


class BranchMembershipRepository:

    @staticmethod
    def _base_queryset():
        return (
            BranchMembership.objects
            .select_related("branch", "branch__company", "user")
            .only(
                "id",
                "public_id",
                "role",
                "is_active",
                "created_at",
                "updated_at",
                "branch_id",
                "branch__id",
                "branch__public_id",
                "branch__name",
                "branch__code",
                "branch__company_id",
                "user_id",
                "user__id",
                "user__public_id",
                "user__email",
                "user__username",
            )
        )

    @staticmethod
    def list_memberships(
        *,
        membership_id=None,
        branch_id=None,
        user_id=None,
        company_id=None,
        role=None,
        roles=None,
        is_active=None,
        email=None,
        name=None,
    ):
        filters = Q()

        if membership_id is not None:
            ids = (
                membership_id
                if isinstance(membership_id, (list, tuple, set))
                else [membership_id]
            )
            filters &= Q(id__in=ids)

        if branch_id is not None:
            filters &= Q(branch_id=branch_id)

        if user_id is not None:
            filters &= Q(user_id=user_id)

        if company_id is not None:
            filters &= Q(branch__company_id=company_id)

        if roles:
            filters &= Q(role__in=[r.strip().lower() for r in roles])
        elif role:
            filters &= Q(role=role.strip().lower())

        if is_active is not None:
            filters &= Q(is_active=is_active)

        if email:
            filters &= Q(user__email__icontains=email.strip())

        if name:
            filters &= Q(user__username__icontains=name.strip())

        return BranchMembershipRepository._base_queryset().filter(filters)

    @staticmethod
    def list_my_branches(
        *,
        user_id: int,
        company_id: int | None = None,
        branch_id: int | None = None,
        name: str | None = None,
    ):
        filters = Q(
            user_id=user_id,
            is_active=True,
            branch__status="ACTIVE",
            branch__deleted_at__isnull=True,
            branch__company__is_active=True,
            branch__company__deleted_at__isnull=True,
        )
        if company_id is not None:
            filters &= Q(branch__company_id=company_id)
        if branch_id is not None:
            filters &= Q(branch_id=branch_id)
        if name:
            filters &= Q(branch__name__icontains=name)

        return (
            BranchMembership.objects.filter(filters)
            .select_related("branch")
            .only(
                "id",
                "branch_id",
                "branch__id",
                "branch__name",
            )
            .order_by("branch__name", "id")
        )

    @staticmethod
    def get_by_id(membership_id: int) -> BranchMembership | None:
        return (
            BranchMembershipRepository
            ._base_queryset()
            .filter(pk=membership_id)
            .first()
        )

    @staticmethod
    def get_conflict(
        *,
        branch_id: int,
        user_id: int,
        exclude_id: int | None = None,
    ) -> BranchMembership | None:
        queryset = BranchMembership.objects.filter(
            branch_id=branch_id,
            user_id=user_id,
        )
        if exclude_id is not None:
            queryset = queryset.exclude(pk=exclude_id)
        return queryset.first()

    @staticmethod
    def create_membership(
        *,
        branch_id: int,
        user_id: int,
        role: str = "staff",
        is_active: bool = True,
    ) -> BranchMembership:
        return BranchMembership.objects.create(
            branch_id=branch_id,
            user_id=user_id,
            role=role,
            is_active=is_active,
        )

    @staticmethod
    def update_membership(
        *,
        membership: BranchMembership,
        branch_id: int,
        user_id: int,
        role: str,
        is_active: bool,
    ) -> BranchMembership:
        membership.branch_id = branch_id
        membership.user_id = user_id
        membership.role = role
        membership.is_active = is_active
        membership.save(
            update_fields=[
                "branch_id",
                "user_id",
                "role",
                "is_active",
                "updated_at",
            ]
        )
        return membership

    @staticmethod
    def soft_delete_by_ids(membership_ids: list[int]) -> int:
        if not membership_ids:
            return 0
        count, _ = BranchMembership.objects.filter(
            id__in=membership_ids
        ).delete()
        return count

    @staticmethod
    def toggle_active_by_ids(membership_ids: list[int]) -> int:
        if not membership_ids:
            return 0
        return BranchMembership.objects.filter(
            id__in=membership_ids
        ).update(
            is_active=Case(
                When(is_active=True, then=Value(False)),
                default=Value(True),
                output_field=BooleanField(),
            ),
            updated_at=timezone.now(),
        )


class CompanyMembershipRepository:

    @staticmethod
    def _base_queryset():
        return (
            CompanyMembership.objects
            .select_related("company", "user")
            .only(
                "id",
                "public_id",
                "role",
                "is_active",
                "created_at",
                "updated_at",
                "company_id",
                "company__id",
                "company__public_id",
                "company__name",
                "company__code",
                "user_id",
                "user__id",
                "user__public_id",
                "user__email",
                "user__username",
            )
        )

    @staticmethod
    def list_memberships(
        *,
        membership_id=None,
        company_id=None,
        user_id=None,
        role=None,
        roles=None,
        is_active=None,
        email=None,
        name=None,
    ):
        filters = Q()

        if membership_id is not None:
            ids = (
                membership_id
                if isinstance(membership_id, (list, tuple, set))
                else [membership_id]
            )
            filters &= Q(id__in=ids)

        if company_id is not None:
            filters &= Q(company_id=company_id)

        if user_id is not None:
            filters &= Q(user_id=user_id)

        if roles:
            filters &= Q(role__in=[r.strip().lower() for r in roles])
        elif role:
            filters &= Q(role=role.strip().lower())

        if is_active is not None:
            filters &= Q(is_active=is_active)

        if email:
            filters &= Q(user__email__icontains=email.strip())

        if name:
            filters &= Q(user__username__icontains=name.strip())

        return CompanyMembershipRepository._base_queryset().filter(filters)

    @staticmethod
    def list_my_companies(
        *,
        user_id: int,
        organization_id: int | None = None,
        company_id: int | None = None,
        name: str | None = None,
    ):
        filters = Q(
            user_id=user_id,
            is_active=True,
            company__is_active=True,
            company__deleted_at__isnull=True,
        )
        if organization_id is not None:
            filters &= Q(company__organization_id=organization_id)
        if company_id is not None:
            filters &= Q(company_id=company_id)
        if name:
            filters &= Q(company__name__icontains=name)

        return (
            CompanyMembership.objects.filter(filters)
            .select_related("company")
            .only(
                "id",
                "company_id",
                "company__id",
                "company__name",
            )
            .order_by("company__name", "id")
        )

    @staticmethod
    def get_by_id(membership_id: int) -> CompanyMembership | None:
        return (
            CompanyMembershipRepository
            ._base_queryset()
            .filter(pk=membership_id)
            .first()
        )

    @staticmethod
    def get_conflict(
        *,
        company_id: int,
        user_id: int,
        exclude_id: int | None = None,
    ) -> CompanyMembership | None:
        queryset = CompanyMembership.objects.filter(
            company_id=company_id,
            user_id=user_id,
        )
        if exclude_id is not None:
            queryset = queryset.exclude(pk=exclude_id)
        return queryset.first()

    @staticmethod
    def create_membership(
        *,
        company_id: int,
        user_id: int,
        role: str = "employee",
        is_active: bool = True,
    ) -> CompanyMembership:
        return CompanyMembership.objects.create(
            company_id=company_id,
            user_id=user_id,
            role=role,
            is_active=is_active,
        )

    @staticmethod
    def update_membership(
        *,
        membership: CompanyMembership,
        company_id: int,
        user_id: int,
        role: str,
        is_active: bool,
    ) -> CompanyMembership:
        membership.company_id = company_id
        membership.user_id = user_id
        membership.role = role
        membership.is_active = is_active
        membership.save(
            update_fields=[
                "company_id",
                "user_id",
                "role",
                "is_active",
                "updated_at",
            ]
        )
        return membership

    @staticmethod
    def soft_delete_by_ids(membership_ids: list[int]) -> int:
        if not membership_ids:
            return 0
        count, _ = CompanyMembership.objects.filter(
            id__in=membership_ids
        ).delete()
        return count

    @staticmethod
    def toggle_active_by_ids(membership_ids: list[int]) -> int:
        if not membership_ids:
            return 0
        return CompanyMembership.objects.filter(
            id__in=membership_ids
        ).update(
            is_active=Case(
                When(is_active=True, then=Value(False)),
                default=Value(True),
                output_field=BooleanField(),
            ),
            updated_at=timezone.now(),
        )


class CatalogRepository:
    _MODELS = {
        "company_type": CompanyType,
        "business_type": BusinessType,
    }

    @staticmethod
    def _model(kind: str):
        model = CatalogRepository._MODELS.get(kind)
        if model is None:
            raise ValueError(f"Unknown catalog kind: {kind}")
        return model

    @staticmethod
    def list_items(*, kind, item_id=None, code=None, name=None, is_active=None):
        model = CatalogRepository._model(kind)
        filters = Q()
        if item_id is not None:
            ids = item_id if isinstance(item_id, (list, tuple, set)) else [item_id]
            filters &= Q(id__in=ids)
        if code:
            filters &= Q(code=code.strip().upper() if kind == "company_type" else code.strip().upper())
        if name:
            filters &= Q(name__icontains=name)
        if is_active is not None:
            filters &= Q(is_active=is_active)
        return model.objects.only(
            "id", "public_id", "name", "code", "is_active", "created_at", "updated_at"
        ).filter(filters)

    @staticmethod
    def get_by_id(*, kind, item_id: int):
        return CatalogRepository._model(kind).objects.filter(pk=item_id).first()

    @staticmethod
    def get_code_conflict(*, kind, code: str, exclude_id=None):
        model = CatalogRepository._model(kind)
        qs = model.objects.filter(code=code.strip().upper())
        if exclude_id is not None:
            qs = qs.exclude(pk=exclude_id)
        return qs.first()

    @staticmethod
    def create_item(*, kind, name, code, is_active=True):
        return CatalogRepository._model(kind).objects.create(
            name=name,
            code=code.strip().upper(),
            is_active=is_active,
        )

    @staticmethod
    def update_item(*, kind, item, name, code, is_active):
        item.name = name
        item.code = code.strip().upper()
        item.is_active = is_active
        item.save(update_fields=["name", "code", "is_active", "updated_at"])
        return item

    @staticmethod
    def delete_by_ids(*, kind, item_ids: list[int]) -> int:
        if not item_ids:
            return 0
        count, _ = CatalogRepository._model(kind).objects.filter(id__in=item_ids).delete()
        return count

    @staticmethod
    def toggle_active_by_ids(*, kind, item_ids: list[int]) -> int:
        if not item_ids:
            return 0
        return CatalogRepository._model(kind).objects.filter(id__in=item_ids).update(
            is_active=Case(
                When(is_active=True, then=Value(False)),
                default=Value(True),
                output_field=BooleanField(),
            ),
            updated_at=timezone.now(),
        )
