from dataclasses import dataclass

from rest_framework.exceptions import (
    PermissionDenied,
    ValidationError,
)

from core.utils.ids import decode_id
from core.utils.tokens import get_workspace_claims


@dataclass(frozen=True)
class WorkspaceScope:
    """
    Server-side company + tenant identity for tenant-app CRUD.
    Always derived from workspace JWT claims — never from client body/headers.
    """

    company_id: int
    tenant_id: int
    db_alias: str | None = None
    branch_id: int | None = None

    @property
    def filter_kwargs(self) -> dict:
        return {
            "tenant_id": self.tenant_id,
            "company_id": self.company_id,
        }


def _decode_claim(uid: str | None, *, field: str) -> int:
    if not uid:
        raise ValidationError({field: ["Missing workspace claim."]})

    try:
        decoded = decode_id(uid)
    except (TypeError, ValueError):
        raise ValidationError({field: ["Invalid id."]}) from None

    if not isinstance(decoded, int):
        raise ValidationError({field: ["Invalid id."]})

    return decoded


def workspace_scope_from_claims(claims: dict) -> WorkspaceScope:
    company_id = _decode_claim(
        claims.get("company_uid"),
        field="company_uid",
    )
    tenant_id = _decode_claim(
        claims.get("tenant_uid"),
        field="tenant_uid",
    )

    branch_id = None
    if claims.get("branch_uid"):
        branch_id = _decode_claim(
            claims["branch_uid"],
            field="branch_uid",
        )

    return WorkspaceScope(
        company_id=company_id,
        tenant_id=tenant_id,
        db_alias=claims.get("db_alias"),
        branch_id=branch_id,
    )


def workspace_scope_from_request(request) -> WorkspaceScope:
    """
    Prefer request.workspace (set by IsWorkspaceAuthenticated).
    Falls back to token claims.
    """
    claims = getattr(request, "workspace", None)
    if not claims:
        claims = get_workspace_claims(getattr(request, "auth", None))

    if not claims:
        raise PermissionDenied("Select a company workspace to continue.")

    return workspace_scope_from_claims(claims)
