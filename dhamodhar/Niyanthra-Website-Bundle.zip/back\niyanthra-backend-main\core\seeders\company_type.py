from core.seeders.base import run_group

GROUP = "company_type"


def run() -> dict:
    return run_group(GROUP)
