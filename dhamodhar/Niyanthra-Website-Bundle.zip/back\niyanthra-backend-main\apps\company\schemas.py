from rest_framework import serializers

from apps.company.models import (
    Branch,
    BranchMembership,
    BusinessType,
    Company,
    CompanyAddress,
    CompanyMembership,
    CompanyModule,
    CompanyTaxRegistration,
    CompanyType,
)
from core.utils.ids import encode_id


def _public_reference(instance, **fields) -> dict | None:
    if instance is None:
        return None

    payload = {
        "uid": encode_id(instance.pk),
        "public_id": str(instance.public_id),
    }
    for key, value in fields.items():
        payload[key] = "" if value is None else value
    return payload


class GetMyBranchesApiSchema(serializers.Serializer):
    value = serializers.SerializerMethodField()
    label = serializers.SerializerMethodField()

    def get_value(self, row) -> str:
        return encode_id(getattr(row, "branch_id", None) or row.pk)

    def get_label(self, row) -> str:
        branch = getattr(row, "branch", None)
        if branch is not None and branch is not row:
            return branch.name or ""
        return getattr(row, "name", None) or ""


class GetMyCompaniesApiSchema(serializers.Serializer):
    value = serializers.SerializerMethodField()
    label = serializers.SerializerMethodField()

    def get_value(self, row) -> str:
        return encode_id(getattr(row, "company_id", None) or row.pk)

    def get_label(self, row) -> str:
        company = getattr(row, "company", None)
        if company is not None and company is not row:
            return company.name or ""
        return getattr(row, "name", None) or ""


class GetMyCompanyDirectoryApiSchema(serializers.Serializer):
    value = serializers.SerializerMethodField()
    label = serializers.SerializerMethodField()
    code = serializers.SerializerMethodField()
    organization = serializers.SerializerMethodField()
    role = serializers.SerializerMethodField()
    branch_count = serializers.IntegerField()
    tenant = serializers.SerializerMethodField()

    def get_value(self, company) -> str:
        return encode_id(company.pk)

    def get_label(self, company) -> str:
        return company.name or ""

    def get_code(self, company) -> str:
        return company.code or ""

    def get_organization(self, company) -> dict:
        organization = company.organization
        return {
            "value": encode_id(organization.pk),
            "label": organization.name or "",
        }

    def get_role(self, company) -> str:
        return getattr(company, "membership_role", None) or "owner"

    def get_tenant(self, company) -> dict | None:
        tenant = company.tenant
        if tenant is None:
            return None
        return {
            "uid": encode_id(tenant.pk),
            "name": tenant.name or "",
            "tenant_type": tenant.tenant_type,
            "status": tenant.provisioning_status,
            "is_ready": bool(tenant.is_ready),
        }


class GetCompaniesApiSchema(serializers.ModelSerializer):
    uid          = serializers.SerializerMethodField()
    organization = serializers.SerializerMethodField()
    timezone     = serializers.SerializerMethodField()
    company_type = serializers.SerializerMethodField()

    class Meta:
        model = Company
        fields = [
            "uid",
            "public_id",
            "name",
            "code",
            "legal_name",
            "is_active",
            "website",
            "logo",
            "registration_number",
            "organization",
            "timezone",
            "company_type",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_organization(self, instance) -> dict:
        organization = instance.organization
        return _public_reference(
            organization,
            name=organization.name,
            code=organization.code,
        )

    def get_timezone(self, instance) -> dict | None:
        timezone = instance.timezone
        if timezone is None:
            return None
        return _public_reference(
            timezone,
            name=timezone.name,
            code=timezone.code,
            utc_offset=timezone.utc_offset,
        )

    def get_company_type(self, instance) -> dict | None:
        company_type = instance.company_type
        if company_type is None:
            return None
        return _public_reference(
            company_type,
            name=company_type.name,
            code=company_type.code,
        )

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data


class GetBranchesApiSchema(serializers.ModelSerializer):
    uid     = serializers.SerializerMethodField()
    company = serializers.SerializerMethodField()

    class Meta:
        model = Branch
        fields = [
            "uid",
            "public_id",
            "name",
            "code",
            "branch_type",
            "status",
            "email",
            "phone",
            "company",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_company(self, instance) -> dict:
        company = instance.company
        return {
            "uid": encode_id(company.pk),
            "public_id": str(company.public_id),
            "name": company.name or "",
            "code": company.code or "",
        }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data


class GetAddressesApiSchema(serializers.ModelSerializer):
    uid = serializers.SerializerMethodField()
    company = serializers.SerializerMethodField()
    country = serializers.SerializerMethodField()

    class Meta:
        model = CompanyAddress
        fields = [
            "uid",
            "public_id",
            "address_type",
            "address_line_1",
            "address_line_2",
            "city",
            "state_province",
            "postal_code",
            "is_primary",
            "company",
            "country",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_company(self, instance) -> dict:
        company = instance.company
        return {
            "uid": encode_id(company.pk),
            "public_id": str(company.public_id),
            "name": company.name or "",
            "code": company.code or "",
        }

    def get_country(self, instance) -> dict:
        country = instance.country
        if country is None:
            return {"uid": "", "public_id": "", "name": "", "code": ""}
        return {
            "uid": encode_id(country.pk),
            "public_id": str(country.public_id),
            "name": country.name or "",
            "code": getattr(country, "code", "") or "",
        }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data


class GetTaxRegistrationsApiSchema(serializers.ModelSerializer):
    uid = serializers.SerializerMethodField()
    company = serializers.SerializerMethodField()
    country = serializers.SerializerMethodField()
    tax_type = serializers.SerializerMethodField()

    class Meta:
        model = CompanyTaxRegistration
        fields = [
            "uid",
            "public_id",
            "registration_number",
            "registration_name",
            "status",
            "effective_from",
            "effective_to",
            "is_primary",
            "company",
            "country",
            "tax_type",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_company(self, instance) -> dict:
        company = instance.company
        return {
            "uid": encode_id(company.pk),
            "public_id": str(company.public_id),
            "name": company.name or "",
            "code": company.code or "",
        }

    def get_country(self, instance) -> dict:
        country = instance.country
        if country is None:
            return {"uid": "", "public_id": "", "name": "", "code": ""}
        return {
            "uid": encode_id(country.pk),
            "public_id": str(country.public_id),
            "name": country.name or "",
            "code": getattr(country, "code", "") or "",
        }

    def get_tax_type(self, instance) -> dict:
        tax_type = instance.tax_type
        if tax_type is None:
            return {"uid": "", "public_id": "", "name": "", "code": ""}
        return {
            "uid": encode_id(tax_type.pk),
            "public_id": str(tax_type.public_id),
            "name": tax_type.name or "",
            "code": tax_type.code or "",
        }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        if data.get("effective_from"):
            data["effective_from"] = str(data["effective_from"])[:10]
        if data.get("effective_to"):
            data["effective_to"] = str(data["effective_to"])[:10]
        return data


class GetBranchMembershipsApiSchema(serializers.ModelSerializer):
    uid    = serializers.SerializerMethodField()
    branch = serializers.SerializerMethodField()
    user   = serializers.SerializerMethodField()

    class Meta:
        model = BranchMembership
        fields = [
            "uid",
            "public_id",
            "role",
            "is_active",
            "branch",
            "user",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_branch(self, instance) -> dict:
        branch = instance.branch
        return {
            "uid": encode_id(branch.pk),
            "public_id": str(branch.public_id),
            "name": branch.name or "",
            "code": branch.code or "",
            "company_uid": encode_id(branch.company_id),
        }

    def get_user(self, instance) -> dict:
        user = instance.user
        return {
            "uid": encode_id(user.pk),
            "public_id": str(user.public_id),
            "email": user.email or "",
            "username": user.username or "",
        }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data


class GetCompanyMembershipsApiSchema(serializers.ModelSerializer):
    uid     = serializers.SerializerMethodField()
    company = serializers.SerializerMethodField()
    user    = serializers.SerializerMethodField()

    class Meta:
        model = CompanyMembership
        fields = [
            "uid",
            "public_id",
            "role",
            "is_active",
            "company",
            "user",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_company(self, instance) -> dict:
        company = instance.company
        return {
            "uid": encode_id(company.pk),
            "public_id": str(company.public_id),
            "name": company.name or "",
            "code": company.code or "",
        }

    def get_user(self, instance) -> dict:
        user = instance.user
        return {
            "uid": encode_id(user.pk),
            "public_id": str(user.public_id),
            "email": user.email or "",
            "username": user.username or "",
        }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data

class GetCompanyTypesApiSchema(serializers.ModelSerializer):
    uid = serializers.SerializerMethodField()

    class Meta:
        model = CompanyType
        fields = [
            "uid",
            "public_id",
            "name",
            "code",
            "is_active",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data


class GetBusinessTypesApiSchema(serializers.ModelSerializer):
    uid = serializers.SerializerMethodField()

    class Meta:
        model = BusinessType
        fields = [
            "uid",
            "public_id",
            "name",
            "code",
            "is_active",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data


class GetCompanyModulesApiSchema(serializers.ModelSerializer):
    uid     = serializers.SerializerMethodField()
    company = serializers.SerializerMethodField()

    class Meta:
        model = CompanyModule
        fields = [
            "uid",
            "public_id",
            "company",
            "modules",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_company(self, instance) -> dict:
        company = instance.company
        return {
            "uid": encode_id(company.pk),
            "public_id": str(company.public_id),
            "name": company.name or "",
            "code": company.code or "",
        }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data
