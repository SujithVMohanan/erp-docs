from contextlib import nullcontext

from rest_framework.exceptions import ValidationError

from core.tenant import get_current_tenant, tenant_context
from core.tenant.workspace import WorkspaceScope
from core.utils.ids import decode_id


def decode_uid(
    uid: str,
    *,
    field: str = "uid",
) -> int:
    try:
        decoded = decode_id(uid)
    except (TypeError, ValueError):
        raise ValidationError(
            {field: ["Invalid id."]}
        ) from None

    if not isinstance(decoded, int):
        raise ValidationError(
            {field: ["Invalid id."]}
        )

    return decoded


def decode_uids(
    uids: list[str],
    *,
    field: str = "uids",
) -> list[int]:
    return list(
        dict.fromkeys(
            decode_uid(uid, field=field)
            for uid in uids
        )
    )


def workspace_context(
    scope: WorkspaceScope,
):
    
    current = get_current_tenant()

    if (
        current
        and current.tenant_id == scope.tenant_id
        and current.company_id == scope.company_id
    ):
        return nullcontext()

    return tenant_context(
        tenant_id=scope.tenant_id,
        company_id=scope.company_id,
    )
