from decimal import Decimal, InvalidOperation

from django.db import transaction
from django.utils import timezone
from openpyxl import load_workbook
from rest_framework.exceptions import ValidationError

from apps.company.models import Branch, TaxRate
from apps.inventory.models import Product
from apps.inventory.repository import InventoryRepository
from apps.inventory.services.scope import workspace_context
from apps.inventory.services.stock_service import (
    StockService,
    company_code,
    money,
    name_key,
    next_sku,
    normalize_unit,
)
from apps.inventory.services.warehouse_service import WarehouseService
from core.exceptions.auth import AuthValidationError
from core.tenant.workspace import WorkspaceScope
from infrastructure.database.context import get_current_db_alias


_MAX_ROWS = 10_000
_BATCH_SIZE = 500
_INVENTORY_SHEET = "inventory"

_TRUE_VALUES = {"1", "true", "yes", "y"}
_FALSE_VALUES = {"0", "false", "no", "n"}

_PRODUCT_UPDATE_FIELDS = (
    "name",
    "name_key",
    "uom_code",
    "hsn_code",
    "tax_rate_id",
    "tax_percent",
    "cost_price",
    "selling_price",
    "track_stock",
    "updated_at",
)


class InventoryImportService:

    @staticmethod
    def import_workbook(
        *,
        scope: WorkspaceScope,
        uploaded_file,
    ) -> dict:
        rows = InventoryImportService._rows(uploaded_file)

        with workspace_context(scope):
            WarehouseService.sync_current()

            company_code_value = company_code(scope.company_id)
            catalog = _Catalog(
                company_id=scope.company_id,
                rows=rows,
                company_code_value=company_code_value,
            )

            summary = InventoryImportService._summary()

            prepared = InventoryImportService._prepare_rows(
                rows=rows,
                scope=scope,
                catalog=catalog,
                company_code_value=company_code_value,
                summary=summary,
            )

            InventoryImportService._apply(
                scope=scope,
                prepared=prepared,
                catalog=catalog,
                summary=summary,
            )

            return summary

    @staticmethod
    def _summary() -> dict:
        return {
            "created": 0,
            "updated": 0,
            "opened": 0,
            "unchanged": 0,
            "failed": 0,
            "errors": [],
        }

    @staticmethod
    def _prepare_rows(
        *,
        rows,
        scope: WorkspaceScope,
        catalog,
        company_code_value: str,
        summary: dict,
    ) -> list:
        prepared = []

        for row_number, row in rows:
            try:
                prepared.append(
                    InventoryImportService._prepare(
                        row_number=row_number,
                        row=row,
                        company_code_value=company_code_value,
                        catalog=catalog,
                        scope=scope,
                    )
                )
            except (
                AuthValidationError,
                ValidationError,
                ValueError,
            ) as exc:
                InventoryImportService._add_error(
                    summary=summary,
                    row=row_number,
                    message=InventoryImportService._message(exc),
                )

        return prepared

    @staticmethod
    def _apply(
        *,
        scope: WorkspaceScope,
        prepared: list,
        catalog,
        summary: dict,
    ) -> None:
        InventoryImportService._apply_products(
            scope=scope,
            prepared=prepared,
            catalog=catalog,
            summary=summary,
        )

        InventoryImportService._apply_opening_stock(
            prepared=prepared,
            catalog=catalog,
            summary=summary,
        )

    @staticmethod
    def _apply_products(
        *,
        scope: WorkspaceScope,
        prepared: list,
        catalog,
        summary: dict,
    ) -> None:
        new_items = [
            item
            for item in prepared
            if item["product"] is None
        ]

        existing_items = [
            item
            for item in prepared
            if item["product"] is not None
        ]

        InventoryImportService._create_products(
            scope=scope,
            items=new_items,
            catalog=catalog,
            summary=summary,
        )

        InventoryImportService._update_products(
            items=existing_items,
            summary=summary,
        )

    @staticmethod
    def _create_products(
        *,
        scope: WorkspaceScope,
        items: list,
        catalog,
        summary: dict,
    ) -> None:
        if not items:
            return

        taken_skus = catalog.taken_skus
        products = []

        for item in items:
            sku = item["sku"]

            if not sku:
                sku = next_sku(
                    catalog.company_code,
                    taken_skus,
                )
                item["sku"] = sku

            elif sku in taken_skus:
                InventoryImportService._add_error(
                    summary=summary,
                    row=item["row"],
                    message="This SKU already exists.",
                )
                continue

            taken_skus.add(sku)

            product = Product(
                company_id=scope.company_id,
                sku=sku,
                name=item["name"],
                name_key=item["name_key"],
                uom_code=item["uom_code"],
                hsn_code=item["hsn_code"],
                tax_rate_id=item["tax_rate_id"],
                tax_percent=item["tax_percent"],
                cost_price=item["cost_price"],
                selling_price=item["selling_price"],
                track_stock=item["track_stock"],
                is_active=True,
            )

            item["product"] = product
            products.append(product)

        if not products:
            return

        alias = get_current_db_alias()

        with transaction.atomic(using=alias):
            Product.objects.bulk_create(
                products,
                batch_size=_BATCH_SIZE,
            )

        summary["created"] += len(products)

        for item in items:
            product = item.get("product")

            if product is None or not product.pk:
                continue

            catalog.by_sku[product.sku] = product
            catalog.by_name.setdefault(
                product.name_key,
                product,
            )

    @staticmethod
    def _update_products(
        *,
        items: list,
        summary: dict,
    ) -> None:
        if not items:
            return

        updates_by_pk = {}

        for item in items:
            product = item["product"]
            changed = False

            for field in (
                "name",
                "name_key",
                "uom_code",
                "hsn_code",
                "tax_rate_id",
                "tax_percent",
                "selling_price",
                "track_stock",
            ):
                value = item.get(field)

                if value is None:
                    continue

                if getattr(product, field) != value:
                    setattr(product, field, value)
                    changed = True

            if item["set_cost"] and product.cost_price != item["cost_price"]:
                product.cost_price = item["cost_price"]
                changed = True

            if not changed:
                continue

            product.updated_at = timezone.now()
            updates_by_pk[product.pk] = product

        if not updates_by_pk:
            return

        Product.objects.bulk_update(
            list(updates_by_pk.values()),
            _PRODUCT_UPDATE_FIELDS,
            batch_size=_BATCH_SIZE,
        )

        summary["updated"] += len(updates_by_pk)

    @staticmethod
    def _apply_opening_stock(
        *,
        prepared: list,
        catalog,
        summary: dict,
    ) -> None:
        queued = {}

        for item in prepared:
            product = item.get("product")

            if product is None or not product.pk:
                continue

            quantity = item["quantity"]

            if quantity <= 0:
                continue

            if item["track_stock"] is False:
                InventoryImportService._add_error(
                    summary=summary,
                    row=item["row"],
                    message="This product does not track stock.",
                )
                continue

            warehouse = item["warehouse"]
            warehouse_id = warehouse.pk
            product_id = product.pk

            if catalog.has_ledger(
                product_id,
                warehouse_id,
            ):
                summary["unchanged"] += 1
                continue

            key = (
                warehouse_id,
                product_id,
            )

            existing = queued.get(key)

            if existing is not None:
                existing["quantity"] = money(
                    existing["quantity"] + quantity
                )
                continue

            queued[key] = item

        if not queued:
            return

        openings = {}

        for item in queued.values():
            warehouse = item["warehouse"]

            openings.setdefault(
                warehouse.pk,
                {
                    "warehouse": warehouse,
                    "items": [],
                },
            )["items"].append(item)

        for opening in openings.values():
            warehouse = opening["warehouse"]
            items = opening["items"]

            InventoryImportService._post_opening_stock(
                warehouse=warehouse,
                items=items,
                catalog=catalog,
                summary=summary,
            )

    @staticmethod
    def _post_opening_stock(
        *,
        warehouse,
        items: list,
        catalog,
        summary: dict,
    ) -> None:
        warehouse_id = warehouse.pk

        try:
            StockService.post_opening(
                warehouse=warehouse,
                lines=[
                    StockService.opening_line(
                        product=item["product"],
                        warehouse_id=warehouse_id,
                        quantity=item["quantity"],
                        unit_cost=item["unit_cost"],
                    )
                    for item in items
                ],
                products={
                    item["product"].pk: item["product"]
                    for item in items
                },
            )
        except AuthValidationError as exc:
            message = InventoryImportService._message(exc)

            summary["failed"] += len(items)

            for item in items:
                InventoryImportService._add_error(
                    summary=summary,
                    row=item["row"],
                    message=message,
                )

            return

        summary["opened"] += len(items)

        for item in items:
            catalog.remember_ledger(
                item["product"].pk,
                warehouse_id,
            )

    @staticmethod
    def _prepare(
        *,
        row_number: int,
        row: dict,
        company_code_value: str,
        catalog,
        scope: WorkspaceScope,
    ) -> dict:
        given_company = (
            InventoryImportService
            ._text(row, "company_code")
            .upper()
        )

        if (
            given_company
            and given_company != company_code_value
        ):
            raise ValueError(
                "Company does not match this workspace."
            )

        name = InventoryImportService._text(
            row,
            "name",
        )

        if not name:
            raise ValueError("NAME is required.")

        quantity = InventoryImportService._decimal(
            row,
            "qty",
            required=True,
        )

        branch_code = (
            InventoryImportService
            ._text(row, "branch_code")
            .upper()
        )

        warehouse = catalog.warehouse_for(
            scope,
            branch_code,
        )

        sku = (
            InventoryImportService
            ._text(row, "sku")
            .upper()
        )

        product = (
            catalog.by_sku.get(sku)
            if sku
            else catalog.by_name.get(name_key(name))
        )

        unit_cost = InventoryImportService._optional_decimal(
            row,
            "unit_cost",
        )

        cost_price = InventoryImportService._optional_decimal(
            row,
            "cost_price",
        )

        selling_price = InventoryImportService._optional_decimal(
            row,
            "selling_price",
        )

        tax_rate_id, tax_percent = (
            InventoryImportService._resolve_tax(
                row=row,
                product=product,
                catalog=catalog,
            )
        )

        uom = InventoryImportService._text(
            row,
            "uom",
        )

        hsn = InventoryImportService._text(
            row,
            "hsn",
        )

        track_stock = InventoryImportService._bool(
            row,
            "track_stock",
        )

        if track_stock is None and product is not None:
            effective_track_stock = product.track_stock
        else:
            effective_track_stock = (
                True
                if track_stock is None
                else track_stock
            )

        cost = (
            unit_cost
            if unit_cost is not None
            else cost_price
        )

        if cost is None:
            cost = (
                product.cost_price
                if product is not None
                else Decimal("0")
            )

        if selling_price is None:
            selling_price = (
                product.selling_price
                if product is not None
                else cost
            )

        if (
            product is not None
            and InventoryImportService._text(
                row,
                "selling_price",
            ) == ""
        ):
            selling_price = None

        return {
            "row": row_number,
            "product": product,
            "sku": sku,
            "name": name,
            "name_key": name_key(name),
            "uom_code": (
                normalize_unit(uom)
                if uom or product is None
                else None
            ),
            "hsn_code": (
                hsn
                if hsn or product is None
                else None
            ),
            "tax_rate_id": tax_rate_id,
            "tax_percent": tax_percent,
            "cost_price": money(cost),
            "set_cost": (
                cost_price is not None
                or unit_cost is not None
            ),
            "selling_price": (
                None
                if selling_price is None
                else money(selling_price)
            ),
            "track_stock": effective_track_stock,
            "quantity": money(quantity),
            "unit_cost": money(cost),
            "warehouse": warehouse,
        }

    @staticmethod
    def _resolve_tax(
        *,
        row: dict,
        product,
        catalog,
    ) -> tuple:
        tax_code = (
            InventoryImportService
            ._text(row, "tax_rate_code")
            .upper()
        )

        if tax_code:
            rate = catalog.tax_rates.get(tax_code)

            if rate is None:
                raise ValueError(
                    f"Unknown tax rate '{tax_code}'."
                )

            return (
                rate.pk,
                money(rate.rate or 0),
            )

        if product is not None:
            return None, None

        return None, Decimal("0")

    @staticmethod
    def _rows(uploaded_file) -> list:
        filename = (
            getattr(uploaded_file, "name", "")
            or ""
        ).lower()

        if not filename.endswith(".xlsx"):
            raise ValidationError(
                {
                    "file": [
                        "Upload an .xlsx file."
                    ]
                }
            )

        try:
            workbook = load_workbook(
                uploaded_file,
                read_only=True,
                data_only=True,
            )
        except Exception as exc:
            raise ValidationError(
                {
                    "file": [
                        "Workbook could not be read."
                    ]
                }
            ) from exc

        if _INVENTORY_SHEET not in workbook.sheetnames:
            raise ValidationError(
                {
                    "file": [
                        "Workbook is missing sheet "
                        "'inventory'."
                    ]
                }
            )

        worksheet = workbook[_INVENTORY_SHEET]
        rows = worksheet.iter_rows(values_only=True)

        try:
            header_row = next(rows)
        except StopIteration:
            return []

        headers = [
            str(cell).strip().lower()
            if cell is not None
            else ""
            for cell in header_row
        ]

        parsed = []

        for row_number, values in enumerate(
            rows,
            start=2,
        ):
            if row_number > _MAX_ROWS + 1:
                break

            if (
                values is None
                or all(
                    cell is None
                    or str(cell).strip() == ""
                    for cell in values
                )
            ):
                continue

            payload = {}

            for index, header in enumerate(headers):
                if (
                    not header
                    or index >= len(values)
                ):
                    continue

                payload[header] = values[index]

            parsed.append(
                (
                    row_number,
                    payload,
                )
            )

        return parsed

    @staticmethod
    def _text(
        row: dict,
        key: str,
    ) -> str:
        value = row.get(key)

        if value is None:
            return ""

        return str(value).strip()

    @staticmethod
    def _decimal(
        row: dict,
        key: str,
        *,
        required: bool,
    ) -> Decimal:
        text = InventoryImportService._text(
            row,
            key,
        )

        if not text:
            if required:
                raise ValueError(
                    "QTY is required."
                )

            return Decimal("0")

        try:
            return Decimal(text)
        except InvalidOperation as exc:
            raise ValueError(
                f"{key.upper()} is not a number."
            ) from exc

    @staticmethod
    def _optional_decimal(
        row: dict,
        key: str,
    ):
        text = InventoryImportService._text(
            row,
            key,
        )

        if not text:
            return None

        try:
            return Decimal(text)
        except InvalidOperation as exc:
            raise ValueError(
                f"{key.upper()} is not a number."
            ) from exc

    @staticmethod
    def _bool(
        row: dict,
        key: str,
    ):
        text = (
            InventoryImportService
            ._text(row, key)
            .lower()
        )

        if not text:
            return None

        if text in _TRUE_VALUES:
            return True

        if text in _FALSE_VALUES:
            return False

        raise ValueError(
            "TRACK_STOCK must be true or false."
        )

    @staticmethod
    def _add_error(
        *,
        summary: dict,
        row: int,
        message: str,
    ) -> None:
        summary["failed"] += 1
        summary["errors"].append(
            {
                "row": row,
                "message": message,
            }
        )

    @staticmethod
    def _message(
        exc: Exception,
    ) -> str:
        detail = getattr(
            exc,
            "detail",
            None,
        )

        if isinstance(detail, dict):
            parts = []

            for value in detail.values():
                text = (
                    value[0]
                    if isinstance(
                        value,
                        (list, tuple),
                    )
                    else value
                )

                parts.append(str(text))

            if parts:
                return " ".join(parts)

        return str(exc) or "Import row failed."


class _Catalog:

    def __init__(
        self,
        company_id: int,
        rows,
        company_code_value: str,
    ):
        self.company_code = company_code_value

        skus = set()
        name_keys = set()
        branch_codes = set()
        tax_codes = set()
        needs_sku = False

        for _, row in rows:
            sku = (
                str(row.get("sku") or "")
                .strip()
                .upper()
            )

            if sku:
                skus.add(sku)
            else:
                needs_sku = True

            name = str(
                row.get("name") or ""
            ).strip()

            if name:
                name_keys.add(
                    name_key(name)
                )

            branch_code = (
                str(
                    row.get("branch_code")
                    or ""
                )
                .strip()
                .upper()
            )

            if branch_code:
                branch_codes.add(
                    branch_code
                )

            tax_code = (
                str(
                    row.get("tax_rate_code")
                    or ""
                )
                .strip()
                .upper()
            )

            if tax_code:
                tax_codes.add(tax_code)

        matched_products = (
            InventoryRepository.products_for_import(
                skus=skus,
                name_keys=name_keys,
            )
        )

        self.by_sku = {
            product.sku: product
            for product in matched_products
        }

        self.by_name = {}

        for product in matched_products:
            self.by_name.setdefault(
                product.name_key,
                product,
            )

        self.taken_skus = set(
            self.by_sku
        )

        if needs_sku:
            self.taken_skus.update(
                InventoryRepository.skus_with_prefix(
                    f"{self.company_code}-"
                )
            )

        self.branches = self._load_branches(
            company_id=company_id,
            branch_codes=branch_codes,
        )

        self.warehouses = {
            warehouse.branch_id: warehouse
            for warehouse in (
                InventoryRepository
                .list_warehouses()
            )
        }

        self.tax_rates = self._load_tax_rates(
            tax_codes=tax_codes,
        )

        product_ids = {
            product.pk
            for product in self.by_sku.values()
        }

        product_ids.update(
            product.pk
            for product in self.by_name.values()
        )

        warehouse_ids = {
            warehouse.pk
            for warehouse in self.warehouses.values()
        }

        self.ledger_pairs = (
            InventoryRepository.ledger_pairs(
                product_ids=product_ids,
                warehouse_ids=warehouse_ids,
            )
        )

    @staticmethod
    def _load_branches(
        *,
        company_id: int,
        branch_codes: set,
    ) -> dict:
        if not branch_codes:
            return {}

        branches = Branch.objects.filter(
            company_id=company_id,
            code__in=branch_codes,
        ).only(
            "id",
            "code",
        )

        return {
            branch.code.upper(): branch.pk
            for branch in branches
            if branch.code
        }

    @staticmethod
    def _load_tax_rates(
        *,
        tax_codes: set,
    ) -> dict:
        if not tax_codes:
            return {}

        from django.db.models.functions import Upper

        rates = TaxRate.objects.annotate(
            code_key=Upper("code"),
        ).filter(
            code_key__in=tax_codes,
        )

        return {
            rate.code.upper(): rate
            for rate in rates
            if rate.code
        }

    def warehouse_for(
        self,
        scope: WorkspaceScope,
        branch_code: str,
    ):
        if branch_code:
            branch_id = self.branches.get(
                branch_code
            )

            if branch_id is None:
                raise ValueError(
                    f"Unknown branch '{branch_code}'."
                )
        elif scope.branch_id:
            branch_id = scope.branch_id
        else:
            active_branch_ids = [
                branch_id
                for branch_id, warehouse
                in self.warehouses.items()
                if warehouse.status == "ACTIVE"
            ]

            if len(active_branch_ids) != 1:
                raise ValueError(
                    "Select a branch."
                )

            branch_id = active_branch_ids[0]

        warehouse = self.warehouses.get(
            branch_id
        )

        if (
            warehouse is None
            or warehouse.status != "ACTIVE"
        ):
            raise ValueError(
                "Warehouse not found."
            )

        return warehouse

    def has_ledger(
        self,
        product_id: int,
        warehouse_id: int,
    ) -> bool:
        return (
            product_id,
            warehouse_id,
        ) in self.ledger_pairs

    def remember_ledger(
        self,
        product_id: int,
        warehouse_id: int,
    ) -> None:
        self.ledger_pairs.add(
            (
                product_id,
                warehouse_id,
            )
        )