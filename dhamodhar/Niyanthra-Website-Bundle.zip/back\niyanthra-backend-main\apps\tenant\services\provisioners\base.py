from abc import (
    ABC,
    abstractmethod,
)

from apps.tenant.models import Tenant


class BaseTenantProvisioner(ABC):

    @abstractmethod
    def provision(self, *, tenant: Tenant) -> Tenant:
        raise NotImplementedError
