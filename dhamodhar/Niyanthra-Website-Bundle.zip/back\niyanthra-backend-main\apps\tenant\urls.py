from django.urls import path

from apps.tenant.views import (
    ActivateSiloTenantApiView,
    CreateTenantApiView,
    DeleteTenantsApiView,
    GetTenantsApiView,
    MyTenantApiView,
    ToggleTenantStatusApiView,
    UpdateTenantApiView,
)

app_name = "tenant"

urlpatterns = [
    path("get-tenants/", GetTenantsApiView.as_view(), name="get-tenants"),
    path("my-tenant/", MyTenantApiView.as_view(), name="my-tenant"),
    path("create-tenant/", CreateTenantApiView.as_view(), name="create-tenant"),
    path("update-tenant/", UpdateTenantApiView.as_view(), name="update-tenant"),
    path("delete-tenants/", DeleteTenantsApiView.as_view(), name="delete-tenants"),
    path(
        "toggle-tenant-status/",
        ToggleTenantStatusApiView.as_view(),
        name="toggle-tenant-status",
    ),
    path(
        "activate-silo-tenant/",
        ActivateSiloTenantApiView.as_view(),
        name="activate-silo-tenant",
    ),
]
