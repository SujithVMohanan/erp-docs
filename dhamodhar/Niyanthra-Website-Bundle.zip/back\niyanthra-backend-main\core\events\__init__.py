"""Small shared event types. Not a microservice bus."""
