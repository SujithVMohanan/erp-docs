from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated

from apps.access.schemas import (
    GetGroupsApiSchema,
    GetPermissionsApiSchema,
    GetRolesApiSchema,
    GetUserGroupAssignmentsApiSchema,
)
from apps.access.serializers import (
    CreateGroupSerializer,
    CreateUserGroupSerializer,
    CreatePermissionSerializer,
    CreateRoleSerializer,
    GetGroupsQuerySerializer,
    GetPermissionsQuerySerializer,
    GetRolesQuerySerializer,
    GroupUidsSerializer,
    PermissionUidsSerializer,
    RoleUidsSerializer,
    UpdateGroupSerializer,
    UpdatePermissionSerializer,
    UpdateRoleSerializer,
)
from apps.access.services.group_service import GroupService
from apps.access.services.user_group_service import UserGroupService
from apps.access.services.permission_service import PermissionService
from apps.access.services.role_service import RoleService
from core.pagination import RestPagination
from core.permissions import (
    HasMembershipAccess,
    IsAppAuthenticated,
    IsPlatformAdmin,
)
from core.responses import ResponseInfo
from core.utils.exceptions import ExceptionHandler


class PermissionBaseApiView:
    response_schema = GetPermissionsApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class RoleBaseApiView:
    response_schema = GetRolesApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class UserGroupBaseApiView:
    response_schema = GetUserGroupAssignmentsApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class GroupBaseApiView:
    response_schema = GetGroupsApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class GetPermissionsApiView(PermissionBaseApiView, generics.ListAPIView):

    serializer_class       = GetPermissionsApiSchema
    query_serializer_class = GetPermissionsQuerySerializer
    pagination_class       = RestPagination
    permission_classes     = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]

    @swagger_auto_schema(
        tags=["Permissions"],
        manual_parameters=[
            openapi.Parameter(
                "uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "codename",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "content_type",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "name",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
        ],
        operation_summary="Get permissions",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(
            data=self.request.query_params
        )
        query.is_valid(raise_exception=True)

        return PermissionService.get_permissions(
            validated_data=query.validated_data
        )


class CreatePermissionApiView(PermissionBaseApiView, generics.CreateAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = CreatePermissionSerializer

    @swagger_auto_schema(
        request_body=CreatePermissionSerializer,
        tags=["Permissions"],
        operation_summary="Create permission",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            permission = PermissionService.create_permission(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.created(
                self.response_schema(permission).data,
                message="Permission created successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdatePermissionApiView(PermissionBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = UpdatePermissionSerializer

    @swagger_auto_schema(
        request_body=UpdatePermissionSerializer,
        tags=["Permissions"],
        operation_summary="Update permission",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            permission = PermissionService.update_permission(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(permission).data,
                message="Permission updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeletePermissionsApiView(PermissionBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = PermissionUidsSerializer

    @swagger_auto_schema(
        request_body=PermissionUidsSerializer,
        tags=["Permissions"],
        operation_summary="Delete permissions",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = PermissionService.delete_permissions(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                payload,
                message="Permission(s) deleted successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class GetRolesApiView(RoleBaseApiView, generics.ListAPIView):

    serializer_class       = GetRolesApiSchema
    query_serializer_class = GetRolesQuerySerializer
    pagination_class       = RestPagination
    permission_classes     = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "query"
    membership_company_field = "company_uid"
    membership_company_required = True

    @swagger_auto_schema(
        tags=["Roles"],
        manual_parameters=[
            openapi.Parameter(
                "uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "company_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "name",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "is_active",
                openapi.IN_QUERY,
                type=openapi.TYPE_BOOLEAN,
            ),
        ],
        operation_summary="Get roles",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(
            data=self.request.query_params
        )
        query.is_valid(raise_exception=True)

        return RoleService.get_roles(
            validated_data=query.validated_data
        )


class CreateRoleApiView(RoleBaseApiView, generics.CreateAPIView):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "data"
    membership_company_field = "company_uid"
    serializer_class = CreateRoleSerializer

    @swagger_auto_schema(
        request_body=CreateRoleSerializer,
        tags=["Roles"],
        operation_summary="Create role",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            role = RoleService.create_role(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.created(
                self.response_schema(role).data,
                message="Role created successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateRoleApiView(RoleBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "data"
    membership_company_field = "company_uid"
    serializer_class = UpdateRoleSerializer

    @swagger_auto_schema(
        request_body=UpdateRoleSerializer,
        tags=["Roles"],
        operation_summary="Update role",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            role = RoleService.update_role(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(role).data,
                message="Role updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteRolesApiView(RoleBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "role_uids"
    serializer_class = RoleUidsSerializer

    @swagger_auto_schema(
        request_body=RoleUidsSerializer,
        tags=["Roles"],
        operation_summary="Delete roles",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = RoleService.delete_roles(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                payload,
                message="Role(s) deleted successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class InactiveActiveRolesApiView(RoleBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "role_uids"
    serializer_class = RoleUidsSerializer

    @swagger_auto_schema(
        request_body=RoleUidsSerializer,
        tags=["Roles"],
        operation_summary="Toggle role active status",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            roles = RoleService.toggle_roles(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(roles, many=True).data,
                message="Role status updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class GetGroupsApiView(GroupBaseApiView, generics.ListAPIView):

    serializer_class       = GetGroupsApiSchema
    query_serializer_class = GetGroupsQuerySerializer
    pagination_class       = RestPagination
    permission_classes     = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "query"
    membership_company_field = "company_uid"
    membership_company_required = True

    @swagger_auto_schema(
        tags=["Groups"],
        manual_parameters=[
            openapi.Parameter(
                "uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "company_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "name",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "is_active",
                openapi.IN_QUERY,
                type=openapi.TYPE_BOOLEAN,
            ),
        ],
        operation_summary="Get groups",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(
            data=self.request.query_params
        )
        query.is_valid(raise_exception=True)

        return GroupService.get_groups(
            validated_data=query.validated_data
        )


class CreateGroupApiView(GroupBaseApiView, generics.CreateAPIView):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "data"
    membership_company_field = "company_uid"
    serializer_class = CreateGroupSerializer

    @swagger_auto_schema(
        request_body=CreateGroupSerializer,
        tags=["Groups"],
        operation_summary="Create group",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            group = GroupService.create_group(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.created(
                self.response_schema(group).data,
                message="Group created successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateGroupApiView(GroupBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "data"
    membership_company_field = "company_uid"
    serializer_class = UpdateGroupSerializer

    @swagger_auto_schema(
        request_body=UpdateGroupSerializer,
        tags=["Groups"],
        operation_summary="Update group",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            group = GroupService.update_group(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(group).data,
                message="Group updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteGroupsApiView(GroupBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "group_uids"
    serializer_class = GroupUidsSerializer

    @swagger_auto_schema(
        request_body=GroupUidsSerializer,
        tags=["Groups"],
        operation_summary="Delete groups",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = GroupService.delete_groups(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                payload,
                message="Group(s) deleted successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class InactiveActiveGroupsApiView(GroupBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "group_uids"
    serializer_class = GroupUidsSerializer

    @swagger_auto_schema(
        request_body=GroupUidsSerializer,
        tags=["Groups"],
        operation_summary="Toggle group active status",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            groups = GroupService.toggle_groups(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(groups, many=True).data,
                message="Group status updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class CreateUserGroupApiView(UserGroupBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "data"
    membership_company_field = "company_uid"
    serializer_class = CreateUserGroupSerializer

    @swagger_auto_schema(
        request_body=CreateUserGroupSerializer,
        tags=["User Groups"],
        operation_summary="Assign groups to a user",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            assignments = UserGroupService.replace_assignments(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.created(
                self.response_schema(assignments, many=True).data,
                message="User groups added successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateUserGroupApiView(UserGroupBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "data"
    membership_company_field = "company_uid"
    serializer_class = CreateUserGroupSerializer

    @swagger_auto_schema(
        request_body=CreateUserGroupSerializer,
        tags=["User Groups"],
        operation_summary="Replace a user's company groups",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            assignments = UserGroupService.replace_assignments(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(assignments, many=True).data,
                message="User groups updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)
