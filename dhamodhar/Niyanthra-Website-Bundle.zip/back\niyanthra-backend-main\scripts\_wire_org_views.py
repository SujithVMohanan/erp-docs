"""Append organization membership/location views and update urls."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

VIEWS_APPEND = r'''

class OrganizationMembershipBaseApiView:
    response_schema = GetOrganizationMembershipsApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class GetOrganizationMembershipsApiView(
    OrganizationMembershipBaseApiView,
    generics.ListAPIView,
):

    serializer_class = GetOrganizationMembershipsApiSchema
    query_serializer_class = GetOrganizationMembershipsQuerySerializer
    pagination_class = RestPagination
    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]

    @swagger_auto_schema(
        tags=["Organization Memberships"],
        manual_parameters=[
            openapi.Parameter("uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("organization_uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("user_uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("role", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("is_active", openapi.IN_QUERY, type=openapi.TYPE_BOOLEAN),
        ],
        operation_summary="Get organization memberships",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(data=self.request.query_params)
        query.is_valid(raise_exception=True)
        return OrganizationMembershipService.get_memberships(
            validated_data=query.validated_data
        )


class CreateOrganizationMembershipApiView(
    OrganizationMembershipBaseApiView,
    generics.CreateAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = CreateOrganizationMembershipSerializer

    @swagger_auto_schema(
        request_body=CreateOrganizationMembershipSerializer,
        tags=["Organization Memberships"],
        operation_summary="Create organization membership",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            membership = OrganizationMembershipService.create_membership(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.created(
                self.response_schema(membership).data,
                message="Organization membership created successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateOrganizationMembershipApiView(
    OrganizationMembershipBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = UpdateOrganizationMembershipSerializer

    @swagger_auto_schema(
        request_body=UpdateOrganizationMembershipSerializer,
        tags=["Organization Memberships"],
        operation_summary="Update organization membership",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            membership = OrganizationMembershipService.update_membership(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                self.response_schema(membership).data,
                message="Organization membership updated successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteOrganizationMembershipsApiView(
    OrganizationMembershipBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = OrganizationMembershipUidsSerializer

    @swagger_auto_schema(
        request_body=OrganizationMembershipUidsSerializer,
        tags=["Organization Memberships"],
        operation_summary="Delete organization memberships",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            payload = OrganizationMembershipService.delete_memberships(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                payload,
                message="Organization membership(s) deleted successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class InactiveActiveOrganizationMembershipsApiView(
    OrganizationMembershipBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = OrganizationMembershipUidsSerializer

    @swagger_auto_schema(
        request_body=OrganizationMembershipUidsSerializer,
        tags=["Organization Memberships"],
        operation_summary="Toggle organization membership active status",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            memberships = OrganizationMembershipService.toggle_memberships(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                self.response_schema(memberships, many=True).data,
                message="Organization membership status updated successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class OrganizationLocationBaseApiView:
    response_schema = GetOrganizationLocationsApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class GetOrganizationLocationsApiView(
    OrganizationLocationBaseApiView,
    generics.ListAPIView,
):

    serializer_class = GetOrganizationLocationsApiSchema
    query_serializer_class = GetOrganizationLocationsQuerySerializer
    pagination_class = RestPagination
    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]

    @swagger_auto_schema(
        tags=["Organization Locations"],
        manual_parameters=[
            openapi.Parameter("uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("organization_uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("location_uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("is_primary", openapi.IN_QUERY, type=openapi.TYPE_BOOLEAN),
        ],
        operation_summary="Get organization locations",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(data=self.request.query_params)
        query.is_valid(raise_exception=True)
        return OrganizationLocationService.get_links(
            validated_data=query.validated_data
        )


class CreateOrganizationLocationApiView(
    OrganizationLocationBaseApiView,
    generics.CreateAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = CreateOrganizationLocationSerializer

    @swagger_auto_schema(
        request_body=CreateOrganizationLocationSerializer,
        tags=["Organization Locations"],
        operation_summary="Create organization location",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            link = OrganizationLocationService.create_link(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.created(
                self.response_schema(link).data,
                message="Organization location created successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateOrganizationLocationApiView(
    OrganizationLocationBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = UpdateOrganizationLocationSerializer

    @swagger_auto_schema(
        request_body=UpdateOrganizationLocationSerializer,
        tags=["Organization Locations"],
        operation_summary="Update organization location",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            link = OrganizationLocationService.update_link(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                self.response_schema(link).data,
                message="Organization location updated successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteOrganizationLocationsApiView(
    OrganizationLocationBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = OrganizationLocationUidsSerializer

    @swagger_auto_schema(
        request_body=OrganizationLocationUidsSerializer,
        tags=["Organization Locations"],
        operation_summary="Delete organization locations",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            payload = OrganizationLocationService.delete_links(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                payload,
                message="Organization location(s) deleted successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)
'''

views_path = ROOT / "apps/organization/views.py"
views = views_path.read_text(encoding="utf-8")
if "GetOrganizationMembershipsApiView" not in views:
    # patch imports
    views = views.replace(
        "from apps.organization.schemas import (\n    GetCountriesApiSchema,\n    GetIndustriesApiSchema,\n    GetOrganizationsApiSchema,\n)",
        "from apps.organization.schemas import (\n    GetCountriesApiSchema,\n    GetIndustriesApiSchema,\n    GetOrganizationLocationsApiSchema,\n    GetOrganizationMembershipsApiSchema,\n    GetOrganizationsApiSchema,\n)",
    )
    views = views.replace(
        "from apps.organization.serializers import (\n    CountryUidsSerializer,\n    CreateCountrySerializer,\n    CreateIndustrySerializer,\n    CreateOrganizationSerializer,\n    GetCountriesQuerySerializer,\n    GetIndustriesQuerySerializer,\n    GetOrganizationsQuerySerializer,\n    IndustryUidsSerializer,\n    OrganizationUidsSerializer,\n    UpdateCountrySerializer,\n    UpdateIndustrySerializer,\n    UpdateOrganizationSerializer,\n)",
        "from apps.organization.serializers import (\n    CountryUidsSerializer,\n    CreateCountrySerializer,\n    CreateIndustrySerializer,\n    CreateOrganizationLocationSerializer,\n    CreateOrganizationMembershipSerializer,\n    CreateOrganizationSerializer,\n    GetCountriesQuerySerializer,\n    GetIndustriesQuerySerializer,\n    GetOrganizationLocationsQuerySerializer,\n    GetOrganizationMembershipsQuerySerializer,\n    GetOrganizationsQuerySerializer,\n    IndustryUidsSerializer,\n    OrganizationLocationUidsSerializer,\n    OrganizationMembershipUidsSerializer,\n    OrganizationUidsSerializer,\n    UpdateCountrySerializer,\n    UpdateIndustrySerializer,\n    UpdateOrganizationLocationSerializer,\n    UpdateOrganizationMembershipSerializer,\n    UpdateOrganizationSerializer,\n)",
    )
    if "OrganizationMembershipService" not in views:
        views = views.replace(
            "from apps.organization.services.organization_service import OrganizationService",
            "from apps.organization.services.organization_location_service import (\n    OrganizationLocationService,\n)\nfrom apps.organization.services.organization_membership_service import (\n    OrganizationMembershipService,\n)\nfrom apps.organization.services.organization_service import OrganizationService",
        )
    views_path.write_text(views.rstrip() + "\n" + VIEWS_APPEND, encoding="utf-8")
    print("patched organization views")
else:
    print("organization views already patched")

URLS = '''from django.urls import path

from apps.organization.views import (
    CreateCountryApiView,
    CreateIndustryApiView,
    CreateOrganizationApiView,
    CreateOrganizationLocationApiView,
    CreateOrganizationMembershipApiView,
    DeleteCountriesApiView,
    DeleteIndustriesApiView,
    DeleteOrganizationLocationsApiView,
    DeleteOrganizationMembershipsApiView,
    DeleteOrganizationsApiView,
    GetCountriesApiView,
    GetIndustriesApiView,
    GetOrganizationLocationsApiView,
    GetOrganizationMembershipsApiView,
    GetOrganizationsApiView,
    InactiveActiveCountriesApiView,
    InactiveActiveIndustriesApiView,
    InactiveActiveOrganizationMembershipsApiView,
    InactiveActiveOrganizationsApiView,
    UpdateCountryApiView,
    UpdateIndustryApiView,
    UpdateOrganizationApiView,
    UpdateOrganizationLocationApiView,
    UpdateOrganizationMembershipApiView,
)

app_name = "organization"

urlpatterns = [
    path("get-countries/", GetCountriesApiView.as_view(), name="get-countries"),
    path("create-country/", CreateCountryApiView.as_view(), name="create-country"),
    path("update-country/", UpdateCountryApiView.as_view(), name="update-country"),
    path("delete-countries/", DeleteCountriesApiView.as_view(), name="delete-countries"),
    path(
        "inactive-active-countries/",
        InactiveActiveCountriesApiView.as_view(),
        name="inactive-active-countries",
    ),
    path("get-industries/", GetIndustriesApiView.as_view(), name="get-industries"),
    path("create-industry/", CreateIndustryApiView.as_view(), name="create-industry"),
    path("update-industry/", UpdateIndustryApiView.as_view(), name="update-industry"),
    path(
        "delete-industries/",
        DeleteIndustriesApiView.as_view(),
        name="delete-industries",
    ),
    path(
        "inactive-active-industries/",
        InactiveActiveIndustriesApiView.as_view(),
        name="inactive-active-industries",
    ),
    path("get-organizations/", GetOrganizationsApiView.as_view(), name="get-organizations"),
    path(
        "create-organization/",
        CreateOrganizationApiView.as_view(),
        name="create-organization",
    ),
    path(
        "update-organization/",
        UpdateOrganizationApiView.as_view(),
        name="update-organization",
    ),
    path(
        "delete-organizations/",
        DeleteOrganizationsApiView.as_view(),
        name="delete-organizations",
    ),
    path(
        "inactive-active-organizations/",
        InactiveActiveOrganizationsApiView.as_view(),
        name="inactive-active-organizations",
    ),
    path(
        "get-organization-memberships/",
        GetOrganizationMembershipsApiView.as_view(),
        name="get-organization-memberships",
    ),
    path(
        "create-organization-membership/",
        CreateOrganizationMembershipApiView.as_view(),
        name="create-organization-membership",
    ),
    path(
        "update-organization-membership/",
        UpdateOrganizationMembershipApiView.as_view(),
        name="update-organization-membership",
    ),
    path(
        "delete-organization-memberships/",
        DeleteOrganizationMembershipsApiView.as_view(),
        name="delete-organization-memberships",
    ),
    path(
        "inactive-active-organization-memberships/",
        InactiveActiveOrganizationMembershipsApiView.as_view(),
        name="inactive-active-organization-memberships",
    ),
    path(
        "get-organization-locations/",
        GetOrganizationLocationsApiView.as_view(),
        name="get-organization-locations",
    ),
    path(
        "create-organization-location/",
        CreateOrganizationLocationApiView.as_view(),
        name="create-organization-location",
    ),
    path(
        "update-organization-location/",
        UpdateOrganizationLocationApiView.as_view(),
        name="update-organization-location",
    ),
    path(
        "delete-organization-locations/",
        DeleteOrganizationLocationsApiView.as_view(),
        name="delete-organization-locations",
    ),
]
'''
(ROOT / "apps/organization/urls.py").write_text(URLS, encoding="utf-8")
print("wrote organization urls")
