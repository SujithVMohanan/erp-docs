from decimal import Decimal
from io import BytesIO

from django.conf import settings
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from openpyxl import Workbook
from rest_framework.test import APIClient

from apps.company.models import (
    Branch,
    Company,
    CompanyMembership,
    CompanyModule,
)
from apps.company.services.branch_service import BranchService
from apps.inventory.models import (
    Product,
    StockSummary,
    Warehouse,
)
from apps.inventory.services.product_service import ProductService
from apps.location.models import Country
from apps.organization.models import Organization
from apps.tenant.models import (
    Tenant,
    TenantDatabase,
)
from apps.users.models import Users
from core.tenant import tenant_context
from core.tenant.workspace import WorkspaceScope
from core.utils.ids import encode_id
from core.utils.tokens import issue_workspace_tokens
from infrastructure.database.context import (
    clear_current_db_alias,
    set_current_db_alias,
)

PASSWORD = "ValidPassw0rd!"


class InventoryApiTests(TestCase):

    databases = {"default", settings.SHARED_DB_ALIAS}

    def setUp(self):
        self.client = APIClient()
        self.user = Users.objects.create_user(
            email="inventory@example.com",
            password=PASSWORD,
            username="inventory",
            phone_number="+15550008888",
            profile_completed=True,
        )
        self.country = Country.objects.create(name="India", code="IN")
        self.organization = Organization.objects.create(
            name="Inventory Org",
            code="IORG",
            legal_name="Inventory Org Pvt",
            country=self.country,
        )
        self.tenant = Tenant.objects.create(
            name="Shared Inventory",
            slug="shared-inventory",
            tenant_type=Tenant.TenantType.SHARED,
            db_alias="shared_inventory",
            provisioning_status=Tenant.ProvisioningStatus.ACTIVE,
            is_active=True,
        )
        TenantDatabase.objects.create(
            tenant=self.tenant,
            db_alias="shared_inventory",
            provisioning_status=TenantDatabase.ProvisioningStatus.ACTIVE,
            is_current=True,
        )
        self.company = Company.objects.create(
            organization=self.organization,
            name="Inventory Co",
            code="ICO",
            tenant=self.tenant,
        )
        CompanyModule.objects.create(
            company=self.company,
            modules={"inventory": True, "sales": True},
        )
        CompanyMembership.objects.create(
            company=self.company,
            user=self.user,
            role=CompanyMembership.Role.OWNER,
            is_active=True,
        )
        self.branch = Branch.objects.create(
            company=self.company,
            name="Main",
            code="HQ",
            status="ACTIVE",
        )
        self.other = Branch.objects.create(
            company=self.company,
            name="Plant",
            code="PLT",
            status="ACTIVE",
        )
        set_current_db_alias(settings.SHARED_DB_ALIAS)
        with tenant_context(tenant_id=self.tenant.pk, company_id=self.company.pk):
            from apps.inventory.services.warehouse_service import WarehouseService

            WarehouseService.sync_current()
        clear_current_db_alias()
        tokens = issue_workspace_tokens(
            self.user,
            company=self.company,
            tenant=self.tenant,
            branch=self.branch,
        )
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")
        self.scope = WorkspaceScope(
            company_id=self.company.pk,
            tenant_id=self.tenant.pk,
            branch_id=self.branch.pk,
            db_alias=settings.SHARED_DB_ALIAS,
        )

    def _summary(self, sku="ICO-00001"):
        set_current_db_alias(settings.SHARED_DB_ALIAS)
        with tenant_context(tenant_id=self.tenant.pk, company_id=self.company.pk):
            product = Product.objects.get(sku=sku)
            row = StockSummary.objects.select_related("warehouse").get(product=product)
            return product, row

    def test_create_product_posts_opening_stock(self):
        response = self.client.post(
            "/api/inventory/create-product/",
            {"name": "Tea Powder", "opening_qty": "10", "unit_cost": "25"},
            format="json",
        )
        self.assertEqual(response.status_code, 201, response.data)
        self.assertEqual(response.data["data"]["sku"], "ICO-00001")
        self.assertEqual(response.data["data"]["uom_code"], "PCS")
        product, row = self._summary()
        self.assertEqual(row.qty_on_hand, Decimal("10.0000"))
        self.assertEqual(product.cost_price, Decimal("25.0000"))
        self.assertEqual(product.selling_price, Decimal("25.0000"))
        self.assertEqual(row.warehouse.branch_id, self.branch.pk)

    def test_receive_updates_weighted_cost_and_replays_client_ref(self):
        self.client.post(
            "/api/inventory/create-product/",
            {"name": "Sugar", "opening_qty": "10", "unit_cost": "10", "sku": "SUGAR"},
            format="json",
        )
        product_uid = self.client.get(
            "/api/inventory/get-products/",
            {"sku": "SUGAR"},
        ).data["data"]["results"][0]["uid"]
        payload = {
            "client_ref": "GRN-1",
            "lines": [
                {"product_uid": product_uid, "quantity": "10", "unit_cost": "30"},
            ],
        }
        first = self.client.post("/api/inventory/receive-stock/", payload, format="json")
        second = self.client.post("/api/inventory/receive-stock/", payload, format="json")
        self.assertEqual(first.status_code, 201, first.data)
        self.assertEqual(second.status_code, 200, second.data)
        self.assertEqual(first.data["data"]["doc_number"], second.data["data"]["doc_number"])
        product, row = self._summary("SUGAR")
        self.assertEqual(row.qty_on_hand, Decimal("20.0000"))
        self.assertEqual(product.cost_price, Decimal("20.0000"))

    def test_adjust_below_zero_rolls_back(self):
        self.client.post(
            "/api/inventory/create-product/",
            {"name": "Salt", "opening_qty": "5", "sku": "SALT"},
            format="json",
        )
        product_uid = self.client.get(
            "/api/inventory/get-products/",
            {"sku": "SALT"},
        ).data["data"]["results"][0]["uid"]
        response = self.client.post(
            "/api/inventory/adjust-stock/",
            {"lines": [{"product_uid": product_uid, "quantity": "-6"}]},
            format="json",
        )
        self.assertEqual(response.status_code, 400, response.data)
        self.assertEqual(response.data["code"], "INSUFFICIENT_STOCK")
        _product, row = self._summary("SALT")
        self.assertEqual(row.qty_on_hand, Decimal("5.0000"))

    def test_transfer_moves_both_warehouses(self):
        created = self.client.post(
            "/api/inventory/create-product/",
            {"name": "Rice", "opening_qty": "10", "sku": "RICE"},
            format="json",
        )
        product_uid = created.data["data"]["uid"]
        response = self.client.post(
            "/api/inventory/transfer-stock/",
            {
                "to_branch_uid": encode_id(self.other.pk),
                "lines": [{"product_uid": product_uid, "quantity": "4"}],
            },
            format="json",
        )
        self.assertEqual(response.status_code, 201, response.data)
        set_current_db_alias(settings.SHARED_DB_ALIAS)
        with tenant_context(tenant_id=self.tenant.pk, company_id=self.company.pk):
            rows = {
                row.warehouse.branch_id: row.qty_on_hand
                for row in StockSummary.objects.select_related("warehouse")
            }
        self.assertEqual(rows[self.branch.pk], Decimal("6.0000"))
        self.assertEqual(rows[self.other.pk], Decimal("4.0000"))

    def test_import_name_and_qty_then_reupload_keeps_quantity(self):
        def workbook():
            book = Workbook()
            sheet = book.active
            sheet.title = "inventory"
            sheet.append(["NAME", "QTY"])
            sheet.append(["Coffee", 8])
            handle = BytesIO()
            book.save(handle)
            handle.seek(0)
            return handle.getvalue()

        upload = SimpleUploadedFile(
            "inventory.xlsx",
            workbook(),
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        first = self.client.post(
            "/api/inventory/import-inventory/",
            {"file": upload},
            format="multipart",
        )
        self.assertEqual(first.status_code, 200, first.data)
        self.assertEqual(first.data["data"]["created"], 1)
        self.assertEqual(first.data["data"]["opened"], 1)
        upload = SimpleUploadedFile(
            "inventory.xlsx",
            workbook(),
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        second = self.client.post(
            "/api/inventory/import-inventory/",
            {"file": upload},
            format="multipart",
        )
        self.assertEqual(second.status_code, 200, second.data)
        self.assertEqual(second.data["data"]["unchanged"], 1)
        self.assertEqual(second.data["data"]["opened"], 0)
        _product, row = self._summary()
        self.assertEqual(row.qty_on_hand, Decimal("8.0000"))

    def test_module_disabled(self):
        CompanyModule.objects.filter(company=self.company).update(
            modules={"inventory": False},
        )
        response = self.client.get("/api/inventory/get-units/")
        self.assertEqual(response.status_code, 403, response.data)
        self.assertEqual(response.data["code"], "MODULE_DISABLED")

    def test_branch_create_adds_warehouse(self):
        BranchService.create_branch(
            validated_data={
                "company_uid": encode_id(self.company.pk),
                "name": "Depot",
                "code": "DEP",
                "status": "ACTIVE",
            },
            actor=self.user,
        )
        set_current_db_alias(settings.SHARED_DB_ALIAS)
        with tenant_context(tenant_id=self.tenant.pk, company_id=self.company.pk):
            self.assertTrue(
                Warehouse.objects.filter(code="DEP", status="ACTIVE").exists()
            )
        clear_current_db_alias()


class InventoryServiceScopeTests(TestCase):

    databases = {"default", settings.SHARED_DB_ALIAS}

    def test_opening_is_scoped_to_workspace_company(self):
        set_current_db_alias(settings.SHARED_DB_ALIAS)
        scope = WorkspaceScope(company_id=10, tenant_id=100)
        try:
            ProductService.create_product(
                scope=scope,
                validated_data={"name": "Scoped", "track_stock": False},
            )
            product = Product.all_objects.get(name="Scoped")
            self.assertEqual(product.company_id, 10)
            self.assertEqual(product.tenant_id, 100)
        finally:
            clear_current_db_alias()
