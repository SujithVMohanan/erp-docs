from django.apps import AppConfig


class SeedersConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "core.seeders"
    label = "seeders"
    verbose_name = "Seeders"
