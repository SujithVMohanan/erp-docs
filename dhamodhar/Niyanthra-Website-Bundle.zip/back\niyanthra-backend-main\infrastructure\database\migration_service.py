import importlib
import logging

from django.apps import apps
from django.conf import settings
from django.core.management import call_command

from apps.tenant.models import Tenant
from apps.tenant.repository import TenantRepository
from infrastructure.database.labels import (
    control_migrate_labels,
    tenant_app_labels,
)
from infrastructure.database.loader import TenantConnectionLoader
from infrastructure.database.migrator import TenantMigrator

logger = logging.getLogger("niyanthra")

_DATA_PLANE_TYPES = (
    Tenant.TenantType.ISOLATED,
    Tenant.TenantType.SILO,
)


class DatabaseMigrationService:
    """
    Control DB and data-plane DB migrations.

    default  — control apps only
    shared   — tenant apps only, one database for every SHARED tenant
    isolated — tenant apps only, one database per active/inactive tenant
    silo     — tenant apps only, one database per active/inactive tenant

    migrate_all = control + shared + active isolated + active silo.
    Inactive isolated/silo databases use migrate_inactive.
    """

    @staticmethod
    def _labels_with_migrations(labels: list[str]) -> list[str]:
        ready = []
        for label in labels:
            try:
                config = apps.get_app_config(label)
            except LookupError:
                continue
            try:
                importlib.import_module(f"{config.name}.migrations")
            except ModuleNotFoundError:
                continue
            ready.append(label)
        return ready

    @staticmethod
    def _migrate_labels(
        *,
        database: str,
        labels: list[str],
        verbosity: int,
    ) -> list[str]:
        applied = DatabaseMigrationService._labels_with_migrations(labels)
        for label in applied:
            logger.info("migrate app=%s database=%s", label, database)
            call_command(
                "migrate",
                label,
                database=database,
                interactive=False,
                verbosity=verbosity,
            )
        return applied

    @staticmethod
    def migrate_control(*, verbosity: int = 1) -> dict:
        logger.info("migrate_control start")
        applied = DatabaseMigrationService._migrate_labels(
            database="default",
            labels=control_migrate_labels(),
            verbosity=verbosity,
        )
        logger.info("migrate_control done apps=%s", applied)
        return {
            "database": "default",
            "apps": applied,
            "ok": True,
        }

    @staticmethod
    def migrate_shared(*, verbosity: int = 1) -> dict:
        alias = settings.SHARED_DB_ALIAS
        if alias == "default":
            raise ValueError(
                "SHARED_DB_ALIAS cannot be 'default'. "
                "Shared data must not use the control database."
            )

        logger.info("migrate_shared start alias=%s", alias)
        TenantMigrator.migrate(alias=alias, verbosity=verbosity)
        return {
            "database": alias,
            "apps": tenant_app_labels(),
            "ok": True,
        }

    @staticmethod
    def _ensure_tenant_connection(*, tenant: Tenant) -> None:
        if TenantConnectionLoader.ensure_alias(tenant.db_alias):
            return

        current_db = TenantRepository.get_current_database(tenant)
        if (
            current_db is None
            or not current_db.db_name
            or not current_db.host
            or not current_db.port
        ):
            raise ValueError(
                f"Tenant '{tenant.slug}' has incomplete database connection metadata."
            )

        TenantConnectionLoader.register_tenant_database(
            db_alias=tenant.db_alias,
            db_name=current_db.db_name,
            host=current_db.host,
            port=current_db.port,
            secret_arn=current_db.secret_arn,
            secret_name=current_db.secret_name,
        )

    @staticmethod
    def migrate_tenant(
        *,
        tenant: Tenant,
        verbosity: int = 1,
    ) -> dict:
        if tenant.tenant_type == Tenant.TenantType.SHARED:
            raise ValueError(
                f"Tenant '{tenant.slug}' is SHARED. "
                "Use migrate_shared for the shared database."
            )

        DatabaseMigrationService._ensure_tenant_connection(tenant=tenant)
        TenantMigrator.migrate(alias=tenant.db_alias, verbosity=verbosity)
        return {
            "tenant": tenant.slug,
            "tenant_type": tenant.tenant_type,
            "db_alias": tenant.db_alias,
            "apps": tenant_app_labels(),
            "ok": True,
        }

    @staticmethod
    def migrate_tenant_by_alias(
        *,
        db_alias: str,
        verbosity: int = 1,
        require_active: bool = False,
    ) -> dict:
        if db_alias in {"default", settings.SHARED_DB_ALIAS}:
            raise ValueError(
                "Use migrate_control or migrate_shared for that database."
            )

        tenant = Tenant.objects.filter(db_alias=db_alias).first()
        if tenant is None:
            raise ValueError(f"No tenant found for db_alias='{db_alias}'.")

        if require_active and not tenant.is_ready:
            raise ValueError(
                f"Tenant '{tenant.slug}' is not ACTIVE/ready."
            )

        return DatabaseMigrationService.migrate_tenant(
            tenant=tenant,
            verbosity=verbosity,
        )

    @staticmethod
    def _tenants(*, tenant_types: tuple[str, ...], active: bool) -> list[Tenant]:
        queryset = Tenant.objects.filter(tenant_type__in=tenant_types)
        if active:
            queryset = queryset.filter(
                provisioning_status=Tenant.ProvisioningStatus.ACTIVE,
                is_active=True,
            )
        else:
            queryset = queryset.exclude(
                provisioning_status=Tenant.ProvisioningStatus.ACTIVE,
                is_active=True,
            )
        return list(queryset.order_by("id"))

    @staticmethod
    def _migrate_tenants(
        *,
        tenants: list[Tenant],
        verbosity: int,
    ) -> dict:
        results = []
        failures = 0

        for tenant in tenants:
            try:
                results.append(
                    DatabaseMigrationService.migrate_tenant(
                        tenant=tenant,
                        verbosity=verbosity,
                    )
                )
            except Exception as exc:
                failures += 1
                logger.exception(
                    "migrate_tenant_failed slug=%s alias=%s",
                    tenant.slug,
                    tenant.db_alias,
                )
                results.append(
                    {
                        "tenant": tenant.slug,
                        "tenant_type": tenant.tenant_type,
                        "db_alias": tenant.db_alias,
                        "ok": False,
                        "error": str(exc),
                    }
                )

        return {
            "count": len(tenants),
            "failures": failures,
            "results": results,
        }

    @staticmethod
    def migrate_isolated(*, verbosity: int = 1) -> dict:
        tenants = DatabaseMigrationService._tenants(
            tenant_types=(Tenant.TenantType.ISOLATED,),
            active=True,
        )
        result = DatabaseMigrationService._migrate_tenants(
            tenants=tenants,
            verbosity=verbosity,
        )
        result["tenant_type"] = Tenant.TenantType.ISOLATED
        result["active"] = True
        return result

    @staticmethod
    def migrate_silo(*, verbosity: int = 1) -> dict:
        tenants = DatabaseMigrationService._tenants(
            tenant_types=(Tenant.TenantType.SILO,),
            active=True,
        )
        result = DatabaseMigrationService._migrate_tenants(
            tenants=tenants,
            verbosity=verbosity,
        )
        result["tenant_type"] = Tenant.TenantType.SILO
        result["active"] = True
        return result

    @staticmethod
    def migrate_active_tenants(*, verbosity: int = 1) -> dict:
        tenants = DatabaseMigrationService._tenants(
            tenant_types=_DATA_PLANE_TYPES,
            active=True,
        )
        result = DatabaseMigrationService._migrate_tenants(
            tenants=tenants,
            verbosity=verbosity,
        )
        result["active"] = True
        return result

    @staticmethod
    def migrate_inactive(*, verbosity: int = 1) -> dict:
        tenants = DatabaseMigrationService._tenants(
            tenant_types=_DATA_PLANE_TYPES,
            active=False,
        )
        result = DatabaseMigrationService._migrate_tenants(
            tenants=tenants,
            verbosity=verbosity,
        )
        result["active"] = False
        return result

    @staticmethod
    def migrate_all(*, verbosity: int = 1) -> dict:
        control = DatabaseMigrationService.migrate_control(verbosity=verbosity)
        shared = DatabaseMigrationService.migrate_shared(verbosity=verbosity)
        tenants = DatabaseMigrationService.migrate_active_tenants(
            verbosity=verbosity,
        )
        return {
            "control": control,
            "shared": shared,
            "tenants": tenants,
            "ok": tenants.get("failures", 0) == 0,
        }
