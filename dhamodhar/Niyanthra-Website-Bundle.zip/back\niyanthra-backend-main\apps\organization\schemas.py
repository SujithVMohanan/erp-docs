from rest_framework import serializers

from apps.location.models import Country
from apps.organization.models import (
    Industry,
    Organization,
    OrganizationLocation,
    OrganizationMembership,
)
from core.utils.ids import encode_id


class GetCountriesApiSchema(serializers.ModelSerializer):
    uid = serializers.SerializerMethodField()

    class Meta:
        model = Country
        fields = [
            "uid",
            "public_id",
            "name",
            "code",
            "iso3",
            "phone_code",
            "currency_code",
            "is_active",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data


class GetIndustriesApiSchema(serializers.ModelSerializer):
    uid = serializers.SerializerMethodField()

    class Meta:
        model = Industry
        fields = [
            "uid",
            "public_id",
            "name",
            "code",
            "is_active",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data



class GetOrganizationsApiSchema(serializers.ModelSerializer):

    uid = serializers.SerializerMethodField()
    country = serializers.SerializerMethodField()
    industries = serializers.SerializerMethodField()

    class Meta:
        model = Organization
        fields = [
            "uid",
            "public_id",
            "name",
            "code",
            "legal_name",
            "description",
            "logo",
            "email",
            "phone_number",
            "website",
            "timezone",
            "is_active",
            "country",
            "industries",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_country(self, instance) -> dict | None:
        country = instance.country

        if country is None:
            return None

        return {
            "uid": encode_id(country.pk),
            "public_id": str(country.public_id),
            "name": country.name,
            "code": country.code,
        }

    def get_industries(self, instance) -> list[dict]:
        return [
            {
                "uid": encode_id(industry.pk),
                "public_id": str(industry.public_id),
                "name": industry.name,
                "code": industry.code,
            }
            for industry in instance.industries.all()
        ]

    def to_representation(self, instance):
        data = super().to_representation(instance)

        for key, value in data.items():
            if value is None:
                data[key] = ""

        return data






class GetOrganizationMembershipsApiSchema(serializers.ModelSerializer):
    uid          = serializers.SerializerMethodField()
    organization = serializers.SerializerMethodField()
    user         = serializers.SerializerMethodField()

    class Meta:
        model = OrganizationMembership
        fields = [
            "uid",
            "public_id",
            "role",
            "is_active",
            "organization",
            "user",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_organization(self, instance) -> dict:
        org = instance.organization
        return {
            "uid": encode_id(org.pk),
            "public_id": str(org.public_id),
            "name": org.name or "",
            "code": org.code or "",
        }

    def get_user(self, instance) -> dict:
        user = instance.user
        return {
            "uid": encode_id(user.pk),
            "public_id": str(user.public_id),
            "email": user.email or "",
            "username": user.username or "",
        }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data


class GetOrganizationLocationsApiSchema(serializers.ModelSerializer):
    uid          = serializers.SerializerMethodField()
    organization = serializers.SerializerMethodField()
    location     = serializers.SerializerMethodField()

    class Meta:
        model = OrganizationLocation
        fields = [
            "uid",
            "public_id",
            "location_type",
            "is_primary",
            "organization",
            "location",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_organization(self, instance) -> dict:
        org = instance.organization
        return {
            "uid": encode_id(org.pk),
            "public_id": str(org.public_id),
            "name": org.name or "",
            "code": org.code or "",
        }

    def get_location(self, instance) -> dict:
        loc = instance.location
        return {
            "uid": encode_id(loc.pk),
            "public_id": str(loc.public_id),
            "city": loc.city or "",
            "address_line_1": loc.address_line_1 or "",
            "country_code": getattr(loc.country, "code", "") or "",
        }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data


class GetMyOrganizationApiSchema(serializers.Serializer):
    value = serializers.SerializerMethodField()
    label = serializers.SerializerMethodField()

    def get_value(self, row) -> str:
        return encode_id(getattr(row, "organization_id", None) or row.pk)

    def get_label(self, row) -> str:
        organization = getattr(row, "organization", None)
        if organization is not None and organization is not row:
            return organization.name or ""
        return getattr(row, "name", None) or ""


class GetMyOrganizationsApiSchema(serializers.Serializer):
    value = serializers.SerializerMethodField()
    label = serializers.SerializerMethodField()
    role = serializers.SerializerMethodField()
    company_count = serializers.IntegerField()

    def get_value(self, organization) -> str:
        return encode_id(organization.pk)

    def get_label(self, organization) -> str:
        return organization.name or ""

    def get_role(self, organization) -> str:
        return getattr(organization, "directory_role", None) or ""
