from django.test import TestCase
from rest_framework.test import APIClient

from apps.location.models import Country
from apps.organization.models import Industry, Organization
from apps.users.models import Users
from core.utils.tokens import (
    issue_registration_token,
    issue_tokens,
)

PASSWORD = "ValidPassw0rd!"


class IndustryApiTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.admin = Users.objects.create_user(
            email="admin@example.com",
            password=PASSWORD,
            username="adminuser",
            phone_number="+15551110001",
            is_admin=True,
        )
        tokens = issue_tokens(self.admin)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")

    def _create(self, **overrides):
        payload = {
            "name": "Retail",
            "code": "retail",
        }
        payload.update(overrides)
        return self.client.post("/api/organization/create-industry/", payload, format="json")

    def test_create_industry(self):
        response = self._create()
        self.assertEqual(response.status_code, 201)
        data = response.data["data"]
        self.assertEqual(data["code"], "retail")
        self.assertEqual(data["name"], "Retail")
        self.assertTrue(data["is_active"])
        self.assertTrue(data["uid"])
        self.assertNotIn("id", data)

    def test_duplicate_code(self):
        self._create()
        response = self._create(name="Retail Stores")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data.get("code"), "INDUSTRY_CODE_EXISTS")

    def test_list_industries(self):
        self._create()
        response = self.client.get("/api/organization/get-industries/")
        self.assertEqual(response.status_code, 200)
        self.assertGreaterEqual(response.data["data"]["count"], 1)

    def test_update_industry(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.put(
            "/api/organization/update-industry/",
            {
                "uid": uid,
                "name": "Retail Updated",
                "code": "retail",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["data"]["name"], "Retail Updated")

    def test_toggle_industry_active_status(self):
        created = self._create()
        uid = created.data["data"]["uid"]

        inactive = self.client.post(
            "/api/organization/inactive-active-industries/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(inactive.status_code, 200)
        self.assertFalse(inactive.data["data"][0]["is_active"])
        self.assertFalse(Industry.objects.get(code="retail").is_active)

        listed = self.client.get(
            "/api/organization/get-industries/?is_active=false&code=retail"
        )
        self.assertEqual(listed.data["data"]["count"], 1)

        active = self.client.post(
            "/api/organization/inactive-active-industries/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(active.status_code, 200)
        self.assertTrue(active.data["data"][0]["is_active"])
        self.assertTrue(Industry.objects.get(code="retail").is_active)

    def test_delete_industry(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.delete(
            "/api/organization/delete-industries/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Industry.objects.filter(code="retail").exists())

    def test_delete_industry_in_use(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        industry = Industry.objects.get(code="retail")
        country = Country.objects.create(
            name="Testland",
            code="TL",
        )
        Organization.objects.create(
            name="Group",
            code="GRP1",
            country=country,
        ).industries.add(industry)
        response = self.client.delete(
            "/api/organization/delete-industries/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data.get("code"), "INDUSTRY_IN_USE")
        self.assertTrue(Industry.objects.filter(code="retail").exists())

    def test_pending_user_cannot_list(self):
        pending = Users.objects.create_user(
            email="pending@example.com",
            password=PASSWORD,
        )
        token = issue_registration_token(pending)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {token['access']}")
        response = self.client.get("/api/organization/get-industries/")
        self.assertEqual(response.status_code, 403)

    def test_non_admin_cannot_create(self):
        member = Users.objects.create_user(
            email="member@example.com",
            password=PASSWORD,
            username="memberuser",
            phone_number="+15551110002",
        )
        tokens = issue_tokens(member)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")
        response = self._create()
        self.assertEqual(response.status_code, 403)
