"""File storage abstraction. Do not hard-code S3 in apps."""
