from rest_framework import serializers

from apps.sales.models import Sale
from core.utils.ids import encode_id


class GetSalesApiSchema(serializers.ModelSerializer):
    uid = serializers.SerializerMethodField()

    class Meta:
        model = Sale
        fields = [
            "uid",
            "public_id",
            "invoice_number",
            "customer_name",
            "sale_date",
            "subtotal",
            "tax_amount",
            "discount_amount",
            "total_amount",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data
