from django.test import TestCase
from rest_framework.test import APIClient

from apps.location.models import Country
from apps.organization.models import Industry, Organization
from apps.users.models import Users
from core.utils.ids import encode_id
from core.utils.tokens import (
    issue_registration_token,
    issue_tokens,
)

PASSWORD = "ValidPassw0rd!"


class OrganizationApiTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.admin = Users.objects.create_user(
            email="admin@example.com",
            password=PASSWORD,
            username="adminuser",
            phone_number="+15551110001",
            is_admin=True,
        )
        tokens = issue_tokens(self.admin)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")
        self.country = Country.objects.create(name="India", code="IN")
        self.industry = Industry.objects.create(name="Retail", code="retail")
        self.industry_two = Industry.objects.create(name="Wholesale", code="wholesale")

    def _payload(self, **overrides):
        payload = {
            "name": "Acme Group",
            "code": "ACME",
            "legal_name": "Acme Private Limited",
            "country_uid": encode_id(self.country.pk),
            "industry_uids": [encode_id(self.industry.pk)],
        }
        payload.update(overrides)
        return payload

    def _create(self, **overrides):
        return self.client.post(
            "/api/organization/create-organization/",
            self._payload(**overrides),
            format="json",
        )

    def test_create_organization(self):
        response = self._create(
            industry_uids=[
                encode_id(self.industry.pk),
                encode_id(self.industry_two.pk),
            ]
        )
        self.assertEqual(response.status_code, 201)
        data = response.data["data"]
        self.assertEqual(data["name"], "Acme Group")
        self.assertEqual(data["legal_name"], "Acme Private Limited")
        self.assertEqual(data["code"], "ACME")
        self.assertEqual(data["country"]["code"], "IN")
        self.assertEqual(len(data["industries"]), 2)
        self.assertNotIn("id", data)
        self.assertEqual(Organization.objects.get(code="ACME").created_by_id, self.admin.pk)

    def test_name_is_required(self):
        response = self._create(name="")
        self.assertEqual(response.status_code, 400)
        self.assertIn("name", response.data.get("errors", {}))

    def test_legal_name_is_required(self):
        payload = self._payload()
        payload.pop("legal_name")
        response = self.client.post(
            "/api/organization/create-organization/",
            payload,
            format="json",
        )
        self.assertEqual(response.status_code, 400)
        self.assertIn("legal_name", response.data.get("errors", {}))

    def test_country_is_required(self):
        payload = self._payload()
        payload.pop("country_uid")
        response = self.client.post(
            "/api/organization/create-organization/",
            payload,
            format="json",
        )
        self.assertEqual(response.status_code, 400)
        self.assertIn("country_uid", response.data.get("errors", {}))

    def test_industry_is_required(self):
        payload = self._payload()
        payload.pop("industry_uids")
        response = self.client.post(
            "/api/organization/create-organization/",
            payload,
            format="json",
        )
        self.assertEqual(response.status_code, 400)
        self.assertIn("industry_uids", response.data.get("errors", {}))

    def test_inactive_country_rejected(self):
        self.country.is_active = False
        self.country.save(update_fields=["is_active", "updated_at"])
        response = self._create()
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data.get("code"), "COUNTRY_NOT_FOUND")

    def test_duplicate_code(self):
        self._create()
        response = self._create(name="Other Group")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data.get("code"), "ORGANIZATION_CODE_EXISTS")

    def test_list_organizations(self):
        self._create()
        response = self.client.get("/api/organization/get-organizations/")
        self.assertEqual(response.status_code, 200)
        self.assertGreaterEqual(response.data["data"]["count"], 1)

    def test_update_organization(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.put(
            "/api/organization/update-organization/",
            self._payload(
                uid=uid,
                name="Acme Holdings",
                legal_name="Acme Holdings Private Limited",
            ),
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["data"]["name"], "Acme Holdings")
        self.assertEqual(response.data["data"]["legal_name"], "Acme Holdings Private Limited")

    def test_toggle_organization_active_status(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        inactive = self.client.post(
            "/api/organization/inactive-active-organizations/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(inactive.status_code, 200)
        self.assertFalse(inactive.data["data"][0]["is_active"])
        active = self.client.post(
            "/api/organization/inactive-active-organizations/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(active.status_code, 200)
        self.assertTrue(active.data["data"][0]["is_active"])

    def test_delete_organization(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.delete(
            "/api/organization/delete-organizations/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Organization.objects.filter(code="ACME").exists())

    def test_pending_user_cannot_list(self):
        pending = Users.objects.create_user(
            email="pending@example.com",
            password=PASSWORD,
        )
        token = issue_registration_token(pending)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {token['access']}")
        response = self.client.get("/api/organization/get-organizations/")
        self.assertEqual(response.status_code, 403)

    def test_non_admin_cannot_create(self):
        member = Users.objects.create_user(
            email="member@example.com",
            password=PASSWORD,
            username="memberuser",
            phone_number="+15551110002",
        )
        tokens = issue_tokens(member)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")
        response = self._create()
        self.assertEqual(response.status_code, 403)
