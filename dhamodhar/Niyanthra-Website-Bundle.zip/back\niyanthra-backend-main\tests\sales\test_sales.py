from datetime import date
from decimal import Decimal

from django.conf import settings
from django.test import TestCase
from rest_framework.test import APIClient

from apps.company.models import (
    Company,
    CompanyMembership,
)
from apps.location.models import Country
from apps.organization.models import Organization
from apps.sales.models import Sale
from apps.sales.services.sale_service import SaleService
from apps.tenant.models import (
    Tenant,
    TenantDatabase,
)
from apps.users.models import Users
from core.tenant.workspace import WorkspaceScope
from core.utils.ids import encode_id
from core.utils.tokens import issue_workspace_tokens
from infrastructure.database.context import (
    clear_current_db_alias,
    set_current_db_alias,
)


PASSWORD = "ValidPassw0rd!"


class SaleServiceScopeTests(TestCase):

    databases = {"default", settings.SHARED_DB_ALIAS}

    def setUp(self):
        set_current_db_alias(settings.SHARED_DB_ALIAS)
        self.scope_a = WorkspaceScope(company_id=10, tenant_id=100)
        self.scope_b = WorkspaceScope(company_id=20, tenant_id=200)

    def tearDown(self):
        clear_current_db_alias()

    def _create(self, *, scope: WorkspaceScope, invoice: str):
        return SaleService.create_sale(
            scope=scope,
            validated_data={
                "invoice_number": invoice,
                "customer_name": "Customer",
                "sale_date": date(2026, 1, 15),
                "subtotal": Decimal("100.00"),
                "tax_amount": Decimal("10.00"),
                "discount_amount": Decimal("0.00"),
                "total_amount": Decimal("110.00"),
            },
        )

    def test_create_stamps_workspace_scope(self):
        sale = self._create(scope=self.scope_a, invoice="INV-001")
        self.assertEqual(sale.tenant_id, 100)
        self.assertEqual(sale.company_id, 10)
        self.assertEqual(sale.invoice_number, "INV-001")

    def test_list_is_scoped_to_workspace(self):
        self._create(scope=self.scope_a, invoice="INV-A")
        self._create(scope=self.scope_b, invoice="INV-B")

        rows = list(
            SaleService.get_sales(
                scope=self.scope_a,
                validated_data={},
            )
        )
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].invoice_number, "INV-A")

    def test_update_cannot_cross_tenant(self):
        sale_b = self._create(scope=self.scope_b, invoice="INV-B")
        from rest_framework.exceptions import NotFound

        with self.assertRaises(NotFound):
            SaleService.update_sale(
                scope=self.scope_a,
                validated_data={
                    "uid": encode_id(sale_b.pk),
                    "customer_name": "Hacked",
                },
            )

    def test_delete_cannot_cross_tenant(self):
        sale_b = self._create(scope=self.scope_b, invoice="INV-B2")
        from rest_framework.exceptions import NotFound

        with self.assertRaises(NotFound):
            SaleService.delete_sales(
                scope=self.scope_a,
                validated_data={"uids": [encode_id(sale_b.pk)]},
            )
        self.assertEqual(
            Sale.all_objects.filter(pk=sale_b.pk).count(),
            1,
        )

    def test_duplicate_invoice_same_scope_rejected(self):
        self._create(scope=self.scope_a, invoice="INV-DUP")
        from core.exceptions.auth import AuthValidationError

        with self.assertRaises(AuthValidationError):
            self._create(scope=self.scope_a, invoice="INV-DUP")

    def test_same_invoice_allowed_on_other_scope(self):
        self._create(scope=self.scope_a, invoice="INV-SHARED")
        sale = self._create(scope=self.scope_b, invoice="INV-SHARED")
        self.assertEqual(sale.company_id, 20)


class SaleApiWorkspaceTests(TestCase):

    databases = {"default", settings.SHARED_DB_ALIAS}

    def setUp(self):
        self.client = APIClient()
        self.user = Users.objects.create_user(
            email="seller@example.com",
            password=PASSWORD,
            username="seller",
            phone_number="+15550009999",
            profile_completed=True,
        )
        self.country = Country.objects.create(name="India", code="IN")
        self.organization = Organization.objects.create(
            name="Sales Org",
            code="SORG",
            legal_name="Sales Org Pvt",
            country=self.country,
        )
        self.tenant = Tenant.objects.create(
            name="Shared Sales",
            slug="shared-sales",
            tenant_type=Tenant.TenantType.SHARED,
            db_alias="shared_sales",
            provisioning_status=Tenant.ProvisioningStatus.ACTIVE,
            is_active=True,
        )
        TenantDatabase.objects.create(
            tenant=self.tenant,
            db_alias="shared_sales",
            provisioning_status=TenantDatabase.ProvisioningStatus.ACTIVE,
            is_current=True,
        )
        self.company = Company.objects.create(
            organization=self.organization,
            name="Sales Co",
            code="SCO",
            tenant=self.tenant,
        )
        CompanyMembership.objects.create(
            company=self.company,
            user=self.user,
            role=CompanyMembership.Role.OWNER,
            is_active=True,
        )
        tokens = issue_workspace_tokens(
            self.user,
            company=self.company,
            tenant=self.tenant,
        )
        self.client.credentials(
            HTTP_AUTHORIZATION=f"Bearer {tokens['access']}",
        )

    def test_create_list_update_delete_sale(self):
        create = self.client.post(
            "/api/sales/create-sale/",
            {
                "invoice_number": "API-001",
                "customer_name": "Acme Buyer",
                "sale_date": "2026-03-01",
                "subtotal": "200.00",
                "tax_amount": "20.00",
                "discount_amount": "0.00",
                "total_amount": "220.00",
            },
            format="json",
        )
        self.assertEqual(create.status_code, 201)
        uid = create.data["data"]["uid"]
        self.assertEqual(create.data["data"]["invoice_number"], "API-001")

        set_current_db_alias(settings.SHARED_DB_ALIAS)
        sale = Sale.all_objects.get()
        self.assertEqual(sale.tenant_id, self.tenant.pk)
        self.assertEqual(sale.company_id, self.company.pk)

        listing = self.client.get("/api/sales/get-sales/")
        self.assertEqual(listing.status_code, 200)
        self.assertEqual(listing.data["data"]["count"], 1)

        update = self.client.put(
            "/api/sales/update-sale/",
            {
                "uid": uid,
                "customer_name": "Acme Buyer Updated",
            },
            format="json",
        )
        self.assertEqual(update.status_code, 200)
        self.assertEqual(
            update.data["data"]["customer_name"],
            "Acme Buyer Updated",
        )

        delete = self.client.post(
            "/api/sales/delete-sales/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(delete.status_code, 200)
        set_current_db_alias(settings.SHARED_DB_ALIAS)
        self.assertFalse(
            Sale.all_objects.filter(deleted_at__isnull=True).exists()
        )

    def test_requires_workspace_claims(self):
        from core.utils.tokens import issue_tokens

        tokens = issue_tokens(self.user)
        self.client.credentials(
            HTTP_AUTHORIZATION=f"Bearer {tokens['access']}",
        )
        response = self.client.get("/api/sales/get-sales/")
        self.assertIn(response.status_code, {401, 403})
