from rest_framework import serializers


class CreateSaleSerializer(serializers.Serializer):
    invoice_number  = serializers.CharField(max_length=100, trim_whitespace=True)
    customer_name   = serializers.CharField(max_length=255, trim_whitespace=True)
    sale_date       = serializers.DateField()
    subtotal        = serializers.DecimalField(max_digits=15, decimal_places=2)
    tax_amount      = serializers.DecimalField(
        max_digits=15,
        decimal_places=2,
        required=False,
        default=0,
    )
    discount_amount = serializers.DecimalField(
        max_digits=15,
        decimal_places=2,
        required=False,
        default=0,
    )
    total_amount    = serializers.DecimalField(max_digits=15, decimal_places=2)

    def validate_invoice_number(self, value):
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        return value

    def validate_customer_name(self, value):
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        return value


class UpdateSaleSerializer(serializers.Serializer):
    uid             = serializers.CharField(trim_whitespace=True)
    invoice_number  = serializers.CharField(
        max_length=100,
        required=False,
        trim_whitespace=True,
    )
    customer_name   = serializers.CharField(
        max_length=255,
        required=False,
        trim_whitespace=True,
    )
    sale_date       = serializers.DateField(required=False)
    subtotal        = serializers.DecimalField(
        max_digits=15,
        decimal_places=2,
        required=False,
    )
    tax_amount      = serializers.DecimalField(
        max_digits=15,
        decimal_places=2,
        required=False,
    )
    discount_amount = serializers.DecimalField(
        max_digits=15,
        decimal_places=2,
        required=False,
    )
    total_amount    = serializers.DecimalField(
        max_digits=15,
        decimal_places=2,
        required=False,
    )

    def validate_invoice_number(self, value):
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        return value

    def validate_customer_name(self, value):
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        return value


class GetSalesQuerySerializer(serializers.Serializer):
    uid            = serializers.CharField(
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )
    invoice_number = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=100,
        trim_whitespace=True,
    )
    customer_name  = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=255,
        trim_whitespace=True,
    )
    sale_date      = serializers.DateField(required=False, allow_null=True)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["invoice_number"] = (
            (attrs.get("invoice_number") or "").strip() or None
        )
        attrs["customer_name"] = (
            (attrs.get("customer_name") or "").strip() or None
        )
        if "sale_date" not in attrs:
            attrs["sale_date"] = None
        return attrs


class SaleUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False, trim_whitespace=True),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique_uids = list(dict.fromkeys(value))
        if not unique_uids:
            raise serializers.ValidationError("Select at least one sale.")
        return unique_uids
