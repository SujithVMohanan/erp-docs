from django.db import (
    IntegrityError,
    transaction,
)
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.location.repository import LocationRepository
from apps.organization.repository import (
    OrganizationLocationRepository,
    OrganizationRepository,
)
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class OrganizationLocationService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})
        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})
        return decoded

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        return list(
            dict.fromkeys(
                OrganizationLocationService._decode_uid(uid, field="uids")
                for uid in uids
            )
        )

    @staticmethod
    def get_links(*, validated_data: dict):
        link_id = None
        organization_id = None
        location_id = None
        if validated_data.get("uid"):
            link_id = [
                OrganizationLocationService._decode_uid(validated_data["uid"])
            ]
        if validated_data.get("organization_uid"):
            organization_id = OrganizationLocationService._decode_uid(
                validated_data["organization_uid"],
                field="organization_uid",
            )
        if validated_data.get("location_uid"):
            location_id = OrganizationLocationService._decode_uid(
                validated_data["location_uid"],
                field="location_uid",
            )
        return OrganizationLocationRepository.list_links(
            link_id=link_id,
            organization_id=organization_id,
            location_id=location_id,
            is_primary=validated_data.get("is_primary"),
        )

    @staticmethod
    def create_link(*, validated_data: dict):
        organization_id = OrganizationLocationService._decode_uid(
            validated_data["organization_uid"],
            field="organization_uid",
        )
        if OrganizationRepository.get_by_id(organization_id) is None:
            raise AuthValidationError(
                {"organization_uid": ["Organization not found."]},
                code="ORGANIZATION_NOT_FOUND",
            )
        location_id = OrganizationLocationService._decode_uid(
            validated_data["location_uid"],
            field="location_uid",
        )
        if LocationRepository.get_by_id(location_id) is None:
            raise AuthValidationError(
                {"location_uid": ["Location not found."]},
                code="LOCATION_NOT_FOUND",
            )
        if OrganizationLocationRepository.get_conflict(
            organization_id=organization_id,
            location_id=location_id,
        ):
            raise AuthValidationError(
                {"location_uid": ["Location already linked to organization."]},
                code="ORGANIZATION_LOCATION_EXISTS",
            )
        is_primary = validated_data.get("is_primary", False)
        try:
            with transaction.atomic():
                if is_primary:
                    OrganizationLocationRepository.clear_primary(
                        organization_id=organization_id
                    )
                link = OrganizationLocationRepository.create_link(
                    organization_id=organization_id,
                    location_id=location_id,
                    location_type=validated_data.get("location_type") or "PRIMARY",
                    is_primary=is_primary,
                )
        except IntegrityError:
            raise AuthValidationError(
                {"location_uid": ["Location already linked to organization."]},
                code="ORGANIZATION_LOCATION_EXISTS",
            ) from None
        return OrganizationLocationRepository.get_by_id(link.pk)

    @staticmethod
    def update_link(*, validated_data: dict):
        link = OrganizationLocationRepository.get_by_id(
            OrganizationLocationService._decode_uid(validated_data["uid"])
        )
        if link is None:
            raise NotFound("Organization location not found.")
        organization_id = OrganizationLocationService._decode_uid(
            validated_data["organization_uid"],
            field="organization_uid",
        )
        if OrganizationRepository.get_by_id(organization_id) is None:
            raise AuthValidationError(
                {"organization_uid": ["Organization not found."]},
                code="ORGANIZATION_NOT_FOUND",
            )
        location_id = OrganizationLocationService._decode_uid(
            validated_data["location_uid"],
            field="location_uid",
        )
        if LocationRepository.get_by_id(location_id) is None:
            raise AuthValidationError(
                {"location_uid": ["Location not found."]},
                code="LOCATION_NOT_FOUND",
            )
        if OrganizationLocationRepository.get_conflict(
            organization_id=organization_id,
            location_id=location_id,
            exclude_id=link.pk,
        ):
            raise AuthValidationError(
                {"location_uid": ["Location already linked to organization."]},
                code="ORGANIZATION_LOCATION_EXISTS",
            )
        is_primary = validated_data.get("is_primary", link.is_primary)
        try:
            with transaction.atomic():
                if is_primary:
                    OrganizationLocationRepository.clear_primary(
                        organization_id=organization_id,
                        exclude_id=link.pk,
                    )
                OrganizationLocationRepository.update_link(
                    link=link,
                    organization_id=organization_id,
                    location_id=location_id,
                    location_type=validated_data.get("location_type")
                    or link.location_type,
                    is_primary=is_primary,
                )
        except IntegrityError:
            raise AuthValidationError(
                {"location_uid": ["Location already linked to organization."]},
                code="ORGANIZATION_LOCATION_EXISTS",
            ) from None
        return OrganizationLocationRepository.get_by_id(link.pk)

    @staticmethod
    def delete_links(*, validated_data: dict) -> dict:
        link_ids = OrganizationLocationService._decode_uids(validated_data["uids"])
        deleted = OrganizationLocationRepository.delete_by_ids(link_ids)
        if not deleted:
            raise NotFound("Organization location not found.")
        return {"deleted": deleted}
