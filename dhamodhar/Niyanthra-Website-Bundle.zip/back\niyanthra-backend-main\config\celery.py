import os

from celery import Celery

from config.environment import get_settings_module

# Django still requires this process env; never put it in product .env files.
os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    get_settings_module(),
)

app = Celery("niyanthra")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()

app.conf.beat_schedule = {
    "dispatch-isolated-jobs-every-minute": {
        "task": "background.dispatch_isolated_jobs",
        "schedule": 60.0,
    },
}
