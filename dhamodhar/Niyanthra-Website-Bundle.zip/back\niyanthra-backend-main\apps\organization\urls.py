from django.urls import path

from apps.organization.views import (
    CreateCountryApiView,CreateIndustryApiView,CreateOrganizationApiView,CreateOrganizationLocationApiView,CreateOrganizationMembershipApiView,
    CreateOrganizationMembershipInviteApiView,
    DeleteCountriesApiView,
    DeleteIndustriesApiView,
    DeleteOrganizationLocationsApiView,
    DeleteOrganizationMembershipsApiView,
    DeleteOrganizationsApiView,
    GetCountriesApiView,
    GetIndustriesApiView,
    GetOrganizationLocationsApiView,
    GetMyOrganizationApiView,
    GetOrganizationMembershipsApiView,
    GetOrganizationsApiView,
    MyOrganizationsApiView,
    InactiveActiveCountriesApiView,
    InactiveActiveIndustriesApiView,
    InactiveActiveOrganizationMembershipsApiView,
    InactiveActiveOrganizationsApiView,
    SkipNowOrganizationApiView,
    UpdateCountryApiView,
    UpdateIndustryApiView,
    UpdateOrganizationApiView,
    UpdateOrganizationLocationApiView,
    UpdateOrganizationMembershipApiView,
)

app_name = "organization"

urlpatterns = [
    path("get-countries/", GetCountriesApiView.as_view(), name="get-countries"),
    path("create-country/", CreateCountryApiView.as_view(), name="create-country"),
    path("update-country/", UpdateCountryApiView.as_view(), name="update-country"),
    path("delete-countries/", DeleteCountriesApiView.as_view(), name="delete-countries"),
    path(
        "inactive-active-countries/",
        InactiveActiveCountriesApiView.as_view(),
        name="inactive-active-countries",
    ),
    path("get-industries/", GetIndustriesApiView.as_view(), name="get-industries"),
    path("create-industry/", CreateIndustryApiView.as_view(), name="create-industry"),
    path("update-industry/", UpdateIndustryApiView.as_view(), name="update-industry"),
    path(
        "delete-industries/",
        DeleteIndustriesApiView.as_view(),
        name="delete-industries",
    ),
    path(
        "inactive-active-industries/",
        InactiveActiveIndustriesApiView.as_view(),
        name="inactive-active-industries",
    ),
    path("get-organizations/", GetOrganizationsApiView.as_view(), name="get-organizations"),
    path(
        "get-my-organization/",
        GetMyOrganizationApiView.as_view(),
        name="get-my-organization",
    ),
    path(
        "my-organizations/",
        MyOrganizationsApiView.as_view(),
        name="my-organizations",
    ),
    path(
        "create-organization/",
        CreateOrganizationApiView.as_view(),
        name="create-organization",
    ),
    path(
        "update-organization/",
        UpdateOrganizationApiView.as_view(),
        name="update-organization",
    ),
    path(
        "delete-organizations/",
        DeleteOrganizationsApiView.as_view(),
        name="delete-organizations",
    ),
    path(
        "inactive-active-organizations/",
        InactiveActiveOrganizationsApiView.as_view(),
        name="inactive-active-organizations",
    ),
    path(
        "get-organization-memberships/",
        GetOrganizationMembershipsApiView.as_view(),
        name="get-organization-memberships",
    ),
    path(
        "create-organization-membership/",
        CreateOrganizationMembershipApiView.as_view(),
        name="create-organization-membership",
    ),
    path(
        "create-organization-membership-invite/",
        CreateOrganizationMembershipInviteApiView.as_view(),
        name="create-organization-membership-invite",
    ),
    path(
        "update-organization-membership/",
        UpdateOrganizationMembershipApiView.as_view(),
        name="update-organization-membership",
    ),
    path(
        "delete-organization-memberships/",
        DeleteOrganizationMembershipsApiView.as_view(),
        name="delete-organization-memberships",
    ),
    path(
        "inactive-active-organization-memberships/",
        InactiveActiveOrganizationMembershipsApiView.as_view(),
        name="inactive-active-organization-memberships",
    ),
    path(
        "get-organization-locations/",
        GetOrganizationLocationsApiView.as_view(),
        name="get-organization-locations",
    ),
    path(
        "create-organization-location/",
        CreateOrganizationLocationApiView.as_view(),
        name="create-organization-location",
    ),
    path(
        "update-organization-location/",
        UpdateOrganizationLocationApiView.as_view(),
        name="update-organization-location",
    ),
    path(
        "delete-organization-locations/",
        DeleteOrganizationLocationsApiView.as_view(),
        name="delete-organization-locations",
    ),
    path(
        "skip-now-organization/",
        SkipNowOrganizationApiView.as_view(),
        name="skip-now-organization",
    ),
]
