"""Abstract mixins. No physical tables — inheriting models get the columns."""

import uuid

from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

from core.database.managers import (
    AllObjectsManager,
    SoftDeleteManager,
)
from core.tenant.context import get_current_tenant
from core.tenant.exceptions import TenantContextError
from core.tenant.managers import (
    COMPANY_FIELD,
    TENANT_FIELD,
    TenantAwareManager,
    TenantUnscopedManager,
)


class PublicIdModel(models.Model):

    public_id = models.UUIDField(
        default=uuid.uuid4,
        unique=True,
        editable=False,
    )

    class Meta:
        abstract = True


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class SoftDeleteModel(models.Model):

    deleted_at = models.DateTimeField(blank=True, null=True)
    objects = SoftDeleteManager()
    all_objects = AllObjectsManager()

    class Meta:
        abstract = True
        default_manager_name = "objects"
        base_manager_name = "all_objects"

    def delete(self, using=None, keep_parents=False):
        using = using or self._state.db or "default"
        now = timezone.now()
        self.deleted_at = now
        update_fields = ["deleted_at"]
        if any(field.name == "updated_at" for field in self._meta.fields):
            update_fields.append("updated_at")
        self.save(using=using, update_fields=update_fields)

    def restore(self):
        if not self.deleted_at:
            return
        using = self._state.db or "default"
        self.deleted_at = None
        update_fields = ["deleted_at"]
        if any(field.name == "updated_at" for field in self._meta.fields):
            update_fields.append("updated_at")
        self.save(using=using, update_fields=update_fields)


class BaseModel(
    PublicIdModel,
    TimeStampedModel,
    SoftDeleteModel,
):
    class Meta:
        abstract = True


class TenantScopedModel(BaseModel):
    """
    Data-plane models. Queries run on the shared, isolated, or silo
    database selected for the request, never on the control database.
    Rows are limited to the active tenant_id and company_id.

    `objects` — alive rows for the active tenant (fail-closed).
    `all_objects` — explicit system access across tenants (includes deleted).

    Control-plane models must keep using BaseModel only.
    """

    tenant_id = models.PositiveBigIntegerField(
        _("tenant id"),
        db_index=True,
    )

    objects = TenantAwareManager()
    all_objects = TenantUnscopedManager()

    class Meta:
        abstract = True
        default_manager_name = "objects"
        base_manager_name = "all_objects"

    def _has_company_field(self) -> bool:
        return any(
            field.name == COMPANY_FIELD for field in self._meta.fields
        )

    def _apply_tenant_identity(self) -> None:
        identity = get_current_tenant()
        if identity is None:
            existing = getattr(self, TENANT_FIELD, None)
            if existing in (None, 0):
                raise TenantContextError(
                    "Tenant context is required, or set tenant_id "
                    "explicitly via all_objects for system operations."
                )
            return

        existing = getattr(self, TENANT_FIELD, None)
        if existing not in (None, 0) and int(existing) != identity.tenant_id:
            raise TenantContextError(
                "Cross-tenant assignment is not allowed."
            )
        setattr(self, TENANT_FIELD, identity.tenant_id)

        if not self._has_company_field() or identity.company_id is None:
            return

        existing_company = getattr(self, COMPANY_FIELD, None)
        if (
            existing_company not in (None, 0)
            and int(existing_company) != identity.company_id
        ):
            raise TenantContextError(
                "Cross-company assignment is not allowed."
            )
        setattr(self, COMPANY_FIELD, identity.company_id)

    def save(self, *args, **kwargs):
        self._apply_tenant_identity()
        return super().save(*args, **kwargs)

    def delete(self, using=None, keep_parents=False):
        identity = get_current_tenant()
        if identity is None:
            return super().delete(using=using, keep_parents=keep_parents)

        if int(getattr(self, TENANT_FIELD)) != identity.tenant_id:
            raise TenantContextError(
                "Cannot delete an object belonging to another tenant."
            )
        if (
            self._has_company_field()
            and identity.company_id is not None
            and int(getattr(self, COMPANY_FIELD)) != identity.company_id
        ):
            raise TenantContextError(
                "Cannot delete an object belonging to another company."
            )
        return super().delete(using=using, keep_parents=keep_parents)
