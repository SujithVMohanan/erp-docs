from rest_framework.exceptions import ValidationError
from rest_framework.permissions import BasePermission

from apps.access.models import Group, Role
from apps.company.models import Branch, BranchMembership, CompanyMembership
from apps.company.repository import CompanyRepository
from apps.company.services.workspace_context_service import (
    WorkspaceContextService,
)
from apps.organization.services.organization_access_service import (
    OrganizationAccessService,
)
from core.exceptions.auth import ProfileIncomplete
from core.utils.ids import decode_id
from core.utils.tokens import (
    TOKEN_USE_REGISTRATION,
    get_workspace_claims,
)


def _token_use(request) -> str:
    token = getattr(request, "auth", None)
    if token is None or not hasattr(token, "get"):
        return "access"
    return token.get("token_use") or "access"


class IsPlatformAdmin(BasePermission):
    def has_permission(self, request, view):
        user = request.user
        return bool(
            user
            and user.is_authenticated
            and getattr(user, "is_admin", False)
        )


class IsAppAuthenticated(BasePermission):
    """Full application access: live user, completed profile, app access token."""

    message = "Complete your profile to continue."

    def has_permission(self, request, view):
        user = request.user
        if not user or not user.is_authenticated or not user.is_active:
            return False
        if _token_use(request) == TOKEN_USE_REGISTRATION or not user.profile_completed:
            raise ProfileIncomplete()
        return True


class IsCompanySelectable(BasePermission):
    """Logged-in user may list/select companies (workspace claims optional)."""

    def has_permission(self, request, view):
        return IsAppAuthenticated().has_permission(request, view)


class HasMembershipAccess(BasePermission):
    

    message = "You do not have access to this company."

    def has_permission(self, request, view):
        if getattr(request, "_membership_access", None) is True:
            return True

        user = getattr(request, "user", None)
        if not user or not user.is_authenticated:
            return False
        if getattr(user, "is_superuser", False):
            request._membership_access = True
            return True

        source = getattr(view, "membership_uid_source", "workspace")
        field = getattr(view, "membership_company_field", "company_uid")
        if source in {
            "branch",
            "company_membership_uids",
            "branch_membership_uids",
            "role_uids",
            "group_uids",
        }:
            if not HasMembershipAccess._allows_related_companies(
                user_id=user.pk,
                request=request,
                source=source,
            ):
                return False
            request._membership_access = True
            return True
        if source == "data":
            data = getattr(request, "data", None) or {}
            company_uid = str(data.get(field) or "").strip()
            if not company_uid:
                return True
        elif source == "query":
            company_uid = str(request.query_params.get(field) or "").strip()
            if not company_uid:
                return not getattr(view, "membership_company_required", False)
        else:
            claims = get_workspace_claims(getattr(request, "auth", None))
            company_uid = claims.get("company_uid")
            if not company_uid:
                return False

        company = WorkspaceContextService.membership_company(
            user=user,
            company_uid=company_uid,
        )
        if not company:
            return False

        request._membership_company = company
        request._membership_access = True
        return True

    @staticmethod
    def _decode_ids(values, field: str) -> list[int]:
        ids = []
        for raw in values:
            text = str(raw or "").strip()
            if not text:
                continue
            try:
                decoded = decode_id(text)
            except ValueError:
                raise ValidationError({field: ["Invalid id."]}) from None
            if not isinstance(decoded, int):
                raise ValidationError({field: ["Invalid id."]})
            ids.append(decoded)
        return ids

    @staticmethod
    def _allows_related_companies(*, user_id: int, request, source: str) -> bool:
        data = getattr(request, "data", None) or {}
        if source == "branch":
            branch_ids = HasMembershipAccess._decode_ids(
                [data.get("branch_uid")],
                "branch_uid",
            )
            if not branch_ids:
                return True
            company_ids = list(
                Branch.objects.filter(pk__in=branch_ids).values_list(
                    "company_id",
                    flat=True,
                )
            )
        elif source == "role_uids":
            record_ids = HasMembershipAccess._decode_ids(
                data.get("uids") or [],
                "uids",
            )
            if not record_ids:
                return True
            company_ids = list(
                Role.objects.filter(pk__in=record_ids).values_list(
                    "company_id",
                    flat=True,
                )
            )
        elif source == "group_uids":
            record_ids = HasMembershipAccess._decode_ids(
                data.get("uids") or [],
                "uids",
            )
            if not record_ids:
                return True
            company_ids = list(
                Group.objects.filter(pk__in=record_ids).values_list(
                    "company_id",
                    flat=True,
                )
            )
        elif source == "company_membership_uids":
            membership_ids = HasMembershipAccess._decode_ids(
                data.get("uids") or [],
                "uids",
            )
            if not membership_ids:
                return True
            company_ids = list(
                CompanyMembership.objects.filter(pk__in=membership_ids).values_list(
                    "company_id",
                    flat=True,
                )
            )
        else:
            membership_ids = HasMembershipAccess._decode_ids(
                data.get("uids") or [],
                "uids",
            )
            if not membership_ids:
                return True
            company_ids = list(
                BranchMembership.objects.filter(pk__in=membership_ids).values_list(
                    "branch__company_id",
                    flat=True,
                )
            )
        if not company_ids:
            return True
        allowed = CompanyRepository.member_company_ids(
            user_id=user_id,
            company_ids=company_ids,
        )
        return set(company_ids) <= allowed


class HasOrganizationPermission(BasePermission):
    """
    Allow a superuser, or a user with an active organization membership
    on the organization that owns the company, branch, address, or tax record.
    """

    message = "You do not have access to this organization."

    def has_permission(self, request, view):
        if getattr(request, "_organization_access", None) is True:
            return True

        user = getattr(request, "user", None)
        if not user or not user.is_authenticated:
            return False
        if getattr(user, "is_superuser", False):
            request._organization_access = True
            return True

        allowed = OrganizationAccessService.allows(
            user_id=user.pk,
            target=getattr(view, "organization_target", "actor"),
            source=getattr(view, "organization_uid_source", "data"),
            field=getattr(view, "organization_uid_field", "uid"),
            request=request,
        )
        if allowed:
            request._organization_access = True
        return allowed


class IsWorkspaceAuthenticated(BasePermission):
    """
    Requires workspace JWT claims and live membership.
    Binds tenant DB context for the request.
    """

    message = "Select a company workspace to continue."

    def has_permission(self, request, view):
        if not IsAppAuthenticated().has_permission(request, view):
            return False

        claims = get_workspace_claims(request.auth)
        if not claims.get("company_uid") or not claims.get("tenant_uid"):
            return False

        if not HasMembershipAccess().has_permission(request, view):
            return False

        WorkspaceContextService.bind_from_claims(
            user=request.user,
            claims=claims,
            company=getattr(request, "_membership_company", None),
        )
        request.workspace = claims
        return True
