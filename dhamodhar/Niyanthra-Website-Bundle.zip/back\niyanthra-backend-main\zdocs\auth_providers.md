# Auth providers

Google social login (ID token). Email/password login is unchanged. Microsoft and Apple use the same API later; they are not accepted yet.

This file lives in `zdocs/` (local notes). That folder is listed in `.gitignore` and is not committed.

## What we built

The client (Next.js) signs in with the Google SDK, then **POSTs the Google ID token** to this API. Django does not run a Google browser redirect. After a valid token, the API finds or creates a `Users` row, stores the Google link in `UserAuthProvider`, and returns the same SimpleJWT `access` / `refresh` pair as password login.

| Now | Later |
|---|---|
| `provider=google` only | Add Microsoft / Apple adapters and serializer choices |
| `GOOGLE_CLIENT_ID` | `MICROSOFT_CLIENT_ID`, `MICROSOFT_TENANT_ID`, `APPLE_CLIENT_ID` |
| `google-auth` | JWKS / PyJWT for Entra and Apple |

## Layers

Same pattern as other APIs: view → serializer → service → repository.

```
Client Google SDK
        │
        │  POST /api/users/social-login/
        ▼
SocialLoginApiView          apps/users/views.py
        │
SocialLoginSerializer       apps/users/serializers.py   (body only)
        │
AuthService.social_login    apps/users/services/auth_service.py
        │
verify_social_token         core/providers/__init__.py
        │
verify_google_token         core/providers/google.py
        │
UserRepository              apps/users/repository.py    (ORM only)
        │
issue_tokens                core/utils/tokens.py
```

`core/providers` is shared platform code (not user-app business). Account find/link/create stays in the users app.

---

## Flow 1 — Google social login

**Endpoint:** `POST /api/users/social-login/`  
**Auth:** public (`AllowAny`, no JWT)  
**URL:** `apps/users/urls.py` → `name="social-login"`

### Request

```json
{
  "provider": "google",
  "id_token": "<Google ID token>",
  "nonce": ""
}
```

- `provider` must be `"google"`. `microsoft` / `apple` fail serializer validation until those adapters exist.
- `id_token` is required.
- `nonce` is optional. If sent, it must match the `nonce` claim in the token.

### View (`SocialLoginApiView`)

1. Validate the body with `SocialLoginSerializer`. Invalid body → `ResponseInfo.validation_error`.
2. Call `AuthService.social_login`.
3. Return `ResponseInfo.ok` with `access`, `refresh`, `user`, and `needs_profile`.
4. Any other exception → `ExceptionHandler.handle`.

`user` is serialized with `LoginUserResponseSchema` (same shape as password login: `uid`, `public_id`, no raw DB `id`).

`needs_profile` is `true` when `username` is empty so the client can open the name / optional-password screen.

### Service (`AuthService.social_login`)

1. Verify the token via `verify_social_token` → `SocialIdentity` (`sub`, email, verified flag, name, picture).
2. If an email is present but **not verified**, reject. Do not link that email to another account.
3. Inside a transaction, resolve the user (`_user_for_identity`).
4. If two requests race on unique email / `(provider, subject)`, catch `IntegrityError` and retry with `_user_after_conflict`.
5. Disabled accounts (`is_active=False`) are rejected.
6. Update `last_login`, issue JWT, set `needs_profile`.

### Account matching (`_user_for_identity`)

1. **Already linked** — live `UserAuthProvider` for `(google, sub)` → that user logs in.
2. **Same verified email** — live `Users` with that email → create a provider row on that user (password users can later use Google, and the reverse).
3. **New email** — `create_social_user`: unusable password, `is_email_verified=True` → then link.
4. **No email and no existing link** — fail. We cannot create a `Users` row without email.

Password registration still requires a password (`UserManager.create_user`). Social create uses `create_social_user` + `set_unusable_password()` so we do not weaken `/register/`.

```mermaid
flowchart TD
  client[Next_Google_SDK]
  api[POST_social-login]
  ser[SocialLoginSerializer]
  svc[AuthService.social_login]
  verify[core.providers.verify_social_token]
  google[verify_google_token]
  find[Find_by_google_sub]
  email[Find_by_verified_email]
  create[create_social_user]
  jwt[issue_tokens]
  profile[needs_profile]

  client --> api --> ser --> svc --> verify --> google
  google --> find
  find -->|linked| jwt
  find -->|new| email
  email -->|existing user| jwt
  email -->|unknown email| create --> jwt
  jwt --> profile
```

---

## Flow 2 — Google ID token verify

**Files:** `core/providers/__init__.py`, `core/providers/google.py`, `core/providers/identity.py`

`verify_social_token` only knows `google` today. The Google module is imported on first use so Django startup does not load Google libraries.

`verify_google_token`:

1. Read audience from `settings.AUTH_PROVIDERS["google"]["client_id"]` (`GOOGLE_CLIENT_ID`). Empty → not configured.
2. Reuse one Google HTTP `Request` after the first call (cert fetch is not rebuilt every login).
3. `google.oauth2.id_token.verify_oauth2_token` checks signature, expiry, and audience.
4. Optional `nonce` must match the token claim.
5. Map claims to `SocialIdentity`. Email is kept only if it looks like an email (`@` present). `email_verified` accepts bool or `"true"` / `"1"`.

Invalid or wrong-audience tokens → `AuthenticationFailed("Invalid Google token.")`.

---

## Flow 3 — Complete profile

**Endpoint:** `POST /api/users/complete-profile/`  
**Auth:** JWT (`IsAuthenticated`)  
**URL:** `name="complete-profile"`

Used after social login when `needs_profile` is true (and can be used later to set a password).

### Request

```json
{
  "username": "Ada",
  "password": "",
  "confirm_password": ""
}
```

- `username` is required (stored on `Users.username`).
- `password` + `confirm_password` are optional. If either is sent, both must match and Django password validators run.

### View / service

1. `CompleteProfileSerializer` validates the body.
2. `UserService.complete_profile` uses `request.user`.
3. Rejects username taken by another live user.
4. `UserRepository.update_user_profile` sets name; if a password was sent, `set_password`.
5. Response is `GetUsersApiSchema` (updated user).

After a password is set, `has_usable_password()` is true, so `POST /api/users/login/` works for that account. Social-only users (no password) still use `/social-login/`; password login rejects unusable passwords.

---

## Flow 4 — Password login (unchanged)

**Endpoint:** `POST /api/users/login/`

1. Find live user by email.
2. Require a usable password and `check_password`.
3. Reject inactive users.
4. Same `issue_tokens` as social login.

Logout still blacklists **our** JWT only (`POST /api/users/logout/`). It does not end the Google session.

---

## Data

Provider IDs are **not** columns on `Users`. They live on `UserAuthProvider` (`user_auth_providers`):

| Column | Meaning |
|---|---|
| `user` | FK to `Users` |
| `provider` | `google` now (CharField; Microsoft/Apple are a later choices expansion) |
| `subject` | Google stable user id (`sub`) |
| `email` | Email at link time (nullable) |
| `public_id`, timestamps, `deleted_at` | Same mixins as other tables |

Live rows are unique on `(provider, subject)` (`uap_provider_subject_alive_uniq`). Deleted links can be reused.

---

## File map

| File | Role |
|---|---|
| `apps/users/views.py` | Thin HTTP: social-login, complete-profile |
| `apps/users/serializers.py` | Inbound: `SocialLoginSerializer`, `CompleteProfileSerializer` |
| `apps/users/schemas.py` | Outbound user shape |
| `apps/users/services/auth_service.py` | `social_login`, find/link/create |
| `apps/users/services/user_service.py` | `complete_profile` |
| `apps/users/repository.py` | ORM: provider lookup, social create, link, profile update |
| `apps/users/models.py` | `create_social_user`, `UserAuthProvider` |
| `apps/users/urls.py` | Routes |
| `core/providers/` | Token verify (Google now) |
| `core/utils/tokens.py` | JWT issue |
| `config/settings.py` | `AUTH_PROVIDERS` |
| `.env.example` | `GOOGLE_CLIENT_ID=` |

---

## Config

`.env` (local, gitignored):

```
GOOGLE_CLIENT_ID=957254465490-a89bv82pkbmomhc1iupj9cs29otb2q7q.apps.googleusercontent.com
```

`config/settings.py` reads it into `AUTH_PROVIDERS["google"]["client_id"]`. That value is the ID-token **audience**. It must match the OAuth client ID used by the Next.js Google SDK (`aud` claim). Restart the Django process after changing `.env`.

Dependencies: `google-auth[requests]` in `requirements.txt`.

---

## Adding Microsoft / Apple later

Do **not** change password login or JWT claims.

1. Expand `UserAuthProvider.Provider` and `SocialLoginSerializer` choices.
2. Add `core/providers/microsoft.py` and `apple.py` (JWKS verify).
3. Branch in `verify_social_token`.
4. Set env client IDs. `AuthService.social_login` matching stays the same.
