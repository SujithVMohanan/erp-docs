"""Django project bootstrap. Settings, URLs, WSGI/ASGI only — not business domains."""

from config.celery import app as celery_app

__all__ = [
    "celery_app",
]
