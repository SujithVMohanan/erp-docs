/**
 * Notifications popup + list helpers.
 * Uses existing inbox-style alerts from the Control Center prototype.
 */
(function (global) {
  "use strict";

  const KEY = "niyanthra_notifs_v1";

  function seed() {
    return [
      {
        id: "n1",
        title: "Hotel Arcadia · INV-1031 overdue",
        body: "₹18,400 due yesterday — collect payment",
        type: "Collect",
        tag: "hot",
        time: "12m ago",
        unread: true,
        href: "dashboard.html",
      },
      {
        id: "n2",
        title: "Atta 10kg below reorder",
        body: "8 on hand · reorder point 20",
        type: "Stock",
        tag: "warn",
        time: "1h ago",
        unread: true,
        href: "dashboard.html",
      },
      {
        id: "n3",
        title: "PO Fresh Dairy needs approval",
        body: "₹6,200 · over staff limit",
        type: "Approve",
        tag: "sky",
        time: "3h ago",
        unread: true,
        href: "dashboard.html",
      },
      {
        id: "n4",
        title: "Kerala Mills · BILL-88 due tomorrow",
        body: "Supplier payment reminder",
        type: "Pay",
        tag: "warn",
        time: "Yesterday",
        unread: false,
        href: "dashboard.html",
      },
      {
        id: "n5",
        title: "Sale INV-1040 posted",
        body: "Walk-in · Bread × 12 · stock OUT",
        type: "Activity",
        tag: "ok",
        time: "Yesterday",
        unread: false,
        href: "dashboard.html",
      },
    ];
  }

  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    const data = seed();
    localStorage.setItem(KEY, JSON.stringify(data));
    return data;
  }

  function save(list) {
    localStorage.setItem(KEY, JSON.stringify(list));
  }

  function unreadCount(list) {
    return list.filter((n) => n.unread).length;
  }

  function tagClass(tag) {
    if (tag === "hot") return "tag-hot";
    if (tag === "warn") return "tag-warn";
    if (tag === "ok") return "tag-ok";
    return "tag-sky";
  }

  function renderItem(n, compact) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "notif-item" + (n.unread ? " is-unread" : "");
    btn.dataset.id = n.id;
    btn.innerHTML =
      '<span class="notif-dot" aria-hidden="true"></span><span>' +
      '<span class="notif-title"></span>' +
      (compact ? "" : '<span class="notif-meta"></span>') +
      '<span style="display:flex;align-items:center;gap:0.4rem;margin-top:0.3rem;flex-wrap:wrap">' +
      '<span class="tag ' +
      tagClass(n.tag) +
      '"></span><span class="notif-time"></span></span></span>';
    btn.querySelector(".notif-title").textContent = n.title;
    if (!compact) btn.querySelector(".notif-meta").textContent = n.body;
    btn.querySelector(".tag").textContent = n.type;
    btn.querySelector(".notif-time").textContent = n.time;
    return btn;
  }

  function mount(options) {
    const trigger = typeof options.trigger === "string" ? document.querySelector(options.trigger) : options.trigger;
    const panel = typeof options.panel === "string" ? document.querySelector(options.panel) : options.panel;
    const badge = options.badge
      ? typeof options.badge === "string"
        ? document.querySelector(options.badge)
        : options.badge
      : null;
    const listEl = panel.querySelector("[data-notif-list]");
    const markAllBtn = panel.querySelector("[data-notif-mark-all]");
    const viewAll = panel.querySelector("[data-notif-view-all]");

    let open = false;
    let items = load();

    function refreshBadge() {
      if (!badge) return;
      const c = unreadCount(items);
      badge.textContent = String(c);
      badge.hidden = c === 0;
      trigger.setAttribute("aria-label", c ? "Notifications, " + c + " unread" : "Notifications");
    }

    function renderList() {
      listEl.innerHTML = "";
      const preview = items.slice(0, 5);
      if (!preview.length) {
        listEl.innerHTML = '<li><div class="empty-state" style="min-height:7rem;padding:1rem"><p>No notifications</p></div></li>';
        return;
      }
      preview.forEach((n) => {
        const li = document.createElement("li");
        const btn = renderItem(n, true);
        btn.addEventListener("click", () => {
          n.unread = false;
          save(items);
          refreshBadge();
          renderList();
          if (typeof UI !== "undefined") UI.toast(n.type + ": opened");
          close();
        });
        li.appendChild(btn);
        listEl.appendChild(li);
      });
    }

    function close() {
      open = false;
      panel.classList.remove("is-open");
      trigger.setAttribute("aria-expanded", "false");
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onKey);
    }

    function onDoc(e) {
      if (panel.contains(e.target) || trigger.contains(e.target)) return;
      close();
    }

    function onKey(e) {
      if (e.key === "Escape") close();
    }

    function toggle() {
      open = !open;
      panel.classList.toggle("is-open", open);
      trigger.setAttribute("aria-expanded", String(open));
      if (open) {
        renderList();
        setTimeout(() => {
          document.addEventListener("mousedown", onDoc);
          document.addEventListener("keydown", onKey);
        }, 0);
      } else {
        document.removeEventListener("mousedown", onDoc);
        document.removeEventListener("keydown", onKey);
      }
    }

    trigger.addEventListener("click", (e) => {
      e.preventDefault();
      toggle();
    });

    if (markAllBtn) {
      markAllBtn.addEventListener("click", () => {
        items.forEach((n) => {
          n.unread = false;
        });
        save(items);
        refreshBadge();
        renderList();
        if (typeof UI !== "undefined") UI.toast("All notifications marked read");
      });
    }

    if (viewAll) {
      viewAll.addEventListener("click", () => {
        close();
      });
    }

    refreshBadge();
    return {
      reload: () => {
        items = load();
        refreshBadge();
        if (open) renderList();
      },
      getItems: () => items,
      save: (next) => {
        items = next;
        save(items);
        refreshBadge();
      },
    };
  }

  function renderPage(container, filter) {
    let items = load();
    const host = typeof container === "string" ? document.querySelector(container) : container;

    function paint() {
      let list = items;
      if (filter === "unread") list = items.filter((n) => n.unread);
      if (filter === "read") list = items.filter((n) => !n.unread);
      host.innerHTML = "";
      if (!list.length) {
        host.innerHTML =
          '<div class="empty-state"><p>No notifications in this view</p><button type="button" class="btn btn-secondary" data-reset>Show all</button></div>';
        const reset = host.querySelector("[data-reset]");
        if (reset) reset.onclick = () => {
          filter = "all";
          document.querySelectorAll(".notif-filters [data-filter]").forEach((b) => {
            b.setAttribute("aria-pressed", String(b.dataset.filter === "all"));
          });
          paint();
        };
        return;
      }
      list.forEach((n) => {
        const btn = renderItem(n, false);
        btn.addEventListener("click", () => {
          n.unread = false;
          save(items);
          paint();
          if (typeof UI !== "undefined") UI.toast("Marked as read");
        });
        host.appendChild(btn);
      });
    }

    paint();
    return {
      setFilter: (f) => {
        filter = f;
        paint();
      },
      markAll: () => {
        items.forEach((n) => {
          n.unread = false;
        });
        save(items);
        paint();
      },
    };
  }

  global.Notifs = { load, save, unreadCount, mount, renderPage, seed };
})(window);
