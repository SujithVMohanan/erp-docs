"""Generate company catalogs, timezone, tax, locations, addresses, and access CRUD."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def write(rel: str, content: str) -> None:
    path = ROOT / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content.lstrip("\n"), encoding="utf-8")
    print("wrote", rel)


# Generic simple catalog template factory pieces for CompanyType / BusinessType
write(
    "apps/company/services/catalog_service.py",
    '''
from django.db import IntegrityError
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.company.repository import CatalogRepository
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class _CatalogMixin:
    kind = ""
    code_error = "CODE_EXISTS"
    not_found = "Not found."

    @classmethod
    def _decode_uid(cls, uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})
        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})
        return decoded

    @classmethod
    def _decode_uids(cls, uids: list[str]) -> list[int]:
        return list(dict.fromkeys(cls._decode_uid(uid, field="uids") for uid in uids))

    @classmethod
    def list_items(cls, *, validated_data: dict):
        item_id = None
        if validated_data.get("uid"):
            item_id = [cls._decode_uid(validated_data["uid"])]
        return CatalogRepository.list_items(
            kind=cls.kind,
            item_id=item_id,
            code=validated_data.get("code"),
            name=validated_data.get("name"),
            is_active=validated_data.get("is_active"),
        )

    @classmethod
    def create_item(cls, *, validated_data: dict):
        code = validated_data["code"]
        if CatalogRepository.get_code_conflict(kind=cls.kind, code=code):
            raise AuthValidationError(
                {"code": ["This code already exists."]},
                code=cls.code_error,
            )
        try:
            return CatalogRepository.create_item(
                kind=cls.kind,
                name=validated_data["name"],
                code=code,
                is_active=validated_data.get("is_active", True),
            )
        except IntegrityError:
            raise AuthValidationError(
                {"code": ["This code already exists."]},
                code=cls.code_error,
            ) from None

    @classmethod
    def update_item(cls, *, validated_data: dict):
        item = CatalogRepository.get_by_id(
            kind=cls.kind,
            item_id=cls._decode_uid(validated_data["uid"]),
        )
        if item is None:
            raise NotFound(cls.not_found)
        code = validated_data["code"]
        if CatalogRepository.get_code_conflict(
            kind=cls.kind,
            code=code,
            exclude_id=item.pk,
        ):
            raise AuthValidationError(
                {"code": ["This code already exists."]},
                code=cls.code_error,
            )
        try:
            return CatalogRepository.update_item(
                kind=cls.kind,
                item=item,
                name=validated_data["name"],
                code=code,
                is_active=validated_data.get("is_active", item.is_active),
            )
        except IntegrityError:
            raise AuthValidationError(
                {"code": ["This code already exists."]},
                code=cls.code_error,
            ) from None

    @classmethod
    def delete_items(cls, *, validated_data: dict) -> dict:
        ids = cls._decode_uids(validated_data["uids"])
        deleted = CatalogRepository.delete_by_ids(kind=cls.kind, item_ids=ids)
        if not deleted:
            raise NotFound(cls.not_found)
        return {"deleted": deleted}

    @classmethod
    def toggle_items(cls, *, validated_data: dict):
        ids = cls._decode_uids(validated_data["uids"])
        updated = CatalogRepository.toggle_active_by_ids(kind=cls.kind, item_ids=ids)
        if not updated:
            raise NotFound(cls.not_found)
        return CatalogRepository.list_items(kind=cls.kind, item_id=ids)


class CompanyTypeService(_CatalogMixin):
    kind = "company_type"
    code_error = "COMPANY_TYPE_CODE_EXISTS"
    not_found = "Company type not found."


class BusinessTypeService(_CatalogMixin):
    kind = "business_type"
    code_error = "BUSINESS_TYPE_CODE_EXISTS"
    not_found = "Business type not found."
''',
)

# Append CatalogRepository to company repository
repo = ROOT / "apps/company/repository.py"
text = repo.read_text(encoding="utf-8")
if "class CatalogRepository" not in text:
    if "CompanyType" not in text.split("from apps.company.models import")[1][:500]:
        text = text.replace(
            "from apps.company.models import (\n    Branch,\n    BranchMembership,\n    Company,\n    CompanyMembership,\n)",
            "from apps.company.models import (\n    Branch,\n    BranchMembership,\n    BusinessType,\n    Company,\n    CompanyMembership,\n    CompanyType,\n)",
        )
    text = text.rstrip() + '''


class CatalogRepository:
    _MODELS = {
        "company_type": CompanyType,
        "business_type": BusinessType,
    }

    @staticmethod
    def _model(kind: str):
        model = CatalogRepository._MODELS.get(kind)
        if model is None:
            raise ValueError(f"Unknown catalog kind: {kind}")
        return model

    @staticmethod
    def list_items(*, kind, item_id=None, code=None, name=None, is_active=None):
        model = CatalogRepository._model(kind)
        filters = Q()
        if item_id is not None:
            ids = item_id if isinstance(item_id, (list, tuple, set)) else [item_id]
            filters &= Q(id__in=ids)
        if code:
            filters &= Q(code=code.strip().upper() if kind == "company_type" else code.strip().upper())
        if name:
            filters &= Q(name__icontains=name)
        if is_active is not None:
            filters &= Q(is_active=is_active)
        return model.objects.only(
            "id", "public_id", "name", "code", "is_active", "created_at", "updated_at"
        ).filter(filters)

    @staticmethod
    def get_by_id(*, kind, item_id: int):
        return CatalogRepository._model(kind).objects.filter(pk=item_id).first()

    @staticmethod
    def get_code_conflict(*, kind, code: str, exclude_id=None):
        model = CatalogRepository._model(kind)
        qs = model.objects.filter(code=code.strip().upper())
        if exclude_id is not None:
            qs = qs.exclude(pk=exclude_id)
        return qs.first()

    @staticmethod
    def create_item(*, kind, name, code, is_active=True):
        return CatalogRepository._model(kind).objects.create(
            name=name,
            code=code.strip().upper(),
            is_active=is_active,
        )

    @staticmethod
    def update_item(*, kind, item, name, code, is_active):
        item.name = name
        item.code = code.strip().upper()
        item.is_active = is_active
        item.save(update_fields=["name", "code", "is_active", "updated_at"])
        return item

    @staticmethod
    def delete_by_ids(*, kind, item_ids: list[int]) -> int:
        if not item_ids:
            return 0
        count, _ = CatalogRepository._model(kind).objects.filter(id__in=item_ids).delete()
        return count

    @staticmethod
    def toggle_active_by_ids(*, kind, item_ids: list[int]) -> int:
        if not item_ids:
            return 0
        return CatalogRepository._model(kind).objects.filter(id__in=item_ids).update(
            is_active=Case(
                When(is_active=True, then=Value(False)),
                default=Value(True),
                output_field=BooleanField(),
            ),
            updated_at=timezone.now(),
        )
'''
    repo.write_text(text, encoding="utf-8")
    print("appended CatalogRepository")
else:
    print("CatalogRepository exists")

print("catalog core done")
