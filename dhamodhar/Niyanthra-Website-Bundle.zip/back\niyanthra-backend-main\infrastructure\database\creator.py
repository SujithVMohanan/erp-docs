import re

import psycopg

from infrastructure.database.credentials import (
    CredentialResolver,
    DatabaseCredentials,
)

_SAFE_DB_NAME = re.compile(r"^[a-z][a-z0-9_]{0,62}$")


class DatabaseCreator:

    @staticmethod
    def validate_db_name(db_name: str) -> str:
        name = (db_name or "").strip().lower()

        if not _SAFE_DB_NAME.match(name):
            raise ValueError(
                "Invalid database name. Use lowercase letters, numbers, underscore."
            )

        return name

    @staticmethod
    def create(
        *,
        db_name: str,
        credentials: DatabaseCredentials | None = None,
    ) -> str:
        db_name = DatabaseCreator.validate_db_name(db_name)
        admin = credentials or CredentialResolver.admin_credentials()

        with psycopg.connect(
            host=admin.host,
            port=admin.port,
            user=admin.user,
            password=admin.password,
            dbname=admin.admin_db,
            autocommit=True,
        ) as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    "SELECT 1 FROM pg_database WHERE datname = %s",
                    (db_name,),
                )
                exists = cursor.fetchone() is not None

                if not exists:
                    # Name validated above — safe as a quoted identifier
                    cursor.execute(f'CREATE DATABASE "{db_name}"')

        return db_name
