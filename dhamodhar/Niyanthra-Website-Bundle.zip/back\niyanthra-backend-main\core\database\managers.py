"""Default querysets hide soft-deleted rows. Bulk delete is one UPDATE."""

from django.db import models
from django.utils import timezone


def _touch_updated_at(model, payload: dict, now) -> dict:
    if any(field.name == "updated_at" for field in model._meta.fields):
        payload["updated_at"] = now
    return payload


class SoftDeleteQuerySet(models.QuerySet):
    def alive(self):
        return self.filter(deleted_at__isnull=True)

    def dead(self):
        return self.filter(deleted_at__isnull=False)

    def delete(self):
        now = timezone.now()
        payload = _touch_updated_at(self.model, {"deleted_at": now}, now)
        count = self.alive().update(**payload)
        return count, {self.model._meta.label: count}

    def restore(self):
        now = timezone.now()
        payload = _touch_updated_at(self.model, {"deleted_at": None}, now)
        return self.dead().update(**payload)


class SoftDeleteManager(models.Manager.from_queryset(SoftDeleteQuerySet)):
    def get_queryset(self):
        return super().get_queryset().alive()


class AllObjectsManager(models.Manager.from_queryset(SoftDeleteQuerySet)):
    """Includes deleted rows. Use for restore, audit, and admin."""
