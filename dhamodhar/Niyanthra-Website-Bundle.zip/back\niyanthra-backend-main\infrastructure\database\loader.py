import logging
import sys

from django.db import connections

from infrastructure.database.connection import ConnectionRegistry
from infrastructure.database.credentials import (
    CredentialResolver,
    DatabaseCredentials,
)

logger = logging.getLogger("niyanthra")

_SKIP_ARGV = {
    "migrate",
    "makemigrations",
    "showmigrations",
    "collectstatic",
}


class TenantConnectionLoader:
    """Register Django DB aliases for ACTIVE isolated/silo tenants."""

    @staticmethod
    def should_skip_autoload() -> bool:
        return any(arg in _SKIP_ARGV for arg in sys.argv)

    @staticmethod
    def build_runtime_credentials(
        *,
        host: str | None = None,
        port: int | None = None,
        secret_arn: str | None = None,
        secret_name: str | None = None,
    ) -> DatabaseCredentials:
        runtime = CredentialResolver.resolve(
            secret_arn=secret_arn,
            secret_name=secret_name,
        )

        return DatabaseCredentials(
            host=host or runtime.host,
            port=int(port or runtime.port),
            user=runtime.user,
            password=runtime.password,
            admin_db=runtime.admin_db,
            secret_arn=runtime.secret_arn or secret_arn,
            secret_name=runtime.secret_name or secret_name,
        )

    @staticmethod
    def register_tenant_database(
        *,
        db_alias: str,
        db_name: str,
        host: str,
        port: int,
        secret_arn: str | None = None,
        secret_name: str | None = None,
    ) -> dict:
        credentials = TenantConnectionLoader.build_runtime_credentials(
            host=host,
            port=port,
            secret_arn=secret_arn,
            secret_name=secret_name,
        )
        return ConnectionRegistry.register(
            alias=db_alias,
            db_name=db_name,
            credentials=credentials,
        )

    @staticmethod
    def ensure_alias(db_alias: str) -> bool:
        return db_alias in connections.databases

    @staticmethod
    def load_by_alias(db_alias: str) -> bool:
        from apps.tenant.models import Tenant
        from apps.tenant.repository import TenantRepository

        tenant = (
            Tenant.objects
            .filter(
                db_alias=db_alias,
                tenant_type__in=[
                    Tenant.TenantType.ISOLATED,
                    Tenant.TenantType.SILO,
                ],
                provisioning_status=Tenant.ProvisioningStatus.ACTIVE,
                is_active=True,
            )
            .only("id", "db_alias")
            .first()
        )
        if tenant is None:
            return False

        current_db = TenantRepository.get_current_database(tenant)
        if (
            current_db is None
            or not current_db.db_name
            or not current_db.host
            or not current_db.port
        ):
            return False

        TenantConnectionLoader.register_tenant_database(
            db_alias=tenant.db_alias,
            db_name=current_db.db_name,
            host=current_db.host,
            port=current_db.port,
            secret_arn=current_db.secret_arn,
            secret_name=current_db.secret_name,
        )
        return True

    @staticmethod
    def load_active_connections() -> int:
        from apps.tenant.models import Tenant
        from apps.tenant.repository import TenantRepository

        tenants = Tenant.objects.filter(
            tenant_type__in=[
                Tenant.TenantType.ISOLATED,
                Tenant.TenantType.SILO,
            ],
            provisioning_status=Tenant.ProvisioningStatus.ACTIVE,
            is_active=True,
        ).only(
            "id",
            "db_alias",
            "tenant_type",
            "provisioning_status",
        )

        loaded = 0

        for tenant in tenants:
            current_db = TenantRepository.get_current_database(tenant)
            if current_db is None:
                continue
            if not current_db.db_name or not current_db.host or not current_db.port:
                continue

            try:
                TenantConnectionLoader.register_tenant_database(
                    db_alias=tenant.db_alias,
                    db_name=current_db.db_name,
                    host=current_db.host,
                    port=current_db.port,
                    secret_arn=current_db.secret_arn,
                    secret_name=current_db.secret_name,
                )
                loaded += 1
            except Exception:
                logger.exception(
                    "Failed to register tenant DB alias=%s",
                    tenant.db_alias,
                )

        return loaded
