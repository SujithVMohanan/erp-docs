from rest_framework import serializers

from apps.access.models import (
    Group,
    Permission,
    Role,
    UserGroupAssignment,
)
from core.utils.ids import encode_id


class GetPermissionsApiSchema(serializers.ModelSerializer):
    uid = serializers.SerializerMethodField()

    class Meta:
        model = Permission
        fields = [
            "uid",
            "public_id",
            "codename",
            "name",
            "content_type",
            "label",
            "sub_label",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data


class GetRolesApiSchema(serializers.ModelSerializer):
    uid         = serializers.SerializerMethodField()
    company     = serializers.SerializerMethodField()
    permissions = serializers.SerializerMethodField()

    class Meta:
        model = Role
        fields = [
            "uid",
            "public_id",
            "name",
            "is_active",
            "company",
            "permissions",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_company(self, instance) -> dict:
        company = instance.company
        return {
            "uid": encode_id(company.pk),
            "public_id": str(company.public_id),
            "name": company.name or "",
            "code": company.code or "",
        }

    def get_permissions(self, instance) -> list:
        return [
            {
                "uid": encode_id(p.pk),
                "codename": p.codename or "",
                "name": p.name or "",
            }
            for p in instance.permissions.all()
        ]

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data


class GetGroupsApiSchema(serializers.ModelSerializer):
    uid     = serializers.SerializerMethodField()
    company = serializers.SerializerMethodField()
    roles   = serializers.SerializerMethodField()

    class Meta:
        model = Group
        fields = [
            "uid",
            "public_id",
            "name",
            "is_active",
            "company",
            "roles",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_company(self, instance) -> dict:
        company = instance.company
        return {
            "uid": encode_id(company.pk),
            "public_id": str(company.public_id),
            "name": company.name or "",
            "code": company.code or "",
        }

    def get_roles(self, instance) -> list:
        return [
            {
                "uid": encode_id(r.pk),
                "name": r.name or "",
            }
            for r in instance.roles.all()
        ]

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data


class GetUserGroupAssignmentsApiSchema(serializers.ModelSerializer):
    uid     = serializers.SerializerMethodField()
    user    = serializers.SerializerMethodField()
    group   = serializers.SerializerMethodField()
    company = serializers.SerializerMethodField()

    class Meta:
        model = UserGroupAssignment
        fields = [
            "uid",
            "public_id",
            "is_active",
            "user",
            "group",
            "company",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_user(self, instance) -> dict:
        user = instance.user
        return {
            "uid": encode_id(user.pk),
            "public_id": str(user.public_id),
            "email": user.email or "",
            "username": user.username or "",
        }

    def get_group(self, instance) -> dict:
        group = instance.group
        return {
            "uid": encode_id(group.pk),
            "name": group.name or "",
        }

    def get_company(self, instance) -> dict:
        company = instance.group.company
        return {
            "uid": encode_id(company.pk),
            "public_id": str(company.public_id),
            "name": company.name or "",
            "code": company.code or "",
        }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data
