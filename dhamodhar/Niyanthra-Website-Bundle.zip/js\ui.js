/**
 * Shared UI helpers: toast, modal, popover, form validation, confirm discard.
 * Presentation / interaction only — no business API changes.
 */
(function (global) {
  "use strict";

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function ensureToastHost() {
    let host = document.getElementById("toast-host");
    if (!host) {
      host = document.createElement("div");
      host.id = "toast-host";
      host.className = "toast-host";
      host.setAttribute("aria-live", "polite");
      document.body.appendChild(host);
    }
    return host;
  }

  function toast(message, ms) {
    const host = ensureToastHost();
    const el = document.createElement("div");
    el.className = "toast";
    el.setAttribute("role", "status");
    el.textContent = message;
    host.appendChild(el);
    const life = typeof ms === "number" ? ms : 2800;
    setTimeout(() => {
      el.remove();
    }, life);
  }

  let activeModal = null;
  let lastFocus = null;

  function getFocusable(root) {
    return Array.from(
      root.querySelectorAll(
        'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
      )
    ).filter((el) => el.offsetParent !== null || el === document.activeElement);
  }

  function openModal(opts) {
    closeModal(true);
    lastFocus = document.activeElement;
    const root = document.createElement("div");
    root.className = "modal-root is-open";
    root.setAttribute("role", "presentation");

    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";

    const dialog = document.createElement("div");
    dialog.className = "modal modal-" + (opts.size || "md");
    dialog.setAttribute("role", "dialog");
    dialog.setAttribute("aria-modal", "true");
    dialog.setAttribute("aria-labelledby", "modal-title");

    const header = document.createElement("div");
    header.className = "modal-header";
    header.innerHTML =
      "<h2 id=\"modal-title\"></h2><button type=\"button\" class=\"btn btn-icon\" data-modal-close aria-label=\"Close\">×</button>";
    header.querySelector("h2").textContent = opts.title || "";

    const body = document.createElement("div");
    body.className = "modal-body";
    if (typeof opts.body === "string") body.innerHTML = opts.body;
    else if (opts.body) body.appendChild(opts.body);

    const footer = document.createElement("div");
    footer.className = "modal-footer";
    (opts.actions || []).forEach((action) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "btn " + (action.className || "btn-secondary");
      btn.textContent = action.label;
      btn.addEventListener("click", () => {
        if (action.onClick) action.onClick({ close: () => closeModal(), setLoading: setLoading });
        else if (action.close !== false) closeModal();
      });
      footer.appendChild(btn);
    });

    dialog.append(header, body);
    if ((opts.actions || []).length) dialog.appendChild(footer);
    root.append(backdrop, dialog);
    document.body.appendChild(root);
    activeModal = { root, dialog, opts, footer };

    const lockOutside = opts.lockOutside === true;
    if (!lockOutside) {
      backdrop.addEventListener("click", () => closeModal());
    }
    root.querySelector("[data-modal-close]").addEventListener("click", () => {
      if (!lockOutside || opts.allowClose) closeModal();
    });

    function onKey(e) {
      if (e.key === "Escape" && !lockOutside) {
        e.preventDefault();
        closeModal();
        return;
      }
      if (e.key !== "Tab") return;
      const nodes = getFocusable(dialog);
      if (!nodes.length) return;
      const first = nodes[0];
      const last = nodes[nodes.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
    root._onKey = onKey;
    document.addEventListener("keydown", onKey);

    const focusables = getFocusable(dialog);
    (focusables[0] || dialog).focus();

    function setLoading(on) {
      footer.querySelectorAll("button").forEach((b) => {
        b.disabled = !!on;
      });
      const primary = footer.querySelector(".btn-primary");
      if (primary) {
        if (on) {
          primary.dataset.label = primary.textContent;
          primary.innerHTML = '<span class="spinner" aria-hidden="true"></span> Saving…';
        } else if (primary.dataset.label) {
          primary.textContent = primary.dataset.label;
        }
      }
    }

    return { close: closeModal, setLoading };
  }

  function closeModal(skipFocus) {
    if (!activeModal) return;
    document.removeEventListener("keydown", activeModal.root._onKey);
    activeModal.root.remove();
    activeModal = null;
    if (!skipFocus && lastFocus && typeof lastFocus.focus === "function") {
      lastFocus.focus();
    }
  }

  function confirmDiscard(onConfirm) {
    return openModal({
      title: "Discard unsaved changes?",
      size: "sm",
      lockOutside: true,
      body: "<p>You have unsaved edits. If you leave now, those changes will be lost.</p>",
      actions: [
        { label: "Keep editing", className: "btn-secondary", close: true },
        {
          label: "Discard",
          className: "btn-danger",
          onClick: ({ close }) => {
            close();
            onConfirm();
          },
        },
      ],
    });
  }

  /* Popover */
  let openPop = null;

  function closePopover() {
    if (!openPop) return;
    document.removeEventListener("mousedown", openPop.onDoc);
    document.removeEventListener("keydown", openPop.onKey);
    openPop.el.classList.remove("is-open");
    openPop.trigger.setAttribute("aria-expanded", "false");
    if (openPop.restoreFocus) openPop.trigger.focus();
    openPop = null;
  }

  function openPopover(trigger, popoverEl, opts) {
    opts = opts || {};
    if (openPop && openPop.el === popoverEl) {
      closePopover();
      return;
    }
    closePopover();
    const rect = trigger.getBoundingClientRect();
    popoverEl.style.position = "fixed";
    popoverEl.style.top = Math.min(window.innerHeight - 8, rect.bottom + 4) + "px";
    popoverEl.style.left = Math.min(window.innerWidth - 200, Math.max(8, rect.left)) + "px";
    popoverEl.classList.add("is-open");
    trigger.setAttribute("aria-expanded", "true");

    const items = Array.from(popoverEl.querySelectorAll(".popover-item, [role='menuitem']"));
    let idx = 0;
    if (items[0]) items[0].focus();

    function onDoc(e) {
      if (popoverEl.contains(e.target) || trigger.contains(e.target)) return;
      closePopover();
    }
    function onKey(e) {
      if (e.key === "Escape") {
        e.preventDefault();
        closePopover();
        return;
      }
      if (!items.length) return;
      if (e.key === "ArrowDown") {
        e.preventDefault();
        idx = (idx + 1) % items.length;
        items[idx].focus();
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        idx = (idx - 1 + items.length) % items.length;
        items[idx].focus();
      } else if (e.key === "Enter" || e.key === " ") {
        if (document.activeElement && items.includes(document.activeElement)) {
          e.preventDefault();
          document.activeElement.click();
        }
      }
    }

    openPop = { el: popoverEl, trigger, onDoc, onKey, restoreFocus: opts.restoreFocus !== false };
    setTimeout(() => {
      document.addEventListener("mousedown", onDoc);
      document.addEventListener("keydown", onKey);
    }, 0);
  }

  /* Form: validate on blur/submit, not every keystroke */
  function wireFieldA11y(field) {
    const control = field.querySelector(".field-control, input, select, textarea");
    if (!control) return;
    const err = field.querySelector(".field-error");
    const hint = field.querySelector(".field-hint");
    if (err && !err.id) {
      err.id = (control.id || "field") + "-error";
    }
    if (hint && !hint.id) {
      hint.id = (control.id || "field") + "-hint";
    }
    const described = [];
    if (hint) described.push(hint.id);
    if (err) described.push(err.id);
    if (described.length) control.setAttribute("aria-describedby", described.join(" "));

    const label = field.querySelector(".field-label");
    if (label && control.hasAttribute("required") && !label.querySelector(".req")) {
      const star = document.createElement("span");
      star.className = "req";
      star.setAttribute("aria-hidden", "true");
      star.textContent = "*";
      label.appendChild(star);
    }
  }

  function validateField(field) {
    const control = field.querySelector(".field-control, input, select, textarea");
    if (!control) return true;
    const required = control.hasAttribute("required") || field.dataset.required === "true";
    const err = field.querySelector(".field-error");
    let message = "";
    const value = (control.value || "").trim();

    if (required && !value) {
      message = err ? err.dataset.default || "This field is required." : "This field is required.";
    } else if (control.type === "email" && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      message = "Enter a valid email address.";
    } else if (control.minLength > 0 && value && value.length < control.minLength) {
      message = "Must be at least " + control.minLength + " characters.";
    }

    if (message) {
      field.classList.add("is-invalid");
      field.classList.remove("is-valid");
      control.setAttribute("aria-invalid", "true");
      if (err) err.textContent = message;
      return false;
    }
    field.classList.remove("is-invalid");
    if (value) field.classList.add("is-valid");
    else field.classList.remove("is-valid");
    control.setAttribute("aria-invalid", "false");
    return true;
  }

  function updateFormSummary(form, ok) {
    const summary = form.querySelector(".form-summary");
    if (!summary) return;
    if (ok) {
      summary.classList.remove("is-visible");
      summary.hidden = true;
      return;
    }
    const count = form.querySelectorAll(".field.is-invalid").length;
    summary.classList.add("is-visible", "banner", "banner-error");
    summary.hidden = false;
    summary.setAttribute("role", "alert");
    summary.innerHTML =
      "<strong>Fix " +
      count +
      " field" +
      (count === 1 ? "" : "s") +
      "</strong> — check the highlighted items below, then try again.";
  }

  function bindForm(form, onValid) {
    form.querySelectorAll(".field").forEach((field) => {
      wireFieldA11y(field);
      const control = field.querySelector(".field-control, input, select, textarea");
      if (!control) return;
      control.addEventListener("blur", () => {
        validateField(field);
      });
      control.addEventListener("input", () => {
        if (field.classList.contains("is-invalid")) validateField(field);
      });
      control.addEventListener("change", () => {
        if (field.classList.contains("is-invalid") || control.tagName === "SELECT") validateField(field);
      });
    });

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      let ok = true;
      form.querySelectorAll(".field").forEach((field) => {
        if (!validateField(field)) ok = false;
      });
      updateFormSummary(form, ok);
      if (!ok) {
        const first = form.querySelector(".field.is-invalid .field-control, .field.is-invalid input, .field.is-invalid select, .field.is-invalid textarea");
        if (first) first.focus();
        return;
      }
      onValid(form);
    });
  }

  function markDirtyBar(metaEl, dirty) {
    if (!metaEl) return;
    if (dirty) {
      metaEl.textContent = "Unsaved changes";
      metaEl.classList.add("is-dirty");
    } else {
      metaEl.textContent = "";
      metaEl.classList.remove("is-dirty");
    }
  }

  function setButtonLoading(btn, on, label) {
    if (!btn) return;
    if (on) {
      btn.disabled = true;
      btn.dataset.label = btn.textContent;
      btn.innerHTML = '<span class="spinner" aria-hidden="true"></span> ' + (label || "Saving…");
    } else {
      btn.disabled = false;
      btn.textContent = btn.dataset.label || label || "Save";
    }
  }

  /* Setup progress storage (prototype only) */
  const SETUP_KEY = "niyanthra_setup_v1";

  function loadSetup() {
    try {
      return JSON.parse(localStorage.getItem(SETUP_KEY) || "{}");
    } catch (e) {
      return {};
    }
  }

  function saveSetup(patch) {
    const next = Object.assign(loadSetup(), patch, { updatedAt: Date.now() });
    localStorage.setItem(SETUP_KEY, JSON.stringify(next));
    return next;
  }

  function setupState() {
    const data = loadSetup();
    const profileDone = !!(data.fullName && data.email);
    const orgDone = !!(data.orgName);
    return {
      data,
      profileDone,
      orgDone,
      companyReady: profileDone && orgDone,
    };
  }

  function renderSetupProgress(current) {
    const nav = document.getElementById("setup-progress");
    if (!nav) return;
    const st = setupState();
    const steps = [
      { id: "profile", label: "Profile", href: "setup-profile.html", done: st.profileDone },
      { id: "organization", label: "Organization", href: "setup-organization.html", done: st.orgDone, locked: !st.profileDone },
      { id: "company", label: "Company", href: "workspace.html", done: false, locked: !st.companyReady },
    ];

    nav.innerHTML = "";
    steps.forEach((step, i) => {
      if (i) {
        const sep = document.createElement("span");
        sep.className = "setup-sep";
        sep.setAttribute("aria-hidden", "true");
        nav.appendChild(sep);
      }
      const btn = document.createElement("button");
      btn.type = "button";
      let state = "ready";
      if (step.locked) state = "locked";
      else if (step.id === current) state = "current";
      else if (step.done) state = "completed";
      else if (step.id !== current && !step.done && !step.locked) state = "ready";

      btn.className = "setup-step is-" + state;
      if (step.id === current) btn.setAttribute("aria-current", "step");
      const mark = state === "completed" ? "✓" : String(i + 1);
      btn.innerHTML = '<span class="num" aria-hidden="true">' + mark + '</span><span class="label">' + step.label + "</span>";
      btn.setAttribute("aria-label", step.label + (state === "locked" ? ", locked" : state === "completed" ? ", completed" : state === "current" ? ", current" : ", ready"));

      if (state === "locked") {
        btn.disabled = true;
      } else {
        btn.addEventListener("click", () => {
          if (step.id === current) return;
          window.location.href = step.href;
        });
      }
      nav.appendChild(btn);
    });
  }

  global.UI = {
    toast,
    openModal,
    closeModal,
    confirmDiscard,
    openPopover,
    closePopover,
    bindForm,
    validateField,
    markDirtyBar,
    setButtonLoading,
    loadSetup,
    saveSetup,
    setupState,
    renderSetupProgress,
    reduceMotion,
  };
})(window);
