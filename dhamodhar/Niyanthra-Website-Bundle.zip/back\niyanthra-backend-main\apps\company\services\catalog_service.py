from django.db import IntegrityError
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.company.repository import CatalogRepository
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class _CatalogMixin:
    kind = ""
    code_error = "CODE_EXISTS"
    not_found = "Not found."

    @classmethod
    def _decode_uid(cls, uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})
        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})
        return decoded

    @classmethod
    def _decode_uids(cls, uids: list[str]) -> list[int]:
        return list(dict.fromkeys(cls._decode_uid(uid, field="uids") for uid in uids))

    @classmethod
    def list_items(cls, *, validated_data: dict):
        item_id = None
        if validated_data.get("uid"):
            item_id = [cls._decode_uid(validated_data["uid"])]
        return CatalogRepository.list_items(
            kind=cls.kind,
            item_id=item_id,
            code=validated_data.get("code"),
            name=validated_data.get("name"),
            is_active=validated_data.get("is_active"),
        )

    @classmethod
    def create_item(cls, *, validated_data: dict):
        code = validated_data["code"]
        if CatalogRepository.get_code_conflict(kind=cls.kind, code=code):
            raise AuthValidationError(
                {"code": ["This code already exists."]},
                code=cls.code_error,
            )
        try:
            return CatalogRepository.create_item(
                kind=cls.kind,
                name=validated_data["name"],
                code=code,
                is_active=validated_data.get("is_active", True),
            )
        except IntegrityError:
            raise AuthValidationError(
                {"code": ["This code already exists."]},
                code=cls.code_error,
            ) from None

    @classmethod
    def update_item(cls, *, validated_data: dict):
        item = CatalogRepository.get_by_id(
            kind=cls.kind,
            item_id=cls._decode_uid(validated_data["uid"]),
        )
        if item is None:
            raise NotFound(cls.not_found)
        code = validated_data["code"]
        if CatalogRepository.get_code_conflict(
            kind=cls.kind,
            code=code,
            exclude_id=item.pk,
        ):
            raise AuthValidationError(
                {"code": ["This code already exists."]},
                code=cls.code_error,
            )
        try:
            return CatalogRepository.update_item(
                kind=cls.kind,
                item=item,
                name=validated_data["name"],
                code=code,
                is_active=validated_data.get("is_active", item.is_active),
            )
        except IntegrityError:
            raise AuthValidationError(
                {"code": ["This code already exists."]},
                code=cls.code_error,
            ) from None

    @classmethod
    def delete_items(cls, *, validated_data: dict) -> dict:
        ids = cls._decode_uids(validated_data["uids"])
        deleted = CatalogRepository.delete_by_ids(kind=cls.kind, item_ids=ids)
        if not deleted:
            raise NotFound(cls.not_found)
        return {"deleted": deleted}

    @classmethod
    def toggle_items(cls, *, validated_data: dict):
        ids = cls._decode_uids(validated_data["uids"])
        updated = CatalogRepository.toggle_active_by_ids(kind=cls.kind, item_ids=ids)
        if not updated:
            raise NotFound(cls.not_found)
        return CatalogRepository.list_items(kind=cls.kind, item_id=ids)


class CompanyTypeService(_CatalogMixin):
    kind = "company_type"
    code_error = "COMPANY_TYPE_CODE_EXISTS"
    not_found = "Company type not found."


class BusinessTypeService(_CatalogMixin):
    kind = "business_type"
    code_error = "BUSINESS_TYPE_CODE_EXISTS"
    not_found = "Business type not found."
