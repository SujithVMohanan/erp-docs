"""Generate remaining control-plane CRUD (except background)."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def write(rel: str, content: str) -> None:
    path = ROOT / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content.lstrip("\n"), encoding="utf-8")
    print("wrote", rel)


def append_once(rel: str, marker: str, content: str) -> None:
    path = ROOT / rel
    text = path.read_text(encoding="utf-8")
    if marker in text:
        print("skip append", rel, marker)
        return
    path.write_text(text.rstrip() + "\n\n" + content.lstrip("\n"), encoding="utf-8")
    print("appended", rel, marker)


# ---------------------------------------------------------------------------
# Organization membership + location serializers / schemas / services / views
# ---------------------------------------------------------------------------

append_once(
    "apps/organization/serializers.py",
    "CreateOrganizationMembershipSerializer",
    '''
class CreateOrganizationMembershipSerializer(serializers.Serializer):
    organization_uid = serializers.CharField(trim_whitespace=True)
    user_uid         = serializers.CharField(trim_whitespace=True)
    role             = serializers.CharField(
        max_length=20,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )
    is_active        = serializers.BooleanField(required=False, default=True)

    def validate_role(self, value):
        normalized = (value or "").strip().lower() or "employee"
        if normalized not in {"owner", "admin", "employee"}:
            raise serializers.ValidationError(
                "Role must be owner, admin, or employee."
            )
        return normalized


class UpdateOrganizationMembershipSerializer(CreateOrganizationMembershipSerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetOrganizationMembershipsQuerySerializer(serializers.Serializer):
    uid              = serializers.CharField(required=False, allow_blank=True)
    organization_uid = serializers.CharField(required=False, allow_blank=True)
    user_uid         = serializers.CharField(required=False, allow_blank=True)
    role             = serializers.CharField(required=False, allow_blank=True, max_length=20)
    is_active        = serializers.BooleanField(required=False, allow_null=True)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["organization_uid"] = (attrs.get("organization_uid") or "").strip() or None
        attrs["user_uid"] = (attrs.get("user_uid") or "").strip() or None
        role = (attrs.get("role") or "").strip().lower() or None
        if role and role not in {"owner", "admin", "employee"}:
            raise serializers.ValidationError(
                {"role": ["Role must be owner, admin, or employee."]}
            )
        attrs["role"] = role
        if "is_active" not in attrs:
            attrs["is_active"] = None
        return attrs


class OrganizationMembershipUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique = []
        seen = set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError(
                "Select at least one organization membership."
            )
        return unique


class CreateOrganizationLocationSerializer(serializers.Serializer):
    organization_uid = serializers.CharField(trim_whitespace=True)
    location_uid     = serializers.CharField(trim_whitespace=True)
    location_type    = serializers.CharField(
        max_length=30,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )
    is_primary       = serializers.BooleanField(required=False, default=False)

    def validate_location_type(self, value):
        return (value or "").strip().upper() or "PRIMARY"


class UpdateOrganizationLocationSerializer(CreateOrganizationLocationSerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetOrganizationLocationsQuerySerializer(serializers.Serializer):
    uid              = serializers.CharField(required=False, allow_blank=True)
    organization_uid = serializers.CharField(required=False, allow_blank=True)
    location_uid     = serializers.CharField(required=False, allow_blank=True)
    is_primary       = serializers.BooleanField(required=False, allow_null=True)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["organization_uid"] = (attrs.get("organization_uid") or "").strip() or None
        attrs["location_uid"] = (attrs.get("location_uid") or "").strip() or None
        if "is_primary" not in attrs:
            attrs["is_primary"] = None
        return attrs


class OrganizationLocationUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique = []
        seen = set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError(
                "Select at least one organization location."
            )
        return unique
''',
)

# Fix organization schemas import + append
schemas_path = ROOT / "apps/organization/schemas.py"
schemas = schemas_path.read_text(encoding="utf-8")
if "OrganizationMembership" not in schemas:
    schemas = schemas.replace(
        "from apps.organization.models import (\n    Industry,\n    Organization,\n)",
        "from apps.organization.models import (\n    Industry,\n    Organization,\n    OrganizationLocation,\n    OrganizationMembership,\n)",
    )
    schemas_path.write_text(schemas, encoding="utf-8")

append_once(
    "apps/organization/schemas.py",
    "GetOrganizationMembershipsApiSchema",
    '''
class GetOrganizationMembershipsApiSchema(serializers.ModelSerializer):
    uid          = serializers.SerializerMethodField()
    organization = serializers.SerializerMethodField()
    user         = serializers.SerializerMethodField()

    class Meta:
        model = OrganizationMembership
        fields = [
            "uid",
            "public_id",
            "role",
            "is_active",
            "organization",
            "user",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_organization(self, instance) -> dict:
        org = instance.organization
        return {
            "uid": encode_id(org.pk),
            "public_id": str(org.public_id),
            "name": org.name or "",
            "code": org.code or "",
        }

    def get_user(self, instance) -> dict:
        user = instance.user
        return {
            "uid": encode_id(user.pk),
            "public_id": str(user.public_id),
            "email": user.email or "",
            "username": user.username or "",
        }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data


class GetOrganizationLocationsApiSchema(serializers.ModelSerializer):
    uid          = serializers.SerializerMethodField()
    organization = serializers.SerializerMethodField()
    location     = serializers.SerializerMethodField()

    class Meta:
        model = OrganizationLocation
        fields = [
            "uid",
            "public_id",
            "location_type",
            "is_primary",
            "organization",
            "location",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_organization(self, instance) -> dict:
        org = instance.organization
        return {
            "uid": encode_id(org.pk),
            "public_id": str(org.public_id),
            "name": org.name or "",
            "code": org.code or "",
        }

    def get_location(self, instance) -> dict:
        loc = instance.location
        return {
            "uid": encode_id(loc.pk),
            "public_id": str(loc.public_id),
            "city": loc.city or "",
            "address_line_1": loc.address_line_1 or "",
            "country_code": getattr(loc.country, "code", "") or "",
        }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data
''',
)

write(
    "apps/organization/services/organization_location_service.py",
    '''
from django.db import (
    IntegrityError,
    transaction,
)
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.location.repository import LocationRepository
from apps.organization.repository import (
    OrganizationLocationRepository,
    OrganizationRepository,
)
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class OrganizationLocationService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})
        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})
        return decoded

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        return list(
            dict.fromkeys(
                OrganizationLocationService._decode_uid(uid, field="uids")
                for uid in uids
            )
        )

    @staticmethod
    def get_links(*, validated_data: dict):
        link_id = None
        organization_id = None
        location_id = None
        if validated_data.get("uid"):
            link_id = [
                OrganizationLocationService._decode_uid(validated_data["uid"])
            ]
        if validated_data.get("organization_uid"):
            organization_id = OrganizationLocationService._decode_uid(
                validated_data["organization_uid"],
                field="organization_uid",
            )
        if validated_data.get("location_uid"):
            location_id = OrganizationLocationService._decode_uid(
                validated_data["location_uid"],
                field="location_uid",
            )
        return OrganizationLocationRepository.list_links(
            link_id=link_id,
            organization_id=organization_id,
            location_id=location_id,
            is_primary=validated_data.get("is_primary"),
        )

    @staticmethod
    def create_link(*, validated_data: dict):
        organization_id = OrganizationLocationService._decode_uid(
            validated_data["organization_uid"],
            field="organization_uid",
        )
        if OrganizationRepository.get_by_id(organization_id) is None:
            raise AuthValidationError(
                {"organization_uid": ["Organization not found."]},
                code="ORGANIZATION_NOT_FOUND",
            )
        location_id = OrganizationLocationService._decode_uid(
            validated_data["location_uid"],
            field="location_uid",
        )
        if LocationRepository.get_by_id(location_id) is None:
            raise AuthValidationError(
                {"location_uid": ["Location not found."]},
                code="LOCATION_NOT_FOUND",
            )
        if OrganizationLocationRepository.get_conflict(
            organization_id=organization_id,
            location_id=location_id,
        ):
            raise AuthValidationError(
                {"location_uid": ["Location already linked to organization."]},
                code="ORGANIZATION_LOCATION_EXISTS",
            )
        is_primary = validated_data.get("is_primary", False)
        try:
            with transaction.atomic():
                if is_primary:
                    OrganizationLocationRepository.clear_primary(
                        organization_id=organization_id
                    )
                link = OrganizationLocationRepository.create_link(
                    organization_id=organization_id,
                    location_id=location_id,
                    location_type=validated_data.get("location_type") or "PRIMARY",
                    is_primary=is_primary,
                )
        except IntegrityError:
            raise AuthValidationError(
                {"location_uid": ["Location already linked to organization."]},
                code="ORGANIZATION_LOCATION_EXISTS",
            ) from None
        return OrganizationLocationRepository.get_by_id(link.pk)

    @staticmethod
    def update_link(*, validated_data: dict):
        link = OrganizationLocationRepository.get_by_id(
            OrganizationLocationService._decode_uid(validated_data["uid"])
        )
        if link is None:
            raise NotFound("Organization location not found.")
        organization_id = OrganizationLocationService._decode_uid(
            validated_data["organization_uid"],
            field="organization_uid",
        )
        if OrganizationRepository.get_by_id(organization_id) is None:
            raise AuthValidationError(
                {"organization_uid": ["Organization not found."]},
                code="ORGANIZATION_NOT_FOUND",
            )
        location_id = OrganizationLocationService._decode_uid(
            validated_data["location_uid"],
            field="location_uid",
        )
        if LocationRepository.get_by_id(location_id) is None:
            raise AuthValidationError(
                {"location_uid": ["Location not found."]},
                code="LOCATION_NOT_FOUND",
            )
        if OrganizationLocationRepository.get_conflict(
            organization_id=organization_id,
            location_id=location_id,
            exclude_id=link.pk,
        ):
            raise AuthValidationError(
                {"location_uid": ["Location already linked to organization."]},
                code="ORGANIZATION_LOCATION_EXISTS",
            )
        is_primary = validated_data.get("is_primary", link.is_primary)
        try:
            with transaction.atomic():
                if is_primary:
                    OrganizationLocationRepository.clear_primary(
                        organization_id=organization_id,
                        exclude_id=link.pk,
                    )
                OrganizationLocationRepository.update_link(
                    link=link,
                    organization_id=organization_id,
                    location_id=location_id,
                    location_type=validated_data.get("location_type")
                    or link.location_type,
                    is_primary=is_primary,
                )
        except IntegrityError:
            raise AuthValidationError(
                {"location_uid": ["Location already linked to organization."]},
                code="ORGANIZATION_LOCATION_EXISTS",
            ) from None
        return OrganizationLocationRepository.get_by_id(link.pk)

    @staticmethod
    def delete_links(*, validated_data: dict) -> dict:
        link_ids = OrganizationLocationService._decode_uids(validated_data["uids"])
        deleted = OrganizationLocationRepository.delete_by_ids(link_ids)
        if not deleted:
            raise NotFound("Organization location not found.")
        return {"deleted": deleted}
''',
)

print("org serializers/schemas/services done")
