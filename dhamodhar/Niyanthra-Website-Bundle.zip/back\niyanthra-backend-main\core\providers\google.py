from django.conf import settings

from core.exceptions.auth import AuthFailed
from core.providers.identity import (
    SocialIdentity,
    claim_email,
    claim_email_verified,
)


_google_verifier = None
_google_request = None


def _get_google_verifier():
    global _google_verifier, _google_request

    if _google_verifier is not None:
        return _google_verifier, _google_request

    try:
        from google.auth.transport import requests
        from google.oauth2 import id_token
    except ImportError as exc:
        raise AuthFailed(
            "Google sign-in is unavailable.",
            code="GOOGLE_NOT_CONFIGURED",
        ) from exc

    _google_request = requests.Request()
    _google_verifier = id_token.verify_oauth2_token

    return _google_verifier, _google_request


def verify_google_token(
    *,
    id_token: str,
    nonce: str | None = None,
) -> SocialIdentity:
    provider_config = settings.AUTH_PROVIDERS.get("google", {})
    client_id = provider_config.get("client_id")

    if not client_id:
        raise AuthFailed(
            "Google sign-in is not configured.",
            code="GOOGLE_NOT_CONFIGURED",
        )

    verify_token, request = _get_google_verifier()

    try:
        claims = verify_token(
            id_token,
            request,
            audience=client_id,
            clock_skew_in_seconds=60,
        )
    except (ValueError, TypeError) as exc:
        raise AuthFailed(
            "Invalid Google token.",
            code="INVALID_GOOGLE_TOKEN",
        ) from exc

    subject = claims.get("sub")

    if not subject:
        raise AuthFailed(
            "Invalid Google token.",
            code="INVALID_GOOGLE_TOKEN",
        )

    issuer = claims.get("iss")
    if issuer not in {"accounts.google.com", "https://accounts.google.com"}:
        raise AuthFailed(
            "Invalid Google token.",
            code="INVALID_GOOGLE_TOKEN",
        )

    if nonce is not None and claims.get("nonce") != nonce:
        raise AuthFailed(
            "Invalid Google token.",
            code="INVALID_GOOGLE_TOKEN",
        )

    return SocialIdentity(
        provider="google",
        subject=str(subject),
        email=claim_email(claims.get("email")),
        email_verified=claim_email_verified(
            claims.get("email_verified")
        ),
        name=(claims.get("name") or "").strip() or None,
        picture=(claims.get("picture") or "").strip() or None,
    )