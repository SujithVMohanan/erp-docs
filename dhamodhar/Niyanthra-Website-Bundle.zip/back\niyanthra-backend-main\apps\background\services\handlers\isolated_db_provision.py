from apps.background.models import BackgroundJob
from apps.background.services.handlers.base import BaseJobHandler
from apps.tenant.services.database_provisioning_service import (
    TenantDatabaseProvisioningService,
)


class IsolatedDbProvisionHandler(BaseJobHandler):

    def execute(self, *, job: BackgroundJob) -> None:
        TenantDatabaseProvisioningService.provision_isolated(
            tenant=job.tenant
        )
