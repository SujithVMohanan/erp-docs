from core.seeders.management.commands._seed_base import SeedGroupCommand
from core.seeders.permission import run


class Command(SeedGroupCommand):
    help = "Seed Permission catalog. Safe to run multiple times."
    group_label = "Permission"
    seeder_run = staticmethod(run)
