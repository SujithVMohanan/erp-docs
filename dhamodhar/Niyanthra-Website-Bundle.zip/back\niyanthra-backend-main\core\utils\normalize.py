def normalize_phone(value: str | None) -> str | None:
    phone = "".join(str(value or "").split())
    return phone or None
