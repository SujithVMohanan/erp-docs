/**
 * Company workspace v2
 * - All sections hide/show (Companies, Details, Branches, Addresses)
 * - Max 3 sections open at once
 * - Multiple company addresses (add / edit)
 * Separate from workspace.js — original page unchanged.
 */
(function () {
  "use strict";

  const COMPANIES_KEY = "niyanthra_companies_v2";
  const VIS_KEY = "niyanthra_ws_v2_vis";
  const MAX_OPEN = 3;

  const CHOICES = {
    companyType: ["Private Limited", "LLP", "Partnership", "Sole Proprietorship"],
    businessType: ["Product", "Service", "Hybrid"],
    businessModel: ["B2B", "B2C", "B2B2C"],
    industry: ["Manufacturing", "Retail", "Hospitality", "Trading", "IT Services"],
    branchType: ["Head office", "Retail", "Warehouse", "Plant", "Mixed"],
    modules: ["Finance", "Inventory", "HR", "CRM", "Sales", "Manufacturing", "Projects"],
    financial: ["April–March, INR", "January–December, USD", "January–December, AED"],
    localization: ["India / English", "UAE / English", "US / English"],
    tax: ["Enable GST", "Skip for now", "GST", "VAT", "None"],
    status: ["Active", "Inactive"],
    addressType: ["Registered", "Billing", "Shipping", "Warehouse", "Other"],
  };

  function seedCompanies() {
    return [
      {
        id: "bakery",
        name: "ABC Bakery Pvt Ltd",
        status: "Active",
        companyType: "Private Limited",
        businessType: "Product",
        industry: "Retail",
        businessModel: "B2C",
        profile: "Fresh bakery products across Kerala.",
        modules: ["Finance", "Inventory", "Sales"],
        financial: "April–March, INR",
        localization: "India / English",
        tax: "Enable GST",
        branches: [
          { id: "bt", name: "Thrissur", location: "Thrissur", type: "Head office", status: "Active" },
          { id: "bk", name: "Kochi", location: "Kochi", type: "Retail", status: "Active" },
        ],
        addresses: [
          {
            id: "a1",
            type: "Registered",
            line1: "12 MG Road",
            line2: "Round West",
            city: "Thrissur",
            state: "Kerala",
            postal: "680001",
            country: "India",
          },
          {
            id: "a2",
            type: "Billing",
            line1: "Finance Desk, ABC Bakery",
            line2: "",
            city: "Thrissur",
            state: "Kerala",
            postal: "680001",
            country: "India",
          },
        ],
      },
      {
        id: "retail",
        name: "ABC Retail Pvt Ltd",
        status: "Active",
        companyType: "Private Limited",
        businessType: "Product",
        industry: "Trading",
        businessModel: "B2B2C",
        profile: "Grocery and staples.",
        modules: ["Finance", "Inventory", "CRM", "Sales"],
        financial: "April–March, INR",
        localization: "India / English",
        tax: "Enable GST",
        branches: [
          { id: "rt", name: "Thrissur", location: "Thrissur", type: "Retail", status: "Active" },
          { id: "rb", name: "Bangalore", location: "Bangalore", type: "Warehouse", status: "Active" },
        ],
        addresses: [
          {
            id: "a3",
            type: "Registered",
            line1: "45 Commercial Street",
            line2: "",
            city: "Bangalore",
            state: "Karnataka",
            postal: "560001",
            country: "India",
          },
        ],
      },
    ];
  }

  function loadCompanies() {
    try {
      const raw = localStorage.getItem(COMPANIES_KEY);
      if (raw) {
        const list = JSON.parse(raw);
        list.forEach((c) => {
          if (!Array.isArray(c.addresses)) c.addresses = [];
        });
        return list;
      }
    } catch (e) {}
    const seed = seedCompanies();
    localStorage.setItem(COMPANIES_KEY, JSON.stringify(seed));
    return seed;
  }

  function saveCompanies(list) {
    localStorage.setItem(COMPANIES_KEY, JSON.stringify(list));
  }

  function loadVis() {
    try {
      const raw = localStorage.getItem(VIS_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return { rail: true, details: true, branches: true, addresses: false };
  }

  function saveVis() {
    localStorage.setItem(
      VIS_KEY,
      JSON.stringify({
        rail: state.show.rail,
        details: state.show.details,
        branches: state.show.branches,
        addresses: state.show.addresses,
      })
    );
  }

  const savedVis = loadVis();
  const state = {
    companies: loadCompanies(),
    selectedId: null,
    filter: "",
    dirty: false,
    editingCompany: false,
    branchView: "list",
    editingBranchId: null,
    addressView: "list",
    editingAddressId: null,
    show: {
      rail: savedVis.rail !== false,
      details: savedVis.details !== false,
      branches: savedVis.branches !== false,
      addresses: !!savedVis.addresses,
    },
    mobileTab: "details",
  };

  // Enforce max 3 on load
  (function clampInitial() {
    const keys = ["rail", "details", "branches", "addresses"];
    let open = keys.filter((k) => state.show[k]);
    while (open.length > MAX_OPEN) {
      const drop = open.pop();
      state.show[drop] = false;
      open = keys.filter((k) => state.show[k]);
    }
    if (!open.length) {
      state.show.details = true;
    }
  })();

  const st = UI.setupState();
  if (!st.companyReady) {
    UI.saveSetup({
      fullName: st.data.fullName || "John",
      email: st.data.email || sessionStorage.getItem("niyanthraEmail") || "john@abc.example",
      orgName: st.data.orgName || "ABC Group",
    });
  }
  UI.renderSetupProgress("company");

  const $ = (id) => document.getElementById(id);
  const rail = $("company-rail");
  const listEl = $("company-list");
  const workspace = $("workspace");

  function selected() {
    return state.companies.find((c) => c.id === state.selectedId) || null;
  }

  function openCount() {
    return ["rail", "details", "branches", "addresses"].filter((k) => state.show[k]).length;
  }

  function warnIfDirty(next) {
    if (!state.dirty) {
      next();
      return;
    }
    UI.confirmDiscard(() => {
      state.dirty = false;
      state.editingCompany = false;
      state.branchView = "list";
      state.editingBranchId = null;
      state.addressView = "list";
      state.editingAddressId = null;
      next();
    });
  }

  function canShow(section) {
    if (state.show[section]) return true;
    return openCount() < MAX_OPEN;
  }

  function setSection(section, on) {
    if (on) {
      if (!canShow(section)) {
        UI.toast("Maximum " + MAX_OPEN + " sections open — hide one to show another");
        return false;
      }
      state.show[section] = true;
    } else {
      // Never hide the last remaining section among content+rail
      if (openCount() <= 1 && state.show[section]) {
        UI.toast("Keep at least one section open");
        return false;
      }
      state.show[section] = false;
      if (section === "details") {
        state.editingCompany = false;
        state.dirty = false;
      }
      if (section === "branches") {
        state.branchView = "list";
        state.editingBranchId = null;
      }
      if (section === "addresses") {
        state.addressView = "list";
        state.editingAddressId = null;
      }
    }
    saveVis();
    applyVisibility();
    return true;
  }

  function applyVisibility() {
    const mobile = window.matchMedia("(max-width: 860px)").matches;
    workspace.classList.toggle("rail-hidden", !state.show.rail);

    if (mobile) {
      rail.hidden = false;
      rail.classList.toggle("is-open", false);
    } else {
      rail.hidden = !state.show.rail;
      rail.classList.remove("is-open");
      $("drawer-backdrop").hidden = true;
      $("drawer-backdrop").classList.remove("is-open");
    }

    ["details", "branches", "addresses"].forEach((key) => {
      const panel = document.querySelector('[data-section="' + key + '"]');
      if (!panel) return;
      panel.hidden = !state.show[key];
      if (mobile) {
        panel.classList.toggle("is-mobile-hidden", state.mobileTab !== key || !state.show[key]);
        if (state.show[key] && state.mobileTab === key) panel.classList.remove("is-mobile-hidden");
      } else {
        panel.classList.remove("is-mobile-hidden");
      }
    });

    // Keep splits hidden — panel flex layout handles open/close cleanly
    $("split-1").hidden = true;
    $("split-2").hidden = true;

    document.querySelectorAll("[data-toggle-section]").forEach((btn) => {
      const key = btn.dataset.toggleSection;
      const pressed = !!state.show[key];
      btn.setAttribute("aria-pressed", String(pressed));
      // Disable turning ON when at max and this one is off
      btn.disabled = !pressed && openCount() >= MAX_OPEN;
    });

    document.querySelectorAll("[data-mobile-tab]").forEach((btn) => {
      const key = btn.dataset.mobileTab;
      btn.disabled = !state.show[key];
      btn.setAttribute("aria-selected", String(state.mobileTab === key && state.show[key]));
    });

    const hint = $("section-hint");
    if (hint) hint.textContent = openCount() + " / " + MAX_OPEN + " sections open";
  }

  function optionList(values, selected) {
    return values
      .map((v) => '<option value="' + v + '"' + (v === selected ? " selected" : "") + ">" + v + "</option>")
      .join("");
  }

  function escapeHtml(s) {
    return String(s || "").replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
  }
  function escapeAttr(s) {
    return escapeHtml(s).replace(/"/g, "&quot;");
  }

  function defItem(label, value, span) {
    const empty = !value;
    return (
      '<div class="def-item' +
      (span ? " def-span" : "") +
      '"><span class="def-label">' +
      label +
      '</span><div class="def-value' +
      (empty ? " is-empty" : "") +
      '">' +
      (empty ? "Not set" : escapeHtml(String(value))) +
      "</div></div>"
    );
  }

  function sectionHead(title, desc) {
    return (
      '<div class="form-section-head"><h2 class="form-section-title">' +
      title +
      "</h2>" +
      (desc ? '<p class="form-section-desc">' + desc + "</p>" : "") +
      "</div>"
    );
  }

  function filteredCompanies() {
    const q = state.filter.trim().toLowerCase();
    if (!q) return state.companies;
    return state.companies.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        (c.industry || "").toLowerCase().includes(q) ||
        (c.status || "").toLowerCase().includes(q)
    );
  }

  function renderList() {
    const items = filteredCompanies();
    listEl.innerHTML = "";
    if (!state.companies.length) {
      listEl.innerHTML =
        '<li><div class="empty-state" style="min-height:8rem;padding:1rem"><p>No companies yet.</p><button type="button" class="btn btn-primary" id="empty-add-co">Add company</button></div></li>';
      const btn = document.getElementById("empty-add-co");
      if (btn) btn.onclick = () => $("add-company").click();
      return;
    }
    if (!items.length) {
      listEl.innerHTML =
        '<li><div class="empty-state" style="min-height:8rem;padding:1rem"><p>No search results.</p><button type="button" class="btn btn-secondary" id="clear-search">Clear filter</button></div></li>';
      document.getElementById("clear-search").onclick = () => {
        $("company-search").value = "";
        state.filter = "";
        renderList();
      };
      return;
    }
    items.forEach((c) => {
      const li = document.createElement("li");
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "company-item";
      btn.setAttribute("role", "option");
      btn.setAttribute("aria-current", c.id === state.selectedId ? "true" : "false");
      const branchCount = (c.branches || []).length;
      const addrCount = (c.addresses || []).length;
      btn.innerHTML =
        '<span class="company-item-name"></span><span class="company-item-meta"><span></span><span class="tag ' +
        (c.status === "Active" ? "tag-ok" : "tag-warn") +
        '"></span></span>';
      btn.querySelector(".company-item-name").textContent = c.name;
      btn.querySelector(".company-item-meta span").textContent =
        branchCount + " branch" + (branchCount === 1 ? "" : "es") + " · " + addrCount + " address" + (addrCount === 1 ? "" : "es");
      btn.querySelector(".tag").textContent = c.status || "Active";
      btn.addEventListener("click", () => selectCompany(c.id));
      li.appendChild(btn);
      listEl.appendChild(li);
    });
  }

  function selectCompany(id) {
    warnIfDirty(() => {
      state.selectedId = id;
      state.editingCompany = false;
      state.branchView = "list";
      state.editingBranchId = null;
      state.addressView = "list";
      state.editingAddressId = null;
      renderList();
      renderWorkspace();
      if (window.matchMedia("(max-width: 860px)").matches) closeRailDrawer();
    });
  }

  function renderDetails() {
    const body = $("details-body");
    const foot = $("details-foot");
    const editBtn = $("edit-company");
    const co = selected();
    if (!co) {
      editBtn.hidden = true;
      foot.hidden = true;
      body.innerHTML = '<div class="empty-state"><p>Select a company from the list.</p></div>';
      return;
    }
    editBtn.hidden = state.editingCompany;
    if (!state.editingCompany) {
      foot.hidden = true;
      body.innerHTML =
        '<section class="form-section">' +
        sectionHead("Identity", "Legal name and registration style.") +
        '<div class="def-grid">' +
        defItem("Company name", co.name, true) +
        defItem("Company type", co.companyType) +
        defItem("Status", co.status) +
        "</div></section>" +
        '<section class="form-section">' +
        sectionHead("Business", "How this company operates.") +
        '<div class="def-grid">' +
        defItem("Business type", co.businessType) +
        defItem("Industry", co.industry) +
        defItem("Business model", co.businessModel) +
        defItem("Tax", co.tax) +
        defItem("Business profile", co.profile, true) +
        "</div></section>" +
        '<section class="form-section">' +
        sectionHead("Modules & locale", "Enabled modules and financial defaults.") +
        '<div class="def-grid">' +
        defItem("Modules", (co.modules || []).join(", "), true) +
        defItem("Financial year & currency", co.financial) +
        defItem("Country / language", co.localization) +
        "</div></section>";
      return;
    }

    foot.hidden = false;
    foot.innerHTML =
      '<div class="form-actions pinned" style="border:0;margin:0">' +
      '<span class="form-actions-meta" id="co-dirty-meta"></span>' +
      '<button type="button" class="btn btn-secondary" id="cancel-company">Cancel</button>' +
      '<button type="button" class="btn btn-primary" id="save-company">Save</button></div>';

    body.innerHTML =
      '<form id="company-form" novalidate><div class="form-summary" hidden></div>' +
      '<section class="form-section">' +
      sectionHead("Identity", "Update the name staff see in the company list.") +
      '<div class="form-stack"><div class="field"><label class="field-label" for="co-name">Company name</label>' +
      '<input class="field-control" id="co-name" required value="' +
      escapeAttr(co.name) +
      '" /><p class="field-error" data-default="Enter company name."></p></div>' +
      '<div class="field-row"><div class="field"><label class="field-label" for="co-type">Company type</label><select class="field-control" id="co-type">' +
      optionList(CHOICES.companyType, co.companyType) +
      '</select></div><div class="field"><label class="field-label" for="co-status">Status</label><select class="field-control" id="co-status">' +
      optionList(CHOICES.status, co.status || "Active") +
      "</select></div></div></div></section>" +
      '<section class="form-section">' +
      sectionHead("Business", "Company profile fields.") +
      '<div class="form-stack"><div class="field-row"><div class="field"><label class="field-label" for="co-btype">Business type</label><select class="field-control" id="co-btype">' +
      optionList(CHOICES.businessType, co.businessType) +
      '</select></div><div class="field"><label class="field-label" for="co-industry">Industry</label><select class="field-control" id="co-industry">' +
      optionList(CHOICES.industry, co.industry) +
      '</select></div></div><div class="field-row"><div class="field"><label class="field-label" for="co-model">Business model</label><select class="field-control" id="co-model">' +
      optionList(CHOICES.businessModel, co.businessModel) +
      '</select></div><div class="field"><label class="field-label" for="co-tax">Tax</label><select class="field-control" id="co-tax">' +
      optionList(CHOICES.tax, co.tax) +
      '</select></div></div><div class="field"><label class="field-label" for="co-profile">Business profile</label><textarea class="field-control" id="co-profile">' +
      escapeHtml(co.profile || "") +
      "</textarea></div></div></section>" +
      '<section class="form-section">' +
      sectionHead("Modules & locale", "") +
      '<div class="form-stack"><div class="field"><label class="field-label" for="co-modules">Modules</label><input class="field-control" id="co-modules" value="' +
      escapeAttr((co.modules || []).join(", ")) +
      '" /><p class="field-hint">Comma-separated list</p></div>' +
      '<div class="field-row"><div class="field"><label class="field-label" for="co-fin">Financial year &amp; currency</label><select class="field-control" id="co-fin">' +
      optionList(CHOICES.financial, co.financial) +
      '</select></div><div class="field"><label class="field-label" for="co-loc">Country / language</label><select class="field-control" id="co-loc">' +
      optionList(CHOICES.localization, co.localization) +
      "</select></div></div></div></section></form>";

    const dirtyMeta = document.getElementById("co-dirty-meta");
    const markDirty = () => {
      state.dirty = true;
      UI.markDirtyBar(dirtyMeta, true);
    };
    body.querySelectorAll("input, select, textarea").forEach((el) => {
      el.addEventListener("input", markDirty);
      el.addEventListener("change", markDirty);
    });

    $("cancel-company").onclick = () => {
      warnIfDirty(() => {
        state.editingCompany = false;
        state.dirty = false;
        renderDetails();
      });
    };
    $("save-company").onclick = () => {
      const nameField = document.getElementById("co-name").closest(".field");
      if (!UI.validateField(nameField)) {
        document.getElementById("co-name").focus();
        return;
      }
      const btn = $("save-company");
      UI.setButtonLoading(btn, true);
      setTimeout(() => {
        co.name = document.getElementById("co-name").value.trim();
        co.companyType = document.getElementById("co-type").value;
        co.status = document.getElementById("co-status").value;
        co.businessType = document.getElementById("co-btype").value;
        co.industry = document.getElementById("co-industry").value;
        co.businessModel = document.getElementById("co-model").value;
        co.tax = document.getElementById("co-tax").value;
        co.profile = document.getElementById("co-profile").value.trim();
        co.modules = document
          .getElementById("co-modules")
          .value.split(",")
          .map((s) => s.trim())
          .filter(Boolean);
        co.financial = document.getElementById("co-fin").value;
        co.localization = document.getElementById("co-loc").value;
        saveCompanies(state.companies);
        state.dirty = false;
        state.editingCompany = false;
        UI.setButtonLoading(btn, false, "Save");
        UI.toast("Company saved");
        renderList();
        renderWorkspace();
      }, 550);
    };
  }

  function renderBranches() {
    const body = $("branches-body");
    const co = selected();
    $("add-branch").hidden = !co || state.branchView !== "list";
    if (!co) {
      body.innerHTML = '<div class="empty-state"><p>Select a company to manage branches.</p></div>';
      return;
    }
    if (state.branchView === "add" || state.branchView === "edit") {
      const br =
        state.branchView === "edit"
          ? (co.branches || []).find((b) => b.id === state.editingBranchId)
          : { name: "", location: "", type: "Retail", status: "Active" };
      body.classList.remove("no-pad");
      body.innerHTML =
        '<div style="padding:0.75rem"><button type="button" class="back-link" id="branch-back">← Back to branches</button>' +
        '<div class="form-section-head" style="margin-bottom:0.85rem"><h2 class="form-section-title">' +
        (state.branchView === "edit" ? "Edit branch" : "Add branch") +
        '</h2></div><form id="branch-form" novalidate><div class="form-stack">' +
        '<div class="field"><label class="field-label" for="br-name">Branch name</label><input class="field-control" id="br-name" required value="' +
        escapeAttr(br.name || "") +
        '" /><p class="field-error" data-default="Enter branch name."></p></div>' +
        '<div class="field"><label class="field-label" for="br-loc">Location</label><input class="field-control" id="br-loc" value="' +
        escapeAttr(br.location || "") +
        '" /></div>' +
        '<div class="field-row"><div class="field"><label class="field-label" for="br-type">Branch type</label><select class="field-control" id="br-type">' +
        optionList(CHOICES.branchType, br.type || "Retail") +
        '</select></div><div class="field"><label class="field-label" for="br-status">Status</label><select class="field-control" id="br-status">' +
        optionList(CHOICES.status, br.status || "Active") +
        "</select></div></div></div>" +
        '<div class="form-actions pinned" style="margin:1rem -0.75rem -0.75rem"><span class="form-actions-meta" id="br-dirty-meta"></span>' +
        '<button type="button" class="btn btn-secondary" id="br-cancel">Cancel</button>' +
        '<button type="submit" class="btn btn-primary" id="br-save">Save</button></div></form></div>';

      const dirtyMeta = document.getElementById("br-dirty-meta");
      const markDirty = () => {
        state.dirty = true;
        UI.markDirtyBar(dirtyMeta, true);
      };
      body.querySelectorAll("input, select").forEach((el) => {
        el.addEventListener("input", markDirty);
        el.addEventListener("change", markDirty);
      });
      const back = () => {
        warnIfDirty(() => {
          state.branchView = "list";
          state.editingBranchId = null;
          state.dirty = false;
          renderBranches();
        });
      };
      $("branch-back").onclick = back;
      $("br-cancel").onclick = back;
      $("branch-form").onsubmit = (e) => {
        e.preventDefault();
        if (!UI.validateField(document.getElementById("br-name").closest(".field"))) return;
        const btn = $("br-save");
        UI.setButtonLoading(btn, true);
        setTimeout(() => {
          const wasEdit = state.branchView === "edit";
          const payload = {
            id: br.id || "br-" + Date.now(),
            name: document.getElementById("br-name").value.trim(),
            location: document.getElementById("br-loc").value.trim(),
            type: document.getElementById("br-type").value,
            status: document.getElementById("br-status").value,
          };
          if (wasEdit) {
            const i = co.branches.findIndex((b) => b.id === br.id);
            if (i >= 0) co.branches[i] = payload;
          } else {
            co.branches = co.branches || [];
            co.branches.push(payload);
          }
          saveCompanies(state.companies);
          state.dirty = false;
          state.branchView = "list";
          state.editingBranchId = null;
          UI.setButtonLoading(btn, false, "Save");
          UI.toast(wasEdit ? "Branch saved" : "Branch created");
          renderList();
          renderWorkspace();
        }, 500);
      };
      return;
    }

    body.classList.add("no-pad");
    const branches = co.branches || [];
    if (!branches.length) {
      body.innerHTML =
        '<div class="empty-state"><p>No branches yet — create your first branch to start managing locations for this company</p><button type="button" class="btn btn-primary" id="empty-add-br">Add Branch</button></div>';
      document.getElementById("empty-add-br").onclick = () => startAddBranch();
      return;
    }
    const ul = document.createElement("ul");
    ul.className = "branch-list";
    branches.forEach((b) => {
      const li = document.createElement("li");
      li.className = "branch-row";
      li.innerHTML =
        '<div><div class="branch-name"></div><div class="branch-meta"></div></div><span class="tag"></span><button type="button" class="btn btn-ghost">Edit</button>';
      li.querySelector(".branch-name").textContent = b.name;
      li.querySelector(".branch-meta").textContent = [b.location, b.type].filter(Boolean).join(" · ");
      const tag = li.querySelector(".tag");
      tag.textContent = b.status || "Active";
      tag.className = "tag " + (b.status === "Inactive" ? "tag-warn" : "tag-ok");
      li.querySelector("button").onclick = () => {
        warnIfDirty(() => {
          state.branchView = "edit";
          state.editingBranchId = b.id;
          state.dirty = false;
          renderBranches();
        });
      };
      ul.appendChild(li);
    });
    body.innerHTML = "";
    body.appendChild(ul);
  }

  function formatAddress(a) {
    return [a.line1, a.line2, [a.city, a.state].filter(Boolean).join(", "), a.postal, a.country]
      .filter(Boolean)
      .join("\n");
  }

  function renderAddresses() {
    const body = $("addresses-body");
    const co = selected();
    $("add-address").hidden = !co || state.addressView !== "list";
    if (!co) {
      body.innerHTML = '<div class="empty-state"><p>Select a company to manage addresses.</p></div>';
      return;
    }

    if (state.addressView === "add" || state.addressView === "edit") {
      const ad =
        state.addressView === "edit"
          ? (co.addresses || []).find((x) => x.id === state.editingAddressId)
          : { type: "Registered", line1: "", line2: "", city: "", state: "", postal: "", country: "India" };
      body.classList.remove("no-pad");
      body.innerHTML =
        '<div style="padding:0.75rem"><button type="button" class="back-link" id="addr-back">← Back to addresses</button>' +
        '<div class="form-section-head" style="margin-bottom:0.85rem"><h2 class="form-section-title">' +
        (state.addressView === "edit" ? "Edit address" : "Add address") +
        '</h2><p class="form-section-desc">Companies can have multiple addresses (registered, billing, shipping, and more).</p></div>' +
        '<form id="addr-form" novalidate><div class="form-stack">' +
        '<div class="field"><label class="field-label" for="ad-type">Address type</label><select class="field-control" id="ad-type">' +
        optionList(CHOICES.addressType, ad.type || "Registered") +
        "</select></div>" +
        '<div class="field"><label class="field-label" for="ad-line1">Address line 1</label><input class="field-control" id="ad-line1" required value="' +
        escapeAttr(ad.line1 || "") +
        '" placeholder="Street, building" /><p class="field-error" data-default="Enter address line 1."></p></div>' +
        '<div class="field"><label class="field-label" for="ad-line2">Address line 2</label><input class="field-control" id="ad-line2" value="' +
        escapeAttr(ad.line2 || "") +
        '" placeholder="Area, landmark (optional)" /></div>' +
        '<div class="field-row"><div class="field"><label class="field-label" for="ad-city">City</label><input class="field-control" id="ad-city" required value="' +
        escapeAttr(ad.city || "") +
        '" /><p class="field-error" data-default="Enter city."></p></div>' +
        '<div class="field"><label class="field-label" for="ad-state">State</label><input class="field-control" id="ad-state" value="' +
        escapeAttr(ad.state || "") +
        '" /></div></div>' +
        '<div class="field-row"><div class="field"><label class="field-label" for="ad-postal">Postal code</label><input class="field-control" id="ad-postal" value="' +
        escapeAttr(ad.postal || "") +
        '" /></div>' +
        '<div class="field"><label class="field-label" for="ad-country">Country</label><input class="field-control" id="ad-country" value="' +
        escapeAttr(ad.country || "") +
        '" /></div></div></div>' +
        '<div class="form-actions pinned" style="margin:1rem -0.75rem -0.75rem"><span class="form-actions-meta" id="ad-dirty-meta"></span>' +
        '<button type="button" class="btn btn-secondary" id="ad-cancel">Cancel</button>' +
        '<button type="submit" class="btn btn-primary" id="ad-save">Save</button></div></form></div>';

      const dirtyMeta = document.getElementById("ad-dirty-meta");
      const markDirty = () => {
        state.dirty = true;
        UI.markDirtyBar(dirtyMeta, true);
      };
      body.querySelectorAll("input, select").forEach((el) => {
        el.addEventListener("input", markDirty);
        el.addEventListener("change", markDirty);
      });
      const back = () => {
        warnIfDirty(() => {
          state.addressView = "list";
          state.editingAddressId = null;
          state.dirty = false;
          renderAddresses();
        });
      };
      $("addr-back").onclick = back;
      $("ad-cancel").onclick = back;
      $("addr-form").onsubmit = (e) => {
        e.preventDefault();
        const f1 = document.getElementById("ad-line1").closest(".field");
        const f2 = document.getElementById("ad-city").closest(".field");
        let ok = UI.validateField(f1);
        if (!UI.validateField(f2)) ok = false;
        if (!ok) return;
        const btn = $("ad-save");
        UI.setButtonLoading(btn, true);
        setTimeout(() => {
          const wasEdit = state.addressView === "edit";
          const payload = {
            id: ad.id || "ad-" + Date.now(),
            type: document.getElementById("ad-type").value,
            line1: document.getElementById("ad-line1").value.trim(),
            line2: document.getElementById("ad-line2").value.trim(),
            city: document.getElementById("ad-city").value.trim(),
            state: document.getElementById("ad-state").value.trim(),
            postal: document.getElementById("ad-postal").value.trim(),
            country: document.getElementById("ad-country").value.trim(),
          };
          co.addresses = co.addresses || [];
          if (wasEdit) {
            const i = co.addresses.findIndex((x) => x.id === ad.id);
            if (i >= 0) co.addresses[i] = payload;
          } else {
            co.addresses.push(payload);
          }
          saveCompanies(state.companies);
          state.dirty = false;
          state.addressView = "list";
          state.editingAddressId = null;
          UI.setButtonLoading(btn, false, "Save");
          UI.toast(wasEdit ? "Address saved" : "Address added");
          renderList();
          renderWorkspace();
        }, 500);
      };
      return;
    }

    body.classList.add("no-pad");
    const addresses = co.addresses || [];
    if (!addresses.length) {
      body.innerHTML =
        '<div class="empty-state"><p>No addresses yet — add registered, billing, or shipping addresses for this company</p><button type="button" class="btn btn-primary" id="empty-add-ad">Add address</button></div>';
      document.getElementById("empty-add-ad").onclick = () => startAddAddress();
      return;
    }
    const ul = document.createElement("ul");
    ul.className = "address-list";
    addresses.forEach((a) => {
      const li = document.createElement("li");
      li.className = "address-card";
      li.innerHTML =
        '<div class="address-card-top"><div><span class="tag tag-sky"></span> <span class="address-card-title"></span></div>' +
        '<button type="button" class="btn btn-ghost">Edit</button></div><div class="address-lines"></div>';
      li.querySelector(".tag").textContent = a.type || "Other";
      li.querySelector(".address-card-title").textContent = a.city || a.line1 || "Address";
      li.querySelector(".address-lines").innerHTML = formatAddress(a)
        .split("\n")
        .map((line) => "<span>" + escapeHtml(line) + "</span>")
        .join("");
      li.querySelector("button").onclick = () => {
        warnIfDirty(() => {
          state.addressView = "edit";
          state.editingAddressId = a.id;
          state.dirty = false;
          renderAddresses();
        });
      };
      ul.appendChild(li);
    });
    body.innerHTML = "";
    body.appendChild(ul);
  }

  function startAddBranch() {
    if (!selected()) return;
    if (!state.show.branches && !setSection("branches", true)) return;
    warnIfDirty(() => {
      state.branchView = "add";
      state.editingBranchId = null;
      state.dirty = false;
      state.mobileTab = "branches";
      applyVisibility();
      renderBranches();
    });
  }

  function startAddAddress() {
    if (!selected()) return;
    if (!state.show.addresses && !setSection("addresses", true)) return;
    warnIfDirty(() => {
      state.addressView = "add";
      state.editingAddressId = null;
      state.dirty = false;
      state.mobileTab = "addresses";
      applyVisibility();
      renderAddresses();
    });
  }

  function renderWorkspace() {
    const co = selected();
    $("ws-title").textContent = co ? co.name : "Select a company";
    $("ws-meta").textContent = co
      ? (co.industry || "") + (co.status ? " · " + co.status : "")
      : UI.loadSetup().orgName || "";
    renderDetails();
    renderBranches();
    renderAddresses();
    applyVisibility();
  }

  function openRailDrawer() {
    if (!state.show.rail && !setSection("rail", true)) return;
    rail.classList.add("is-open");
    const bd = $("drawer-backdrop");
    bd.hidden = false;
    bd.classList.add("is-open");
  }
  function closeRailDrawer() {
    rail.classList.remove("is-open");
    const bd = $("drawer-backdrop");
    bd.classList.remove("is-open");
    bd.hidden = true;
  }

  /* Events */
  $("company-search").addEventListener("input", (e) => {
    state.filter = e.target.value;
    renderList();
  });

  document.querySelectorAll("[data-toggle-section]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const key = btn.dataset.toggleSection;
      setSection(key, !state.show[key]);
    });
  });

  document.querySelectorAll("[data-hide-section]").forEach((btn) => {
    btn.addEventListener("click", () => {
      setSection(btn.dataset.hideSection, false);
    });
  });

  $("hide-rail").addEventListener("click", () => setSection("rail", false));
  $("open-rail").addEventListener("click", openRailDrawer);
  $("drawer-backdrop").addEventListener("click", closeRailDrawer);

  document.querySelectorAll("[data-mobile-tab]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const key = btn.dataset.mobileTab;
      if (!state.show[key]) return;
      state.mobileTab = key;
      applyVisibility();
    });
  });

  $("edit-company").addEventListener("click", () => {
    state.editingCompany = true;
    state.dirty = false;
    renderDetails();
  });
  $("add-branch").addEventListener("click", startAddBranch);
  $("add-address").addEventListener("click", startAddAddress);

  $("add-company").addEventListener("click", () => {
    warnIfDirty(() => {
      UI.openModal({
        title: "Add company",
        size: "md",
        body:
          '<form id="new-co-form" class="auth-form" novalidate>' +
          '<div class="field"><label class="field-label" for="new-name">Company name</label><input class="field-control" id="new-name" required placeholder="e.g. ABC Bakery Pvt Ltd" /><p class="field-error" data-default="Enter company name."></p></div>' +
          '<div class="field-row"><div class="field"><label class="field-label" for="new-type">Company type</label><select class="field-control" id="new-type">' +
          optionList(CHOICES.companyType, "Private Limited") +
          '</select></div><div class="field"><label class="field-label" for="new-industry">Industry</label><select class="field-control" id="new-industry">' +
          optionList(CHOICES.industry, "Retail") +
          "</select></div></div></form>",
        actions: [
          { label: "Cancel", className: "btn-secondary" },
          {
            label: "Create",
            className: "btn-primary",
            onClick: ({ close, setLoading }) => {
              const field = document.getElementById("new-name").closest(".field");
              if (!UI.validateField(field)) return;
              setLoading(true);
              setTimeout(() => {
                const company = {
                  id: "co-" + Date.now(),
                  name: document.getElementById("new-name").value.trim(),
                  status: "Active",
                  companyType: document.getElementById("new-type").value,
                  businessType: "Product",
                  industry: document.getElementById("new-industry").value,
                  businessModel: "B2B",
                  profile: "",
                  modules: ["Finance"],
                  financial: "April–March, INR",
                  localization: "India / English",
                  tax: "Skip for now",
                  branches: [],
                  addresses: [],
                };
                state.companies.push(company);
                saveCompanies(state.companies);
                state.selectedId = company.id;
                state.editingCompany = true;
                state.dirty = false;
                setLoading(false);
                close();
                UI.toast("Company created");
                renderList();
                renderWorkspace();
              }, 450);
            },
          },
        ],
      });
    });
  });

  window.addEventListener("resize", applyVisibility);

  if (state.companies.length) state.selectedId = state.companies[0].id;
  renderList();
  renderWorkspace();
})();
