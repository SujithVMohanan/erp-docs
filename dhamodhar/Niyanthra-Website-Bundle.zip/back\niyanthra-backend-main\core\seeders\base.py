from core.seeders.loader import load_group


def run_group(group: str) -> dict:
    result = load_group(group)
    return {
        "created": result["created"],
        "updated": result["updated"],
        "total": result["total"],
        "fixtures": result["fixtures"],
    }
