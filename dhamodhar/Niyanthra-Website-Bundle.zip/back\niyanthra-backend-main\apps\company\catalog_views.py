from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated

from apps.company.schemas import (
    GetBusinessTypesApiSchema,
    GetCompanyTypesApiSchema,
)
from apps.company.serializer import (
    BusinessTypeUidsSerializer,
    CompanyTypeUidsSerializer,
    CreateBusinessTypeSerializer,
    CreateCompanyTypeSerializer,
    GetBusinessTypesQuerySerializer,
    GetCompanyTypesQuerySerializer,
    UpdateBusinessTypeSerializer,
    UpdateCompanyTypeSerializer,
)
from apps.company.services.catalog_service import (
    BusinessTypeService,
    CompanyTypeService,
)
from core.pagination import RestPagination
from core.permissions import (
    IsAppAuthenticated,
    IsPlatformAdmin,
)
from core.responses import ResponseInfo
from core.utils.exceptions import ExceptionHandler


def _make_catalog_views(*, tag, schema, query_ser, create_ser, update_ser, uids_ser, service, label):
    class Base:
        response_schema = schema

        def handle_exception_response(self, exc, request):
            return ExceptionHandler.handle(exc, request=request, view=self)

    class GetView(Base, generics.ListAPIView):
        serializer_class = schema
        query_serializer_class = query_ser
        pagination_class = RestPagination
        permission_classes = [IsAuthenticated, IsAppAuthenticated]

        @swagger_auto_schema(
            tags=[tag],
            manual_parameters=[
                openapi.Parameter("uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
                openapi.Parameter("code", openapi.IN_QUERY, type=openapi.TYPE_STRING),
                openapi.Parameter("name", openapi.IN_QUERY, type=openapi.TYPE_STRING),
                openapi.Parameter("is_active", openapi.IN_QUERY, type=openapi.TYPE_BOOLEAN),
            ],
            operation_summary=f"Get {label}",
        )
        def get(self, request, *args, **kwargs):
            try:
                return super().get(request, *args, **kwargs)
            except Exception as exc:
                return self.handle_exception_response(exc, request)

        def get_queryset(self):
            query = self.query_serializer_class(data=self.request.query_params)
            query.is_valid(raise_exception=True)
            return service.list_items(validated_data=query.validated_data)

    class CreateView(Base, generics.CreateAPIView):
        permission_classes = [IsAuthenticated, IsAppAuthenticated, IsPlatformAdmin]
        serializer_class = create_ser

        @swagger_auto_schema(
            request_body=create_ser,
            tags=[tag],
            operation_summary=f"Create {label}",
        )
        def post(self, request, *args, **kwargs):
            try:
                serializer = self.get_serializer(data=request.data)
                if not serializer.is_valid():
                    return ResponseInfo.validation_error(serializer.errors)
                item = service.create_item(validated_data=serializer.validated_data)
                return ResponseInfo.created(
                    self.response_schema(item).data,
                    message=f"{label} created successfully.",
                )
            except Exception as exc:
                return self.handle_exception_response(exc, request)

    class UpdateView(Base, generics.GenericAPIView):
        permission_classes = [IsAuthenticated, IsAppAuthenticated, IsPlatformAdmin]
        serializer_class = update_ser

        @swagger_auto_schema(
            request_body=update_ser,
            tags=[tag],
            operation_summary=f"Update {label}",
        )
        def put(self, request, *args, **kwargs):
            try:
                serializer = self.get_serializer(data=request.data)
                if not serializer.is_valid():
                    return ResponseInfo.validation_error(serializer.errors)
                item = service.update_item(validated_data=serializer.validated_data)
                return ResponseInfo.ok(
                    self.response_schema(item).data,
                    message=f"{label} updated successfully.",
                )
            except Exception as exc:
                return self.handle_exception_response(exc, request)

    class DeleteView(Base, generics.GenericAPIView):
        permission_classes = [IsAuthenticated, IsAppAuthenticated, IsPlatformAdmin]
        serializer_class = uids_ser

        @swagger_auto_schema(
            request_body=uids_ser,
            tags=[tag],
            operation_summary=f"Delete {label}",
        )
        def delete(self, request, *args, **kwargs):
            try:
                serializer = self.get_serializer(data=request.data)
                if not serializer.is_valid():
                    return ResponseInfo.validation_error(serializer.errors)
                payload = service.delete_items(validated_data=serializer.validated_data)
                return ResponseInfo.ok(
                    payload,
                    message=f"{label} deleted successfully.",
                )
            except Exception as exc:
                return self.handle_exception_response(exc, request)

    class ToggleView(Base, generics.GenericAPIView):
        permission_classes = [IsAuthenticated, IsAppAuthenticated, IsPlatformAdmin]
        serializer_class = uids_ser

        @swagger_auto_schema(
            request_body=uids_ser,
            tags=[tag],
            operation_summary=f"Toggle {label} active status",
        )
        def post(self, request, *args, **kwargs):
            try:
                serializer = self.get_serializer(data=request.data)
                if not serializer.is_valid():
                    return ResponseInfo.validation_error(serializer.errors)
                items = service.toggle_items(validated_data=serializer.validated_data)
                return ResponseInfo.ok(
                    self.response_schema(items, many=True).data,
                    message=f"{label} status updated successfully.",
                )
            except Exception as exc:
                return self.handle_exception_response(exc, request)

    return GetView, CreateView, UpdateView, DeleteView, ToggleView


(
    GetCompanyTypesApiView,
    CreateCompanyTypeApiView,
    UpdateCompanyTypeApiView,
    DeleteCompanyTypesApiView,
    InactiveActiveCompanyTypesApiView,
) = _make_catalog_views(
    tag="Company Types",
    schema=GetCompanyTypesApiSchema,
    query_ser=GetCompanyTypesQuerySerializer,
    create_ser=CreateCompanyTypeSerializer,
    update_ser=UpdateCompanyTypeSerializer,
    uids_ser=CompanyTypeUidsSerializer,
    service=CompanyTypeService,
    label="company type",
)

(
    GetBusinessTypesApiView,
    CreateBusinessTypeApiView,
    UpdateBusinessTypeApiView,
    DeleteBusinessTypesApiView,
    InactiveActiveBusinessTypesApiView,
) = _make_catalog_views(
    tag="Business Types",
    schema=GetBusinessTypesApiSchema,
    query_ser=GetBusinessTypesQuerySerializer,
    create_ser=CreateBusinessTypeSerializer,
    update_ser=UpdateBusinessTypeSerializer,
    uids_ser=BusinessTypeUidsSerializer,
    service=BusinessTypeService,
    label="business type",
)
