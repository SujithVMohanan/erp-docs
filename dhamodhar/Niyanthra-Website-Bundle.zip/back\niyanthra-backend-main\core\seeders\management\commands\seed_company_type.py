from core.seeders.company_type import run
from core.seeders.management.commands._seed_base import SeedGroupCommand


class Command(SeedGroupCommand):
    help = "Seed CompanyType master data. Safe to run multiple times."
    group_label = "CompanyType"
    seeder_run = staticmethod(run)
