from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated

from apps.company.schemas import GetCompanyModulesApiSchema
from apps.company.serializer import (
    CompanyScopedListQuerySerializer,
    CreateCompanyModuleSerializer,
    UpdateCompanyModuleSerializer,
)
from apps.company.services.company_module_service import CompanyModuleService
from apps.company.views import CompanyBaseApiView
from core.pagination import RestPagination
from core.permissions import HasOrganizationPermission
from core.responses import ResponseInfo


class GetCompanyModulesApiView(CompanyBaseApiView, generics.ListAPIView):

    serializer_class       = GetCompanyModulesApiSchema
    query_serializer_class = CompanyScopedListQuerySerializer
    pagination_class       = RestPagination
    permission_classes     = [
        IsAuthenticated,
        HasOrganizationPermission,
    ]
    organization_target     = "company"
    organization_uid_source = "query"
    organization_uid_field  = "company_uid"
    response_schema         = GetCompanyModulesApiSchema

    @swagger_auto_schema(
        tags=["Company Modules"],
        manual_parameters=[
            openapi.Parameter(
                "company_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
                required=True,
            ),
            openapi.Parameter(
                "uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
        ],
        operation_summary="Get company modules",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(data=self.request.query_params)
        query.is_valid(raise_exception=True)
        return CompanyModuleService.list_modules(
            validated_data=query.validated_data
        )


class CreateCompanyModuleApiView(CompanyBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasOrganizationPermission,
    ]
    organization_target     = "company"
    organization_uid_source = "data"
    organization_uid_field  = "company_uid"
    serializer_class        = CreateCompanyModuleSerializer
    response_schema         = GetCompanyModulesApiSchema

    @swagger_auto_schema(
        request_body=CreateCompanyModuleSerializer,
        tags=["Company Modules"],
        operation_summary="Add modules to a company",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            row = CompanyModuleService.create_modules(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.created(
                self.response_schema(row).data,
                message="Company modules added successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateCompanyModuleApiView(CompanyBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasOrganizationPermission,
    ]
    organization_target     = "company"
    organization_uid_source = "data"
    organization_uid_field  = "company_uid"
    serializer_class        = UpdateCompanyModuleSerializer
    response_schema         = GetCompanyModulesApiSchema

    @swagger_auto_schema(
        request_body=UpdateCompanyModuleSerializer,
        tags=["Company Modules"],
        operation_summary="Update a company module",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            row = CompanyModuleService.update_module(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(row).data,
                message="Company module updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteCompanyModuleApiView(CompanyBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasOrganizationPermission,
    ]
    organization_target     = "company"
    organization_uid_source = "data"
    organization_uid_field  = "company_uid"
    serializer_class        = UpdateCompanyModuleSerializer
    response_schema         = GetCompanyModulesApiSchema

    @swagger_auto_schema(
        request_body=UpdateCompanyModuleSerializer,
        tags=["Company Modules"],
        operation_summary="Turn off company modules",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            row = CompanyModuleService.delete_modules(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(row).data,
                message="Company modules removed successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class GetModuleSectionsApiView(CompanyBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasOrganizationPermission,
    ]
    organization_target     = "company"
    organization_uid_source = "query"
    organization_uid_field  = "company_uid"
    serializer_class        = CompanyScopedListQuerySerializer

    @swagger_auto_schema(
        tags=["Company Modules"],
        manual_parameters=[
            openapi.Parameter(
                "company_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
                required=True,
            ),
        ],
        operation_summary="Get company module sections",
    )
    def get(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.query_params)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = CompanyModuleService.section_areas(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                payload,
                message="Data retrieved successfully",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)
