import logging

import redis
from django.conf import settings

logger = logging.getLogger("niyanthra")


class RedisHealth:

    @staticmethod
    def ping() -> dict:
        url = getattr(settings, "CELERY_BROKER_URL", "") or ""
        if not url.startswith("redis://") and not url.startswith("rediss://"):
            return {
                "ok": False,
                "degraded": True,
                "reason": "broker_not_redis",
            }

        try:
            client = redis.Redis.from_url(
                url,
                socket_connect_timeout=2,
                socket_timeout=2,
            )
            client.ping()
            return {
                "ok": True,
                "degraded": False,
            }
        except Exception as exc:
            logger.warning("redis_ping_failed error=%s", exc)
            return {
                "ok": False,
                "degraded": True,
                "reason": str(exc),
            }
