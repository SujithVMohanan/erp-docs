from core.seeders.base import run_group

GROUP = "state"


def run() -> dict:
    return run_group(GROUP)
