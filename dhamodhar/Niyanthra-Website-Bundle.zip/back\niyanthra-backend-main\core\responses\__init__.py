"""Standard API JSON envelope."""

from core.responses.api_responses import ResponseInfo

__all__ = ["ResponseInfo"]
