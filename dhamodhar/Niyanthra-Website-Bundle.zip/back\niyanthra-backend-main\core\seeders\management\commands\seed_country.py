from core.seeders.country import run
from core.seeders.management.commands._seed_base import SeedGroupCommand


class Command(SeedGroupCommand):
    help = "Seed Country master data. Safe to run multiple times."
    group_label = "Country"
    seeder_run = staticmethod(run)
