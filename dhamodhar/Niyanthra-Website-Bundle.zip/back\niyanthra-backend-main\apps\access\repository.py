from django.db.models import (
    BooleanField,
    Case,
    Prefetch,
    Q,
    Value,
    When,
)
from django.utils import timezone

from apps.access.models import (
    Group,
    GroupRole,
    Permission,
    Role,
    RolePermission,
    UserGroupAssignment,
)


class PermissionRepository:

    @staticmethod
    def upsert(
        *,
        public_id,
        codename: str,
        name: str,
        content_type: str,
        label: str | None = None,
        sub_label: str | None = None,
    ) -> tuple[Permission, bool]:
        normalized_codename = (codename or "").strip()
        normalized_content_type = (content_type or "").strip()
        row = Permission.all_objects.filter(
            content_type=normalized_content_type,
            codename=normalized_codename,
        ).first()
        if row is None:
            row = Permission(
                public_id=public_id,
                codename=normalized_codename,
                name=name,
                content_type=normalized_content_type,
                label=label,
                sub_label=sub_label,
            )
            row.save()
            return row, True

        row.name = name
        row.label = label
        row.sub_label = sub_label
        row.deleted_at = None
        row.save(
            update_fields=[
                "name",
                "label",
                "sub_label",
                "deleted_at",
                "updated_at",
            ]
        )
        return row, False

    @staticmethod
    def list_permissions(*, permission_id=None, codename=None, content_type=None, name=None):
        filters = Q()
        if permission_id is not None:
            ids = permission_id if isinstance(permission_id, (list, tuple, set)) else [permission_id]
            filters &= Q(id__in=ids)
        if codename:
            filters &= Q(codename=codename)
        if content_type:
            filters &= Q(content_type=content_type)
        if name:
            filters &= Q(name__icontains=name)
        return (
            Permission.objects.only(
                "id",
                "public_id",
                "codename",
                "name",
                "content_type",
                "label",
                "sub_label",
                "created_at",
                "updated_at",
            )
            .filter(filters)
            .order_by("label", "sub_label", "name", "id")
        )

    @staticmethod
    def get_by_id(permission_id: int):
        return Permission.objects.filter(pk=permission_id).first()

    @staticmethod
    def create(**fields):
        return Permission.objects.create(**fields)

    @staticmethod
    def update(permission, **fields):
        for k, v in fields.items():
            setattr(permission, k, v)
        permission.save(update_fields=list(fields.keys()) + ["updated_at"])
        return permission

    @staticmethod
    def delete_by_ids(ids: list[int]) -> int:
        if not ids:
            return 0
        count, _ = Permission.objects.filter(id__in=ids).delete()
        return count


class RoleRepository:

    @staticmethod
    def _base():
        return (
            Role.objects.select_related("company")
            .prefetch_related(
                Prefetch(
                    "permissions",
                    queryset=Permission.objects.only(
                        "id",
                        "codename",
                        "name",
                    ),
                )
            )
            .only(
                "id",
                "public_id",
                "name",
                "is_active",
                "created_at",
                "updated_at",
                "company_id",
                "company__id",
                "company__public_id",
                "company__name",
                "company__code",
            )
        )

    @staticmethod
    def list_roles(*, role_id=None, company_id=None, name=None, is_active=None):
        filters = Q()
        if role_id is not None:
            ids = role_id if isinstance(role_id, (list, tuple, set)) else [role_id]
            filters &= Q(id__in=ids)
        if company_id is not None:
            filters &= Q(company_id=company_id)
        if name:
            filters &= Q(name__icontains=name)
        if is_active is not None:
            filters &= Q(is_active=is_active)
        return RoleRepository._base().filter(filters).order_by("name", "id")

    @staticmethod
    def get_by_id(role_id: int):
        return RoleRepository._base().filter(pk=role_id).first()

    @staticmethod
    def create(*, company_id, name, is_active=True):
        return Role.objects.create(company_id=company_id, name=name, is_active=is_active)

    @staticmethod
    def set_permissions(*, role, permission_ids: list[int]):
        RolePermission.objects.filter(role=role).exclude(
            permission_id__in=permission_ids
        ).delete()
        existing = set(
            RolePermission.objects.filter(role=role).values_list("permission_id", flat=True)
        )
        to_create = [
            RolePermission(role=role, permission_id=pid)
            for pid in permission_ids
            if pid not in existing
        ]
        if to_create:
            RolePermission.objects.bulk_create(to_create)

    @staticmethod
    def update(*, role, company_id, name, is_active):
        role.company_id = company_id
        role.name = name
        role.is_active = is_active
        role.save(update_fields=["company_id", "name", "is_active", "updated_at"])
        return role

    @staticmethod
    def delete_by_ids(ids: list[int]) -> int:
        if not ids:
            return 0
        count, _ = Role.objects.filter(id__in=ids).delete()
        return count

    @staticmethod
    def toggle_active_by_ids(ids: list[int]) -> int:
        if not ids:
            return 0
        return Role.objects.filter(id__in=ids).update(
            is_active=Case(
                When(is_active=True, then=Value(False)),
                default=Value(True),
                output_field=BooleanField(),
            ),
            updated_at=timezone.now(),
        )


class GroupRepository:

    @staticmethod
    def _base():
        return (
            Group.objects.select_related("company")
            .prefetch_related(
                Prefetch(
                    "roles",
                    queryset=Role.objects.only(
                        "id",
                        "name",
                    ),
                )
            )
            .only(
                "id",
                "public_id",
                "name",
                "is_active",
                "created_at",
                "updated_at",
                "company_id",
                "company__id",
                "company__public_id",
                "company__name",
                "company__code",
            )
        )

    @staticmethod
    def list_groups(*, group_id=None, company_id=None, name=None, is_active=None):
        filters = Q()
        if group_id is not None:
            ids = group_id if isinstance(group_id, (list, tuple, set)) else [group_id]
            filters &= Q(id__in=ids)
        if company_id is not None:
            filters &= Q(company_id=company_id)
        if name:
            filters &= Q(name__icontains=name)
        if is_active is not None:
            filters &= Q(is_active=is_active)
        return GroupRepository._base().filter(filters).order_by("name", "id")

    @staticmethod
    def get_by_id(group_id: int):
        return GroupRepository._base().filter(pk=group_id).first()

    @staticmethod
    def create(*, company_id, name, is_active=True):
        return Group.objects.create(company_id=company_id, name=name, is_active=is_active)

    @staticmethod
    def set_roles(*, group, role_ids: list[int]):
        GroupRole.objects.filter(group=group).exclude(role_id__in=role_ids).delete()
        existing = set(
            GroupRole.objects.filter(group=group).values_list("role_id", flat=True)
        )
        to_create = [
            GroupRole(group=group, role_id=rid)
            for rid in role_ids
            if rid not in existing
        ]
        if to_create:
            GroupRole.objects.bulk_create(to_create)

    @staticmethod
    def update(*, group, company_id, name, is_active):
        group.company_id = company_id
        group.name = name
        group.is_active = is_active
        group.save(update_fields=["company_id", "name", "is_active", "updated_at"])
        return group

    @staticmethod
    def delete_by_ids(ids: list[int]) -> int:
        if not ids:
            return 0
        count, _ = Group.objects.filter(id__in=ids).delete()
        return count

    @staticmethod
    def toggle_active_by_ids(ids: list[int]) -> int:
        if not ids:
            return 0
        return Group.objects.filter(id__in=ids).update(
            is_active=Case(
                When(is_active=True, then=Value(False)),
                default=Value(True),
                output_field=BooleanField(),
            ),
            updated_at=timezone.now(),
        )


class UserGroupAssignmentRepository:

    @staticmethod
    def _base():
        return (
            UserGroupAssignment.objects.select_related(
                "user",
                "group",
                "group__company",
            )
            .only(
                "id",
                "public_id",
                "is_active",
                "created_at",
                "updated_at",
                "user_id",
                "user__id",
                "user__public_id",
                "user__email",
                "user__username",
                "group_id",
                "group__id",
                "group__name",
                "group__company_id",
                "group__company__id",
                "group__company__public_id",
                "group__company__name",
                "group__company__code",
            )
        )

    @staticmethod
    def groups_by_ids(group_ids: list[int]):
        return list(
            Group.objects.filter(pk__in=group_ids).only(
                "id",
                "company_id",
                "name",
            )
        )

    @staticmethod
    def rows_for_user_company(*, user_id: int, company_id: int):
        return list(
            UserGroupAssignment.all_objects.filter(
                user_id=user_id,
                group__company_id=company_id,
            ).only("id", "group_id", "branch_id", "deleted_at")
        )

    @staticmethod
    def delete_by_ids(assignment_ids: list[int]) -> int:
        if not assignment_ids:
            return 0
        count, _ = UserGroupAssignment.objects.filter(
            pk__in=assignment_ids,
        ).delete()
        return count

    @staticmethod
    def touch_active(*, assignment_ids: list[int], is_active: bool) -> None:
        if not assignment_ids:
            return
        UserGroupAssignment.objects.filter(pk__in=assignment_ids).update(
            is_active=is_active,
            updated_at=timezone.now(),
        )

    @staticmethod
    def restore_active(*, assignment_ids: list[int], is_active: bool) -> None:
        if not assignment_ids:
            return
        UserGroupAssignment.all_objects.filter(pk__in=assignment_ids).update(
            deleted_at=None,
            is_active=is_active,
            updated_at=timezone.now(),
        )

    @staticmethod
    def create_many(
        *,
        user_id: int,
        group_ids: list[int],
        is_active: bool,
    ) -> list[int]:
        if not group_ids:
            return []
        rows = UserGroupAssignment.objects.bulk_create(
            [
                UserGroupAssignment(
                    user_id=user_id,
                    group_id=group_id,
                    branch_id=None,
                    is_active=is_active,
                )
                for group_id in group_ids
            ]
        )
        return [row.pk for row in rows]

    @staticmethod
    def list_for_user_groups(*, user_id: int, group_ids: list[int]):
        return (
            UserGroupAssignmentRepository._base()
            .filter(
                user_id=user_id,
                group_id__in=group_ids,
                branch__isnull=True,
            )
            .order_by("id")
        )
