from contextlib import nullcontext

from django.db import IntegrityError
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.sales.repository import SaleRepository
from core.exceptions.auth import AuthValidationError
from core.tenant import (
    get_current_tenant,
    tenant_context,
)
from core.tenant.workspace import WorkspaceScope
from core.utils.ids import decode_id


class SaleService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            sale_id = decode_id(uid)
        except (TypeError, ValueError):
            raise ValidationError({field: ["Invalid id."]}) from None

        if not isinstance(sale_id, int):
            raise ValidationError({field: ["Invalid id."]})

        return sale_id

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        return list(
            dict.fromkeys(
                SaleService._decode_uid(uid, field="uids")
                for uid in uids
            )
        )

    @staticmethod
    def _scope_context(scope: WorkspaceScope):
        """
        Reuse active workspace context when already bound.
        Otherwise open a nested tenant_context (tests / background).
        """
        current = get_current_tenant()
        if (
            current
            and current.tenant_id == scope.tenant_id
            and current.company_id == scope.company_id
        ):
            return nullcontext()
        return tenant_context(
            tenant_id=scope.tenant_id,
            company_id=scope.company_id,
        )

    @staticmethod
    def _invoice_exists_error():
        return AuthValidationError(
            {"invoice_number": ["This invoice number already exists."]},
            code="SALE_INVOICE_EXISTS",
        )

    @staticmethod
    def get_sales(*, scope: WorkspaceScope, validated_data: dict):
        sale_ids = None
        if validated_data.get("uid"):
            sale_ids = [SaleService._decode_uid(validated_data["uid"])]

        with SaleService._scope_context(scope):
            return SaleRepository.list_sales(
                sale_ids=sale_ids,
                invoice_number=validated_data.get("invoice_number"),
                customer_name=validated_data.get("customer_name"),
                sale_date=validated_data.get("sale_date"),
            )

    @staticmethod
    def create_sale(*, scope: WorkspaceScope, validated_data: dict):
        invoice_number = validated_data["invoice_number"]

        with SaleService._scope_context(scope):
            if SaleRepository.get_invoice_conflict(
                invoice_number=invoice_number,
            ):
                raise SaleService._invoice_exists_error()

            try:
                return SaleRepository.create_sale(
                    invoice_number=invoice_number,
                    customer_name=validated_data["customer_name"],
                    sale_date=validated_data["sale_date"],
                    subtotal=validated_data["subtotal"],
                    tax_amount=validated_data.get("tax_amount", 0),
                    discount_amount=validated_data.get("discount_amount", 0),
                    total_amount=validated_data["total_amount"],
                )
            except IntegrityError:
                raise SaleService._invoice_exists_error() from None

    @staticmethod
    def update_sale(*, scope: WorkspaceScope, validated_data: dict):
        with SaleService._scope_context(scope):
            sale = SaleRepository.get_by_id(
                sale_id=SaleService._decode_uid(validated_data["uid"]),
            )
            if sale is None:
                raise NotFound("Sale not found.")

            invoice_number = validated_data.get(
                "invoice_number",
                sale.invoice_number,
            )
            if SaleRepository.get_invoice_conflict(
                invoice_number=invoice_number,
                exclude_id=sale.pk,
            ):
                raise SaleService._invoice_exists_error()

            values = {
                "invoice_number": invoice_number,
                "customer_name": validated_data.get(
                    "customer_name",
                    sale.customer_name,
                ),
                "sale_date": validated_data.get("sale_date", sale.sale_date),
                "subtotal": validated_data.get("subtotal", sale.subtotal),
                "tax_amount": validated_data.get(
                    "tax_amount",
                    sale.tax_amount,
                ),
                "discount_amount": validated_data.get(
                    "discount_amount",
                    sale.discount_amount,
                ),
                "total_amount": validated_data.get(
                    "total_amount",
                    sale.total_amount,
                ),
            }

            try:
                return SaleRepository.update_sale(sale=sale, **values)
            except IntegrityError:
                raise SaleService._invoice_exists_error() from None

    @staticmethod
    def delete_sales(*, scope: WorkspaceScope, validated_data: dict) -> dict:
        sale_ids = SaleService._decode_uids(validated_data["uids"])

        with SaleService._scope_context(scope):
            deleted = SaleRepository.soft_delete_by_ids(sale_ids=sale_ids)
            if not deleted:
                raise NotFound("Sale not found.")
            return {"deleted": deleted}
