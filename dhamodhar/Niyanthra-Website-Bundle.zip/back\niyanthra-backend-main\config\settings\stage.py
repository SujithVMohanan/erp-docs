"""
Staging environment settings.
"""

from .base import *


ENVIRONMENT = "stage"

DEBUG = env_bool("DEBUG", False)


# -----------------------------------------------------------------------------
# Hosts
# -----------------------------------------------------------------------------

ALLOWED_HOSTS = env_list(
    "ALLOWED_HOSTS",
)


# -----------------------------------------------------------------------------
# Database
# -----------------------------------------------------------------------------

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": env("CONTROL_DB_NAME"),
        "USER": env("CONTROL_DB_USER"),
        "PASSWORD": env("CONTROL_DB_PASSWORD"),
        "HOST": env("CONTROL_DB_HOST"),
        "PORT": env("CONTROL_DB_PORT", "5432"),
        "CONN_MAX_AGE": env_int(
            "CONTROL_DB_CONN_MAX_AGE",
            60,
        ),
        "CONN_HEALTH_CHECKS": True,
        "OPTIONS": {
            "connect_timeout": 10,
        },
    },
}

DATABASES[SHARED_DB_ALIAS] = shared_database_config(required=True)


# -----------------------------------------------------------------------------
# Security
# -----------------------------------------------------------------------------

SECURE_SSL_REDIRECT = True

SESSION_COOKIE_SECURE = True

CSRF_COOKIE_SECURE = True

SECURE_HSTS_SECONDS = 31536000

SECURE_HSTS_INCLUDE_SUBDOMAINS = True

SECURE_HSTS_PRELOAD = False

SECURE_CONTENT_TYPE_NOSNIFF = True

SECURE_REFERRER_POLICY = "strict-origin-when-cross-origin"

X_FRAME_OPTIONS = "DENY"


# -----------------------------------------------------------------------------
# CORS
# -----------------------------------------------------------------------------

CORS_ALLOWED_ORIGINS = env_list(
    "CORS_ALLOWED_ORIGINS",
)


# -----------------------------------------------------------------------------
# CSRF
# -----------------------------------------------------------------------------

CSRF_TRUSTED_ORIGINS = env_list(
    "CSRF_TRUSTED_ORIGINS",
)


# -----------------------------------------------------------------------------
# Cache
# -----------------------------------------------------------------------------

CACHES = {
    "default": {
        "BACKEND": resolve_cache_backend("redis"),
        "LOCATION": env(
            "CACHE_LOCATION",
            env("CELERY_BROKER_URL", "redis://127.0.0.1:6379/1"),
        ),
    },
}


# -----------------------------------------------------------------------------
# Email
# -----------------------------------------------------------------------------

EMAIL_BACKEND = resolve_email_backend("smtp")


# -----------------------------------------------------------------------------
# Logging
# -----------------------------------------------------------------------------

LOG_LEVEL = env("LOG_LEVEL", "INFO")

LOGGING["loggers"]["niyanthra"]["level"] = LOG_LEVEL
LOGGING["loggers"]["niyanthra.auth"]["level"] = LOG_LEVEL