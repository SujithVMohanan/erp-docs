from core.tenant.exceptions import TenantContextError
from infrastructure.database.labels import tenant_app_labels


class TenantDatabaseRouter:
    """
    Control-plane apps always use `default`.
    Tenant-plane apps use the active data-plane alias only:
    shared, isolated, or silo. Never the control database.
    """

    @staticmethod
    def _tenant_app_labels() -> set[str]:
        return set(tenant_app_labels())

    def db_for_read(self, model, **hints):
        return self._route(model._meta.app_label)

    def db_for_write(self, model, **hints):
        return self._route(model._meta.app_label)

    def allow_relation(self, obj1, obj2, **hints):
        db_list = {obj1._state.db, obj2._state.db}
        if None in db_list:
            return True
        return len(db_list) == 1

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        tenant_apps = self._tenant_app_labels()

        if db == "default":
            return app_label not in tenant_apps

        return app_label in tenant_apps

    def _route(self, app_label: str) -> str:
        if app_label not in self._tenant_app_labels():
            return "default"

        from infrastructure.database.context import get_current_db_alias

        alias = get_current_db_alias()
        if not alias or alias == "default":
            raise TenantContextError(
                "Tenant database is not selected. "
                "Refusing to query the control database."
            )

        return alias
