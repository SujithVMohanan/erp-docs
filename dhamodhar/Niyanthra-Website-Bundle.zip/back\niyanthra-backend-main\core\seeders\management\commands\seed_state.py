from core.seeders.management.commands._seed_base import SeedGroupCommand
from core.seeders.state import run


class Command(SeedGroupCommand):
    help = "Seed Indian State master data. Safe to run multiple times."
    group_label = "State"
    seeder_run = staticmethod(run)
