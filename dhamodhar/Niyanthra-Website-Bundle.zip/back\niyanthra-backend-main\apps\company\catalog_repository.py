from decimal import Decimal

from apps.company.models import (
    BusinessType,
    CompanyType,
    Module,
    TaxComponent,
    TaxRate,
    TaxRateComponent,
    TaxType,
)


class ModuleRepository:
    @staticmethod
    def upsert(
        *,
        public_id,
        code: str,
        name: str,
        is_active: bool = True,
    ) -> tuple[Module, bool]:
        normalized = code.strip().lower()
        row = Module.all_objects.filter(code=normalized).first()
        if row is None:
            row = Module(
                public_id=public_id,
                code=normalized,
                name=name,
                is_active=is_active,
            )
            row.save()
            return row, True

        row.name = name
        row.is_active = is_active
        row.deleted_at = None
        row.save(
            update_fields=[
                "name",
                "is_active",
                "deleted_at",
                "updated_at",
            ]
        )
        return row, False

    @staticmethod
    def list_active():
        return list(
            Module.objects.filter(is_active=True)
            .only("id", "public_id", "name", "code")
            .order_by("name", "id")
        )

    @staticmethod
    def active_codes() -> list[str]:
        return list(
            Module.objects.filter(is_active=True)
            .order_by("code")
            .values_list("code", flat=True)
        )

    @staticmethod
    def active_code_set() -> set[str]:
        return set(ModuleRepository.active_codes())


class CompanyTypeRepository:
    @staticmethod
    def upsert(
        *,
        public_id,
        code: str,
        name: str,
        is_active: bool = True,
    ) -> tuple[CompanyType, bool]:
        normalized = code.strip().lower()
        row = CompanyType.all_objects.filter(code=normalized).first()
        if row is None:
            row = CompanyType(
                public_id=public_id,
                code=normalized,
                name=name,
                is_active=is_active,
            )
            row.save()
            return row, True

        row.name = name
        row.is_active = is_active
        row.deleted_at = None
        row.save(
            update_fields=[
                "name",
                "is_active",
                "deleted_at",
                "updated_at",
            ]
        )
        return row, False


class BusinessTypeRepository:
    @staticmethod
    def upsert(
        *,
        public_id,
        code: str,
        name: str,
        is_active: bool = True,
    ) -> tuple[BusinessType, bool]:
        normalized = code.strip().lower()
        row = BusinessType.all_objects.filter(code=normalized).first()
        if row is None:
            row = BusinessType(
                public_id=public_id,
                code=normalized,
                name=name,
                is_active=is_active,
            )
            row.save()
            return row, True

        row.name = name
        row.is_active = is_active
        row.deleted_at = None
        row.save(
            update_fields=[
                "name",
                "is_active",
                "deleted_at",
                "updated_at",
            ]
        )
        return row, False


class TaxTypeRepository:
    @staticmethod
    def upsert(*, public_id, code: str, name: str) -> tuple[TaxType, bool]:
        normalized = code.strip().lower()
        row = TaxType.all_objects.filter(code=normalized).first()
        if row is None:
            row = TaxType(
                public_id=public_id,
                code=normalized,
                name=name,
            )
            row.save()
            return row, True

        row.name = name
        row.deleted_at = None
        row.save(update_fields=["name", "deleted_at", "updated_at"])
        return row, False


class TaxComponentRepository:
    @staticmethod
    def upsert(
        *,
        public_id,
        tax_type: TaxType,
        code: str,
        name: str,
        component_type: str | None = None,
    ) -> tuple[TaxComponent, bool]:
        normalized = code.strip().lower()
        row = TaxComponent.all_objects.filter(
            tax_type_id=tax_type.pk,
            code=normalized,
        ).first()
        if row is None:
            row = TaxComponent(
                public_id=public_id,
                tax_type=tax_type,
                code=normalized,
                name=name,
                component_type=component_type,
            )
            row.save()
            return row, True

        row.name = name
        row.component_type = component_type
        row.deleted_at = None
        row.save(
            update_fields=[
                "name",
                "component_type",
                "deleted_at",
                "updated_at",
            ]
        )
        return row, False


class TaxRateRepository:
    @staticmethod
    def upsert(
        *,
        public_id,
        tax_type: TaxType,
        code: str,
        name: str,
        rate,
        rate_type: str = "PERCENTAGE",
        effective_from=None,
        effective_to=None,
    ) -> tuple[TaxRate, bool]:
        normalized = code.strip().lower()
        rate_value = Decimal(str(rate)) if rate is not None else None
        row = TaxRate.all_objects.filter(
            tax_type_id=tax_type.pk,
            code=normalized,
        ).first()
        if row is None:
            row = TaxRate(
                public_id=public_id,
                tax_type=tax_type,
                code=normalized,
                name=name,
                rate=rate_value,
                rate_type=rate_type,
                effective_from=effective_from,
                effective_to=effective_to,
            )
            row.save()
            return row, True

        row.name = name
        row.rate = rate_value
        row.rate_type = rate_type
        row.effective_from = effective_from
        row.effective_to = effective_to
        row.deleted_at = None
        row.save(
            update_fields=[
                "name",
                "rate",
                "rate_type",
                "effective_from",
                "effective_to",
                "deleted_at",
                "updated_at",
            ]
        )
        return row, False


class TaxRateComponentRepository:
    @staticmethod
    def upsert(
        *,
        public_id,
        tax_rate: TaxRate,
        tax_component: TaxComponent,
        rate,
    ) -> tuple[TaxRateComponent, bool]:
        rate_value = Decimal(str(rate))
        row = TaxRateComponent.all_objects.filter(
            tax_rate_id=tax_rate.pk,
            tax_component_id=tax_component.pk,
        ).first()
        if row is None:
            row = TaxRateComponent(
                public_id=public_id,
                tax_rate=tax_rate,
                tax_component=tax_component,
                rate=rate_value,
            )
            row.save()
            return row, True

        row.rate = rate_value
        row.deleted_at = None
        row.save(update_fields=["rate", "deleted_at", "updated_at"])
        return row, False
