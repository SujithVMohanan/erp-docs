from core.seeders.industry import run
from core.seeders.management.commands._seed_base import SeedGroupCommand


class Command(SeedGroupCommand):
    help = "Seed Industry master data. Safe to run multiple times."
    group_label = "Industry"
    seeder_run = staticmethod(run)
