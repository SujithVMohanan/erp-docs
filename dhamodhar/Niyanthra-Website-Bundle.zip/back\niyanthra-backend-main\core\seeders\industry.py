from core.seeders.base import run_group

GROUP = "industry"


def run() -> dict:
    return run_group(GROUP)
