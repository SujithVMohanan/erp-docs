"""Partial unique constraints for live (non-deleted) rows."""

from django.db.models import (
    Q,
    UniqueConstraint,
)


def alive_q(**extra):
    return Q(deleted_at__isnull=True, **extra)


def alive_unique(fields, name, **extra):
    """Unique among live rows only. Deleted values can be reused."""
    return UniqueConstraint(fields=fields, condition=alive_q(**extra), name=name)
