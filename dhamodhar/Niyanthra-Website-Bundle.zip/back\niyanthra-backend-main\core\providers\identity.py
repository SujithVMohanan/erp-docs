from dataclasses import dataclass


@dataclass(frozen=True)
class SocialIdentity:
    provider          : str
    subject           : str
    email             : str | None
    email_verified    : bool
    name              : str | None
    picture           : str | None


def claim_email(value) -> str | None:
    email = str(value or "").strip()
    if email and "@" in email:
        return email
    return None


def claim_email_verified(value) -> bool:
    if isinstance(value, str):
        return value.strip().lower() in {"true", "1"}
    return bool(value)
