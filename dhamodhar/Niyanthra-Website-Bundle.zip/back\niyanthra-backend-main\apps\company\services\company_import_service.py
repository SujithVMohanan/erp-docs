from datetime import (
    date,
    datetime,
)

from django.conf import settings
from django.db import transaction
from openpyxl import load_workbook
from rest_framework.exceptions import ValidationError

from apps.company.models import (
    Branch,
    BranchTaxRegistration,
    Company,
    CompanyAddress,
    CompanyModule,
    CompanyTaxRegistration,
    CompanyType,
    Module,
    TaxType,
)
from apps.company.repository import CompanyRepository
from apps.location.models import Country
from apps.organization.models import Organization
from apps.organization.repository import OrganizationMembershipRepository
from apps.tenant.models import Tenant
from apps.tenant.services.tenant_service import TenantService
from apps.users.models import TimeZone
from core.exceptions.auth import AuthValidationError
from core.utils.ids import (
    decode_id,
    encode_id,
)

_SHEETS = (
    "companies",
    "company_modules",
    "branches",
    "addresses",
    "tax_registrations",
    "branch_taxes",
    "tenants",
)
_MAX_ROWS = 10000
_BATCH = 500
_ADDRESS_TYPES = {choice for choice, _label in CompanyAddress.AddressType.choices}
_TENANT_TYPES = {choice for choice, _label in Tenant.TenantType.choices}


class _ImportCatalog:
    """One lookup query per table for the whole workbook."""

    def __init__(self, organization_id: int):
        self.organization_id = organization_id
        self.companies = {
            company.code.upper(): company
            for company in Company.objects.filter(
                organization_id=organization_id,
            ).select_related("tenant").only(
                "id",
                "code",
                "name",
                "organization_id",
                "tenant_id",
                "tenant__id",
                "tenant__name",
            )
            if company.code
        }
        self.countries = {
            row.code.upper(): row.pk
            for row in Country.objects.filter(is_active=True).only("id", "code")
            if row.code
        }
        self.timezones = {
            row.code.lower(): row.pk
            for row in TimeZone.objects.filter(is_active=True).only("id", "code")
            if row.code
        }
        self.company_types = {
            row.code.lower(): row.pk
            for row in CompanyType.objects.only("id", "code")
            if row.code
        }
        self.tax_types = {
            row.code.lower(): row.pk
            for row in TaxType.objects.only("id", "code")
            if row.code
        }
        self.module_codes = list(
            Module.objects.filter(is_active=True)
            .order_by("code")
            .values_list("code", flat=True)
        )
        self.branches = {}
        self.addresses = {}
        self.taxes = {}
        self.branch_taxes = {}
        self.company_modules = {}
        self.new_company_ids = []
        company_ids = [company.pk for company in self.companies.values()]
        if not company_ids:
            return
        for branch in Branch.objects.filter(company_id__in=company_ids).only(
            "id",
            "company_id",
            "code",
            "name",
            "branch_type",
            "status",
            "email",
            "phone",
        ):
            self.branches[(branch.company_id, (branch.code or "").upper())] = branch
        for address in CompanyAddress.objects.filter(company_id__in=company_ids).only(
            "id",
            "company_id",
            "address_type",
            "address_line_1",
            "address_line_2",
            "city",
            "state_province",
            "postal_code",
            "is_primary",
            "country_id",
        ):
            self.addresses[_address_key(address)] = address
        for tax in CompanyTaxRegistration.objects.filter(company_id__in=company_ids).only(
            "id",
            "company_id",
            "tax_type_id",
            "registration_number",
            "registration_name",
            "status",
            "effective_from",
            "effective_to",
            "is_primary",
            "country_id",
        ):
            self.taxes[_tax_key(tax)] = tax
        for link in BranchTaxRegistration.objects.filter(
            branch__company_id__in=company_ids,
        ).only(
            "id",
            "branch_id",
            "tax_registration_id",
            "is_primary",
            "effective_from",
            "effective_to",
        ):
            self.branch_taxes[(link.branch_id, link.tax_registration_id)] = link
        for row in CompanyModule.objects.filter(company_id__in=company_ids).only(
            "id",
            "company_id",
            "modules",
        ):
            self.company_modules[row.company_id] = row

    def company(self, code: str):
        if not code:
            return None
        return self.companies.get(code.upper())

    def remember_company(self, company):
        self.companies[company.code.upper()] = company


def _address_key(address) -> tuple:
    return (
        address.company_id,
        address.address_type,
        address.address_line_1 or "",
    )


def _tax_key(tax) -> tuple:
    return (
        tax.company_id,
        tax.tax_type_id,
        tax.registration_number or "",
    )


class CompanyImportService:

    @staticmethod
    def import_workbook(*, actor, uploaded_file, organization_uid: str) -> dict:
        organization_id = CompanyImportService._authorized_organization_id(
            actor=actor,
            organization_uid=organization_uid,
        )
        sheets = CompanyImportService._read_sheets(uploaded_file)
        catalog = _ImportCatalog(organization_id)
        summary = {
            name: {"created": 0, "updated": 0, "failed": 0}
            for name in _SHEETS
        }
        summary["tenants"]["skipped"] = 0
        errors = []
        is_member = OrganizationMembershipRepository.list_memberships(
            user_id=actor.pk,
            organization_id=organization_id,
            is_active=True,
        ).exists()
        CompanyImportService._import_companies(
            rows=sheets["companies"],
            organization_id=organization_id,
            actor_id=actor.pk if is_member or not actor.is_admin else None,
            summary=summary["companies"],
            errors=errors,
            catalog=catalog,
        )
        CompanyImportService._seed_company_modules(
            catalog=catalog,
            summary=summary["company_modules"],
        )
        CompanyImportService._import_company_modules(
            rows=sheets["company_modules"],
            summary=summary["company_modules"],
            errors=errors,
            catalog=catalog,
        )
        CompanyImportService._import_branches(
            rows=sheets["branches"],
            actor_id=actor.pk,
            summary=summary["branches"],
            errors=errors,
            catalog=catalog,
        )
        CompanyImportService._import_addresses(
            rows=sheets["addresses"],
            summary=summary["addresses"],
            errors=errors,
            catalog=catalog,
        )
        CompanyImportService._import_tax_registrations(
            rows=sheets["tax_registrations"],
            summary=summary["tax_registrations"],
            errors=errors,
            catalog=catalog,
        )
        CompanyImportService._import_branch_taxes(
            rows=sheets["branch_taxes"],
            summary=summary["branch_taxes"],
            errors=errors,
            catalog=catalog,
        )
        CompanyImportService._import_tenants(
            rows=sheets["tenants"],
            organization_id=organization_id,
            summary=summary["tenants"],
            errors=errors,
            catalog=catalog,
        )
        summary["errors"] = errors
        return summary

    @staticmethod
    def _authorized_organization_id(*, actor, organization_uid: str) -> int:
        try:
            organization_id = decode_id(organization_uid)
        except (TypeError, ValueError):
            raise ValidationError(
                {"organization_uid": ["Invalid id."]}
            ) from None
        if not isinstance(organization_id, int):
            raise ValidationError({"organization_uid": ["Invalid id."]})

        organization = Organization.objects.filter(
            pk=organization_id,
            is_active=True,
        ).only("id").first()
        if organization is None:
            raise AuthValidationError(
                {"organization_uid": ["Organization not found or inactive."]},
                code="ORGANIZATION_NOT_FOUND",
            )

        if getattr(actor, "is_admin", False):
            return organization.pk

        allowed = OrganizationMembershipRepository.list_memberships(
            user_id=actor.pk,
            organization_id=organization.pk,
            is_active=True,
        ).filter(organization__is_active=True).exists()
        if not allowed:
            raise AuthValidationError(
                {"organization_uid": ["You do not have access to this organization."]},
                code="ORGANIZATION_FORBIDDEN",
            )
        return organization.pk

    @staticmethod
    def _read_sheets(uploaded_file) -> dict:
        name = (getattr(uploaded_file, "name", "") or "").lower()
        if not name.endswith(".xlsx"):
            raise ValidationError({"file": ["Upload an .xlsx file."]})
        try:
            workbook = load_workbook(uploaded_file, read_only=True, data_only=True)
        except Exception as exc:
            raise ValidationError({"file": ["Workbook could not be read."]}) from exc
        missing = [sheet for sheet in _SHEETS if sheet not in workbook.sheetnames]
        if missing:
            raise ValidationError(
                {"file": [f"Workbook is missing sheet '{missing[0]}'."]}
            )
        return {
            sheet: CompanyImportService._sheet_rows(workbook[sheet])
            for sheet in _SHEETS
        }

    @staticmethod
    def _sheet_rows(worksheet) -> list[tuple[int, dict]]:
        rows = worksheet.iter_rows(values_only=True)
        try:
            header_row = next(rows)
        except StopIteration:
            return []
        headers = [
            str(cell).strip().lower() if cell is not None else ""
            for cell in header_row
        ]
        parsed = []
        for offset, values in enumerate(rows, start=2):
            if offset > _MAX_ROWS + 1:
                break
            if values is None or all(cell is None or str(cell).strip() == "" for cell in values):
                continue
            payload = {}
            for index, header in enumerate(headers):
                if not header or index >= len(values):
                    continue
                payload[header] = values[index]
            parsed.append((offset, payload))
        return parsed

    @staticmethod
    def _text(row: dict, key: str) -> str:
        value = row.get(key)
        if value is None:
            return ""
        return str(value).strip()

    @staticmethod
    def _optional(row: dict, key: str) -> str | None:
        text = CompanyImportService._text(row, key)
        return text or None

    @staticmethod
    def _bool(row: dict, key: str, default=None):
        text = CompanyImportService._text(row, key).lower()
        if not text:
            return default
        if text in {"1", "true", "yes", "y"}:
            return True
        if text in {"0", "false", "no", "n"}:
            return False
        raise ValueError(f"{key} must be true or false.")

    @staticmethod
    def _date(row: dict, key: str):
        value = row.get(key)
        if value is None or str(value).strip() == "":
            return None
        if isinstance(value, datetime):
            return value.date()
        if isinstance(value, date):
            return value
        return datetime.strptime(str(value).strip()[:10], "%Y-%m-%d").date()

    @staticmethod
    def _fail(summary: dict, errors: list, *, sheet: str, row: int, company_code: str, message: str):
        summary["failed"] += 1
        errors.append({
            "sheet": sheet,
            "row": row,
            "company_code": company_code,
            "message": message,
        })

    @staticmethod
    def _import_companies(*, rows, organization_id, actor_id, summary, errors, catalog):
        from apps.users.services.membership_service import MembershipService

        for row_number, row in rows:
            code = CompanyImportService._text(row, "company_code").upper()
            name = CompanyImportService._text(row, "name")
            try:
                if not code or not name:
                    raise ValueError("company_code and name are required.")
                is_active = CompanyImportService._bool(row, "is_active", True)
                timezone_id = CompanyImportService._timezone_id(row, catalog)
                company_type_id = CompanyImportService._company_type_id(row, catalog)
                existing = catalog.company(code)
                fields = CompanyImportService._present_fields(row, {
                    "legal_name": "legal_name",
                    "registration_number": "registration_number",
                })
                if CompanyImportService._text(row, "is_active"):
                    fields["is_active"] = is_active
                if CompanyImportService._text(row, "timezone_code"):
                    fields["timezone_id"] = timezone_id
                if CompanyImportService._text(row, "company_type_code"):
                    fields["company_type_id"] = company_type_id
                fields["name"] = name
                with transaction.atomic():
                    if existing is None:
                        company = CompanyRepository.create_company(
                            organization_id=organization_id,
                            name=name,
                            code=code,
                            legal_name=fields.get("legal_name"),
                            registration_number=fields.get("registration_number"),
                            timezone_id=fields.get("timezone_id"),
                            company_type_id=fields.get("company_type_id"),
                            is_active=fields.get("is_active", True),
                        )
                        MembershipService.grant_company_to_org_principals(
                            company_id=company.pk,
                            organization_id=organization_id,
                            actor_id=actor_id,
                        )
                        catalog.remember_company(company)
                        catalog.new_company_ids.append(company.pk)
                        summary["created"] += 1
                    else:
                        CompanyRepository.update_company(company=existing, fields=fields)
                        summary["updated"] += 1
            except Exception as exc:
                CompanyImportService._fail(
                    summary,
                    errors,
                    sheet="companies",
                    row=row_number,
                    company_code=code,
                    message=CompanyImportService._message(exc),
                )

    @staticmethod
    def _present_fields(row: dict, mapping: dict) -> dict:
        fields = {}
        for column, attr in mapping.items():
            if CompanyImportService._text(row, column):
                fields[attr] = CompanyImportService._text(row, column)
        return fields

    @staticmethod
    def _timezone_id(row: dict, catalog: _ImportCatalog) -> int | None:
        code = CompanyImportService._text(row, "timezone_code").lower()
        if not code:
            return None
        timezone_id = catalog.timezones.get(code)
        if timezone_id is None:
            raise ValueError("Timezone not found.")
        return timezone_id

    @staticmethod
    def _company_type_id(row: dict, catalog: _ImportCatalog) -> int | None:
        code = CompanyImportService._text(row, "company_type_code").lower()
        if not code:
            return None
        company_type_id = catalog.company_types.get(code)
        if company_type_id is None:
            raise ValueError("Company type not found.")
        return company_type_id

    @staticmethod
    def _country_id(row: dict, catalog: _ImportCatalog) -> int:
        code = CompanyImportService._text(row, "country_code").upper()
        if not code:
            raise ValueError("country_code is required.")
        country_id = catalog.countries.get(code)
        if country_id is None:
            raise ValueError("Country not found.")
        return country_id

    @staticmethod
    def _tax_type_id(row: dict, catalog: _ImportCatalog) -> int:
        code = CompanyImportService._text(row, "tax_type_code").lower()
        if not code:
            raise ValueError("tax_type_code is required.")
        tax_type_id = catalog.tax_types.get(code)
        if tax_type_id is None:
            raise ValueError("Tax type not found.")
        return tax_type_id

    @staticmethod
    def _seed_company_modules(*, catalog: _ImportCatalog, summary: dict):
        missing = [
            company_id
            for company_id in catalog.new_company_ids
            if company_id not in catalog.company_modules
        ]
        if not missing:
            return
        flags = {code: True for code in catalog.module_codes}
        rows = [
            CompanyModule(company_id=company_id, modules=dict(flags))
            for company_id in missing
        ]
        created = CompanyModule.objects.bulk_create(rows, batch_size=_BATCH)
        for row in created:
            catalog.company_modules[row.company_id] = row
            summary["created"] += 1

    @staticmethod
    def _import_company_modules(*, rows, summary, errors, catalog: _ImportCatalog):
        to_update = []
        seen = set()
        for row_number, row in rows:
            company_code = CompanyImportService._text(row, "company_code").upper()
            try:
                company = catalog.company(company_code)
                if company is None:
                    raise ValueError("Company not found.")
                flags = {}
                for key, value in row.items():
                    if key in {"", "company_code"}:
                        continue
                    if key not in catalog.module_codes:
                        raise ValueError(f"Unknown module '{key}'.")
                    if value is None or str(value).strip() == "":
                        continue
                    flags[key] = CompanyImportService._bool(row, key)
                assignment = catalog.company_modules.get(company.pk)
                if assignment is None:
                    modules = {code: True for code in catalog.module_codes}
                    modules.update(flags)
                    assignment = CompanyModule(company_id=company.pk, modules=modules)
                    catalog.company_modules[company.pk] = assignment
                    CompanyModule.objects.bulk_create([assignment])
                    summary["created"] += 1
                    continue
                merged = dict(assignment.modules or {})
                merged.update(flags)
                assignment.modules = merged
                if assignment.pk and assignment.pk not in seen:
                    to_update.append(assignment)
                    seen.add(assignment.pk)
                summary["updated"] += 1
            except Exception as exc:
                CompanyImportService._fail(
                    summary,
                    errors,
                    sheet="company_modules",
                    row=row_number,
                    company_code=company_code,
                    message=CompanyImportService._message(exc),
                )
        if to_update:
            CompanyModule.objects.bulk_update(
                to_update,
                ["modules", "updated_at"],
                batch_size=_BATCH,
            )

    @staticmethod
    def _import_branches(*, rows, actor_id, summary, errors, catalog: _ImportCatalog):
        to_create = []
        to_update = []
        updated_ids = set()
        for row_number, row in rows:
            company_code = CompanyImportService._text(row, "company_code").upper()
            branch_code = CompanyImportService._text(row, "branch_code").upper()
            name = CompanyImportService._text(row, "name")
            try:
                if not company_code or not branch_code or not name:
                    raise ValueError("company_code, branch_code, and name are required.")
                company = catalog.company(company_code)
                if company is None:
                    raise ValueError("Company not found.")
                status = (CompanyImportService._text(row, "status") or "ACTIVE").upper()
                if status not in {"ACTIVE", "INACTIVE"}:
                    raise ValueError("Status must be ACTIVE or INACTIVE.")
                key = (company.pk, branch_code)
                existing = catalog.branches.get(key)
                if existing is None:
                    branch = Branch(
                        company_id=company.pk,
                        name=name,
                        code=branch_code,
                        branch_type=CompanyImportService._optional(row, "branch_type"),
                        status=status,
                        email=CompanyImportService._optional(row, "email"),
                        phone=CompanyImportService._optional(row, "phone"),
                        created_by_id=actor_id,
                    )
                    catalog.branches[key] = branch
                    to_create.append(branch)
                    summary["created"] += 1
                else:
                    if CompanyImportService._text(row, "branch_type"):
                        existing.branch_type = CompanyImportService._text(row, "branch_type")
                    if CompanyImportService._text(row, "status"):
                        existing.status = status
                    if CompanyImportService._text(row, "email"):
                        existing.email = CompanyImportService._text(row, "email")
                    if CompanyImportService._text(row, "phone"):
                        existing.phone = CompanyImportService._text(row, "phone")
                    existing.name = name
                    if existing.pk and existing.pk not in updated_ids:
                        to_update.append(existing)
                        updated_ids.add(existing.pk)
                    summary["updated"] += 1
            except Exception as exc:
                CompanyImportService._fail(
                    summary,
                    errors,
                    sheet="branches",
                    row=row_number,
                    company_code=company_code,
                    message=CompanyImportService._message(exc),
                )
        if to_create:
            Branch.objects.bulk_create(to_create, batch_size=_BATCH)
        if to_update:
            Branch.objects.bulk_update(
                to_update,
                ["name", "branch_type", "status", "email", "phone", "updated_at"],
                batch_size=_BATCH,
            )

    @staticmethod
    def _import_addresses(*, rows, summary, errors, catalog: _ImportCatalog):
        to_create = []
        to_update = []
        updated_ids = set()
        for row_number, row in rows:
            company_code = CompanyImportService._text(row, "company_code").upper()
            try:
                address_type = CompanyImportService._text(row, "address_type").lower()
                if address_type not in _ADDRESS_TYPES:
                    raise ValueError("address_type is invalid.")
                company = catalog.company(company_code)
                if company is None:
                    raise ValueError("Company not found.")
                country_id = CompanyImportService._country_id(row, catalog)
                line_1 = CompanyImportService._optional(row, "address_line_1")
                key = (company.pk, address_type, line_1 or "")
                existing = catalog.addresses.get(key)
                values = {"country_id": country_id}
                for column, attr in (
                    ("address_line_2", "address_line_2"),
                    ("city", "city"),
                    ("state_province", "state_province"),
                    ("postal_code", "postal_code"),
                ):
                    if CompanyImportService._text(row, column):
                        values[attr] = CompanyImportService._text(row, column)
                if CompanyImportService._text(row, "is_primary"):
                    values["is_primary"] = CompanyImportService._bool(row, "is_primary")
                if existing is None:
                    address = CompanyAddress(
                        company_id=company.pk,
                        address_type=address_type,
                        address_line_1=line_1,
                        **values,
                    )
                    catalog.addresses[key] = address
                    to_create.append(address)
                    summary["created"] += 1
                else:
                    for attr, value in values.items():
                        setattr(existing, attr, value)
                    if existing.pk and existing.pk not in updated_ids:
                        to_update.append(existing)
                        updated_ids.add(existing.pk)
                    summary["updated"] += 1
            except Exception as exc:
                CompanyImportService._fail(
                    summary,
                    errors,
                    sheet="addresses",
                    row=row_number,
                    company_code=company_code,
                    message=CompanyImportService._message(exc),
                )
        if to_create:
            CompanyAddress.objects.bulk_create(to_create, batch_size=_BATCH)
        if to_update:
            CompanyAddress.objects.bulk_update(
                to_update,
                [
                    "country_id",
                    "address_line_2",
                    "city",
                    "state_province",
                    "postal_code",
                    "is_primary",
                    "updated_at",
                ],
                batch_size=_BATCH,
            )

    @staticmethod
    def _import_tax_registrations(*, rows, summary, errors, catalog: _ImportCatalog):
        to_create = []
        to_update = []
        updated_ids = set()
        for row_number, row in rows:
            company_code = CompanyImportService._text(row, "company_code").upper()
            number = CompanyImportService._text(row, "registration_number")
            try:
                if not number:
                    raise ValueError("registration_number is required.")
                company = catalog.company(company_code)
                if company is None:
                    raise ValueError("Company not found.")
                tax_type_id = CompanyImportService._tax_type_id(row, catalog)
                country_id = CompanyImportService._country_id(row, catalog)
                key = (company.pk, tax_type_id, number)
                existing = catalog.taxes.get(key)
                values = {"country_id": country_id}
                if CompanyImportService._text(row, "registration_name"):
                    values["registration_name"] = CompanyImportService._text(row, "registration_name")
                if CompanyImportService._text(row, "status"):
                    values["status"] = CompanyImportService._text(row, "status").upper()
                if CompanyImportService._text(row, "effective_from"):
                    values["effective_from"] = CompanyImportService._date(row, "effective_from")
                if CompanyImportService._text(row, "effective_to"):
                    values["effective_to"] = CompanyImportService._date(row, "effective_to")
                if CompanyImportService._text(row, "is_primary"):
                    values["is_primary"] = CompanyImportService._bool(row, "is_primary")
                if existing is None:
                    tax = CompanyTaxRegistration(
                        company_id=company.pk,
                        tax_type_id=tax_type_id,
                        registration_number=number,
                        status=values.get("status", "ACTIVE"),
                        **{key: value for key, value in values.items() if key != "status"},
                    )
                    catalog.taxes[key] = tax
                    to_create.append(tax)
                    summary["created"] += 1
                else:
                    for attr, value in values.items():
                        setattr(existing, attr, value)
                    if existing.pk and existing.pk not in updated_ids:
                        to_update.append(existing)
                        updated_ids.add(existing.pk)
                    summary["updated"] += 1
            except Exception as exc:
                CompanyImportService._fail(
                    summary,
                    errors,
                    sheet="tax_registrations",
                    row=row_number,
                    company_code=company_code,
                    message=CompanyImportService._message(exc),
                )
        if to_create:
            CompanyTaxRegistration.objects.bulk_create(to_create, batch_size=_BATCH)
        if to_update:
            CompanyTaxRegistration.objects.bulk_update(
                to_update,
                [
                    "country_id",
                    "registration_name",
                    "status",
                    "effective_from",
                    "effective_to",
                    "is_primary",
                    "updated_at",
                ],
                batch_size=_BATCH,
            )

    @staticmethod
    def _import_branch_taxes(*, rows, summary, errors, catalog: _ImportCatalog):
        to_create = []
        to_update = []
        updated_ids = set()
        for row_number, row in rows:
            company_code = CompanyImportService._text(row, "company_code").upper()
            branch_code = CompanyImportService._text(row, "branch_code").upper()
            number = CompanyImportService._text(row, "registration_number")
            try:
                company = catalog.company(company_code)
                if company is None:
                    raise ValueError("Company not found.")
                branch = catalog.branches.get((company.pk, branch_code))
                if branch is None or not branch.pk:
                    raise ValueError("Branch not found.")
                tax_type_id = CompanyImportService._tax_type_id(row, catalog)
                registration = catalog.taxes.get((company.pk, tax_type_id, number))
                if registration is None or not registration.pk:
                    raise ValueError("Company tax registration not found.")
                key = (branch.pk, registration.pk)
                existing = catalog.branch_taxes.get(key)
                values = {}
                if CompanyImportService._text(row, "is_primary"):
                    values["is_primary"] = CompanyImportService._bool(row, "is_primary")
                if CompanyImportService._text(row, "effective_from"):
                    values["effective_from"] = CompanyImportService._date(row, "effective_from")
                if CompanyImportService._text(row, "effective_to"):
                    values["effective_to"] = CompanyImportService._date(row, "effective_to")
                if existing is None:
                    link = BranchTaxRegistration(
                        branch_id=branch.pk,
                        tax_registration_id=registration.pk,
                        **values,
                    )
                    catalog.branch_taxes[key] = link
                    to_create.append(link)
                    summary["created"] += 1
                else:
                    for attr, value in values.items():
                        setattr(existing, attr, value)
                    if existing.pk and values and existing.pk not in updated_ids:
                        to_update.append(existing)
                        updated_ids.add(existing.pk)
                    summary["updated"] += 1
            except Exception as exc:
                CompanyImportService._fail(
                    summary,
                    errors,
                    sheet="branch_taxes",
                    row=row_number,
                    company_code=company_code,
                    message=CompanyImportService._message(exc),
                )
        if to_create:
            BranchTaxRegistration.objects.bulk_create(to_create, batch_size=_BATCH)
        if to_update:
            BranchTaxRegistration.objects.bulk_update(
                to_update,
                ["is_primary", "effective_from", "effective_to", "updated_at"],
                batch_size=_BATCH,
            )

    @staticmethod
    def _import_tenants(*, rows, organization_id, summary, errors, catalog: _ImportCatalog):
        blocked_aliases = {"default", getattr(settings, "SHARED_DB_ALIAS", "shared")}
        for row_number, row in rows:
            company_code = CompanyImportService._text(row, "company_code").upper()
            try:
                company = catalog.company(company_code)
                if company is None or company.organization_id != organization_id:
                    raise ValueError("Company not found.")
                name = CompanyImportService._text(row, "name")
                if company.tenant_id:
                    if name and name != (company.tenant.name or ""):
                        tenant = company.tenant
                        tenant.name = name
                        tenant.save(update_fields=["name", "updated_at"])
                        summary["updated"] += 1
                    else:
                        summary["skipped"] += 1
                    from apps.inventory.services.warehouse_service import (
                        WarehouseService,
                    )

                    WarehouseService.ensure_for_company_id(company.pk)
                    continue
                tenant_type = CompanyImportService._text(row, "tenant_type").lower()
                slug = CompanyImportService._text(row, "slug").lower()
                db_alias = CompanyImportService._text(row, "db_alias").strip()
                if tenant_type not in _TENANT_TYPES:
                    raise ValueError("tenant_type must be shared, isolated, or silo.")
                if not name or not slug or not db_alias:
                    raise ValueError("name, slug, and db_alias are required.")
                if db_alias in blocked_aliases:
                    raise ValueError("db_alias cannot be the control or shared database alias.")
                tenant = TenantService.create_tenant(
                    validated_data={
                        "company": encode_id(company.pk),
                        "name": name,
                        "slug": slug,
                        "tenant_type": tenant_type,
                        "db_alias": db_alias,
                        "celery_queue": "default",
                    }
                )
                company.tenant_id = tenant.pk
                company.tenant = tenant
                summary["created"] += 1
            except Exception as exc:
                CompanyImportService._fail(
                    summary,
                    errors,
                    sheet="tenants",
                    row=row_number,
                    company_code=company_code,
                    message=CompanyImportService._message(exc),
                )

    @staticmethod
    def _message(exc: Exception) -> str:
        detail = getattr(exc, "detail", None)
        if isinstance(detail, dict):
            parts = []
            for key, value in detail.items():
                text = value[0] if isinstance(value, (list, tuple)) else value
                parts.append(f"{key}: {text}")
            if parts:
                return " ".join(parts)
        if isinstance(detail, list) and detail:
            return str(detail[0])
        return str(exc) or "Import row failed."
