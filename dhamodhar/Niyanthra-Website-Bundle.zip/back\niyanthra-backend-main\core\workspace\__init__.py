"""
Deprecated import path — use ``core.tenant.workspace`` instead.

Kept so older imports keep working without changing runtime behavior.
"""

from core.tenant.workspace import (
    WorkspaceScope,
    workspace_scope_from_claims,
    workspace_scope_from_request,
)

__all__ = [
    "WorkspaceScope",
    "workspace_scope_from_claims",
    "workspace_scope_from_request",
]
