from django.test import TestCase
from rest_framework.test import APIClient

from apps.company.models import (
    Branch,
    BranchMembership,
    Company,
    CompanyMembership,
)
from apps.location.models import Country
from apps.organization.models import (
    Organization,
    OrganizationMembership,
)
from apps.users.models import Users
from core.utils.ids import (
    decode_id,
    encode_id,
)
from core.utils.tokens import issue_tokens

PASSWORD = "ValidPassw0rd!"


class BranchMembershipApiTests(TestCase):

    def setUp(self):
        self.client = APIClient()
        self.admin = Users.objects.create_user(
            email="admin@example.com",
            password=PASSWORD,
            username="adminuser",
            phone_number="+15551110001",
            is_admin=True,
            profile_completed=True,
        )
        self.member = Users.objects.create_user(
            email="member@example.com",
            password=PASSWORD,
            username="memberuser",
            phone_number="+15551110002",
            profile_completed=True,
        )
        tokens = issue_tokens(self.admin)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")

        self.country = Country.objects.create(name="India", code="IN")
        self.organization = Organization.objects.create(
            name="Membership Org",
            code="MORG",
            legal_name="Membership Org Pvt",
            country=self.country,
        )
        self.company = Company.objects.create(
            name="Membership Co",
            code="MCO",
            organization=self.organization,
            is_active=True,
        )
        self.branch = Branch.objects.create(
            company=self.company,
            name="HQ",
            code="HQ",
            status="ACTIVE",
        )
        self.branch_uid = encode_id(self.branch.pk)
        self.user_uid = encode_id(self.member.pk)
        CompanyMembership.objects.create(
            company=self.company,
            user=self.admin,
            role=CompanyMembership.Role.ADMIN,
            is_active=True,
        )

    def _create(self, **overrides):
        payload = {
            "branch_uid": self.branch_uid,
            "user_uid": self.user_uid,
            "role": "staff",
            "is_active": True,
        }
        payload.update(overrides)
        return self.client.post(
            "/api/company/create-branch-membership/",
            payload,
            format="json",
        )

    def test_create_membership(self):
        response = self._create()
        self.assertEqual(response.status_code, 201)
        data = response.data["data"]
        self.assertEqual(data["role"], "staff")
        self.assertTrue(data["is_active"])
        self.assertEqual(data["branch"]["code"], "HQ")
        self.assertEqual(data["user"]["email"], "member@example.com")
        self.assertTrue(data["uid"])
        self.assertNotIn("id", data)
        self.assertEqual(
            CompanyMembership.objects.filter(
                company=self.company,
                user=self.member,
            ).count(),
            1,
        )
        self.assertEqual(
            OrganizationMembership.objects.filter(
                organization=self.organization,
                user=self.member,
            ).count(),
            1,
        )
        other = Branch.objects.create(
            company=self.company,
            name="Plant",
            code="PLT",
            status="ACTIVE",
        )
        self.assertFalse(
            BranchMembership.objects.filter(
                branch=other,
                user=self.member,
            ).exists()
        )

    def test_duplicate_membership(self):
        self._create()
        response = self._create(role="manager")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data.get("code"), "BRANCH_MEMBERSHIP_EXISTS")

    def test_list_memberships(self):
        self._create()
        response = self.client.get(
            "/api/company/get-branch-memberships/",
            {"branch_uid": self.branch_uid},
        )
        self.assertEqual(response.status_code, 200)
        self.assertGreaterEqual(response.data["data"]["count"], 1)

    def test_update_membership(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.put(
            "/api/company/update-branch-membership/",
            {
                "uid": uid,
                "branch_uid": self.branch_uid,
                "user_uid": self.user_uid,
                "role": "manager",
                "is_active": True,
            },
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["data"]["role"], "manager")

    def test_toggle_membership(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.post(
            "/api/company/inactive-active-branch-memberships/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.data["data"][0]["is_active"])
        membership = BranchMembership.objects.get(pk=self.branch.memberships.first().pk)
        self.assertFalse(membership.is_active)

    def test_delete_membership(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.delete(
            "/api/company/delete-branch-memberships/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["data"]["deleted"], 1)
        self.assertFalse(
            BranchMembership.objects.filter(branch=self.branch, user=self.member).exists()
        )

    def test_my_branches_returns_encoded_value_for_memberships(self):
        self._create()
        other = Branch.objects.create(
            company=self.company,
            name="Plant",
            code="PLT",
            status="ACTIVE",
        )
        tokens = issue_tokens(self.member)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")
        response = self.client.get(
            "/api/company/get-my-branches/",
            {"company_uid": str(self.company.public_id)},
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["data"]["branches_count"], 1)
        row = response.data["data"]["branches"][0]
        self.assertEqual(row["label"], "HQ")
        self.assertEqual(decode_id(row["value"]), self.branch.pk)
        self.assertNotEqual(decode_id(row["value"]), other.pk)
