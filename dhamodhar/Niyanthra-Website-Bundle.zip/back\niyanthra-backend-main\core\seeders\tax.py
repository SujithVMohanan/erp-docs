from core.seeders.base import run_group

GROUP = "tax"


def run() -> dict:
    return run_group(GROUP)
