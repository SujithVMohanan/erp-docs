# niyanthra-backend
Niyanthra ERP backend built with Python, Django, and Django REST Framework. Provides secure and scalable APIs for authentication, organizations, companies, branches, users, permissions, inventory, products, sales, purchasing, accounting, reporting, and other core ERP operations.

**Local setup (packages, migrate, seed, Redis, Celery):** see [zdocs/setup-and-commands.md](zdocs/setup-and-commands.md).

How companies, databases, migrations, and secrets work: see [TENANCY.md](TENANCY.md).

Master vs year databases, master-only migrate, ids across DBs, and Django admin: see [MASTER-DB.md](MASTER-DB.md).
