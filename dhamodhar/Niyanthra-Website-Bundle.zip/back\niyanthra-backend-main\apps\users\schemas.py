from rest_framework import serializers

from apps.organization.models import OrganizationMembership
from apps.users.models import (
    TimeZone,
    Users,
)
from core.utils.ids import encode_id


class GetUsersApiSchema(serializers.ModelSerializer):

    uid    = serializers.SerializerMethodField()

    class Meta:
        model = Users
        fields = [
            "uid",
            "public_id",
            "username",
            "email",
            "phone_number",
            "profile_image",
            "profile_completed",
            "is_active",
            "is_admin",
            "is_staff",
            "is_superuser",
            "is_email_verified",
            "is_phone_verified",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)


    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data


class LoginUserResponseSchema(GetUsersApiSchema):
    pass


class RegisterUserResponseSchema(GetUsersApiSchema):
    pass


class CompleteProfileResponseSchema(GetUsersApiSchema):
    pass


class AuthSessionResponseSchema(serializers.Serializer):
    token_type                    = serializers.CharField()
    access                        = serializers.CharField()
    refresh                       = serializers.CharField(required=False)
    profile_completed             = serializers.BooleanField()
    requires_profile_completion   = serializers.BooleanField(required=False)
    requires_organization_setup   = serializers.BooleanField(required=False)
    scope                         = serializers.CharField(required=False)
    organizations                 = serializers.ListField(required=False)
    user                          = GetUsersApiSchema()


class RegistrationStatusResponseSchema(serializers.Serializer):
    profile_completed  = serializers.BooleanField()
    missing_fields     = serializers.ListField(child=serializers.CharField())
    user               = GetUsersApiSchema()


class GetTimeZonesApiSchema(serializers.ModelSerializer):
    uid = serializers.SerializerMethodField()

    class Meta:
        model = TimeZone
        fields = [
            "uid",
            "public_id",
            "name",
            "code",
            "utc_offset",
            "is_active",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data
