from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin

from apps.users.models import (
    TimeZone,
    UserAuthProvider,
    Users,
)


@admin.register(Users)
class UsersAdmin(DjangoUserAdmin):
    ordering = ("email",)
    list_display = (
        "email",
        "username",
        "is_admin",
        "is_active",
        "profile_completed",
        "is_email_verified",
        "deleted_at",
    )
    list_filter = ("is_admin", "is_active", "profile_completed", "is_email_verified")
    search_fields = ("email", "username", "phone_number", "public_id")
    readonly_fields = ("public_id", "created_at", "updated_at", "deleted_at", "last_login")
    fieldsets = (
        (None, {"fields": ("email", "password")}),
        (
            "Profile",
            {
                "fields": (
                    "public_id",
                    "username",
                    "phone_number",
                    "profile_image",
                    "is_email_verified",
                    "email_verified_at",
                    "profile_completed",
                    "invited_by",
                )
            },
        ),
        (
            "Permissions",
            {"fields": ("is_admin", "is_active", "is_superuser", "groups", "user_permissions")},
        ),
        ("Audit", {"fields": ("last_login", "created_at", "updated_at", "deleted_at")}),
    )
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": ("email", "username", "phone_number", "password1", "password2"),
            },
        ),
    )

    def get_queryset(self, request):
        return self.model.all_objects.all()


@admin.register(UserAuthProvider)
class UserAuthProviderAdmin(admin.ModelAdmin):
    list_display = ("provider", "email", "user", "subject", "deleted_at")
    list_filter = ("provider",)
    search_fields = ("subject", "email", "user__email")
    readonly_fields = ("public_id", "created_at", "updated_at", "deleted_at")

    def get_queryset(self, request):
        return self.model.all_objects.all()


@admin.register(TimeZone)
class TimeZoneAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "utc_offset", "is_active", "deleted_at")
    list_filter = ("is_active",)
    search_fields = ("name", "code", "utc_offset")
