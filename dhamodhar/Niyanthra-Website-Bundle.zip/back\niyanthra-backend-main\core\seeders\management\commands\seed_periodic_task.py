from core.seeders.management.commands._seed_base import SeedGroupCommand
from core.seeders.periodic_task import run


class Command(SeedGroupCommand):
    help = "Seed PeriodicTask catalog. Safe to run multiple times."
    group_label = "PeriodicTask"
    seeder_run = staticmethod(run)
