from django.core.management.base import BaseCommand

from infrastructure.database.migration_service import DatabaseMigrationService


class Command(BaseCommand):
    help = (
        "Migrate inactive isolated and silo databases only. "
        "Does not migrate the control database, the shared database, "
        "or active tenants."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--verbosity-level",
            type=int,
            default=1,
            dest="migrate_verbosity",
        )

    def handle(self, *args, **options):
        result = DatabaseMigrationService.migrate_inactive(
            verbosity=options["migrate_verbosity"],
        )
        style = (
            self.style.SUCCESS
            if result.get("failures", 0) == 0
            else self.style.WARNING
        )
        self.stdout.write(style(f"migrate_inactive: {result}"))
