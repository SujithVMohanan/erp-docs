"""View try/except helper. Do not import this from core.utils package init."""

import logging
import traceback

from django.conf import settings
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import IntegrityError
from django.utils import timezone
from rest_framework import status
from rest_framework.exceptions import (
    APIException,
    ValidationError as DRFValidationError,
)

from core.exceptions.messages import get_error_message
from core.responses import ResponseInfo

logger = logging.getLogger("niyanthra")

_STATUS_RESPONSES = {
    status.HTTP_400_BAD_REQUEST: ResponseInfo.bad_request,
    status.HTTP_401_UNAUTHORIZED: ResponseInfo.unauthorized,
    status.HTTP_403_FORBIDDEN: ResponseInfo.forbidden,
    status.HTTP_404_NOT_FOUND: ResponseInfo.not_found,
    status.HTTP_405_METHOD_NOT_ALLOWED: ResponseInfo.method_not_allowed,
    status.HTTP_409_CONFLICT: ResponseInfo.conflict,
    status.HTTP_422_UNPROCESSABLE_ENTITY: ResponseInfo.unprocessable,
    status.HTTP_429_TOO_MANY_REQUESTS: ResponseInfo.too_many_requests,
    status.HTTP_500_INTERNAL_SERVER_ERROR: ResponseInfo.server_error,
}


class ExceptionHandler:
    @classmethod
    def handle(cls, exception, *, request=None, view=None):
        payload = cls._error_payload(exception, request=request, view=view)
        response = cls._to_response(exception)
        payload["status_code"] = response.status_code
        cls._record_error(payload)
        return response

    @classmethod
    def _to_response(cls, exception):
        if isinstance(exception, DRFValidationError):
            return ResponseInfo.validation_error(
                cls._errors(exception.detail),
                message=getattr(exception, "auth_message", None) or None,
                error_code=getattr(exception, "auth_code", None),
            )
        if isinstance(exception, APIException):
            return cls._from_api(exception)
        if isinstance(exception, DjangoValidationError):
            return cls._from_django_validation(exception)
        if isinstance(exception, IntegrityError):
            return ResponseInfo.conflict(
                "Request could not be completed.",
                errors={"detail": "Conflict."},
                error_code="CONFLICT",
            )
        return cls._unexpected(exception)

    @staticmethod
    def _errors(detail):
        return detail if isinstance(detail, dict) else {"detail": detail}

    @classmethod
    def _from_api(cls, exception: APIException):
        errors = cls._errors(exception.detail)
        message = get_error_message(exception.detail) or str(exception.default_detail)
        error_code = getattr(exception, "auth_code", None)
        responder = _STATUS_RESPONSES.get(exception.status_code)
        if responder is None:
            responder = (
                ResponseInfo.server_error
                if exception.status_code >= 500
                else ResponseInfo.bad_request
            )
        return responder(message=message, errors=errors, error_code=error_code)

    @classmethod
    def _from_django_validation(cls, exception: DjangoValidationError):
        errors = (
            exception.message_dict
            if hasattr(exception, "message_dict")
            else cls._errors(exception.messages)
        )
        return ResponseInfo.validation_error(errors)

    @staticmethod
    def _unexpected(exception):
        detail = str(exception) if settings.DEBUG else "Something went wrong."
        return ResponseInfo.server_error(
            message="Something went wrong.",
            errors={"detail": detail},
        )

    @staticmethod
    def _origin(exception):
        frames = traceback.extract_tb(exception.__traceback__)
        return frames[-1] if frames else None

    @classmethod
    def _error_payload(cls, exception, *, request=None, view=None) -> dict:
        origin = cls._origin(exception)
        user = getattr(request, "user", None) if request is not None else None
        authenticated = bool(getattr(user, "is_authenticated", False))
        return {
            "occurred_at": timezone.now(),
            "user_id": getattr(user, "pk", None) if authenticated else None,
            "user_public_id": (
                str(getattr(user, "public_id", "")) if authenticated else ""
            ),
            "request_method": getattr(request, "method", "") if request else "",
            "request_path": getattr(request, "path", "") if request else "",
            "view": type(view).__name__ if view is not None else "",
            "function": origin.name if origin else "",
            "filename": origin.filename if origin else "",
            "line": origin.lineno if origin else None,
            "error_type": type(exception).__name__,
            "error": str(exception),
            "status_code": None,
        }

    @classmethod
    def _record_error(cls, payload: dict) -> None:
        """
        Future: insert into an error-log model.

        Ready fields:
            occurred_at, user_id, user_public_id, request_method, request_path,
            view, function, filename, line, error_type, error, status_code

        Do not create/save a model here yet.
        """
        if (payload.get("status_code") or 0) < 500 and payload.get("error_type") != "IntegrityError":
            return

        logger.exception(
            "API error in %s.%s (%s:%s) user=%s",
            payload.get("view"),
            payload.get("function"),
            payload.get("filename"),
            payload.get("line"),
            payload.get("user_public_id") or payload.get("user_id") or "anonymous",
        )
        # ErrorLog.objects.create(**payload)
        return
