from django.core.management.base import (
    BaseCommand,
    CommandError,
)

from core.seeders.loader import load_all
from core.seeders.registry import (
    INITIAL_FIXTURES,
    SEED_GROUPS,
)


class Command(BaseCommand):
    help = (
        "Load all initial master data from core/seeders/fixtures. "
        "Safe to run multiple times (upsert by business key)."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--only",
            nargs="+",
            choices=list(INITIAL_FIXTURES),
            help="Load only the listed fixture stem(s).",
        )
        parser.add_argument(
            "--group",
            choices=sorted(SEED_GROUPS),
            help=(
                "Load a single seed group "
                f"({', '.join(sorted(SEED_GROUPS))})."
            ),
        )

    def handle(self, *args, **options):
        only = options.get("only")
        group = options.get("group")
        if only and group:
            raise CommandError("Use either --only or --group, not both.")

        try:
            if group:
                from core.seeders.loader import load_group

                result = load_group(group)
            else:
                result = load_all(only=only)
        except Exception as exc:
            raise CommandError(str(exc)) from exc

        for stem, fixture_result in result["fixtures"].items():
            self.stdout.write(
                f"  {stem}: "
                f"created={fixture_result['created']} "
                f"updated={fixture_result['updated']} "
                f"total={fixture_result['total']}"
            )

        self.stdout.write(
            self.style.SUCCESS(
                "initial_loaddata finished: "
                f"created={result['created']} "
                f"updated={result['updated']} "
                f"total={result['total']}"
            )
        )
