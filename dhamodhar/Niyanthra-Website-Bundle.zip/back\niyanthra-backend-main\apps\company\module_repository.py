from apps.company.models import CompanyModule


class CompanyModuleRepository:

    @staticmethod
    def _base():
        return CompanyModule.objects.select_related("company").only(
            "id",
            "public_id",
            "modules",
            "created_at",
            "updated_at",
            "company_id",
            "company__id",
            "company__public_id",
            "company__name",
            "company__code",
        )

    @staticmethod
    def list_for_company(*, company_id: int, assignment_id: int | None = None):
        filters = {"company_id": company_id}
        if assignment_id is not None:
            filters["pk"] = assignment_id
        return (
            CompanyModuleRepository._base()
            .filter(**filters)
            .order_by("id")
        )

    @staticmethod
    def get_by_id(assignment_id: int) -> CompanyModule | None:
        return (
            CompanyModuleRepository._base()
            .filter(pk=assignment_id)
            .first()
        )

    @staticmethod
    def get_for_company(company_id: int) -> CompanyModule | None:
        return (
            CompanyModuleRepository._base()
            .filter(company_id=company_id)
            .first()
        )

    @staticmethod
    def create(*, company_id: int, modules: dict) -> CompanyModule:
        return CompanyModule.objects.create(
            company_id=company_id,
            modules=modules,
        )

    @staticmethod
    def save_modules(*, assignment: CompanyModule, modules: dict) -> None:
        assignment.modules = modules
        assignment.save(update_fields=["modules", "updated_at"])
