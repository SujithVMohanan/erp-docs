from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics
from rest_framework.exceptions import ValidationError as DRFValidationError
from rest_framework.permissions import (
    AllowAny,
    IsAuthenticated,
)

from apps.users.schemas import (
    AuthSessionResponseSchema,
    CompleteProfileResponseSchema,
    GetTimeZonesApiSchema,
    GetUsersApiSchema,
    LoginUserResponseSchema,
    RegisterUserResponseSchema,
    RegistrationStatusResponseSchema,
)
from apps.users.serializers import (
    CompleteProfileSerializer,
    CreateTimeZoneSerializer,
    DeleteUsersSerializer,
    GetTimeZonesQuerySerializer,
    GetUsersQuerySerializer,
    LoginUserSerializer,
    LogoutUserSerializer,
    RefreshTokenSerializer,
    RegisterUserSerializer,
    SocialLoginSerializer,
    TimeZoneUidsSerializer,
    UpdateTimeZoneSerializer,
)
from apps.users.services.auth_service import AuthService
from apps.users.services.timezone_service import TimeZoneService
from apps.users.services.user_service import UserService
from core.exceptions.auth import AuthValidationError
from core.pagination import RestPagination
from core.permissions import (
    IsAppAuthenticated,
    IsPlatformAdmin,
)
from core.responses import ResponseInfo
from core.throttles import AuthRateThrottle
from core.utils.exceptions import ExceptionHandler


def _bearer_access(request) -> str | None:
    header = request.META.get("HTTP_AUTHORIZATION", "")
    if header.startswith("Bearer "):
        return header.split(" ", 1)[1].strip() or None
    return None


def _session_payload(tokens: dict, user, schema) -> dict:
    user_data = schema(user).data
    return {
        **tokens,
        "profile_completed": user_data.get("profile_completed") is True,
        "user": user_data,
    }


class UsersBaseApiView:
    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class LoginUserApiView(UsersBaseApiView, generics.CreateAPIView):

    permission_classes     = [AllowAny]
    authentication_classes = []
    throttle_classes       = [AuthRateThrottle]
    serializer_class       = LoginUserSerializer
    response_schema        = LoginUserResponseSchema

    @swagger_auto_schema(
        request_body=LoginUserSerializer,
        tags=["auth"],
        operation_summary="User login",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            tokens, user = AuthService.login(
                validated_data=serializer.validated_data
            )
            
            return ResponseInfo.ok(
                _session_payload(tokens, user, self.response_schema),
                message="Login successful",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class LogoutUserApiView(UsersBaseApiView, generics.GenericAPIView):

    permission_classes = [IsAuthenticated]
    serializer_class   = LogoutUserSerializer

    @swagger_auto_schema(
        request_body=LogoutUserSerializer,
        tags=["auth"],
        operation_summary="User logout",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            access = (
                serializer.validated_data.get("access")
                or _bearer_access(request)
            )

            AuthService.logout(
                validated_data=serializer.validated_data,
                access_token=access,
            )

            return ResponseInfo.ok(message="Logout successful")

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class RefreshTokenApiView(UsersBaseApiView, generics.GenericAPIView):

    permission_classes     = [AllowAny]
    authentication_classes = []
    serializer_class       = RefreshTokenSerializer

    @swagger_auto_schema(
        request_body=RefreshTokenSerializer,
        tags=["auth"],
        operation_summary="Refresh access token",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            tokens = AuthService.refresh(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                tokens,
                message="Token refreshed.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class SocialLoginApiView(UsersBaseApiView, generics.CreateAPIView):

    permission_classes     = [AllowAny]
    authentication_classes = []
    throttle_classes       = [AuthRateThrottle]
    serializer_class       = SocialLoginSerializer
    response_schema        = LoginUserResponseSchema

    @swagger_auto_schema(
        request_body=SocialLoginSerializer,
        tags=["auth"],
        operation_summary="Social login",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            tokens, user = AuthService.social_login(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                _session_payload(tokens, user, self.response_schema),
                message="Login successful",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class CompleteProfileApiView(UsersBaseApiView, generics.GenericAPIView):

    permission_classes = [IsAuthenticated]
    serializer_class   = CompleteProfileSerializer
    response_schema    = CompleteProfileResponseSchema

    @swagger_auto_schema(
        request_body=CompleteProfileSerializer,
        responses={200: AuthSessionResponseSchema},
        tags=["auth"],
        operation_summary="Complete profile",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors,
                    data={"profile_completed": False},
                )

            tokens, user = UserService.complete_profile(
                user=request.user,
                validated_data=serializer.validated_data,
                access_token=_bearer_access(request),
            )

            if tokens.get("requires_organization_setup"):
                message = "Create your organization to continue."
            elif tokens.get("requires_company_selection"):
                message = "Select a company to continue."
            else:
                message = "Profile completed successfully."

            return ResponseInfo.ok(
                _session_payload(tokens, user, self.response_schema),
                message=message,
            )

        except AuthValidationError as exc:
            return ResponseInfo.validation_error(
                ExceptionHandler._errors(exc.detail),
                message=exc.auth_message or None,
                error_code=exc.auth_code,
                data={"profile_completed": False},
            )
        except DRFValidationError as exc:
            return ResponseInfo.validation_error(
                ExceptionHandler._errors(exc.detail),
                data={"profile_completed": False},
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class RegisterUserApiView(UsersBaseApiView, generics.CreateAPIView):

    permission_classes     = [AllowAny]
    authentication_classes = []
    throttle_classes       = [AuthRateThrottle]
    serializer_class       = RegisterUserSerializer
    response_schema        = LoginUserResponseSchema

    @swagger_auto_schema(
        request_body=RegisterUserSerializer,
        tags=["auth"],
        operation_summary="User register",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            tokens, user = UserService.register_user(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.created(
                _session_payload(tokens, user, self.response_schema),
                message="User registered successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class CurrentUserApiView(UsersBaseApiView, generics.GenericAPIView):

    permission_classes = [IsAuthenticated]
    serializer_class   = GetUsersApiSchema

    @swagger_auto_schema(
        tags=["auth"],
        operation_summary="Current user",
    )
    def get(self, request, *args, **kwargs):
        try:
            return ResponseInfo.ok(
                self.serializer_class(request.user).data,
                message="User retrieved successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class RegistrationStatusApiView(UsersBaseApiView, generics.GenericAPIView):

    permission_classes = [IsAuthenticated]
    response_schema    = GetUsersApiSchema

    @swagger_auto_schema(
        responses={200: RegistrationStatusResponseSchema},
        tags=["auth"],
        operation_summary="Registration status",
    )
    def get(self, request, *args, **kwargs):
        try:
            payload = UserService.registration_status(
                user=request.user
            )
            payload["user"] = self.response_schema(request.user).data

            return ResponseInfo.ok(
                payload,
                message="Registration status retrieved.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class GetUsersApiView(UsersBaseApiView, generics.ListAPIView):

    serializer_class       = GetUsersApiSchema
    query_serializer_class = GetUsersQuerySerializer
    pagination_class       = RestPagination
    permission_classes     = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]

    @swagger_auto_schema(
        tags=["Users"],
        manual_parameters=[
            openapi.Parameter(
                "uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "email",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "name",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
        ],
        operation_summary="Get users",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(
            data=self.request.query_params
        )
        query.is_valid(raise_exception=True)

        return UserService.get_users(
            validated_data=query.validated_data
        )


class DeleteUsersApiView(UsersBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = DeleteUsersSerializer

    @swagger_auto_schema(
        request_body=DeleteUsersSerializer,
        tags=["Users"],
        operation_summary="Delete users",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = UserService.delete_users(
                validated_data=serializer.validated_data,
            )

            return ResponseInfo.ok(
                payload,
                message="User(s) deleted successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class HardDeleteUsersApiView(UsersBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = DeleteUsersSerializer

    @swagger_auto_schema(
        request_body=DeleteUsersSerializer,
        tags=["Users"],
        operation_summary="Permanently delete users",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = UserService.hard_delete_users(
                actor=request.user,
                validated_data=serializer.validated_data,
            )

            return ResponseInfo.ok(
                payload,
                message="User(s) permanently deleted.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)

class TimeZoneBaseApiView:
    response_schema = GetTimeZonesApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(exc, request=request, view=self)


class GetTimeZonesApiView(TimeZoneBaseApiView, generics.ListAPIView):
    serializer_class = GetTimeZonesApiSchema
    query_serializer_class = GetTimeZonesQuerySerializer
    pagination_class = RestPagination
    permission_classes = [IsAuthenticated, IsAppAuthenticated]

    @swagger_auto_schema(tags=["Time Zones"], operation_summary="Get time zones")
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(data=self.request.query_params)
        query.is_valid(raise_exception=True)
        return TimeZoneService.get_timezones(validated_data=query.validated_data)


class CreateTimeZoneApiView(TimeZoneBaseApiView, generics.CreateAPIView):
    permission_classes = [IsAuthenticated, IsAppAuthenticated, IsPlatformAdmin]
    serializer_class = CreateTimeZoneSerializer

    @swagger_auto_schema(
        request_body=CreateTimeZoneSerializer,
        tags=["Time Zones"],
        operation_summary="Create time zone",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            item = TimeZoneService.create_timezone(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.created(
                self.response_schema(item).data,
                message="Time zone created successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateTimeZoneApiView(TimeZoneBaseApiView, generics.GenericAPIView):
    permission_classes = [IsAuthenticated, IsAppAuthenticated, IsPlatformAdmin]
    serializer_class = UpdateTimeZoneSerializer

    @swagger_auto_schema(
        request_body=UpdateTimeZoneSerializer,
        tags=["Time Zones"],
        operation_summary="Update time zone",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            item = TimeZoneService.update_timezone(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                self.response_schema(item).data,
                message="Time zone updated successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteTimeZonesApiView(TimeZoneBaseApiView, generics.GenericAPIView):
    permission_classes = [IsAuthenticated, IsAppAuthenticated, IsPlatformAdmin]
    serializer_class = TimeZoneUidsSerializer

    @swagger_auto_schema(
        request_body=TimeZoneUidsSerializer,
        tags=["Time Zones"],
        operation_summary="Delete time zones",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            payload = TimeZoneService.delete_timezones(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                payload,
                message="Time zone(s) deleted successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class InactiveActiveTimeZonesApiView(TimeZoneBaseApiView, generics.GenericAPIView):
    permission_classes = [IsAuthenticated, IsAppAuthenticated, IsPlatformAdmin]
    serializer_class = TimeZoneUidsSerializer

    @swagger_auto_schema(
        request_body=TimeZoneUidsSerializer,
        tags=["Time Zones"],
        operation_summary="Toggle time zone active status",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            items = TimeZoneService.toggle_timezones(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                self.response_schema(items, many=True).data,
                message="Time zone status updated successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)
