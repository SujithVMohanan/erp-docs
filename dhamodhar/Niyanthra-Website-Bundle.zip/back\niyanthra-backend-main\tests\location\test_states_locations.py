from django.test import TestCase
from rest_framework.test import APIClient

from apps.location.models import (
    Country,
    Location,
    State,
)
from apps.users.models import Users
from core.utils.ids import encode_id
from core.utils.tokens import issue_tokens

PASSWORD = "ValidPassw0rd!"


class StateApiTests(TestCase):

    def setUp(self):
        self.client = APIClient()
        self.admin = Users.objects.create_user(
            email="state-admin@example.com",
            password=PASSWORD,
            username="stateadmin",
            phone_number="+15554440001",
            is_admin=True,
            profile_completed=True,
        )
        tokens = issue_tokens(self.admin)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")
        self.country = Country.objects.create(name="India", code="IN")
        self.country_uid = encode_id(self.country.pk)

    def _create(self, **overrides):
        payload = {
            "name": "Kerala",
            "code": "KL",
            "country_uid": self.country_uid,
            "is_active": True,
        }
        payload.update(overrides)
        return self.client.post(
            "/api/location/create-state/",
            payload,
            format="json",
        )

    def test_create_state(self):
        response = self._create()
        self.assertEqual(response.status_code, 201)
        data = response.data["data"]
        self.assertEqual(data["code"], "KL")
        self.assertEqual(data["country"]["code"], "IN")
        self.assertNotIn("id", data)

    def test_duplicate_code(self):
        self._create()
        response = self._create(name="Other")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data.get("code"), "STATE_CODE_EXISTS")

    def test_list_and_toggle(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        listed = self.client.get(
            "/api/location/get-states/",
            {"country_uid": self.country_uid},
        )
        self.assertEqual(listed.status_code, 200)
        self.assertGreaterEqual(listed.data["data"]["count"], 1)
        toggled = self.client.post(
            "/api/location/inactive-active-states/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(toggled.status_code, 200)
        self.assertFalse(toggled.data["data"][0]["is_active"])


class LocationApiTests(TestCase):

    def setUp(self):
        self.client = APIClient()
        self.admin = Users.objects.create_user(
            email="loc-admin@example.com",
            password=PASSWORD,
            username="locadmin",
            phone_number="+15554440002",
            is_admin=True,
            profile_completed=True,
        )
        tokens = issue_tokens(self.admin)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")
        self.country = Country.objects.create(name="India", code="IN")
        self.state = State.objects.create(
            country=self.country,
            name="Kerala",
            code="KL",
        )
        self.country_uid = encode_id(self.country.pk)
        self.state_uid = encode_id(self.state.pk)

    def _create(self, **overrides):
        payload = {
            "country_uid": self.country_uid,
            "state_uid": self.state_uid,
            "city": "Kochi",
            "postal_code": "682001",
            "address_line_1": "MG Road",
        }
        payload.update(overrides)
        return self.client.post(
            "/api/location/create-location/",
            payload,
            format="json",
        )

    def test_create_and_list_location(self):
        response = self._create()
        self.assertEqual(response.status_code, 201)
        data = response.data["data"]
        self.assertEqual(data["city"], "Kochi")
        self.assertEqual(data["state"]["code"], "KL")
        listed = self.client.get(
            "/api/location/get-locations/",
            {"city": "Kochi"},
        )
        self.assertEqual(listed.status_code, 200)
        self.assertGreaterEqual(listed.data["data"]["count"], 1)

    def test_delete_location(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.delete(
            "/api/location/delete-locations/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(Location.objects.count(), 0)
