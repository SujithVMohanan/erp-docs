from django.contrib import admin

from .models import (
    Industry,
    Organization,
    OrganizationIndustry,
    OrganizationLocation,
    OrganizationMembership,
)


@admin.register(Industry)
class IndustryAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "parent", "is_active", "deleted_at")
    list_filter = ("is_active",)
    search_fields = ("name", "code")


@admin.register(Organization)
class OrganizationAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "country", "is_active", "deleted_at")
    list_filter = ("is_active", "country")
    search_fields = ("name", "code", "legal_name", "email", "phone_number")


@admin.register(OrganizationIndustry)
class OrganizationIndustryAdmin(admin.ModelAdmin):
    list_display = ("organization", "industry", "is_primary", "created_at", "deleted_at")
    list_filter = ("is_primary",)
    search_fields = ("organization__name", "organization__code", "industry__name", "industry__code")


@admin.register(OrganizationMembership)
class OrganizationMembershipAdmin(admin.ModelAdmin):
    list_display = ("organization", "user", "role", "is_active", "created_at", "deleted_at")
    list_filter = ("role", "is_active")
    search_fields = ("organization__name", "organization__code", "user__email", "user__username")


@admin.register(OrganizationLocation)
class OrganizationLocationAdmin(admin.ModelAdmin):
    list_display = ("organization", "location", "location_type", "is_primary", "deleted_at")
    list_filter = ("location_type", "is_primary")
    search_fields = ("organization__name", "organization__code", "location__city", "location__postal_code")
