from rest_framework.exceptions import (
    PermissionDenied,
    ValidationError,
)

from apps.company.repository import CompanyRepository
from apps.tenant.models import Tenant
from apps.tenant.services.tenant_database_context import TenantDatabaseContext
from core.cache import SafeCache
from core.tenant import set_current_tenant
from core.utils.ids import decode_id

_MEMBERSHIP_CACHE_TTL = 60


class WorkspaceContextService:

    @staticmethod
    def _access_cache_key(*, user_id: int, company_id: int) -> str:
        return f"ws:access:{user_id}:{company_id}"

    @staticmethod
    def _decode_uid(uid: str, *, field: str) -> int:
        try:
            decoded = decode_id(uid)
        except (TypeError, ValueError):
            raise ValidationError({field: ["Invalid id."]}) from None

        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})

        return decoded

    @staticmethod
    def remember_access(*, user_id: int, company_id: int, tenant: Tenant) -> None:
        SafeCache.set(
            WorkspaceContextService._access_cache_key(
                user_id=user_id,
                company_id=company_id,
            ),
            {
                "tenant_id": tenant.pk,
                "db_alias": tenant.db_alias or "",
                "tenant_type": tenant.tenant_type,
            },
            timeout=_MEMBERSHIP_CACHE_TTL,
        )

    @staticmethod
    def _activate_cached(cached: dict) -> bool:
        from django.conf import settings

        from infrastructure.database.context import set_current_db_alias
        from infrastructure.database.loader import TenantConnectionLoader

        if cached.get("tenant_type") == Tenant.TenantType.SHARED:
            set_current_db_alias(settings.SHARED_DB_ALIAS)
            return True

        db_alias = cached.get("db_alias") or ""
        if (
            db_alias
            and db_alias != "default"
            and TenantConnectionLoader.ensure_alias(db_alias)
        ):
            set_current_db_alias(db_alias)
            return True
        return False

    @staticmethod
    def membership_company(*, user, company_uid: str):
        if getattr(user, "is_superuser", False):
            return True
        company_id = WorkspaceContextService._decode_uid(
            company_uid,
            field="company_uid",
        )
        return CompanyRepository.get_company_for_member(
            user_id=user.pk,
            company_id=company_id,
        )

    @staticmethod
    def bind_from_claims(*, user, claims: dict, company=None) -> Tenant | None:
        company_id = WorkspaceContextService._decode_uid(
            claims["company_uid"],
            field="company_uid",
        )
        tenant_id = WorkspaceContextService._decode_uid(
            claims["tenant_uid"],
            field="tenant_uid",
        )
        claim_alias = claims.get("db_alias")
        cache_key = WorkspaceContextService._access_cache_key(
            user_id=user.pk,
            company_id=company_id,
        )
        cached = SafeCache.get(cache_key)
        if isinstance(cached, dict) and cached.get("tenant_id") == tenant_id:
            if claim_alias and claim_alias != cached.get("db_alias"):
                raise PermissionDenied("Invalid tenant workspace.")
            if WorkspaceContextService._activate_cached(cached):
                set_current_tenant(
                    tenant_id=tenant_id,
                    company_id=company_id,
                )
                return None
        if cached is False:
            raise PermissionDenied("You do not have access to this company.")

        is_superuser = bool(getattr(user, "is_superuser", False))
        if company is None:
            company = CompanyRepository.resolve_workspace_company(
                user_id=user.pk,
                company_id=company_id,
                is_superuser=is_superuser,
            )
        if company is None:
            if not is_superuser:
                SafeCache.set(cache_key, False, timeout=_MEMBERSHIP_CACHE_TTL)
            raise PermissionDenied("You do not have access to this company.")

        tenant = company.tenant
        if tenant is None or tenant.pk != tenant_id or not tenant.is_ready:
            raise PermissionDenied("Invalid tenant workspace.")
        if claim_alias and claim_alias != tenant.db_alias:
            raise PermissionDenied("Invalid tenant workspace.")

        WorkspaceContextService.remember_access(
            user_id=user.pk,
            company_id=company_id,
            tenant=tenant,
        )
        TenantDatabaseContext.activate(tenant=tenant)
        set_current_tenant(
            tenant_id=tenant.pk,
            company_id=company_id,
        )
        return tenant
