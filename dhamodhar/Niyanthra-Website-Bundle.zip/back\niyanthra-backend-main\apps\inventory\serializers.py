from rest_framework import serializers

from apps.inventory.models import StockDocument
from apps.inventory.units import UNIT_CODES


def _blank(value: str | None) -> str | None:
    value = (value or "").strip()
    return value or None


class BlankFieldsMixin:
    """Normalize optional string fields to None."""

    blank_fields: tuple[str, ...] = ()

    def normalize_blank_fields(self, attrs):
        for field in self.blank_fields:
            if field in attrs:
                attrs[field] = _blank(attrs.get(field))

        return attrs


# ---------------------------------------------------------------------------
# Stock Lines
# ---------------------------------------------------------------------------


class ProductLineSerializer(serializers.Serializer):
    product_uid = serializers.CharField(trim_whitespace=True)
    quantity = serializers.DecimalField(
        max_digits=18,
        decimal_places=4,
    )
    unit_cost = serializers.DecimalField(
        max_digits=18,
        decimal_places=4,
        required=False,
        allow_null=True,
    )

    def validate_quantity(self, value):
        if value <= 0:
            raise serializers.ValidationError(
                "Enter a quantity greater than zero."
            )

        return value


class AdjustLineSerializer(serializers.Serializer):
    product_uid = serializers.CharField(trim_whitespace=True)
    quantity = serializers.DecimalField(
        max_digits=18,
        decimal_places=4,
    )

    def validate_quantity(self, value):
        if value == 0:
            raise serializers.ValidationError("Enter a quantity.")

        return value


# ---------------------------------------------------------------------------
# Products
# ---------------------------------------------------------------------------


class CreateProductSerializer(
    BlankFieldsMixin,
    serializers.Serializer,
):
    name = serializers.CharField(
        max_length=255,
        trim_whitespace=True,
    )

    opening_qty = serializers.DecimalField(
        max_digits=18,
        decimal_places=4,
        required=False,
        allow_null=True,
    )

    unit_cost = serializers.DecimalField(
        max_digits=18,
        decimal_places=4,
        required=False,
        allow_null=True,
    )

    sku = serializers.CharField(
        max_length=100,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )

    uom_code = serializers.CharField(
        max_length=10,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )

    hsn_code = serializers.CharField(
        max_length=20,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )

    tax_rate_uid = serializers.CharField(
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )

    cost_price = serializers.DecimalField(
        max_digits=18,
        decimal_places=4,
        required=False,
        allow_null=True,
    )

    selling_price = serializers.DecimalField(
        max_digits=18,
        decimal_places=4,
        required=False,
        allow_null=True,
    )

    track_stock = serializers.BooleanField(
        required=False,
    )

    branch_uid = serializers.CharField(
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )

    client_ref = serializers.CharField(
        max_length=100,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )

    blank_fields = (
        "sku",
        "uom_code",
        "tax_rate_uid",
        "branch_uid",
        "client_ref",
    )

    def validate_name(self, value):
        if not value:
            raise serializers.ValidationError(
                "This field may not be blank."
            )

        return value

    def validate_uom_code(self, value):
        code = value.strip().upper()

        if code and code not in UNIT_CODES:
            raise serializers.ValidationError("Unknown unit.")

        return code

    def validate_opening_qty(self, value):
        if value is not None and value < 0:
            raise serializers.ValidationError(
                "Opening quantity cannot be negative."
            )

        return value

    def validate(self, attrs):
        attrs = self.normalize_blank_fields(attrs)

        if attrs.get("sku"):
            attrs["sku"] = attrs["sku"].upper()

        # Keep HSN as an empty string because the existing
        # service/model contract expects that value.
        attrs["hsn_code"] = attrs.get("hsn_code") or ""

        return attrs


class UpdateProductSerializer(CreateProductSerializer):
    uid = serializers.CharField(
        trim_whitespace=True,
    )

    name = serializers.CharField(
        max_length=255,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )

    def validate_name(self, value):
        if value == "":
            raise serializers.ValidationError(
                "This field may not be blank."
            )

        return value

    def validate(self, attrs):
        attrs = self.normalize_blank_fields(attrs)

        if "sku" in attrs and attrs["sku"]:
            attrs["sku"] = attrs["sku"].upper()

        return attrs


class ProductUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(
            allow_blank=False,
            trim_whitespace=True,
        ),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique_uids = list(dict.fromkeys(value))

        if not unique_uids:
            raise serializers.ValidationError(
                "Select at least one product."
            )

        return unique_uids


# ---------------------------------------------------------------------------
# Warehouse
# ---------------------------------------------------------------------------


class UpdateWarehouseSerializer(serializers.Serializer):
    uid = serializers.CharField(
        trim_whitespace=True,
    )

    name = serializers.CharField(
        max_length=150,
        trim_whitespace=True,
    )

    def validate_name(self, value):
        if not value:
            raise serializers.ValidationError(
                "This field may not be blank."
            )

        return value


# ---------------------------------------------------------------------------
# Query Serializers
# ---------------------------------------------------------------------------


class ProductQuerySerializer(
    BlankFieldsMixin,
    serializers.Serializer,
):
    uid = serializers.CharField(
        required=False,
        allow_blank=True,
    )

    sku = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=100,
    )

    name = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=255,
    )

    blank_fields = (
        "uid",
        "sku",
        "name",
    )

    def validate(self, attrs):
        return self.normalize_blank_fields(attrs)


class WarehouseQuerySerializer(
    BlankFieldsMixin,
    serializers.Serializer,
):
    uid = serializers.CharField(
        required=False,
        allow_blank=True,
    )

    branch_uid = serializers.CharField(
        required=False,
        allow_blank=True,
    )

    blank_fields = (
        "uid",
        "branch_uid",
    )

    def validate(self, attrs):
        return self.normalize_blank_fields(attrs)


class StockQuerySerializer(
    BlankFieldsMixin,
    serializers.Serializer,
):
    product_uid = serializers.CharField(
        required=False,
        allow_blank=True,
    )

    warehouse_uid = serializers.CharField(
        required=False,
        allow_blank=True,
    )

    branch_uid = serializers.CharField(
        required=False,
        allow_blank=True,
    )

    blank_fields = (
        "product_uid",
        "warehouse_uid",
        "branch_uid",
    )

    def validate(self, attrs):
        return self.normalize_blank_fields(attrs)


class DocumentQuerySerializer(
    BlankFieldsMixin,
    serializers.Serializer,
):
    uid = serializers.CharField(
        required=False,
        allow_blank=True,
    )

    doc_type = serializers.ChoiceField(
        choices=StockDocument.DocType.choices,
        required=False,
        allow_blank=True,
    )

    doc_number = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=30,
    )

    date_from = serializers.DateField(
        required=False,
        allow_null=True,
    )

    date_to = serializers.DateField(
        required=False,
        allow_null=True,
    )

    blank_fields = (
        "uid",
        "doc_type",
        "doc_number",
    )

    def validate(self, attrs):
        return self.normalize_blank_fields(attrs)


class LedgerQuerySerializer(
    BlankFieldsMixin,
    serializers.Serializer,
):
    product_uid = serializers.CharField(
        required=False,
        allow_blank=True,
    )

    warehouse_uid = serializers.CharField(
        required=False,
        allow_blank=True,
    )

    doc_type = serializers.ChoiceField(
        choices=StockDocument.DocType.choices,
        required=False,
        allow_blank=True,
    )

    date_from = serializers.DateField(
        required=False,
        allow_null=True,
    )

    date_to = serializers.DateField(
        required=False,
        allow_null=True,
    )

    blank_fields = (
        "product_uid",
        "warehouse_uid",
        "doc_type",
    )

    def validate(self, attrs):
        return self.normalize_blank_fields(attrs)


# ---------------------------------------------------------------------------
# Stock Documents
# ---------------------------------------------------------------------------


class _DocumentSerializer(
    BlankFieldsMixin,
    serializers.Serializer,
):
    branch_uid = serializers.CharField(
        required=False,
        allow_blank=True,
    )

    client_ref = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=100,
    )

    notes = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=255,
    )

    blank_fields = (
        "branch_uid",
        "client_ref",
    )

    def validate(self, attrs):
        attrs = self.normalize_blank_fields(attrs)

        # Preserve existing API behavior.
        attrs["notes"] = attrs.get("notes") or ""

        return attrs


class ReceiveStockSerializer(_DocumentSerializer):
    lines = ProductLineSerializer(
        many=True,
        allow_empty=False,
        max_length=500,
    )


class AdjustStockSerializer(_DocumentSerializer):
    lines = AdjustLineSerializer(
        many=True,
        allow_empty=False,
        max_length=500,
    )


class TransferStockSerializer(_DocumentSerializer):
    to_branch_uid = serializers.CharField(
        trim_whitespace=True,
    )

    lines = ProductLineSerializer(
        many=True,
        allow_empty=False,
        max_length=500,
    )


# ---------------------------------------------------------------------------
# Inventory Import
# ---------------------------------------------------------------------------


class ImportInventorySerializer(serializers.Serializer):
    file = serializers.FileField()

