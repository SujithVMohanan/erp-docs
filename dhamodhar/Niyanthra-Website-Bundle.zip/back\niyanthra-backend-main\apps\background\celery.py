"""Celery app re-export for the background worker domain."""

from config.celery import app as celery_app

__all__ = [
    "celery_app",
]
