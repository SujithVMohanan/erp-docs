"""Project tests. Cases live in tests/<app>/, named test_*.py."""
