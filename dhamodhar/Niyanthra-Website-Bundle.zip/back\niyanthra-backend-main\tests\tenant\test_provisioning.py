from unittest.mock import patch

from django.conf import settings
from django.test import TestCase

from apps.background.models import (
    BackgroundJob,
    PeriodicTask,
)
from apps.background.repository import BackgroundRepository
from apps.company.models import Company
from apps.location.models import Country
from apps.organization.models import Organization
from apps.tenant.models import (
    Tenant,
    TenantDatabase,
)
from apps.tenant.services.provisioning_service import TenantProvisioningService
from apps.tenant.services.tenant_service import TenantService
from core.utils.ids import encode_id


class TenantProvisioningFlowTests(TestCase):

    databases = {"default", settings.SHARED_DB_ALIAS}

    def setUp(self):
        self.country = Country.objects.create(name="India", code="IN")
        self.organization = Organization.objects.create(
            name="Org One",
            code="ORG1",
            legal_name="Org One Pvt Ltd",
            country=self.country,
        )
        self.company = Company.objects.create(
            organization=self.organization,
            name="Company One",
            code="CO1",
        )
        self.periodic, _ = PeriodicTask.objects.get_or_create(
            code=BackgroundRepository.DISPATCH_ISOLATED_CODE,
            defaults={
                "name": "Dispatch isolated jobs",
                "task_path": "apps.background.tasks.dispatch_isolated_jobs",
                "is_enabled": True,
                "interval_seconds": 60,
                "max_workers": 2,
            },
        )

    def _create_payload(self, **overrides):
        payload = {
            "company": encode_id(self.company.pk),
            "name": "Acme",
            "slug": "acme",
            "tenant_type": Tenant.TenantType.SHARED,
            "db_alias": "shared_acme",
            "celery_queue": "default",
        }
        payload.update(overrides)
        return payload

    def test_shared_create_payload_becomes_active(self):
        tenant = TenantService.create_tenant(
            validated_data=self._create_payload(
                tenant_type=Tenant.TenantType.SHARED,
                db_alias="shared_acme",
                slug="acme-shared",
                name="Acme Shared",
            )
        )

        self.assertEqual(tenant.tenant_type, Tenant.TenantType.SHARED)
        self.assertEqual(tenant.db_alias, "shared_acme")
        self.assertEqual(
            tenant.provisioning_status,
            Tenant.ProvisioningStatus.ACTIVE,
        )
        self.assertTrue(tenant.is_ready)

        current_db = TenantDatabase.objects.get(
            tenant=tenant,
            is_current=True,
        )
        self.assertEqual(
            current_db.provisioning_status,
            TenantDatabase.ProvisioningStatus.ACTIVE,
        )
        self.company.refresh_from_db()
        self.assertEqual(self.company.tenant_id, tenant.pk)
        self.assertEqual(BackgroundJob.objects.count(), 0)

    def test_isolated_create_enqueues_background_job(self):
        tenant = TenantService.create_tenant(
            validated_data=self._create_payload(
                tenant_type=Tenant.TenantType.ISOLATED,
                db_alias="tenant_acme",
                slug="acme-isolated",
                name="Acme Isolated",
            )
        )

        self.assertEqual(tenant.tenant_type, Tenant.TenantType.ISOLATED)
        self.assertEqual(tenant.db_alias, "tenant_acme")
        self.assertEqual(
            tenant.provisioning_status,
            Tenant.ProvisioningStatus.PROVISIONING,
        )
        self.assertFalse(tenant.is_ready)

        job = BackgroundJob.objects.get()
        self.assertEqual(job.tenant_id, tenant.pk)
        self.assertEqual(
            job.job_type,
            BackgroundJob.JobType.ISOLATED_DB_PROVISION,
        )
        self.assertEqual(job.status, BackgroundJob.Status.PENDING)
        self.assertEqual(job.payload["db_alias"], "tenant_acme")

    def test_silo_create_stays_pending_without_job(self):
        tenant = TenantService.create_tenant(
            validated_data=self._create_payload(
                tenant_type=Tenant.TenantType.SILO,
                db_alias="tenant_vip",
                slug="vip-silo",
                name="VIP Silo",
            )
        )

        self.assertEqual(tenant.tenant_type, Tenant.TenantType.SILO)
        self.assertEqual(tenant.db_alias, "tenant_vip")
        self.assertEqual(
            tenant.provisioning_status,
            Tenant.ProvisioningStatus.PENDING,
        )
        self.assertFalse(tenant.is_ready)
        self.assertEqual(BackgroundJob.objects.count(), 0)

    def test_isolated_without_periodic_task_raises(self):
        self.periodic.delete()
        tenant = Tenant.objects.create(
            name="Broken",
            slug="broken",
            tenant_type=Tenant.TenantType.ISOLATED,
            db_alias="tenant_broken",
            provisioning_status=Tenant.ProvisioningStatus.PENDING,
        )
        TenantDatabase.objects.create(
            tenant=tenant,
            db_alias="tenant_broken",
            provisioning_status=TenantDatabase.ProvisioningStatus.PENDING,
            is_current=True,
        )

        with self.assertRaises(ValueError):
            TenantProvisioningService.provision(tenant=tenant)

    @patch(
        "apps.tenant.services.database_provisioning_service."
        "IsolatedDatabaseProvisioner.provision"
    )
    def test_isolated_job_handler_marks_active(self, provision):
        provision.return_value = {
            "db_alias": "tenant_acme",
            "db_name": "tenant_acme_isolated",
            "host": "localhost",
            "port": 5432,
            "secret_arn": None,
            "secret_name": None,
        }

        tenant = TenantService.create_tenant(
            validated_data=self._create_payload(
                tenant_type=Tenant.TenantType.ISOLATED,
                db_alias="tenant_acme",
                slug="acme-isolated",
                name="Acme Isolated",
            )
        )

        from apps.background.services.handlers.isolated_db_provision import (
            IsolatedDbProvisionHandler,
        )

        job = BackgroundJob.objects.get(tenant=tenant)
        IsolatedDbProvisionHandler().execute(job=job)

        tenant.refresh_from_db()
        self.assertEqual(
            tenant.provisioning_status,
            Tenant.ProvisioningStatus.ACTIVE,
        )
        self.assertTrue(tenant.is_ready)

        current_db = TenantDatabase.objects.get(
            tenant=tenant,
            is_current=True,
        )
        self.assertEqual(current_db.db_name, "tenant_acme_isolated")
        self.assertEqual(current_db.host, "localhost")
        self.assertEqual(current_db.port, 5432)
        self.assertEqual(
            current_db.provisioning_status,
            TenantDatabase.ProvisioningStatus.ACTIVE,
        )
        provision.assert_called_once()
