"""Encrypted membership invite tokens. Opaque — no raw ids in the link."""

import base64
import hashlib
import json
from typing import Any

from cryptography.fernet import (
    Fernet,
    InvalidToken,
)
from django.conf import settings

_VERSION = 1
_KEY_CONTEXT = b"niyanthra.membership-invite.v1"

KIND_ORGANIZATION = "organization"
KIND_COMPANY = "company"
KIND_BRANCH = "branch"
VALID_KINDS = frozenset(
    {
        KIND_ORGANIZATION,
        KIND_COMPANY,
        KIND_BRANCH,
    }
)


def invite_max_age_seconds() -> int:
    return int(
        getattr(
            settings,
            "MEMBERSHIP_INVITE_MAX_AGE_SECONDS",
            60 * 60 * 24 * 7,
        )
    )


def _fernet() -> Fernet:
    digest = hashlib.sha256(
        _KEY_CONTEXT + str(settings.SECRET_KEY).encode("utf-8")
    ).digest()
    return Fernet(base64.urlsafe_b64encode(digest))


def create_membership_invite_token(
    *,
    kind: str,
    role: str,
    organization_id: int | None = None,
    company_id: int | None = None,
    branch_id: int | None = None,
) -> str:
    if kind not in VALID_KINDS:
        raise ValueError("Invalid invite kind.")
    if not role:
        raise ValueError("role is required.")

    if kind == KIND_ORGANIZATION:
        if not organization_id:
            raise ValueError("organization_id is required for organization invites.")
    elif kind == KIND_COMPANY:
        if not company_id:
            raise ValueError("company_id is required for company invites.")
    elif kind == KIND_BRANCH:
        if not company_id or not branch_id:
            raise ValueError(
                "company_id and branch_id are required for branch invites."
            )

    payload: dict[str, Any] = {
        "v": _VERSION,
        "kind": kind,
        "role": role,
    }
    if organization_id is not None:
        payload["organization_id"] = int(organization_id)
    if company_id is not None:
        payload["company_id"] = int(company_id)
    if branch_id is not None:
        payload["branch_id"] = int(branch_id)

    plaintext = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    return _fernet().encrypt(plaintext).decode("ascii")


def verify_membership_invite_token(token: str) -> dict[str, Any]:
    if not token or not str(token).strip():
        raise ValueError("Missing invite token.")

    try:
        plaintext = _fernet().decrypt(
            str(token).strip().encode("ascii"),
            ttl=invite_max_age_seconds(),
        )
    except InvalidToken as exc:
        raise ValueError("Invalid or expired invite link.") from exc

    try:
        payload = json.loads(plaintext.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("Invalid invite link.") from exc

    if not isinstance(payload, dict) or payload.get("v") != _VERSION:
        raise ValueError("Invalid invite link.")

    kind = payload.get("kind")
    if kind not in VALID_KINDS:
        raise ValueError("Invalid invite link.")

    role = payload.get("role")
    if not isinstance(role, str) or not role:
        raise ValueError("Invalid invite link.")

    organization_id = payload.get("organization_id")
    company_id = payload.get("company_id")
    branch_id = payload.get("branch_id")

    if kind == KIND_ORGANIZATION:
        if not isinstance(organization_id, int) or organization_id <= 0:
            raise ValueError("Invalid invite link.")
        company_id = None
        branch_id = None
    elif kind == KIND_COMPANY:
        if not isinstance(company_id, int) or company_id <= 0:
            raise ValueError("Invalid invite link.")
        branch_id = None
    else:
        if not isinstance(company_id, int) or company_id <= 0:
            raise ValueError("Invalid invite link.")
        if not isinstance(branch_id, int) or branch_id <= 0:
            raise ValueError("Invalid invite link.")

    return {
        "kind": kind,
        "role": role,
        "organization_id": organization_id,
        "company_id": company_id,
        "branch_id": branch_id,
    }
