import os


SETTINGS_MAP = {
    "local": "config.settings.local",
    "stage": "config.settings.stage",
    "production": "config.settings.production",
}


def get_settings_module() -> str:
    environment = os.getenv(
        "ENVIRONMENT",
        "local",
    ).strip().lower()

    settings_module = SETTINGS_MAP.get(environment)

    if not settings_module:
        raise RuntimeError(
            f"Invalid ENVIRONMENT='{environment}'. "
            f"Expected one of: {', '.join(SETTINGS_MAP)}"
        )

    return settings_module