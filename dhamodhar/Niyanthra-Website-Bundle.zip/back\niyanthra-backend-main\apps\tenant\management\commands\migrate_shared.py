from django.core.management.base import (
    BaseCommand,
    CommandError,
)

from infrastructure.database.migration_service import DatabaseMigrationService


class Command(BaseCommand):
    help = (
        "Migrate the shared data-plane database only (tenant apps such as sales). "
        "Does not touch the control database."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--verbosity-level",
            type=int,
            default=1,
            dest="migrate_verbosity",
        )

    def handle(self, *args, **options):
        try:
            result = DatabaseMigrationService.migrate_shared(
                verbosity=options["migrate_verbosity"],
            )
        except ValueError as exc:
            raise CommandError(str(exc)) from exc

        self.stdout.write(self.style.SUCCESS(f"migrate_shared: {result}"))
