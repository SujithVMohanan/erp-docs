from django.db import transaction

from apps.tenant.models import (
    Tenant,
    TenantDatabase,
)
from apps.tenant.repository import TenantRepository
from infrastructure.database.provisioner import IsolatedDatabaseProvisioner


class TenantDatabaseProvisioningService:

    @staticmethod
    def _default_db_name(tenant: Tenant) -> str:
        slug = tenant.slug.replace("-", "_").lower()
        return f"tenant_{slug}"

    @staticmethod
    def provision_isolated(*, tenant: Tenant) -> Tenant:
        current_db = TenantRepository.get_current_database(tenant)
        db_name = TenantDatabaseProvisioningService._default_db_name(tenant)

        try:
            result = IsolatedDatabaseProvisioner.provision(
                db_alias=tenant.db_alias,
                db_name=db_name,
                secret_arn=(
                    current_db.secret_arn if current_db else None
                ),
                secret_name=(
                    current_db.secret_name if current_db else None
                ),
            )

            with transaction.atomic():
                TenantRepository.update_current_database_connection(
                    tenant=tenant,
                    db_name=result["db_name"],
                    host=result["host"],
                    port=result["port"],
                    status=TenantDatabase.ProvisioningStatus.ACTIVE,
                )
                TenantRepository.update_current_database_secrets(
                    tenant=tenant,
                    secret_arn=result.get("secret_arn"),
                    secret_name=result.get("secret_name"),
                )
                tenant = TenantRepository.set_provisioning_status(
                    tenant=tenant,
                    status=Tenant.ProvisioningStatus.ACTIVE,
                    error=None,
                )
        except Exception as exc:
            # Mark FAILED so operators can retry; then re-raise
            TenantRepository.set_current_database_status(
                tenant=tenant,
                status=TenantDatabase.ProvisioningStatus.FAILED,
                error=str(exc),
            )
            tenant = TenantRepository.set_provisioning_status(
                tenant=tenant,
                status=Tenant.ProvisioningStatus.FAILED,
                error=str(exc),
            )
            raise

        return tenant
