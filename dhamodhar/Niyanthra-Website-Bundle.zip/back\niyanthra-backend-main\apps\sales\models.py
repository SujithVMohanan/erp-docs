from django.db import models
from django.utils.translation import gettext_lazy as _

from core.database.constraints import alive_unique
from core.database.models import TenantScopedModel


class Sale(TenantScopedModel):
    """
    Tenant-plane sale row.

    tenant_id / company_id are stamped from tenant context (workspace JWT).
    Not DB FKs — isolated/silo DBs have no control-plane Tenant/Company tables.
    """

    company_id = models.PositiveBigIntegerField(
        _("company id"),
        db_index=True,
    )

    invoice_number = models.CharField(
        _("invoice number"),
        max_length=100,
    )
    customer_name = models.CharField(
        _("customer name"),
        max_length=255,
    )
    sale_date = models.DateField(_("sale date"))

    subtotal = models.DecimalField(
        _("subtotal"),
        max_digits=15,
        decimal_places=2,
    )
    tax_amount = models.DecimalField(
        _("tax amount"),
        max_digits=15,
        decimal_places=2,
        default=0,
    )
    discount_amount = models.DecimalField(
        _("discount amount"),
        max_digits=15,
        decimal_places=2,
        default=0,
    )
    total_amount = models.DecimalField(
        _("total amount"),
        max_digits=15,
        decimal_places=2,
    )

    class Meta:
        db_table = "sales"
        verbose_name = _("sale")
        verbose_name_plural = _("sales")
        ordering = ("-sale_date", "-id")
        indexes = [
            models.Index(fields=["tenant_id", "company_id", "sale_date"]),
            models.Index(fields=["tenant_id", "company_id", "invoice_number"]),
        ]
        constraints = [
            alive_unique(
                ["tenant_id", "company_id", "invoice_number"],
                "sales_invoice_alive_uniq",
            ),
        ]

    def __str__(self):
        return f"Sale {self.invoice_number} - {self.customer_name}"
