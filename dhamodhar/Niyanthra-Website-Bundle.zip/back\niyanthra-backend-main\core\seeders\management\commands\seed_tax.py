from core.seeders.management.commands._seed_base import SeedGroupCommand
from core.seeders.tax import run


class Command(SeedGroupCommand):
    help = "Seed tax catalog (types, components, rates). Safe to run multiple times."
    group_label = "Tax"
    seeder_run = staticmethod(run)
