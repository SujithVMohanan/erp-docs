from datetime import timedelta
from threading import Thread
from unittest.mock import patch

from django.db import connection
from django.test import (
    TestCase,
    TransactionTestCase,
    override_settings,
)
from rest_framework.test import APIClient
from rest_framework_simplejwt.tokens import AccessToken

from apps.users.models import (
    UserAuthProvider,
    Users,
)
from core.exceptions.auth import AuthFailed
from core.providers.identity import SocialIdentity
from core.utils.ids import encode_id
from core.utils.tokens import (
    TOKEN_USE_ACCESS,
    TOKEN_USE_REGISTRATION,
)


PASSWORD = "ValidPassw0rd!"
GOOGLE_EMAIL = "google.user@example.com"


def _identity(**overrides) -> SocialIdentity:
    payload = {
        "provider": "google",
        "subject": "google-sub-1",
        "email": GOOGLE_EMAIL,
        "email_verified": True,
        "name": "Google User",
        "picture": None,
    }
    payload.update(overrides)
    return SocialIdentity(**payload)


@override_settings(
    AUTH_PROVIDERS={"google": {"client_id": "test-google-client-id.apps.googleusercontent.com"}},
    AUTH_THROTTLE_DISABLED=True,
)
class AuthLifecycleTests(TestCase):
    def setUp(self):
        self.client = APIClient()

    def _register(self, email="new.user@example.com"):
        return self.client.post(
            "/api/users/register/",
            {
                "email": email,
                "password": PASSWORD,
                "confirm_password": PASSWORD,
            },
            format="json",
        )

    def _complete(self, access, *, username="newuser", phone="+15550001111"):
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {access}")
        return self.client.post(
            "/api/users/complete-profile/",
            {
                "username": username,
                "phone_number": phone,
            },
            format="json",
        )

    def _auth(self, access):
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {access}")

    def test_normal_registration_success(self):
        response = self._register()
        self.assertEqual(response.status_code, 201)
        self.assertTrue(response.data["status"])
        self.assertEqual(response.data["errors"], {})
        data = response.data["data"]
        self.assertEqual(data["token_type"], "Bearer")
        self.assertTrue(data["access"])
        self.assertNotIn("refresh", data)
        self.assertEqual(set(data), {"token_type", "access", "profile_completed", "user"})
        self.assertFalse(data["profile_completed"])
        self.assertFalse(data["user"]["profile_completed"])
        self.assertEqual(Users.objects.count(), 1)
        user = Users.objects.get()
        self.assertFalse(user.profile_completed)

    def test_duplicate_active_email(self):
        self._register("dup@example.com")
        response = self._register("dup@example.com")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data.get("code"), "EMAIL_ALREADY_EXISTS")
        self.assertIn("email", response.data["errors"])
        self.assertEqual(Users.objects.count(), 1)

    def test_duplicate_active_phone(self):
        first = self._register("one@example.com")
        self._complete(first.data["data"]["access"], username="oneuser", phone="+15550001111")
        second = self._register("two@example.com")
        response = self._complete(
            second.data["data"]["access"],
            username="twouser",
            phone="+15550001111",
        )
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data.get("code"), "PHONE_ALREADY_EXISTS")
        self.assertFalse(response.data["data"]["profile_completed"])
        self.assertIn("phone_number", response.data["errors"])
        self.assertEqual(Users.objects.filter(profile_completed=True).count(), 1)

    @patch("apps.users.services.auth_service.verify_social_token")
    def test_google_registration(self, verify):
        verify.return_value = _identity()
        response = self.client.post(
            "/api/users/social-login/",
            {"provider": "google", "id_token": "valid-google-token"},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["message"], "Login successful")
        data = response.data["data"]
        self.assertNotIn("refresh", data)
        self.assertFalse(data["user"]["profile_completed"])
        self.assertEqual(set(data), {"token_type", "access", "profile_completed", "user"})
        self.assertFalse(data["profile_completed"])
        self.assertEqual(Users.objects.count(), 1)
        self.assertEqual(UserAuthProvider.objects.count(), 1)
        user = Users.objects.get()
        self.assertEqual(user.username, "Google User")
        self.assertFalse(user.profile_completed)

    @patch("apps.users.services.auth_service.verify_social_token")
    def test_existing_google_login(self, verify):
        verify.return_value = _identity()
        first = self.client.post(
            "/api/users/social-login/",
            {"provider": "google", "id_token": "token-1"},
            format="json",
        )
        completed = self._complete(
            first.data["data"]["access"],
            username="googleuser",
            phone="+15550002222",
        )
        self.assertEqual(completed.status_code, 200)
        verify.return_value = _identity()
        second = self.client.post(
            "/api/users/social-login/",
            {"provider": "google", "id_token": "token-2"},
            format="json",
        )
        self.assertEqual(second.status_code, 200)
        self.assertEqual(second.data["message"], "Login successful")
        self.assertTrue(second.data["data"]["user"]["profile_completed"])
        self.assertIn("refresh", second.data["data"])
        self.assertEqual(
            set(second.data["data"]),
            {"token_type", "access", "refresh", "profile_completed", "user"},
        )
        self.assertTrue(second.data["data"]["profile_completed"])
        self.assertEqual(Users.objects.count(), 1)
        self.assertEqual(UserAuthProvider.objects.count(), 1)

    @patch("apps.users.services.auth_service.verify_social_token")
    def test_google_email_matching_existing_account(self, verify):
        registered = self._register(GOOGLE_EMAIL)
        self.assertEqual(registered.status_code, 201)
        verify.return_value = _identity(subject="google-sub-link")
        response = self.client.post(
            "/api/users/social-login/",
            {"provider": "google", "id_token": "token-link"},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(Users.objects.count(), 1)
        self.assertEqual(UserAuthProvider.objects.count(), 1)
        self.assertFalse(response.data["data"]["user"]["profile_completed"])

    def test_incomplete_profile_blocks_protected_api(self):
        registered = self._register()
        self._auth(registered.data["data"]["access"])
        response = self.client.get("/api/users/get-users/")
        self.assertEqual(response.status_code, 403)
        self.assertEqual(response.data.get("code"), "PROFILE_INCOMPLETE")

    def test_complete_profile_success(self):
        registered = self._register()
        response = self._complete(registered.data["data"]["access"])
        self.assertEqual(response.status_code, 200)
        data = response.data["data"]
        self.assertTrue(data["profile_completed"])
        self.assertTrue(data["access"])
        self.assertTrue(data["refresh"])
        self.assertEqual(data["user"]["username"], "newuser")
        self.assertEqual(data["user"]["phone_number"], "+15550001111")
        self.assertNotIn("password", data["user"])

    def test_complete_profile_duplicate_email_on_register_only(self):
        self._register("taken@example.com")
        response = self._register("taken@example.com")
        self.assertEqual(response.data.get("code"), "EMAIL_ALREADY_EXISTS")

    def test_complete_profile_duplicate_phone(self):
        first = self._register("a@example.com")
        self._complete(first.data["data"]["access"], username="auser", phone="+15550003333")
        second = self._register("b@example.com")
        response = self._complete(
            second.data["data"]["access"],
            username="buser",
            phone="+15550003333",
        )
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data.get("code"), "PHONE_ALREADY_EXISTS")
        pending = Users.objects.get(email="b@example.com")
        self.assertFalse(pending.profile_completed)

    def test_deleted_account_can_register_again(self):
        registered = self._register("gone@example.com")
        completed = self._complete(
            registered.data["data"]["access"],
            username="goneuser",
            phone="+15550004444",
        )
        user = Users.objects.get(email="gone@example.com")
        self._auth(completed.data["data"]["access"])
        deleted = self.client.delete(
            "/api/users/delete-users/",
            {"uids": [encode_id(user.pk)]},
            format="json",
        )
        self.assertEqual(deleted.status_code, 200)
        self.assertFalse(Users.objects.filter(email="gone@example.com").exists())
        again = self._register("gone@example.com")
        self.assertEqual(again.status_code, 201)
        self.assertEqual(Users.objects.filter(email="gone@example.com").count(), 1)
        self.assertFalse(Users.objects.get(email="gone@example.com").profile_completed)

    def test_deleted_account_cannot_authenticate(self):
        registered = self._register("old@example.com")
        completed = self._complete(
            registered.data["data"]["access"],
            username="olduser",
            phone="+15550005555",
        )
        user = Users.objects.get(email="old@example.com")
        user.delete()
        login = self.client.post(
            "/api/users/login/",
            {"email": "old@example.com", "password": PASSWORD},
            format="json",
        )
        self.assertEqual(login.status_code, 401)
        self._auth(completed.data["data"]["access"])
        me = self.client.get("/api/users/me/")
        self.assertEqual(me.status_code, 401)

    def test_pending_user_cannot_access_protected_apis(self):
        registered = self._register()
        self._auth(registered.data["data"]["access"])
        me = self.client.get("/api/users/me/")
        self.assertEqual(me.status_code, 200)
        users = self.client.get("/api/users/get-users/")
        self.assertEqual(users.status_code, 403)

    def test_final_token_issued_only_after_profile_completion(self):
        registered = self._register()
        self.assertNotIn("refresh", registered.data["data"])
        completed = self._complete(registered.data["data"]["access"])
        self.assertIn("refresh", completed.data["data"])
        self.assertTrue(completed.data["data"]["profile_completed"])

    def test_invalid_expired_registration_token(self):
        registered = self._register("expire@example.com")
        user = Users.objects.get(email="expire@example.com")
        token = AccessToken.for_user(user)
        token["public_id"] = str(user.public_id)
        token["token_use"] = TOKEN_USE_REGISTRATION
        token.set_exp(lifetime=timedelta(seconds=-5))
        self._auth(str(token))
        response = self.client.post(
            "/api/users/complete-profile/",
            {"username": "expireuser", "phone_number": "+15550006666"},
            format="json",
        )
        self.assertEqual(response.status_code, 401)

    def test_expired_access_token(self):
        registered = self._register("access@example.com")
        completed = self._complete(
            registered.data["data"]["access"],
            username="accessuser",
            phone="+15550007777",
        )
        user = Users.objects.get(email="access@example.com")
        token = AccessToken.for_user(user)
        token["public_id"] = str(user.public_id)
        token["token_use"] = TOKEN_USE_ACCESS
        token.set_exp(lifetime=timedelta(seconds=-5))
        self._auth(str(token))
        response = self.client.get("/api/users/me/")
        self.assertEqual(response.status_code, 401)
        self.assertTrue(completed.data["data"]["refresh"])

    def test_refresh_token(self):
        registered = self._register("refresh@example.com")
        completed = self._complete(
            registered.data["data"]["access"],
            username="refreshuser",
            phone="+15550008888",
        )
        refresh = completed.data["data"]["refresh"]
        response = self.client.post(
            "/api/users/refresh/",
            {"refresh": refresh},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.data["data"]["access"])
        self.assertTrue(response.data["data"]["refresh"])
        replay = self.client.post(
            "/api/users/refresh/",
            {"refresh": refresh},
            format="json",
        )
        self.assertEqual(replay.status_code, 401)

    def test_logout_revocation(self):
        registered = self._register("logout@example.com")
        completed = self._complete(
            registered.data["data"]["access"],
            username="logoutuser",
            phone="+15550009999",
        )
        access = completed.data["data"]["access"]
        refresh = completed.data["data"]["refresh"]
        self._auth(access)
        logout = self.client.post(
            "/api/users/logout/",
            {"refresh": refresh, "access": access},
            format="json",
        )
        self.assertEqual(logout.status_code, 200)
        me = self.client.get("/api/users/me/")
        self.assertEqual(me.status_code, 401)
        replay = self.client.post(
            "/api/users/refresh/",
            {"refresh": refresh},
            format="json",
        )
        self.assertEqual(replay.status_code, 401)

    def test_repeated_form_submission(self):
        registered = self._register("repeat@example.com")
        access = registered.data["data"]["access"]
        first = self._complete(access, username="repeatuser", phone="+15551112222")
        second = self._complete(
            first.data["data"]["access"],
            username="repeatuser",
            phone="+15551112222",
        )
        self.assertEqual(first.status_code, 200)
        self.assertEqual(second.status_code, 200)
        self.assertTrue(second.data["data"]["profile_completed"])
        self.assertEqual(Users.objects.filter(email="repeat@example.com").count(), 1)

    @patch("apps.users.services.auth_service.verify_social_token")
    def test_invalid_google_identity(self, verify):
        verify.side_effect = AuthFailed("Invalid Google token.", code="INVALID_GOOGLE_TOKEN")
        response = self.client.post(
            "/api/users/social-login/",
            {"provider": "google", "id_token": "bad-token"},
            format="json",
        )
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.data.get("code"), "INVALID_GOOGLE_TOKEN")
        self.assertEqual(Users.objects.count(), 0)

    def test_disabled_account(self):
        registered = self._register("disabled@example.com")
        self._complete(
            registered.data["data"]["access"],
            username="disableduser",
            phone="+15550001212",
        )
        user = Users.objects.get(email="disabled@example.com")
        user.is_active = False
        user.save(update_fields=["is_active"])
        login = self.client.post(
            "/api/users/login/",
            {"email": "disabled@example.com", "password": PASSWORD},
            format="json",
        )
        self.assertEqual(login.status_code, 401)
        self.assertEqual(login.data.get("code"), "ACCOUNT_DISABLED")

    def test_login_pending_returns_registration_token(self):
        self._register("pending.login@example.com")
        response = self.client.post(
            "/api/users/login/",
            {"email": "pending.login@example.com", "password": PASSWORD},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertNotIn("refresh", response.data["data"])
        self.assertFalse(response.data["data"]["user"]["profile_completed"])


@override_settings(
    AUTH_PROVIDERS={"google": {"client_id": "test-google-client-id.apps.googleusercontent.com"}},
    AUTH_THROTTLE_DISABLED=True,
)
class ConcurrentRegisterTests(TransactionTestCase):
    def test_concurrent_duplicate_registration(self):
        results = []

        def register():
            connection.close()
            client = APIClient()
            response = client.post(
                "/api/users/register/",
                {
                    "email": "race@example.com",
                    "password": PASSWORD,
                    "confirm_password": PASSWORD,
                },
                format="json",
            )
            results.append(response.status_code)

        threads = [Thread(target=register), Thread(target=register)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()

        self.assertEqual(Users.objects.filter(email="race@example.com").count(), 1)
        self.assertIn(201, results)
        self.assertTrue(any(code in {400, 409} for code in results))
