from django.db import (
    IntegrityError,
    transaction,
)
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.company.repository import (
    CatalogRepository,
    CompanyRepository,
)
from apps.organization.repository import OrganizationMembershipRepository
from apps.users.timezone_repository import TimeZoneRepository
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class CompanyService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})

        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})

        return decoded

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        return list(
            dict.fromkeys(
                CompanyService._decode_uid(uid, field="uids")
                for uid in uids
            )
        )


    @staticmethod
    def _resolve_actor_organization(actor) -> int:
        user_id = getattr(actor, "pk", None)
        if not user_id:
            raise AuthValidationError(
                {
                    "organization": [
                        "Organization not found or inactive."
                    ]
                },
                code="ORGANIZATION_NOT_FOUND",
            )

        organization_id = (
            OrganizationMembershipRepository.list_memberships(
                user_id=user_id,
                is_active=True,
            )
            .filter(organization__is_active=True)
            .values_list("organization_id", flat=True)
            .first()
        )

        if organization_id is None:
            raise AuthValidationError(
                {
                    "organization": [
                        "Organization not found or inactive."
                    ]
                },
                code="ORGANIZATION_NOT_FOUND",
            )

        return organization_id

    @staticmethod
    def _resolve_timezone(uid: str | None) -> int | None:
        if not uid:
            return None

        timezone_id = CompanyService._decode_uid(
            uid,
            field="timezone_uid",
        )
        timezone = TimeZoneRepository.get_by_id(timezone_id)
        if timezone is None or not timezone.is_active:
            raise AuthValidationError(
                {
                    "timezone_uid": [
                        "Timezone not found or inactive."
                    ]
                },
                code="TIMEZONE_NOT_FOUND",
            )
        return timezone_id

    @staticmethod
    def _resolve_company_type(uid: str | None) -> int | None:
        if not uid:
            return None

        company_type_id = CompanyService._decode_uid(
            uid,
            field="company_type_uid",
        )
        company_type = CatalogRepository.get_by_id(
            kind="company_type",
            item_id=company_type_id,
        )
        if company_type is None or not company_type.is_active:
            raise AuthValidationError(
                {
                    "company_type_uid": [
                        "Company type not found or inactive."
                    ]
                },
                code="COMPANY_TYPE_NOT_FOUND",
            )
        return company_type_id

    @staticmethod
    def _validate_code(
        *,
        code: str,
        organization_id: int,
        exclude_id: int | None = None,
    ) -> None:
        if CompanyRepository.get_code_conflict(
            code=code,
            organization_id=organization_id,
            exclude_id=exclude_id,
        ):
            raise AuthValidationError(
                {
                    "code": [
                        "This company code already exists in the organization."
                    ]
                },
                code="COMPANY_CODE_EXISTS",
            )

    @staticmethod
    def get_companies(*, validated_data: dict):
        company_id = None
        organization_id = None

        if validated_data.get("uid"):
            company_id = [
                CompanyService._decode_uid(
                    validated_data["uid"]
                )
            ]

        if validated_data.get("organization_uid"):
            organization_id = CompanyService._decode_uid(
                validated_data["organization_uid"],
                field="organization_uid",
            )

        return CompanyRepository.list_companies(
            company_id=company_id,
            organization_id=organization_id,
            code=validated_data.get("code"),
            name=validated_data.get("name"),
            is_active=validated_data.get("is_active"),
        )

    @staticmethod
    def create_company(*, validated_data: dict, actor=None):
        organization_id = CompanyService._resolve_actor_organization(
            actor
        )

        code = validated_data["code"]

        CompanyService._validate_code(
            code=code,
            organization_id=organization_id,
        )
        timezone_id = CompanyService._resolve_timezone(
            validated_data.get("timezone_uid")
        )
        company_type_id = CompanyService._resolve_company_type(
            validated_data.get("company_type_uid")
        )

        try:
            with transaction.atomic():
                company = CompanyRepository.create_company(
                    organization_id=organization_id,
                    name=validated_data["name"],
                    code=code,
                    legal_name=validated_data.get("legal_name"),
                    website=validated_data.get("website"),
                    logo=validated_data.get("logo"),
                    timezone_id=timezone_id,
                    registration_number=validated_data.get(
                        "registration_number"
                    ),
                    company_type_id=company_type_id,
                    is_active=validated_data.get("is_active", True),
                )
                from apps.users.services.membership_service import (
                    MembershipService,
                )

                MembershipService.grant_company_to_org_principals(
                    company_id=company.pk,
                    organization_id=organization_id,
                    actor_id=getattr(actor, "pk", None),
                )
                from apps.company.services.company_module_service import (
                    CompanyModuleService,
                )

                CompanyModuleService.seed_for_company(
                    company_id=company.pk,
                    modules=validated_data.get("modules"),
                )

        except IntegrityError:
            raise AuthValidationError(
                {
                    "code": [
                        "This company code already exists in the organization."
                    ]
                },
                code="COMPANY_CODE_EXISTS",
            ) from None

        return CompanyRepository.get_by_id(company.pk)

    @staticmethod
    def update_company(*, validated_data: dict):
        company_id = CompanyService._decode_uid(
            validated_data["uid"]
        )

        company = CompanyRepository.get_by_id(company_id)

        if company is None:
            raise NotFound("Company not found.")

        fields = {}

        if "name" in validated_data:
            fields["name"] = validated_data["name"]

        if "code" in validated_data:
            code = validated_data["code"]
            CompanyService._validate_code(
                code=code,
                organization_id=company.organization_id,
                exclude_id=company.pk,
            )
            fields["code"] = code

        for key in (
            "legal_name",
            "website",
            "logo",
            "registration_number",
            "is_active",
        ):
            if key in validated_data:
                fields[key] = validated_data[key]

        if "timezone_uid" in validated_data:
            fields["timezone_id"] = CompanyService._resolve_timezone(
                validated_data.get("timezone_uid")
            )

        if "company_type_uid" in validated_data:
            fields["company_type_id"] = CompanyService._resolve_company_type(
                validated_data.get("company_type_uid")
            )

        try:
            with transaction.atomic():
                CompanyRepository.update_company(
                    company=company,
                    fields=fields,
                )
                if validated_data.get("modules"):
                    from apps.company.services.company_module_service import (
                        CompanyModuleService,
                    )

                    CompanyModuleService.apply_flags(
                        company_id=company.pk,
                        modules=validated_data["modules"],
                    )

        except IntegrityError:
            raise AuthValidationError(
                {
                    "code": [
                        "This company code already exists in the organization."
                    ]
                },
                code="COMPANY_CODE_EXISTS",
            ) from None

        return CompanyRepository.get_by_id(company.pk)

    @staticmethod
    def delete_companies(*, validated_data: dict) -> dict:
        company_ids = CompanyService._decode_uids(
            validated_data["uids"]
        )

        deleted = CompanyRepository.soft_delete_by_ids(
            company_ids
        )

        if not deleted:
            raise NotFound("Company not found.")

        return {
            "deleted": deleted
        }

    @staticmethod
    def toggle_companies(*, validated_data: dict):
        company_ids = CompanyService._decode_uids(
            validated_data["uids"]
        )

        updated = CompanyRepository.toggle_active_by_ids(
            company_ids
        )

        if not updated:
            raise NotFound("Company not found.")

        return CompanyRepository.list_companies(
            company_id=company_ids
        )

    @staticmethod
    def update_company_tenant(
        *,
        company_uid: str,
        tenant_id: int,
    ):
        company_id = CompanyService._decode_uid(
            company_uid
        )

        company = CompanyRepository.get_by_id(
            company_id
        )

        if company is None:
            raise NotFound("Company not found.")

        updated = CompanyRepository.update_tenant_for_company(
            company_id=company.pk,
            tenant_id=tenant_id,
        )

        if not updated:
            raise NotFound("Company not found.")

        return CompanyRepository.get_by_id(company.pk)