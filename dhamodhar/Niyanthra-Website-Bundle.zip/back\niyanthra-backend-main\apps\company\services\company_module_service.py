from django.db import IntegrityError, transaction
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.company.catalog_repository import ModuleRepository
from apps.company.models import CompanyModule
from apps.company.module_repository import CompanyModuleRepository
from apps.company.repository import CompanyRepository
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id, encode_id


class CompanyModuleService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str) -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})

        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})

        return decoded

    @staticmethod
    def default_modules() -> dict:
        return {code: True for code in ModuleRepository.active_codes()}

    @staticmethod
    def seed_for_company(*, company_id: int, modules: dict | None = None) -> CompanyModule:
        flags = CompanyModuleService.default_modules()
        if modules:
            CompanyModuleService._known_codes(list(modules))
            flags.update(modules)
        return CompanyModuleRepository.create(
            company_id=company_id,
            modules=flags,
        )

    @staticmethod
    def apply_flags(*, company_id: int, modules: dict) -> CompanyModule:
        CompanyModuleService._known_codes(list(modules))
        assignment = CompanyModuleRepository.get_for_company(company_id)
        if assignment is None:
            flags = CompanyModuleService.default_modules()
            flags.update(modules)
            CompanyModuleRepository.create(
                company_id=company_id,
                modules=flags,
            )
            return CompanyModuleRepository.get_for_company(company_id)

        merged = dict(assignment.modules or {})
        merged.update(modules)
        CompanyModuleRepository.save_modules(
            assignment=assignment,
            modules=merged,
        )
        return CompanyModuleRepository.get_by_id(assignment.pk)

    @staticmethod
    def _company_id(uid: str) -> int:
        company_id = CompanyModuleService._decode_uid(
            uid,
            field="company_uid",
        )
        if CompanyRepository.get_by_id(company_id) is None:
            raise NotFound("Company not found.")
        return company_id

    @staticmethod
    def _known_codes(codes: list[str]) -> None:
        active = ModuleRepository.active_code_set()
        if any(code not in active for code in codes):
            raise AuthValidationError(
                {
                    "modules": [
                        "One or more modules are missing or inactive.",
                    ]
                },
                code="MODULE_NOT_FOUND",
            )

    @staticmethod
    def list_modules(*, validated_data: dict):
        company_id = CompanyModuleService._decode_uid(
            validated_data["company_uid"],
            field="company_uid",
        )
        assignment_id = None
        if validated_data.get("uid"):
            assignment_id = CompanyModuleService._decode_uid(
                validated_data["uid"],
                field="uid",
            )
        return CompanyModuleRepository.list_for_company(
            company_id=company_id,
            assignment_id=assignment_id,
        )

    @staticmethod
    def create_modules(*, validated_data: dict):
        company_id = CompanyModuleService._company_id(
            validated_data["company_uid"]
        )
        modules = validated_data.get("modules") or {}
        flags = CompanyModuleService.default_modules()
        if modules:
            CompanyModuleService._known_codes(list(modules))
            flags.update(modules)
        modules = flags
        if CompanyModuleRepository.get_for_company(company_id) is not None:
            raise AuthValidationError(
                {
                    "company_uid": [
                        "This company already has modules.",
                    ]
                },
                code="COMPANY_MODULE_EXISTS",
            )
        try:
            with transaction.atomic():
                CompanyModuleRepository.create(
                    company_id=company_id,
                    modules=modules,
                )
        except IntegrityError:
            raise AuthValidationError(
                {
                    "company_uid": [
                        "This company already has modules.",
                    ]
                },
                code="COMPANY_MODULE_EXISTS",
            ) from None
        return CompanyModuleRepository.get_for_company(company_id)

    @staticmethod
    def update_module(*, validated_data: dict):
        company_id = CompanyModuleService._company_id(
            validated_data["company_uid"]
        )
        assignment = CompanyModuleRepository.get_by_id(
            CompanyModuleService._decode_uid(
                validated_data["uid"],
                field="uid",
            )
        )
        if assignment is None or assignment.company_id != company_id:
            raise NotFound("Company module not found.")

        return CompanyModuleService.apply_flags(
            company_id=company_id,
            modules=validated_data["modules"],
        )

    @staticmethod
    def delete_modules(*, validated_data: dict):
        company_id = CompanyModuleService._company_id(
            validated_data["company_uid"]
        )
        assignment = CompanyModuleRepository.get_by_id(
            CompanyModuleService._decode_uid(
                validated_data["uid"],
                field="uid",
            )
        )
        if assignment is None or assignment.company_id != company_id:
            raise NotFound("Company module not found.")

        incoming = validated_data["modules"]
        CompanyModuleService._known_codes(list(incoming))
        merged = dict(assignment.modules or {})
        for code in incoming:
            merged[code] = False
        CompanyModuleRepository.save_modules(
            assignment=assignment,
            modules=merged,
        )
        return CompanyModuleRepository.get_by_id(assignment.pk)

    @staticmethod
    def section_areas(*, validated_data: dict) -> dict:
        company_id = CompanyModuleService._company_id(
            validated_data["company_uid"]
        )
        company = CompanyRepository.get_by_id(company_id)
        assignment = CompanyModuleRepository.get_for_company(company_id)
        flags = dict(assignment.modules or {}) if assignment else {}
        return {
            "uid": encode_id(assignment.pk) if assignment else "",
            "public_id": str(assignment.public_id) if assignment else "",
            "company": {
                "uid": encode_id(company.pk),
                "public_id": str(company.public_id),
                "name": company.name or "",
                "code": company.code or "",
            },
            "sections": [
                {
                    "uid": encode_id(module.pk),
                    "public_id": str(module.public_id),
                    "name": module.name or "",
                    "code": module.code or "",
                    "enabled": bool(flags.get(module.code, False)),
                }
                for module in ModuleRepository.list_active()
            ],
        }
