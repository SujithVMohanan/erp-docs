"""
Deprecated import path — use ``core.tenant`` instead.

Kept so older imports keep working without changing runtime behavior.
"""

from core.tenant import (
    TenantAwareManager,
    TenantAwareQuerySet,
    TenantContextError,
    TenantIdentity,
    TenantUnscopedManager,
    TenantUnscopedQuerySet,
    clear_current_tenant,
    get_current_tenant,
    get_current_tenant_id,
    require_current_tenant,
    reset_current_tenant,
    set_current_tenant,
    tenant_context,
)

__all__ = [
    "TenantAwareManager",
    "TenantAwareQuerySet",
    "TenantContextError",
    "TenantIdentity",
    "TenantUnscopedManager",
    "TenantUnscopedQuerySet",
    "clear_current_tenant",
    "get_current_tenant",
    "get_current_tenant_id",
    "require_current_tenant",
    "reset_current_tenant",
    "set_current_tenant",
    "tenant_context",
]
