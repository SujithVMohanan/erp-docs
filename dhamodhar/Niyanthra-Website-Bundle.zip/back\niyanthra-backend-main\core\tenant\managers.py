from __future__ import annotations

from django.db import models
from django.db.models import Q

from core.database.managers import SoftDeleteQuerySet
from core.tenant.context import (
    TenantIdentity,
    require_current_tenant,
)
from core.tenant.exceptions import TenantContextError

TENANT_FIELD = "tenant_id"
COMPANY_FIELD = "company_id"


def _model_has_field(model, name: str) -> bool:
    cache = model._meta.__dict__.get("_niyanthra_field_names")
    if cache is None:
        cache = frozenset(field.name for field in model._meta.fields)
        model._meta.__dict__["_niyanthra_field_names"] = cache
    return name in cache


def _guard_value(value, *, current: int, field: str) -> None:
    if value is None:
        return
    try:
        coerced = int(value)
    except (TypeError, ValueError) as exc:
        raise TenantContextError(f"Invalid {field} value.") from exc
    if coerced != current:
        raise TenantContextError(f"Cross-tenant {field} is not allowed.")


def _scope_for(model, identity: TenantIdentity) -> dict:
    scope = {TENANT_FIELD: identity.tenant_id}
    if (
        _model_has_field(model, COMPANY_FIELD)
        and identity.company_id is not None
    ):
        scope[COMPANY_FIELD] = identity.company_id
    return scope


def _guard_kwargs(kwargs: dict, *, identity: TenantIdentity) -> dict:
    cleaned = dict(kwargs)

    if TENANT_FIELD in cleaned:
        _guard_value(
            cleaned[TENANT_FIELD],
            current=identity.tenant_id,
            field=TENANT_FIELD,
        )
        cleaned[TENANT_FIELD] = identity.tenant_id

    if COMPANY_FIELD in cleaned and identity.company_id is not None:
        _guard_value(
            cleaned[COMPANY_FIELD],
            current=identity.company_id,
            field=COMPANY_FIELD,
        )
        cleaned[COMPANY_FIELD] = identity.company_id

    return cleaned


def _strip_tenant_from_q(
    q_object: Q,
    *,
    identity: TenantIdentity,
) -> Q:
    if not isinstance(q_object, Q):
        return q_object

    new_children = []
    for child in q_object.children:
        if isinstance(child, Q):
            new_children.append(
                _strip_tenant_from_q(child, identity=identity)
            )
            continue

        if isinstance(child, tuple) and len(child) == 2:
            key, value = child
            field = key.split("__", 1)[0]
            if field == TENANT_FIELD:
                _guard_value(
                    value,
                    current=identity.tenant_id,
                    field=TENANT_FIELD,
                )
                continue
            if field == COMPANY_FIELD and identity.company_id is not None:
                _guard_value(
                    value,
                    current=identity.company_id,
                    field=COMPANY_FIELD,
                )
                continue
            new_children.append(child)
            continue

        new_children.append(child)

    rebuilt = Q(*new_children)
    rebuilt.connector = q_object.connector
    rebuilt.negated = q_object.negated
    return rebuilt


def _stamp_instance(obj, *, scope: dict, identity: TenantIdentity) -> None:
    existing = getattr(obj, TENANT_FIELD, None)
    if existing not in (None, 0):
        _guard_value(
            existing,
            current=identity.tenant_id,
            field=TENANT_FIELD,
        )
    setattr(obj, TENANT_FIELD, identity.tenant_id)

    if COMPANY_FIELD not in scope:
        return

    existing_company = getattr(obj, COMPANY_FIELD, None)
    if existing_company not in (None, 0):
        _guard_value(
            existing_company,
            current=scope[COMPANY_FIELD],
            field=COMPANY_FIELD,
        )
    setattr(obj, COMPANY_FIELD, scope[COMPANY_FIELD])


class TenantAwareQuerySet(SoftDeleteQuerySet):
    """Soft-delete queryset scoped to the active tenant context."""

    def _identity(self) -> TenantIdentity:
        return require_current_tenant()

    def _scope_kwargs(self) -> dict:
        return _scope_for(self.model, self._identity())

    def _prepare(self, args: tuple, kwargs: dict) -> tuple[tuple, dict]:
        identity = self._identity()
        guarded_args = tuple(
            _strip_tenant_from_q(arg, identity=identity)
            if isinstance(arg, Q)
            else arg
            for arg in args
        )
        return guarded_args, _guard_kwargs(kwargs, identity=identity)

    def filter(self, *args, **kwargs):
        args, kwargs = self._prepare(args, kwargs)
        return super().filter(*args, **kwargs)

    def exclude(self, *args, **kwargs):
        args, kwargs = self._prepare(args, kwargs)
        return super().exclude(*args, **kwargs)

    def create(self, **kwargs):
        identity = self._identity()
        scope = _scope_for(self.model, identity)
        cleaned = _guard_kwargs(kwargs, identity=identity)
        cleaned.update(scope)
        return super().create(**cleaned)

    def get_or_create(self, defaults=None, **kwargs):
        identity = self._identity()
        scope = _scope_for(self.model, identity)
        cleaned = _guard_kwargs(kwargs, identity=identity)
        cleaned.update(scope)
        defaults = _guard_kwargs(defaults or {}, identity=identity)
        defaults.update(scope)
        return super().get_or_create(defaults=defaults, **cleaned)

    def update_or_create(self, defaults=None, **kwargs):
        identity = self._identity()
        scope = _scope_for(self.model, identity)
        cleaned = _guard_kwargs(kwargs, identity=identity)
        cleaned.update(scope)
        defaults = _guard_kwargs(defaults or {}, identity=identity)
        defaults.pop(TENANT_FIELD, None)
        if COMPANY_FIELD in scope:
            defaults[COMPANY_FIELD] = scope[COMPANY_FIELD]
        return super().update_or_create(defaults=defaults, **cleaned)

    def update(self, **kwargs):
        cleaned = _guard_kwargs(kwargs, identity=self._identity())
        cleaned.pop(TENANT_FIELD, None)
        return super().update(**cleaned)

    def bulk_create(
        self,
        objs,
        batch_size=None,
        ignore_conflicts=False,
        update_conflicts=False,
        update_fields=None,
        unique_fields=None,
    ):
        identity = self._identity()
        scope = _scope_for(self.model, identity)
        for obj in objs:
            _stamp_instance(obj, scope=scope, identity=identity)

        return super().bulk_create(
            objs,
            batch_size=batch_size,
            ignore_conflicts=ignore_conflicts,
            update_conflicts=update_conflicts,
            update_fields=update_fields,
            unique_fields=unique_fields,
        )

    def bulk_update(self, objs, fields, batch_size=None):
        identity = self._identity()
        if TENANT_FIELD in fields:
            raise TenantContextError(
                "bulk_update cannot modify tenant_id."
            )
        for obj in objs:
            existing = getattr(obj, TENANT_FIELD, None)
            if existing is None:
                raise TenantContextError(
                    "bulk_update requires tenant_id on each object."
                )
            _guard_value(
                existing,
                current=identity.tenant_id,
                field=TENANT_FIELD,
            )
        return super().bulk_update(objs, fields, batch_size=batch_size)


class TenantUnscopedQuerySet(SoftDeleteQuerySet):
    """System/admin queryset — no automatic tenant filter."""


class TenantAwareManager(models.Manager.from_queryset(TenantAwareQuerySet)):
    """Default manager: alive rows for the current tenant only."""

    def get_queryset(self):
        identity = require_current_tenant()
        return (
            super()
            .get_queryset()
            .alive()
            .filter(**_scope_for(self.model, identity))
        )


class TenantUnscopedManager(
    models.Manager.from_queryset(TenantUnscopedQuerySet)
):
    """
    Explicit global access (all tenants, including soft-deleted).
    Never use as the default manager for application code.
    """
