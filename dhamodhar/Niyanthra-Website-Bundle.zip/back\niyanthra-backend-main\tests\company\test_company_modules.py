from django.test import TestCase
from rest_framework.test import APIClient

from apps.company.models import (
    Company,
    CompanyModule,
    Module,
)
from apps.location.models import Country
from apps.organization.models import (
    Organization,
    OrganizationMembership,
)
from apps.users.models import Users
from core.utils.ids import encode_id
from core.utils.tokens import issue_tokens

PASSWORD = "ValidPassw0rd!"


class CompanyModuleApiTests(TestCase):

    def setUp(self):
        self.client = APIClient()
        self.admin = Users.objects.create_user(
            email="mod-admin@example.com",
            password=PASSWORD,
            username="modadmin",
            phone_number="+15554440001",
            is_admin=True,
            profile_completed=True,
        )
        tokens = issue_tokens(self.admin)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")

        country = Country.objects.create(name="India", code="IN")
        self.organization = Organization.objects.create(
            name="Mod Org",
            code="MODORG",
            legal_name="Mod Org Pvt",
            country=country,
        )
        OrganizationMembership.objects.create(
            organization=self.organization,
            user=self.admin,
            role=OrganizationMembership.Role.OWNER,
            is_active=True,
        )
        Module.objects.create(name="Sales", code="sales")
        Module.objects.create(name="Inventory", code="inventory")
        Module.objects.create(name="Product", code="product")

    def test_company_create_seeds_all_modules_true(self):
        response = self.client.post(
            "/api/company/create-company/",
            {
                "name": "Mod Co",
                "code": "MODCO",
                "legal_name": "Mod Co Pvt",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 201)
        company = Company.objects.get(code="MODCO")
        row = CompanyModule.objects.get(company=company)
        self.assertEqual(
            row.modules,
            {
                "inventory": True,
                "product": True,
                "sales": True,
            },
        )

    def test_company_create_accepts_modules_json(self):
        response = self.client.post(
            "/api/company/create-company/",
            {
                "name": "Mod Co",
                "code": "MODCO",
                "legal_name": "Mod Co Pvt",
                "modules": {"inventory": False},
            },
            format="json",
        )
        self.assertEqual(response.status_code, 201)
        row = CompanyModule.objects.get(company__code="MODCO")
        self.assertFalse(row.modules["inventory"])
        self.assertTrue(row.modules["sales"])
        self.assertTrue(row.modules["product"])

    def test_updates_module_flags(self):
        created = self.client.post(
            "/api/company/create-company/",
            {
                "name": "Mod Co",
                "code": "MODCO",
                "legal_name": "Mod Co Pvt",
            },
            format="json",
        )
        self.assertEqual(created.status_code, 201)
        company = Company.objects.get(code="MODCO")
        row = CompanyModule.objects.get(company=company)
        listed = self.client.get(
            "/api/company/get-company-modules/",
            {"company_uid": encode_id(company.pk)},
        )
        self.assertEqual(listed.status_code, 200)
        body = listed.json()["data"]["results"][0]
        self.assertTrue(body["modules"]["sales"])

        updated = self.client.put(
            "/api/company/update-company-module/",
            {
                "uid": encode_id(row.pk),
                "company_uid": encode_id(company.pk),
                "modules": {"inventory": False},
            },
            format="json",
        )
        self.assertEqual(updated.status_code, 200)
        flags = updated.json()["data"]["modules"]
        self.assertFalse(flags["inventory"])
        self.assertTrue(flags["sales"])
        self.assertTrue(flags["product"])

        removed = self.client.delete(
            "/api/company/delete-company-module/",
            {
                "uid": encode_id(row.pk),
                "company_uid": encode_id(company.pk),
                "modules": {"sales": True},
            },
            format="json",
        )
        self.assertEqual(removed.status_code, 200)
        self.assertFalse(removed.json()["data"]["modules"]["sales"])
        self.assertTrue(removed.json()["data"]["modules"]["product"])

        sections = self.client.get(
            "/api/company/get-module-sections/",
            {"company_uid": encode_id(company.pk)},
        )
        self.assertEqual(sections.status_code, 200)
        enabled = {
            item["code"]: item["enabled"]
            for item in sections.json()["data"]["sections"]
        }
        self.assertFalse(enabled["sales"])
        self.assertFalse(enabled["inventory"])
        self.assertTrue(enabled["product"])
