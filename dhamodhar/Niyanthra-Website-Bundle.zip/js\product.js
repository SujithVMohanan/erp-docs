/**
 * Niyanthra ERP — Product Landing Website Interactivity
 * Handles:
 * 1. Interactive UI Showcase switcher
 * 2. High-conversion enquiry capture with Web3Forms + WhatsApp fallback + Local Storage
 * 3. Accessible Dialog Modal for instant demo bookings
 * 4. Mobile navigation drawer toggle
 */

document.addEventListener('DOMContentLoaded', () => {
  initShowcaseTabs();
  initEnquiryForm();
  initDemoModal();
  initMobileNav();
  initWhatsAppDirect();
});

/* --------------------------------------------------------------------------
   1. Interactive UI Showcase Tab Switcher
   -------------------------------------------------------------------------- */
function initShowcaseTabs() {
  const tabs = document.querySelectorAll('.tab-btn[data-tab]');
  const panes = document.querySelectorAll('.showcase-content-pane');

  if (!tabs.length || !panes.length) return;

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetId = tab.getAttribute('data-tab');

      // Update active tab buttons
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      // Update active panes
      panes.forEach(pane => {
        if (pane.id === targetId) {
          pane.classList.add('active');
        } else {
          pane.classList.remove('active');
        }
      });
    });
  });
}

/* --------------------------------------------------------------------------
   2. Enquiry Form & Lead Capture (Web3Forms + WhatsApp fallback)
   -------------------------------------------------------------------------- */
function initEnquiryForm() {
  const form = document.getElementById('enquiry-form');
  const alertBox = document.getElementById('form-status-alert');
  const submitBtn = document.getElementById('btn-submit-enquiry');

  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = form.querySelector('[name="name"]')?.value.trim();
    const phone = form.querySelector('[name="phone"]')?.value.trim();
    const email = form.querySelector('[name="email"]')?.value.trim();
    const company = form.querySelector('[name="company"]')?.value.trim();
    const industry = form.querySelector('[name="industry"]')?.value;
    const branches = form.querySelector('[name="branches"]')?.value;
    const message = form.querySelector('[name="message"]')?.value.trim();

    if (!name || !phone || !company) {
      showFormAlert('Please fill in your name, contact phone, and business name.', 'error');
      return;
    }

    const leadData = {
      name,
      phone,
      email,
      company,
      industry,
      branches,
      message,
      timestamp: new Date().toISOString()
    };

    // Store in browser local storage as backup ledger
    try {
      const existingLeads = JSON.parse(localStorage.getItem('niyanthra_leads') || '[]');
      existingLeads.push(leadData);
      localStorage.setItem('niyanthra_leads', JSON.stringify(existingLeads));
    } catch (err) {
      console.warn('LocalStorage error:', err);
    }

    // Set loading state on submit button
    const originalText = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML = `
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="spin-icon">
        <circle cx="12" cy="12" r="10" stroke-opacity="0.25"/>
        <path d="M12 2a10 10 0 0 1 10 10"/>
      </svg> Submitting Request...
    `;

    // Web3Forms endpoint integration
    const accessKey = form.querySelector('[name="access_key"]')?.value || 'YOUR_ACCESS_KEY_HERE';
    let submittedSuccessfully = false;

    if (accessKey && accessKey !== 'YOUR_ACCESS_KEY_HERE') {
      try {
        const response = await fetch('https://api.web3forms.com/submit', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify({
            access_key: accessKey,
            subject: `New Niyanthra ERP Enquiry from ${company} (${industry})`,
            from_name: name,
            ...leadData
          })
        });
        const result = await response.json();
        if (result.success) {
          submittedSuccessfully = true;
        }
      } catch (networkErr) {
        console.warn('Web3Forms fetch failed, falling back to local success & WhatsApp:', networkErr);
      }
    } else {
      // Prototype mode: simulate brief response delay
      await new Promise(r => setTimeout(r, 600));
      submittedSuccessfully = true;
    }

    submitBtn.disabled = false;
    submitBtn.innerHTML = originalText;

    if (submittedSuccessfully) {
      form.reset();
      const whatsappText = encodeURIComponent(
        `Hello Niyanthra Team! I would like to schedule a demo.\n` +
        `Name: ${name}\n` +
        `Company: ${company}\n` +
        `Industry: ${industry}\n` +
        `Branches: ${branches}\n` +
        `Phone: ${phone}`
      );
      const whatsappUrl = `https://wa.me/919447000000?text=${whatsappText}`;

      showFormAlert(`
        <div>
          <strong>Thank you, ${name}! Your demo request has been received.</strong>
          <p style="margin-top:0.35rem;font-weight:normal;font-size:0.85rem">
            Our enterprise solutions team will contact you within 24 hours.
          </p>
          <div style="margin-top:0.75rem">
            <a href="${whatsappUrl}" target="_blank" rel="noopener" class="btn btn-secondary" style="font-size:0.75rem;padding:0.4rem 0.8rem;border-color:#25d366;color:#128c7e">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m3 21 1.9-5.7a8.5 8.5 0 1 1 3.8 3.8z"/></svg>
              Fast-track via WhatsApp Now
            </a>
          </div>
        </div>
      `, 'success');
    } else {
      showFormAlert('Submission could not be completed. Please try contacting us directly via WhatsApp.', 'error');
    }
  });

  function showFormAlert(htmlContent, type) {
    alertBox.innerHTML = htmlContent;
    alertBox.className = `form-status-alert ${type}`;
    alertBox.style.display = 'block';
  }
}

/* --------------------------------------------------------------------------
   3. Accessible Demo Request Modal
   -------------------------------------------------------------------------- */
function initDemoModal() {
  const modal = document.getElementById('demo-modal');
  const triggers = document.querySelectorAll('[data-open-modal="demo-modal"]');
  const closeBtn = document.getElementById('btn-close-modal');

  if (!modal) return;

  triggers.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      modal.showModal();
    });
  });

  closeBtn?.addEventListener('click', () => {
    modal.close();
  });

  // Close on backdrop click
  modal.addEventListener('click', (e) => {
    const dialogDimensions = modal.getBoundingClientRect();
    if (
      e.clientX < dialogDimensions.left ||
      e.clientX > dialogDimensions.right ||
      e.clientY < dialogDimensions.top ||
      e.clientY > dialogDimensions.bottom
    ) {
      modal.close();
    }
  });
}

/* --------------------------------------------------------------------------
   4. Mobile Navigation Drawer
   -------------------------------------------------------------------------- */
function initMobileNav() {
  const toggle = document.querySelector('.mobile-toggle');
  const navMenu = document.querySelector('.nav-menu');

  if (!toggle || !navMenu) return;

  toggle.addEventListener('click', () => {
    const isOpen = navMenu.style.display === 'flex';
    navMenu.style.display = isOpen ? 'none' : 'flex';
    navMenu.style.flexDirection = 'column';
    navMenu.style.position = 'absolute';
    navMenu.style.top = 'var(--nav-height)';
    navMenu.style.left = '0';
    navMenu.style.right = '0';
    navMenu.style.background = '#ffffff';
    navMenu.style.padding = '1.5rem';
    navMenu.style.boxShadow = '0 10px 25px rgba(0,0,0,0.1)';
    navMenu.style.borderBottom = '1px solid var(--border)';
  });
}

/* --------------------------------------------------------------------------
   5. WhatsApp Direct Links
   -------------------------------------------------------------------------- */
function initWhatsAppDirect() {
  const whatsappBtns = document.querySelectorAll('[data-whatsapp-cta]');
  whatsappBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const message = encodeURIComponent("Hello Niyanthra team, I am interested in seeing a live demo of Niyanthra ERP for our business.");
      window.open(`https://wa.me/919447000000?text=${message}`, '_blank');
    });
  });
}
