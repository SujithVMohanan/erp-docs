import io

from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from PIL import Image
from rest_framework.test import APIClient

from apps.company.models import (
    Company,
    CompanyType,
)
from apps.location.models import Country
from apps.organization.models import (
    Organization,
    OrganizationMembership,
)
from apps.users.models import (
    TimeZone,
    Users,
)
from core.utils.ids import (
    decode_id,
    encode_id,
)
from core.utils.tokens import issue_tokens

PASSWORD = "ValidPassw0rd!"


def _png(name="logo.png"):
    buffer = io.BytesIO()
    Image.new("RGB", (1, 1), color="red").save(buffer, format="PNG")
    return SimpleUploadedFile(name, buffer.getvalue(), content_type="image/png")


class CompanyApiTests(TestCase):

    def setUp(self):
        self.client = APIClient()
        self.admin = Users.objects.create_user(
            email="admin@example.com",
            password=PASSWORD,
            username="adminuser",
            phone_number="+15551110001",
            is_admin=True,
            profile_completed=True,
        )
        tokens = issue_tokens(self.admin)
        self.client.credentials(
            HTTP_AUTHORIZATION=f"Bearer {tokens['access']}"
        )

        self.country = Country.objects.create(name="India", code="IN")
        self.organization = Organization.objects.create(
            name="Company Org",
            code="CORG",
            legal_name="Company Org Pvt",
            country=self.country,
        )
        OrganizationMembership.objects.create(
            organization=self.organization,
            user=self.admin,
            role=OrganizationMembership.Role.OWNER,
            is_active=True,
        )
        self.timezone = TimeZone.objects.create(
            name="India Standard Time",
            code="Asia/Kolkata",
            utc_offset="+05:30",
            is_active=True,
        )
        self.company_type = CompanyType.objects.create(
            name="Private Limited",
            code="PVT",
            is_active=True,
        )
        self.timezone_uid = encode_id(self.timezone.pk)
        self.company_type_uid = encode_id(self.company_type.pk)
        self.organization_uid = encode_id(self.organization.pk)

    def _create(self, **overrides):
        payload = {
            "name": "Acme Industries",
            "code": "acme",
            "legal_name": "Acme Industries Pvt Ltd",
            "website": "https://acme.example.com",
            "timezone_uid": self.timezone_uid,
            "registration_number": "REG-100",
            "company_type_uid": self.company_type_uid,
            "is_active": True,
        }
        payload.update(overrides)
        return self.client.post(
            "/api/company/create-company/",
            payload,
            format="json",
        )

    def test_create_company_uses_actor_organization(self):
        response = self._create()
        self.assertEqual(response.status_code, 201, response.data)
        data = response.data["data"]
        self.assertEqual(data["name"], "Acme Industries")
        self.assertEqual(data["code"], "ACME")
        self.assertEqual(data["legal_name"], "Acme Industries Pvt Ltd")
        self.assertEqual(data["website"], "https://acme.example.com")
        self.assertEqual(data["registration_number"], "REG-100")
        self.assertTrue(data["is_active"])
        self.assertEqual(
            decode_id(data["organization"]["uid"]),
            self.organization.pk,
        )
        self.assertEqual(decode_id(data["timezone"]["uid"]), self.timezone.pk)
        self.assertEqual(data["timezone"]["code"], "Asia/Kolkata")
        self.assertEqual(
            decode_id(data["company_type"]["uid"]),
            self.company_type.pk,
        )
        self.assertEqual(data["company_type"]["code"], "PVT")
        self.assertNotIn("id", data)
        self.assertNotIn("id", data["timezone"])
        self.assertNotIn("id", data["company_type"])
        self.assertNotIn("id", data["organization"])
        self.assertNotIn("tenant", data)
        self.assertNotIn("tenant_uid", data)

        company = Company.objects.get(code="ACME")
        self.assertEqual(company.organization_id, self.organization.pk)
        self.assertIsNone(company.tenant_id)
        self.assertEqual(company.timezone_id, self.timezone.pk)
        self.assertEqual(company.company_type_id, self.company_type.pk)

    def test_create_rejects_organization_and_tenant(self):
        response = self._create(
            organization_uid=self.organization_uid,
            tenant_uid="not-allowed",
        )
        self.assertEqual(response.status_code, 400, response.data)
        self.assertIn("organization_uid", response.data["errors"])
        self.assertIn("tenant_uid", response.data["errors"])
        self.assertFalse(Company.objects.filter(code="ACME").exists())

    def test_create_requires_organization_membership(self):
        OrganizationMembership.objects.filter(user=self.admin).delete()
        response = self._create()
        self.assertEqual(response.status_code, 403, response.data)

    def test_duplicate_code_in_organization(self):
        self._create()
        response = self._create(name="Other Acme")
        self.assertEqual(response.status_code, 400, response.data)
        self.assertEqual(response.data.get("code"), "COMPANY_CODE_EXISTS")

    def test_same_code_allowed_in_another_organization(self):
        self._create()
        other_user = Users.objects.create_user(
            email="other@example.com",
            password=PASSWORD,
            username="otheruser",
            phone_number="+15551110002",
            is_admin=True,
            profile_completed=True,
        )
        other_org = Organization.objects.create(
            name="Other Org",
            code="OORG",
            legal_name="Other Org Pvt",
            country=self.country,
        )
        OrganizationMembership.objects.create(
            organization=other_org,
            user=other_user,
            role=OrganizationMembership.Role.OWNER,
            is_active=True,
        )
        tokens = issue_tokens(other_user)
        self.client.credentials(
            HTTP_AUTHORIZATION=f"Bearer {tokens['access']}"
        )
        response = self._create()
        self.assertEqual(response.status_code, 201, response.data)
        self.assertEqual(
            decode_id(response.data["data"]["organization"]["uid"]),
            other_org.pk,
        )
        self.assertEqual(
            Company.objects.filter(code="ACME").count(),
            2,
        )

    def test_invalid_timezone_and_company_type(self):
        missing = encode_id(999999)
        timezone_response = self._create(timezone_uid=missing)
        self.assertEqual(timezone_response.status_code, 400, timezone_response.data)
        self.assertEqual(
            timezone_response.data.get("code"),
            "TIMEZONE_NOT_FOUND",
        )

        self.company_type.is_active = False
        self.company_type.save(update_fields=["is_active", "updated_at"])
        type_response = self._create()
        self.assertEqual(type_response.status_code, 400, type_response.data)
        self.assertEqual(
            type_response.data.get("code"),
            "COMPANY_TYPE_NOT_FOUND",
        )

    def test_create_with_logo(self):
        payload = {
            "name": "Logo Co",
            "code": "LOGO",
            "logo": _png(),
        }
        response = self.client.post(
            "/api/company/create-company/",
            payload,
            format="multipart",
        )
        self.assertEqual(response.status_code, 201, response.data)
        self.assertIn("/companies/logos/", response.data["data"]["logo"])
        self.assertTrue(response.data["data"]["logo"].endswith(".png"))
        self.assertEqual(response.data["data"]["timezone"], "")
        self.assertEqual(response.data["data"]["company_type"], "")

    def test_partial_update_keeps_omitted_fields_and_organization(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        other_org = Organization.objects.create(
            name="Blocked Org",
            code="BORG",
            legal_name="Blocked Org Pvt",
            country=self.country,
        )
        response = self.client.put(
            "/api/company/update-company/",
            {
                "uid": uid,
                "name": "Acme Updated",
                "website": "https://updated.example.com",
                "organization_uid": encode_id(other_org.pk),
                "tenant_id": 1,
            },
            format="json",
        )
        self.assertEqual(response.status_code, 400, response.data)
        self.assertIn("organization_uid", response.data["errors"])
        self.assertIn("tenant_id", response.data["errors"])

        response = self.client.put(
            "/api/company/update-company/",
            {
                "uid": uid,
                "name": "Acme Updated",
                "website": "https://updated.example.com",
                "is_active": False,
            },
            format="json",
        )
        self.assertEqual(response.status_code, 200, response.data)
        data = response.data["data"]
        self.assertEqual(data["name"], "Acme Updated")
        self.assertEqual(data["code"], "ACME")
        self.assertEqual(data["website"], "https://updated.example.com")
        self.assertEqual(data["legal_name"], "Acme Industries Pvt Ltd")
        self.assertEqual(data["registration_number"], "REG-100")
        self.assertEqual(decode_id(data["timezone"]["uid"]), self.timezone.pk)
        self.assertEqual(
            decode_id(data["company_type"]["uid"]),
            self.company_type.pk,
        )
        self.assertEqual(
            decode_id(data["organization"]["uid"]),
            self.organization.pk,
        )
        self.assertFalse(data["is_active"])

        company = Company.objects.get(pk=Company.objects.get(code="ACME").pk)
        self.assertEqual(company.organization_id, self.organization.pk)
        self.assertIsNone(company.tenant_id)

    def test_update_can_clear_optional_relations(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.put(
            "/api/company/update-company/",
            {
                "uid": uid,
                "timezone_uid": "",
                "company_type_uid": None,
                "legal_name": "",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 200, response.data)
        data = response.data["data"]
        self.assertEqual(data["timezone"], "")
        self.assertEqual(data["company_type"], "")
        self.assertEqual(data["legal_name"], "")
        self.assertEqual(data["code"], "ACME")

    def test_update_code_conflict_and_missing_company(self):
        first = self._create()
        second = self._create(name="Beta", code="BETA")
        response = self.client.put(
            "/api/company/update-company/",
            {
                "uid": second.data["data"]["uid"],
                "code": "acme",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 400, response.data)
        self.assertEqual(response.data.get("code"), "COMPANY_CODE_EXISTS")

        company = Company.objects.get(code="BETA")
        company.delete()
        response = self.client.put(
            "/api/company/update-company/",
            {
                "uid": second.data["data"]["uid"],
                "name": "Gone",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 404, response.data)
        self.assertEqual(first.data["data"]["code"], "ACME")

    def test_list_companies_returns_public_references(self):
        self._create()
        response = self.client.get("/api/company/get-companies/")
        self.assertEqual(response.status_code, 200, response.data)
        row = response.data["data"]["results"][0]
        self.assertEqual(decode_id(row["timezone"]["uid"]), self.timezone.pk)
        self.assertNotIn("id", row["timezone"])
        self.assertNotIn("id", row["company_type"])
        self.assertNotIn("tenant", row)
