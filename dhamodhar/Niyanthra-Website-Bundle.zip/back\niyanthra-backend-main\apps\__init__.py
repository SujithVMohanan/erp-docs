"""Business Django apps. Add domain packages here later."""
