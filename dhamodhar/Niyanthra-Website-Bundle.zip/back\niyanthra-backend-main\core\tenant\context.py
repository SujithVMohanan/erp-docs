from __future__ import annotations

from contextlib import contextmanager
from contextvars import (
    ContextVar,
    Token,
)
from dataclasses import dataclass
from typing import Iterator

from core.tenant.exceptions import TenantContextError

_tenant_identity: ContextVar[TenantIdentity | None] = ContextVar(
    "tenant_identity",
    default=None,
)


@dataclass(frozen=True)
class TenantIdentity:
    """
    Active tenant (and optional company) for data-plane ORM isolation.
    Separate from DB routing alias (infrastructure.database.context).
    """

    tenant_id: int
    company_id: int | None = None


def get_current_tenant() -> TenantIdentity | None:
    return _tenant_identity.get()


def get_current_tenant_id() -> int | None:
    identity = get_current_tenant()
    return identity.tenant_id if identity else None


def require_current_tenant() -> TenantIdentity:
    identity = get_current_tenant()
    if identity is None or not identity.tenant_id:
        raise TenantContextError(
            "Tenant context is required for this operation. "
            "Bind a workspace (API) or use tenant_context(...) "
            "(background tasks)."
        )
    return identity


def set_current_tenant(
    *,
    tenant_id: int,
    company_id: int | None = None,
) -> Token:
    if not tenant_id:
        raise TenantContextError("tenant_id is required.")
    return _tenant_identity.set(
        TenantIdentity(
            tenant_id=int(tenant_id),
            company_id=int(company_id) if company_id else None,
        )
    )


def clear_current_tenant() -> None:
    _tenant_identity.set(None)


def reset_current_tenant(token: Token) -> None:
    _tenant_identity.reset(token)


@contextmanager
def tenant_context(
    tenant_id: int | None = None,
    *,
    company_id: int | None = None,
    tenant_uid: str | None = None,
) -> Iterator[TenantIdentity]:
    """
    Bind tenant identity for the current execution context.

    Prefer tenant_id from a trusted server source. tenant_uid is decoded
    for Celery/background jobs that only carry the encoded public claim.
    """
    resolved_id = tenant_id
    if resolved_id is None and tenant_uid:
        from core.utils.ids import decode_id

        try:
            decoded = decode_id(tenant_uid)
        except (TypeError, ValueError) as exc:
            raise TenantContextError("Invalid tenant_uid.") from exc
        if not isinstance(decoded, int):
            raise TenantContextError("Invalid tenant_uid.")
        resolved_id = decoded

    if resolved_id is None:
        raise TenantContextError(
            "tenant_context requires tenant_id or tenant_uid."
        )

    token = set_current_tenant(
        tenant_id=resolved_id,
        company_id=company_id,
    )
    try:
        yield require_current_tenant()
    finally:
        reset_current_tenant(token)
