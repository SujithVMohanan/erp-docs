# Authentication API

Niyanthra authentication is API-only. All responses use the `ResponseInfo` envelope:

```json
{
  "status": true,
  "status_code": 200,
  "message": "Login successful",
  "data": {},
  "errors": {}
}
```

Failed requests add a stable machine-readable `code` when one exists:

```json
{
  "status": false,
  "status_code": 400,
  "message": "This phone number is already registered.",
  "code": "PHONE_ALREADY_EXISTS",
  "data": {
    "profile_completed": false
  },
  "errors": {
    "phone_number": ["This phone number is already registered."]
  }
}
```

Never parse exception text. Use `code` plus field keys in `errors`.

Public IDs are encoded (`uid` / `public_id`). Raw database integers are never accepted or returned.

---

## Account lifecycle

```
PENDING REGISTRATION  →  COMPLETE PROFILE  →  ACTIVE AUTHENTICATED USER
```

| State | How it is stored | Tokens |
|---|---|---|
| Pending | `is_active=true`, `profile_completed=false`, `deleted_at=null` | Short-lived **registration** access token only. No refresh token. |
| Active | `is_active=true`, `profile_completed=true` | App **access** + **refresh** tokens. |
| Disabled | `is_active=false`, `deleted_at=null` | Cannot authenticate. |
| Soft-deleted | `deleted_at` set, `is_active=false` | Cannot authenticate. Email / phone / Google identity can be reused. |

`profile_completed` is derived on save: both `username` and `phone_number` must be present.

A pending user can call:

- `POST /api/users/complete-profile/`
- `GET /api/users/me/`
- `GET /api/users/registration-status/`
- `POST /api/users/logout/`

A pending user cannot call protected application APIs such as `GET /api/users/get-users/`. Those require an app access token (`token_use=access`) and `profile_completed=true`.

---

## Token architecture

| Token | Claim `token_use` | Lifetime | Refresh | Use |
|---|---|---|---|---|
| Registration | `registration` | 30 minutes | No | Profile completion only |
| Access | `access` | 15 minutes | Yes | Application APIs |
| Refresh | `access` | 30 days, rotated | — | Issues a new access + refresh pair |

Registration tokens are `AccessToken`s. They are **not** stored as outstanding refresh tokens and never grant application access.

App refresh tokens rotate. The previous refresh token is blacklisted after a successful refresh (replay fails).

Logout blacklists:

- refresh token in the database
- access token `jti` in cache until it would have expired

JWT authentication rejects:

- expired tokens
- blacklisted access tokens
- inactive / soft-deleted users

`Authorization: Bearer <token>`

---

## Endpoints

Base path: `/api/users/`

| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | `register/` | Public | Email / password pending registration |
| POST | `login/` | Public | Email / password login |
| POST | `social-login/` | Public | Google ID-token verify |
| POST | `complete-profile/` | Registration or access token | Finish mandatory profile |
| GET | `registration-status/` | Any live token | Missing fields + `profile_completed` |
| GET | `me/` | Any live token | Current user |
| POST | `refresh/` | Public (refresh body) | Rotate app tokens |
| POST | `logout/` | Any live token | Revoke tokens |
| GET | `get-users/` | App token | Paginated users |
| DELETE | `delete-users/` | App token | Soft delete |
| DELETE | `hard-delete-users/` | App token + platform admin | Permanent delete |

---

## 1. Normal registration

`POST /api/users/register/`

Requires only credentials. Does **not** issue app tokens.

Request:

```json
{
  "email": "ada@example.com",
  "password": "ValidPassw0rd!",
  "confirm_password": "ValidPassw0rd!"
}
```

Success `201`:

```json
{
  "status": true,
  "status_code": 201,
  "message": "User registered successfully.",
  "data": {
    "token_type": "Bearer",
    "access": "<registration-token>",
    "profile_completed": false,
    "user": {
      "uid": "...",
      "public_id": "...",
      "username": "",
      "email": "ada@example.com",
      "phone_number": "",
      "profile_completed": false
    }
  },
  "errors": {}
}
```

Duplicate live email `400` / `EMAIL_ALREADY_EXISTS`. Soft-deleted emails do not block registration.

Continue to Complete Profile with the registration token.

---

## 2. Google OAuth

Frontend obtains a Google ID token. The backend verifies it with Google OIDC (`google-auth`) against `GOOGLE_CLIENT_ID`. Frontend email is never trusted.

`POST /api/users/social-login/`

```json
{
  "provider": "google",
  "id_token": "<google-id-token>",
  "nonce": "<optional>"
}
```

Resolution order:

1. Live `UserAuthProvider` row for `provider + subject` (Google `sub`)
2. Else, if Google `email_verified` and a live user has that email: **link** Google to that account
3. Else create a pending social user (`set_unusable_password`, `profile_completed=false`)

Verified-email linking is an explicit security rule: Google has already verified the mailbox. Unverified Google emails are rejected (`GOOGLE_EMAIL_UNVERIFIED`). Accounts are not linked from an unverified email string.

- Existing **active** Google / email account with a completed profile → app access + refresh
- New or incomplete account → registration token only
- Disabled account → `ACCOUNT_DISABLED`
- Soft-deleted Google identity is released so the same Google user can register again

Invalid token: `401` / `INVALID_GOOGLE_TOKEN`.

---

## 3. Complete profile

`POST /api/users/complete-profile/`

Header: `Authorization: Bearer <registration-token>`

Request:

```json
{
  "username": "ada",
  "phone_number": "+15550001111",
  "password": "optional-for-google-users",
  "confirm_password": "optional-for-google-users"
}
```

Mandatory: `username`, `phone_number`. Password is optional (email users already have one; Google users may set one to enable password login later).

Field errors keep the user pending. The frontend can correct the field and resubmit. The registration is not cancelled.

Duplicate phone `400`:

```json
{
  "status": false,
  "status_code": 400,
  "message": "This phone number is already registered.",
  "code": "PHONE_ALREADY_EXISTS",
  "data": {
    "profile_completed": false
  },
  "errors": {
    "phone_number": ["This phone number is already registered."]
  }
}
```

Success `200` — **this is the first time app tokens are issued**:

```json
{
  "status": true,
  "status_code": 200,
  "message": "Login successful",
  "data": {
    "token_type": "Bearer",
    "access": "<app-access-token>",
    "refresh": "<app-refresh-token>",
    "profile_completed": true,
    "user": {
      "uid": "...",
      "public_id": "...",
      "username": "ada",
      "email": "ada@example.com",
      "phone_number": "+15550001111",
      "profile_completed": true
    }
  },
  "errors": {}
}
```

The previous registration token is blacklisted after success. Repeated submit of a completed profile is idempotent and returns a new app session.

---

## 4. Login

`POST /api/users/login/`

```json
{
  "email": "ada@example.com",
  "password": "ValidPassw0rd!"
}
```

| Account | Result |
|---|---|
| Active, profile complete | App access + refresh |
| Pending | Registration token only (`profile_completed: false`) |
| Disabled | `401` / `ACCOUNT_DISABLED` |
| Soft-deleted or wrong password | `401` / `INVALID_CREDENTIALS` |

---

## 5. Registration status and current user

`GET /api/users/registration-status/`

```json
{
  "status": true,
  "status_code": 200,
  "message": "Registration status retrieved.",
  "data": {
    "profile_completed": false,
    "missing_fields": ["username", "phone_number"],
    "user": {}
  },
  "errors": {}
}
```

`GET /api/users/me/` returns the user schema, including `profile_completed`.

---

## 6. Refresh

`POST /api/users/refresh/`

```json
{
  "refresh": "<app-refresh-token>"
}
```

Success returns a new `access` and rotated `refresh`. Registration tokens cannot be refreshed.

Pending / disabled / deleted accounts cannot refresh.

---

## 7. Logout

`POST /api/users/logout/`

Pending sessions may send only `access`. App sessions should send both:

```json
{
  "refresh": "<refresh>",
  "access": "<access>"
}
```

If `access` is omitted, the `Authorization` bearer token is revoked.

---

## 8. Soft delete and uniqueness

Live uniqueness is enforced in PostgreSQL with partial unique indexes (`deleted_at IS NULL`):

- `users_email_alive_uniq`
- `users_phone_alive_uniq`
- `users_username_alive_uniq`
- `uap_provider_subject_alive_uniq` on `(provider, subject)`

Application checks run first; `IntegrityError` is mapped to the same field errors so concurrent requests cannot create duplicates.

Soft delete:

- sets `deleted_at`, `is_active=false`
- soft-deletes Google provider rows
- blacklists outstanding refresh tokens
- does not cascade-create related business data (those apps are added later)

The same email, phone, or Google `sub` can register again as a **new** user.

---

## Error codes

| Code | Typical HTTP | Meaning |
|---|---|---|
| `VALIDATION_ERROR` | 400 | Serializer / generic field errors |
| `EMAIL_ALREADY_EXISTS` | 400 | Live email already registered |
| `PHONE_ALREADY_EXISTS` | 400 | Live phone already registered |
| `USERNAME_ALREADY_TAKEN` | 400 | Live username already taken |
| `INVALID_CREDENTIALS` | 401 | Login failed |
| `ACCOUNT_DISABLED` | 401 | Live but disabled |
| `INVALID_GOOGLE_TOKEN` | 401 | Google ID token failed verification |
| `GOOGLE_EMAIL_UNVERIFIED` | 401 | Google email not verified |
| `GOOGLE_EMAIL_MISSING` | 401 | Google did not return email |
| `GOOGLE_NOT_CONFIGURED` | 401 | Missing `GOOGLE_CLIENT_ID` |
| `UNSUPPORTED_PROVIDER` | 401 | Provider is not Google |
| `INVALID_REFRESH_TOKEN` | 401 | Refresh missing, expired, or replayed |
| `PROFILE_INCOMPLETE` | 403 | Pending user hit an app API |
| `CONFLICT` | 409 | Unmapped unique constraint |

---

## Frontend flow

### Email / password

1. `POST /register/` → store `data.access` as a **registration** token (not an app session)
2. Collect username + phone
3. `POST /complete-profile/` with that token
4. On field error, keep the same token and resubmit
5. On success, replace storage with `access` + `refresh` and treat the user as logged in

### Google

1. Obtain Google ID token on the client
2. `POST /social-login/` with `{ provider: "google", id_token }`
3. If `profile_completed === false`, same as step 2–5 above
4. If `profile_completed === true`, store app `access` + `refresh`

### Authenticated app

- Send `Authorization: Bearer <access>`
- On `401`, try `POST /refresh/` then retry
- On `403` + `PROFILE_INCOMPLETE`, send the user to complete-profile
- On logout, call `POST /logout/` and clear tokens

---

## Security notes

- Passwords hashed with Argon2
- Google identity verified server-side (audience, issuer, signature, expiry)
- Auth endpoints throttled (`auth` scope, 30/min)
- CORS via `CORS_ALLOWED_ORIGINS`
- CSRF applies to cookie/session admin; API auth is Bearer JWT
- Auth logs record event name + `public_id` only — never passwords, tokens, ID tokens, or secrets
- `SECRET_KEY`, `GOOGLE_CLIENT_ID`, and DB credentials come from environment

Set in `.env`:

```
GOOGLE_CLIENT_ID=your-client-id.apps.googleusercontent.com
CORS_ALLOWED_ORIGINS=http://localhost:3000
```
