from django.db.models import Q

from apps.sales.models import Sale


class SaleRepository:

    @staticmethod
    def list_sales(
        *,
        sale_ids=None,
        invoice_number=None,
        customer_name=None,
        sale_date=None,
    ):
        filters = Q()

        if sale_ids:
            ids = (
                sale_ids
                if isinstance(sale_ids, (list, tuple, set))
                else [sale_ids]
            )
            filters &= Q(id__in=ids)

        if invoice_number:
            filters &= Q(invoice_number__icontains=invoice_number)

        if customer_name:
            filters &= Q(customer_name__icontains=customer_name)

        if sale_date:
            filters &= Q(sale_date=sale_date)

        return (
            Sale.objects
            .only(
                "id",
                "public_id",
                "tenant_id",
                "company_id",
                "invoice_number",
                "customer_name",
                "sale_date",
                "subtotal",
                "tax_amount",
                "discount_amount",
                "total_amount",
                "created_at",
                "updated_at",
            )
            .filter(filters)
            .order_by("-sale_date", "-id")
        )

    @staticmethod
    def get_by_id(*, sale_id: int) -> Sale | None:
        return Sale.objects.filter(pk=sale_id).first()

    @staticmethod
    def get_invoice_conflict(
        *,
        invoice_number: str,
        exclude_id: int | None = None,
    ) -> Sale | None:
        query = Sale.objects.filter(invoice_number=invoice_number)
        if exclude_id is not None:
            query = query.exclude(pk=exclude_id)
        return query.only("id").first()

    @staticmethod
    def create_sale(**values) -> Sale:
        return Sale.objects.create(**values)

    @staticmethod
    def update_sale(*, sale: Sale, **values) -> Sale:
        for key, value in values.items():
            setattr(sale, key, value)
        sale.save(update_fields=[*values.keys(), "updated_at"])
        return sale

    @staticmethod
    def soft_delete_by_ids(*, sale_ids: list[int]) -> int:
        if not sale_ids:
            return 0
        count, _ = Sale.objects.filter(id__in=sale_ids).delete()
        return count
