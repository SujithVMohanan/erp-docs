"""Standalone scripts only. Django commands live under apps management."""
