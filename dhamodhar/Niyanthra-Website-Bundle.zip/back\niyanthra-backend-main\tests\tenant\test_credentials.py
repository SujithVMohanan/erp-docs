from unittest.mock import (
    MagicMock,
    patch,
)

from django.test import (
    SimpleTestCase,
    override_settings,
)

from infrastructure.database.credentials import CredentialResolver


_LOCAL_ADMIN = {
    "HOST": "localhost",
    "PORT": "5432",
    "USER": "admin_user",
    "PASSWORD": "admin_pass",
    "NAME": "postgres",
}


@override_settings(
    ENVIRONMENT="local",
    TENANT_DB_ADMIN=_LOCAL_ADMIN,
    TENANT_DB_RUNTIME_USER="runtime_user",
    TENANT_DB_RUNTIME_PASSWORD="runtime_pass",
    TENANT_DB_ADMIN_SECRET_NAME="",
    TENANT_DB_RUNTIME_SECRET_NAME="",
)
class LocalCredentialResolverTests(SimpleTestCase):

    def test_is_not_remote(self):
        self.assertFalse(CredentialResolver.is_remote())

    def test_admin_credentials_from_env(self):
        credentials = CredentialResolver.admin_credentials()
        self.assertEqual(credentials.host, "localhost")
        self.assertEqual(credentials.port, 5432)
        self.assertEqual(credentials.user, "admin_user")
        self.assertEqual(credentials.password, "admin_pass")
        self.assertEqual(credentials.admin_db, "postgres")
        self.assertIsNone(credentials.secret_name)

    def test_runtime_credentials_from_env(self):
        credentials = CredentialResolver.resolve()
        self.assertEqual(credentials.host, "localhost")
        self.assertEqual(credentials.user, "runtime_user")
        self.assertEqual(credentials.password, "runtime_pass")


@override_settings(
    ENVIRONMENT="production",
    TENANT_DB_ADMIN_SECRET_NAME="niyanthra/prod/tenant-db-admin",
    TENANT_DB_RUNTIME_SECRET_NAME="niyanthra/prod/tenant-db-runtime",
    TENANT_DB_ADMIN=_LOCAL_ADMIN,
    TENANT_DB_RUNTIME_USER="ignored",
    TENANT_DB_RUNTIME_PASSWORD="ignored",
)
class RemoteCredentialResolverTests(SimpleTestCase):

    def test_is_remote(self):
        self.assertTrue(CredentialResolver.is_remote())

    @patch("infrastructure.database.credentials.SecretsManagerClient")
    def test_admin_uses_secrets_manager_not_env(self, client_cls):
        client = MagicMock()
        client.get_secret_dict.return_value = {
            "host": "prod-tenant.rds.amazonaws.com",
            "port": 5432,
            "username": "sm_admin",
            "password": "sm_admin_pass",
            "admin_database": "postgres",
        }
        client_cls.return_value = client

        credentials = CredentialResolver.admin_credentials()

        client.get_secret_dict.assert_called_once_with(
            secret_id="niyanthra/prod/tenant-db-admin",
        )
        self.assertEqual(credentials.host, "prod-tenant.rds.amazonaws.com")
        self.assertEqual(credentials.user, "sm_admin")
        self.assertEqual(credentials.password, "sm_admin_pass")
        self.assertNotEqual(credentials.user, "admin_user")

    @patch("infrastructure.database.credentials.SecretsManagerClient")
    def test_runtime_prefers_per_tenant_secret_name(self, client_cls):
        client = MagicMock()
        client.get_secret_dict.return_value = {
            "hostname": "vip.example.com",
            "user": "vip_user",
            "password": "vip_pass",
            "port": "5433",
        }
        client_cls.return_value = client

        credentials = CredentialResolver.resolve(
            secret_name="niyanthra/prod/tenant-vip",
        )

        client.get_secret_dict.assert_called_once_with(
            secret_id="niyanthra/prod/tenant-vip",
        )
        self.assertEqual(credentials.host, "vip.example.com")
        self.assertEqual(credentials.port, 5433)
        self.assertEqual(credentials.user, "vip_user")

    @override_settings(
        ENVIRONMENT="stage",
        TENANT_DB_ADMIN_SECRET_NAME="",
        TENANT_DB_RUNTIME_SECRET_NAME="",
    )
    def test_remote_without_secret_raises(self):
        with self.assertRaises(ValueError) as ctx:
            CredentialResolver.resolve()
        self.assertIn("TENANT_DB", str(ctx.exception))

    @patch("infrastructure.database.credentials.SecretsManagerClient")
    def test_stage_environment_is_remote(self, client_cls):
        with override_settings(
            ENVIRONMENT="stage",
            TENANT_DB_RUNTIME_SECRET_NAME="niyanthra/stage/tenant-db-runtime",
        ):
            client = MagicMock()
            client.get_secret_dict.return_value = {
                "host": "stage-tenant.example.com",
                "username": "stage_user",
                "password": "stage_pass",
            }
            client_cls.return_value = client

            self.assertTrue(CredentialResolver.is_remote())
            credentials = CredentialResolver.resolve()
            self.assertEqual(credentials.host, "stage-tenant.example.com")
