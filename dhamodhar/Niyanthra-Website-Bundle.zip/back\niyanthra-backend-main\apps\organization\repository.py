from django.db.models import (
    BooleanField,
    Case,
    CharField,
    Count,
    IntegerField,
    OuterRef,
    Prefetch,
    Q,
    Subquery,
    Value,
    When,
)
from django.db.models.functions import Coalesce
from django.utils import timezone

from apps.location.models import Country
from apps.organization.models import (
    Industry,
    Organization,
    OrganizationIndustry,
    OrganizationLocation,
    OrganizationMembership,
)


class CountryRepository:
    @staticmethod
    def upsert(
        *,
        public_id,
        code: str,
        name: str,
        iso3: str | None = None,
        phone_code: str | None = None,
        currency_code: str | None = None,
        is_active: bool = True,
    ) -> tuple[Country, bool]:
        country = Country.all_objects.filter(code=code.strip().upper()).first()
        if country is None:
            country = Country(
                public_id=public_id,
                code=code,
                name=name,
                iso3=iso3,
                phone_code=phone_code,
                currency_code=currency_code,
                is_active=is_active,
            )
            country.save()
            return country, True

        country.name = name
        country.iso3 = iso3
        country.phone_code = phone_code
        country.currency_code = currency_code
        country.is_active = is_active
        country.deleted_at = None
        country.save(
            update_fields=[
                "name",
                "iso3",
                "phone_code",
                "currency_code",
                "is_active",
                "deleted_at",
                "updated_at",
            ]
        )
        return country, False

    @staticmethod
    def list_countries(
        *,
        country_id=None,
        code=None,
        name=None,
        is_active=None,
    ):
        filters = Q()

        if country_id:
            ids = country_id if isinstance(country_id, (list, tuple, set)) else [country_id]
            filters &= Q(id__in=ids)

        if code:
            filters &= Q(code=code)

        if name:
            filters &= Q(name__icontains=name)

        if is_active is not None:
            filters &= Q(is_active=is_active)

        return Country.objects.only(
            "id",
            "public_id",
            "name",
            "code",
            "iso3",
            "phone_code",
            "currency_code",
            "is_active",
            "created_at",
            "updated_at",
        ).filter(filters)

    @staticmethod
    def get_by_id(country_id: int) -> Country | None:
        return Country.objects.filter(pk=country_id).first()

    @staticmethod
    def get_active_by_id(country_id: int) -> Country | None:
        return Country.objects.filter(pk=country_id, is_active=True).only("id").first()

    @staticmethod
    def get_code_conflict(*, code: str, exclude_id: int | None = None) -> Country | None:
        query = Country.objects.filter(code=code.strip().upper())
        if exclude_id:
            query = query.exclude(pk=exclude_id)
        return query.first()

    @staticmethod
    def create_country(
        *,
        name: str,
        code: str,
        iso3: str | None = None,
        phone_code: str | None = None,
        currency_code: str | None = None,
    ) -> Country:
        country = Country(
            name          = name,
            code          = code,
            iso3          = iso3,
            phone_code    = phone_code,
            currency_code = currency_code,
            is_active     = True,
        )
        country.save()
        return country

    @staticmethod
    def update_country(
        *,
        country: Country,
        name: str,
        code: str,
        iso3: str | None = None,
        phone_code: str | None = None,
        currency_code: str | None = None,
    ) -> Country:
        country.name          = name
        country.code          = code
        country.iso3          = iso3
        country.phone_code    = phone_code
        country.currency_code = currency_code
        country.save(
            update_fields=[
                "name",
                "code",
                "iso3",
                "phone_code",
                "currency_code",
                "updated_at",
            ]
        )
        return country

    @staticmethod
    def countries_in_use(country_ids: list[int]) -> bool:
        return Organization.all_objects.filter(country_id__in=country_ids).exists()

    @staticmethod
    def soft_delete_by_ids(country_ids: list[int]) -> int:
        count, _ = Country.objects.filter(id__in=country_ids).delete()
        return count

    @staticmethod
    def toggle_active_by_ids(country_ids: list[int]) -> int:
        return Country.objects.filter(id__in=country_ids).update(
            is_active=Case(
                When(is_active=True, then=Value(False)),
                default=Value(True),
                output_field=BooleanField(),
            ),
            updated_at=timezone.now(),
        )


class IndustryRepository:
    @staticmethod
    def upsert(
        *,
        public_id,
        code: str,
        name: str,
        parent: Industry | None = None,
        is_active: bool = True,
    ) -> tuple[Industry, bool]:
        industry = Industry.all_objects.filter(code=code.strip().lower()).first()
        if industry is None:
            industry = Industry(
                public_id=public_id,
                code=code,
                name=name,
                parent=parent,
                is_active=is_active,
            )
            industry.save()
            return industry, True

        industry.name = name
        industry.parent = parent
        industry.is_active = is_active
        industry.deleted_at = None
        industry.save(
            update_fields=[
                "name",
                "parent",
                "is_active",
                "deleted_at",
                "updated_at",
            ]
        )
        return industry, False

    @staticmethod
    def list_industries(
        *,
        industry_id=None,
        code=None,
        name=None,
        is_active=None,
    ):
        filters = Q()

        if industry_id:
            ids = industry_id if isinstance(industry_id, (list, tuple, set)) else [industry_id]
            filters &= Q(id__in=ids)

        if code:
            filters &= Q(code=code)

        if name:
            filters &= Q(name__icontains=name)

        if is_active is not None:
            filters &= Q(is_active=is_active)

        return Industry.objects.only(
            "id",
            "public_id",
            "name",
            "code",
            "is_active",
            "created_at",
            "updated_at",
        ).filter(filters)

    @staticmethod
    def get_by_id(industry_id: int) -> Industry | None:
        return Industry.objects.filter(pk=industry_id).first()

    @staticmethod
    def get_active_ids(industry_ids: list[int]) -> list[int]:
        found = set(
            Industry.objects.filter(id__in=industry_ids, is_active=True).values_list("id", flat=True)
        )
        return [industry_id for industry_id in industry_ids if industry_id in found]

    @staticmethod
    def get_code_conflict(*, code: str, exclude_id: int | None = None) -> Industry | None:
        query = Industry.objects.filter(code=code.strip().lower())
        if exclude_id:
            query = query.exclude(pk=exclude_id)
        return query.first()

    @staticmethod
    def create_industry(*, name: str, code: str) -> Industry:
        industry = Industry(
            name=name, 
            code=code, 
            is_active=True
        )
        industry.save()
        return industry

    @staticmethod
    def update_industry(*, industry: Industry, name: str, code: str) -> Industry:
        industry.name = name
        industry.code = code
        industry.save(update_fields=["name", "code", "updated_at"])
        return industry

    @staticmethod
    def industries_in_use(industry_ids: list[int]) -> bool:
        return OrganizationIndustry.objects.filter(industry_id__in=industry_ids).exists()

    @staticmethod
    def soft_delete_by_ids(industry_ids: list[int]) -> int:
        count, _ = Industry.objects.filter(id__in=industry_ids).delete()
        return count

    @staticmethod
    def toggle_active_by_ids(industry_ids: list[int]) -> int:
        return Industry.objects.filter(id__in=industry_ids).update(
            is_active=Case(
                When(is_active=True, then=Value(False)),
                default=Value(True),
                output_field=BooleanField(),
            ),
            updated_at=timezone.now(),
        )


class OrganizationRepository:
    _list_prefetch = (
        Prefetch(
            "industries",
            queryset=Industry.objects.only("id", "public_id", "name", "code"),
        ),
    )

    @staticmethod
    def _base_queryset():
        return (
            Organization.objects.select_related("country")
            .prefetch_related(*OrganizationRepository._list_prefetch)
            .only(
                "id",
                "public_id",
                "name",
                "code",
                "legal_name",
                "description",
                "logo",
                "email",
                "phone_number",
                "website",
                "timezone",
                "is_active",
                "created_at",
                "updated_at",
                "country_id",
                "country__id",
                "country__public_id",
                "country__name",
                "country__code",
            )
        )

    @staticmethod
    def list_organizations(
        *,
        organization_id=None,
        code=None,
        name=None,
        is_active=None,
        country_id=None,
        industry_id=None,
    ):
        filters = Q()

        if organization_id:
            ids = organization_id if isinstance(organization_id, (list, tuple, set)) else [organization_id]
            filters &= Q(id__in=ids)

        if code:
            filters &= Q(code=code)

        if name:
            filters &= Q(name__icontains=name)

        if is_active is not None:
            filters &= Q(is_active=is_active)

        if country_id:
            filters &= Q(country_id=country_id)

        if industry_id:
            ids = industry_id if isinstance(industry_id, (list, tuple, set)) else [industry_id]
            filters &= Q(industries__id__in=ids)

        queryset = OrganizationRepository._base_queryset().filter(filters)
        if industry_id:
            queryset = queryset.distinct()
        return queryset

    @staticmethod
    def list_directory(*, user, name: str | None = None):
        from apps.company.models import Company

        company_count = (
            Company.objects.filter(
                organization_id=OuterRef("pk"),
                is_active=True,
            )
            .order_by()
            .values("organization_id")
            .annotate(total=Count("id"))
            .values("total")[:1]
        )
        role = OrganizationMembership.objects.filter(
            organization_id=OuterRef("pk"),
            user_id=user.pk,
            is_active=True,
        ).values("role")[:1]

        queryset = Organization.objects.filter(is_active=True)
        if name:
            queryset = queryset.filter(name__icontains=name)
        if user.is_admin:
            directory_role = Value("platform", output_field=CharField())
        else:
            queryset = queryset.filter(
                memberships__user_id=user.pk,
                memberships__is_active=True,
            )
            directory_role = Subquery(role, output_field=CharField())

        return queryset.annotate(
            company_count=Coalesce(
                Subquery(company_count, output_field=IntegerField()),
                Value(0),
            ),
            directory_role=directory_role,
        ).order_by("name")

    @staticmethod
    def superuser_list(*, name: str | None = None):
        filters = Q()
        if name:
            filters &= Q(name__icontains=name)
        return (
            Organization.objects.filter(filters)
            .only("id", "name")
            .order_by("name", "id")
        )

    @staticmethod
    def get_by_id(organization_id: int) -> Organization | None:
        return OrganizationRepository._base_queryset().filter(pk=organization_id).first()

    @staticmethod
    def get_code_conflict(*, code: str, exclude_id: int | None = None) -> Organization | None:
        query = Organization.objects.filter(code=code.strip().upper())
        if exclude_id:
            query = query.exclude(pk=exclude_id)
        return query.first()

    @staticmethod
    def create_organization(
        *,
        name: str,
        code: str | None = None,
        legal_name: str,
        country_id: int,
        created_by_id: int | None = None,
        description: str | None = None,
        logo: str | None = None,
        email: str | None = None,
        phone_number: str | None = None,
        website: str | None = None,
        timezone: str | None = None,
    ) -> Organization:
        organization = Organization(
            name=name,
            code=code,
            legal_name=legal_name,
            description=description,
            logo=logo,
            email=email,
            phone_number=phone_number,
            website=website,
            timezone=timezone,
            country_id=country_id,
            created_by_id=created_by_id,
            is_active=True,
        )
        organization.save()
        return organization

    @staticmethod
    def update_organization(
        *,
        organization: Organization,
        name: str,
        code: str,
        legal_name: str,
        country_id: int,
        description: str | None = None,
        logo: str | None = None,
        email: str | None = None,
        phone_number: str | None = None,
        website: str | None = None,
        timezone: str | None = None,
    ) -> Organization:
        organization.name = name
        organization.code = code
        organization.legal_name = legal_name
        organization.description = description
        organization.logo = logo
        organization.email = email
        organization.phone_number = phone_number
        organization.website = website
        organization.timezone = timezone
        organization.country_id = country_id
        organization.save(
            update_fields=[
                "name",
                "code",
                "legal_name",
                "description",
                "logo",
                "email",
                "phone_number",
                "website",
                "timezone",
                "country",
                "updated_at",
            ]
        )
        return organization

    @staticmethod
    def replace_industries(*, organization: Organization, industry_ids: list[int]) -> None:

        OrganizationIndustry.objects.filter(
                        organization_id=organization.pk
                        ).delete()

        OrganizationIndustry.objects.bulk_create(
            [
                OrganizationIndustry(
                    organization    = organization,
                    industry_id     = industry_id,
                    is_primary      = index == 0,
                )
                for index, industry_id in enumerate(industry_ids)
            ]
        )

    @staticmethod
    def soft_delete_by_ids(organization_ids: list[int]) -> int:
        count, _ = Organization.objects.filter(id__in=organization_ids).delete()
        return count

    @staticmethod
    def toggle_active_by_ids(organization_ids: list[int]) -> int:
        return Organization.objects.filter(id__in=organization_ids).update(
            is_active=Case(
                When(is_active=True, then=Value(False)),
                default=Value(True),
                output_field=BooleanField(),
            ),
            updated_at=timezone.now(),
        )


    
    @staticmethod
    def upsert_membership_scope(*, organization_id: int, user) -> None:

        organization = OrganizationRepository.get_by_id(organization_id)

        OrganizationMembership.objects.update_or_create(
            organization=organization,
            user=user,
        )


class OrganizationMembershipRepository:

    @staticmethod
    def _base_queryset():
        return (
            OrganizationMembership.objects
            .select_related("organization", "user")
            .only(
                "id",
                "public_id",
                "role",
                "is_active",
                "created_at",
                "updated_at",
                "organization_id",
                "organization__id",
                "organization__public_id",
                "organization__name",
                "organization__code",
                "user_id",
                "user__id",
                "user__public_id",
                "user__email",
                "user__username",
            )
        )

    @staticmethod
    def list_memberships(
        *,
        membership_id=None,
        organization_id=None,
        user_id=None,
        role=None,
        roles=None,
        is_active=None,
        email=None,
        name=None,
    ):
        filters = Q()

        if membership_id is not None:
            ids = (
                membership_id
                if isinstance(membership_id, (list, tuple, set))
                else [membership_id]
            )
            filters &= Q(id__in=ids)

        if organization_id is not None:
            filters &= Q(organization_id=organization_id)

        if user_id is not None:
            filters &= Q(user_id=user_id)

        if roles:
            filters &= Q(role__in=[r.strip().lower() for r in roles])
        elif role:
            filters &= Q(role=role.strip().lower())

        if is_active is not None:
            filters &= Q(is_active=is_active)

        if email:
            filters &= Q(user__email__icontains=email.strip())

        if name:
            filters &= Q(user__username__icontains=name.strip())

        return OrganizationMembershipRepository._base_queryset().filter(filters)

    @staticmethod
    def list_my_organizations(*, user_id: int, name: str | None = None):
        filters = Q(
            user_id=user_id,
            is_active=True,
            organization__is_active=True,
            organization__deleted_at__isnull=True,
        )
        if name:
            filters &= Q(organization__name__icontains=name)

        return (
            OrganizationMembership.objects.filter(filters)
            .select_related("organization")
            .only(
                "id",
                "organization_id",
                "organization__id",
                "organization__name",
            )
            .order_by("organization__name", "id")
        )

    @staticmethod
    def count_active_owners(*, organization_id: int) -> int:
        return OrganizationMembership.objects.filter(
            organization_id=organization_id,
            role="owner",
            is_active=True,
        ).count()

    @staticmethod
    def get_by_id(membership_id: int) -> OrganizationMembership | None:
        return (
            OrganizationMembershipRepository
            ._base_queryset()
            .filter(pk=membership_id)
            .first()
        )

    @staticmethod
    def get_conflict(
        *,
        organization_id: int,
        user_id: int,
        exclude_id: int | None = None,
    ) -> OrganizationMembership | None:
        queryset = OrganizationMembership.objects.filter(
            organization_id=organization_id,
            user_id=user_id,
        )
        if exclude_id is not None:
            queryset = queryset.exclude(pk=exclude_id)
        return queryset.first()

    @staticmethod
    def create_membership(
        *,
        organization_id: int,
        user_id: int,
        role: str = "employee",
        is_active: bool = True,
    ) -> OrganizationMembership:
        return OrganizationMembership.objects.create(
            organization_id=organization_id,
            user_id=user_id,
            role=role,
            is_active=is_active,
        )

    @staticmethod
    def update_membership(
        *,
        membership: OrganizationMembership,
        organization_id: int,
        user_id: int,
        role: str,
        is_active: bool,
    ) -> OrganizationMembership:
        membership.organization_id = organization_id
        membership.user_id = user_id
        membership.role = role
        membership.is_active = is_active
        membership.save(
            update_fields=[
                "organization_id",
                "user_id",
                "role",
                "is_active",
                "updated_at",
            ]
        )
        return membership

    @staticmethod
    def soft_delete_by_ids(membership_ids: list[int]) -> int:
        if not membership_ids:
            return 0
        count, _ = OrganizationMembership.objects.filter(
            id__in=membership_ids
        ).delete()
        return count

    @staticmethod
    def toggle_active_by_ids(membership_ids: list[int]) -> int:
        if not membership_ids:
            return 0
        return OrganizationMembership.objects.filter(
            id__in=membership_ids
        ).update(
            is_active=Case(
                When(is_active=True, then=Value(False)),
                default=Value(True),
                output_field=BooleanField(),
            ),
            updated_at=timezone.now(),
        )


class OrganizationLocationRepository:

    @staticmethod
    def _base_queryset():
        return (
            OrganizationLocation.objects
            .select_related(
                "organization",
                "location",
                "location__country",
            )
            .only(
                "id",
                "public_id",
                "location_type",
                "is_primary",
                "created_at",
                "updated_at",
                "organization_id",
                "organization__id",
                "organization__public_id",
                "organization__name",
                "organization__code",
                "location_id",
                "location__id",
                "location__public_id",
                "location__city",
                "location__address_line_1",
                "location__country_id",
                "location__country__code",
            )
        )

    @staticmethod
    def list_links(
        *,
        link_id=None,
        organization_id=None,
        location_id=None,
        is_primary=None,
    ):
        filters = Q()

        if link_id is not None:
            ids = (
                link_id
                if isinstance(link_id, (list, tuple, set))
                else [link_id]
            )
            filters &= Q(id__in=ids)

        if organization_id is not None:
            filters &= Q(organization_id=organization_id)

        if location_id is not None:
            filters &= Q(location_id=location_id)

        if is_primary is not None:
            filters &= Q(is_primary=is_primary)

        return OrganizationLocationRepository._base_queryset().filter(filters)

    @staticmethod
    def get_by_id(link_id: int) -> OrganizationLocation | None:
        return (
            OrganizationLocationRepository
            ._base_queryset()
            .filter(pk=link_id)
            .first()
        )

    @staticmethod
    def get_conflict(
        *,
        organization_id: int,
        location_id: int,
        exclude_id: int | None = None,
    ) -> OrganizationLocation | None:
        queryset = OrganizationLocation.objects.filter(
            organization_id=organization_id,
            location_id=location_id,
        )
        if exclude_id is not None:
            queryset = queryset.exclude(pk=exclude_id)
        return queryset.first()

    @staticmethod
    def clear_primary(*, organization_id: int, exclude_id: int | None = None):
        queryset = OrganizationLocation.objects.filter(
            organization_id=organization_id,
            is_primary=True,
        )
        if exclude_id is not None:
            queryset = queryset.exclude(pk=exclude_id)
        queryset.update(is_primary=False, updated_at=timezone.now())

    @staticmethod
    def create_link(**fields) -> OrganizationLocation:
        return OrganizationLocation.objects.create(**fields)

    @staticmethod
    def update_link(*, link: OrganizationLocation, **fields) -> OrganizationLocation:
        for key, value in fields.items():
            setattr(link, key, value)
        link.save(update_fields=list(fields.keys()) + ["updated_at"])
        return link

    @staticmethod
    def delete_by_ids(link_ids: list[int]) -> int:
        if not link_ids:
            return 0
        count, _ = OrganizationLocation.objects.filter(id__in=link_ids).delete()
        return count
