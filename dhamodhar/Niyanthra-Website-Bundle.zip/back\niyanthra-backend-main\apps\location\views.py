from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated

from apps.location.schemas import (
    GetLocationsApiSchema,
    GetStatesApiSchema,
)
from apps.location.serializers import (
    CreateLocationSerializer,
    CreateStateSerializer,
    GetLocationsQuerySerializer,
    GetStatesQuerySerializer,
    LocationUidsSerializer,
    StateUidsSerializer,
    UpdateLocationSerializer,
    UpdateStateSerializer,
)
from apps.location.services.location_service import LocationService
from apps.location.services.state_service import StateService
from core.pagination import RestPagination
from core.permissions import (
    IsAppAuthenticated,
    IsPlatformAdmin,
)
from core.responses import ResponseInfo
from core.utils.exceptions import ExceptionHandler


class StateBaseApiView:
    response_schema = GetStatesApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class LocationBaseApiView:
    response_schema = GetLocationsApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class GetStatesApiView(StateBaseApiView, generics.ListAPIView):

    serializer_class = GetStatesApiSchema
    query_serializer_class = GetStatesQuerySerializer
    pagination_class = RestPagination
    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]

    @swagger_auto_schema(
        tags=["States"],
        manual_parameters=[
            openapi.Parameter("uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("country_uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("code", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("name", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("is_active", openapi.IN_QUERY, type=openapi.TYPE_BOOLEAN),
        ],
        operation_summary="Get states",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(data=self.request.query_params)
        query.is_valid(raise_exception=True)
        return StateService.get_states(validated_data=query.validated_data)


class CreateStateApiView(StateBaseApiView, generics.CreateAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = CreateStateSerializer

    @swagger_auto_schema(
        request_body=CreateStateSerializer,
        tags=["States"],
        operation_summary="Create state",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            state = StateService.create_state(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.created(
                self.response_schema(state).data,
                message="State created successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateStateApiView(StateBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = UpdateStateSerializer

    @swagger_auto_schema(
        request_body=UpdateStateSerializer,
        tags=["States"],
        operation_summary="Update state",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            state = StateService.update_state(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                self.response_schema(state).data,
                message="State updated successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteStatesApiView(StateBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = StateUidsSerializer

    @swagger_auto_schema(
        request_body=StateUidsSerializer,
        tags=["States"],
        operation_summary="Delete states",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            payload = StateService.delete_states(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                payload,
                message="State(s) deleted successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class InactiveActiveStatesApiView(StateBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = StateUidsSerializer

    @swagger_auto_schema(
        request_body=StateUidsSerializer,
        tags=["States"],
        operation_summary="Toggle state active status",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            states = StateService.toggle_states(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                self.response_schema(states, many=True).data,
                message="State status updated successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class GetLocationsApiView(LocationBaseApiView, generics.ListAPIView):

    serializer_class = GetLocationsApiSchema
    query_serializer_class = GetLocationsQuerySerializer
    pagination_class = RestPagination
    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]

    @swagger_auto_schema(
        tags=["Locations"],
        manual_parameters=[
            openapi.Parameter("uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("country_uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("state_uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("city", openapi.IN_QUERY, type=openapi.TYPE_STRING),
        ],
        operation_summary="Get locations",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(data=self.request.query_params)
        query.is_valid(raise_exception=True)
        return LocationService.get_locations(
            validated_data=query.validated_data
        )


class CreateLocationApiView(LocationBaseApiView, generics.CreateAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = CreateLocationSerializer

    @swagger_auto_schema(
        request_body=CreateLocationSerializer,
        tags=["Locations"],
        operation_summary="Create location",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            location = LocationService.create_location(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.created(
                self.response_schema(location).data,
                message="Location created successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateLocationApiView(LocationBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = UpdateLocationSerializer

    @swagger_auto_schema(
        request_body=UpdateLocationSerializer,
        tags=["Locations"],
        operation_summary="Update location",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            location = LocationService.update_location(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                self.response_schema(location).data,
                message="Location updated successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteLocationsApiView(LocationBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = LocationUidsSerializer

    @swagger_auto_schema(
        request_body=LocationUidsSerializer,
        tags=["Locations"],
        operation_summary="Delete locations",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            payload = LocationService.delete_locations(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                payload,
                message="Location(s) deleted successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)
