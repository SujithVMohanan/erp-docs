import socket

from django.conf import settings


class CronAuthService:

    @staticmethod
    def is_authorized() -> bool:
        if not getattr(settings, "CRON_SERVER_ENABLED", False):
            return False

        expected = (getattr(settings, "CRON_SERVER_HOSTNAME", "") or "").strip()
        if not expected:
            return True

        return socket.gethostname().lower() == expected.lower()
