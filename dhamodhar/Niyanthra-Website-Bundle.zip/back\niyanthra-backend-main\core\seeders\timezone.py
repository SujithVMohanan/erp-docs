from core.seeders.base import run_group

GROUP = "timezone"


def run() -> dict:
    return run_group(GROUP)
