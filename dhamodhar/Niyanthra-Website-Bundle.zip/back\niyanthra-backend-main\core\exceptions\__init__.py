"""API error types and handlers."""

from core.exceptions.messages import get_error_message

__all__ = ["get_error_message"]
