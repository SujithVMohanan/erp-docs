from rest_framework import serializers

from apps.inventory.models import (
    Product,
    StockDocument,
    StockDocumentLine,
    StockLedger,
    StockSummary,
    Warehouse,
)
from core.utils.ids import encode_id


def _empty_none(data: dict) -> dict:
    return {
        key: "" if value is None else value
        for key, value in data.items()
    }


class GetProductsApiSchema(serializers.ModelSerializer):
    uid = serializers.SerializerMethodField()
    tax_rate_uid = serializers.SerializerMethodField()

    class Meta:
        model = Product
        fields = [
            "uid",
            "public_id",
            "sku",
            "name",
            "uom_code",
            "hsn_code",
            "tax_rate_uid",
            "tax_percent",
            "cost_price",
            "selling_price",
            "track_stock",
            "is_active",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_tax_rate_uid(self, instance) -> str:
        if not instance.tax_rate_id:
            return ""

        return encode_id(instance.tax_rate_id)

    def to_representation(self, instance):
        return _empty_none(super().to_representation(instance))


class GetWarehousesApiSchema(serializers.ModelSerializer):
    uid = serializers.SerializerMethodField()
    branch_uid = serializers.SerializerMethodField()

    class Meta:
        model = Warehouse
        fields = [
            "uid",
            "public_id",
            "branch_uid",
            "name",
            "code",
            "status",
            "is_default",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_branch_uid(self, instance) -> str:
        return encode_id(instance.branch_id)

    def to_representation(self, instance):
        return _empty_none(super().to_representation(instance))


class GetStockApiSchema(serializers.ModelSerializer):
    uid = serializers.SerializerMethodField()
    product_uid = serializers.SerializerMethodField()
    sku = serializers.CharField(source="product.sku")
    name = serializers.CharField(source="product.name")
    warehouse_uid = serializers.SerializerMethodField()
    warehouse_name = serializers.CharField(source="warehouse.name")
    branch_uid = serializers.SerializerMethodField()
    cost_price = serializers.DecimalField(
        source="product.cost_price",
        max_digits=18,
        decimal_places=4,
    )
    qty_available = serializers.SerializerMethodField()

    class Meta:
        model = StockSummary
        fields = [
            "uid",
            "product_uid",
            "sku",
            "name",
            "warehouse_uid",
            "warehouse_name",
            "branch_uid",
            "qty_on_hand",
            "qty_reserved",
            "qty_available",
            "cost_price",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_product_uid(self, instance) -> str:
        return encode_id(instance.product_id)

    def get_warehouse_uid(self, instance) -> str:
        return encode_id(instance.warehouse_id)

    def get_branch_uid(self, instance) -> str:
        return encode_id(instance.warehouse.branch_id)

    def get_qty_available(self, instance) -> str:
        return str(instance.qty_on_hand - instance.qty_reserved)


class StockLineSchema(serializers.ModelSerializer):
    product_uid = serializers.SerializerMethodField()
    sku = serializers.CharField(source="product.sku")
    name = serializers.CharField(source="product.name")

    class Meta:
        model = StockDocumentLine
        fields = [
            "product_uid",
            "sku",
            "name",
            "quantity",
            "direction",
            "unit_cost",
        ]
        read_only_fields = fields

    def get_product_uid(self, instance) -> str:
        return encode_id(instance.product_id)


class GetStockDocumentsApiSchema(serializers.ModelSerializer):
    uid = serializers.SerializerMethodField()
    warehouse_uid = serializers.SerializerMethodField()
    to_warehouse_uid = serializers.SerializerMethodField()
    lines = StockLineSchema(many=True)

    class Meta:
        model = StockDocument
        fields = [
            "uid",
            "public_id",
            "doc_type",
            "doc_number",
            "client_ref",
            "doc_date",
            "status",
            "warehouse_uid",
            "to_warehouse_uid",
            "notes",
            "lines",
            "created_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_warehouse_uid(self, instance) -> str:
        return encode_id(instance.warehouse_id)

    def get_to_warehouse_uid(self, instance) -> str:
        if not instance.to_warehouse_id:
            return ""

        return encode_id(instance.to_warehouse_id)

    def to_representation(self, instance):
        return _empty_none(super().to_representation(instance))


class GetStockLedgerApiSchema(serializers.ModelSerializer):
    uid = serializers.SerializerMethodField()
    product_uid = serializers.SerializerMethodField()
    sku = serializers.CharField(source="product.sku")
    warehouse_uid = serializers.SerializerMethodField()
    doc_number = serializers.SerializerMethodField()
    doc_type = serializers.SerializerMethodField()

    class Meta:
        model = StockLedger
        fields = [
            "uid",
            "product_uid",
            "sku",
            "warehouse_uid",
            "doc_number",
            "doc_type",
            "movement",
            "qty_delta",
            "qty_on_hand_after",
            "unit_cost",
            "occurred_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_product_uid(self, instance) -> str:
        return encode_id(instance.product_id)

    def get_warehouse_uid(self, instance) -> str:
        return encode_id(instance.warehouse_id)

    def get_doc_number(self, instance) -> str:
        document = instance.document

        if not document:
            return ""

        return document.doc_number

    def get_doc_type(self, instance) -> str:
        document = instance.document

        if not document:
            return ""

        return document.doc_type
