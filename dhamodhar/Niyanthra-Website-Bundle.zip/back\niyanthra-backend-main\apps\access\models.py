from django.db import models
from django.utils.translation import gettext_lazy as _

from core.database.models import BaseModel

# Create your models here.
    
class Permission(BaseModel):

    codename        = models.CharField(_("Codename"), max_length=100,blank=True,null=True,)
    name            = models.CharField(_("Name"), max_length=150,blank=True,null=True,)
    content_type    = models.CharField(_("Content Type"), max_length=100,db_index=True,)
    label           = models.CharField(_("Label"), max_length=100,blank=True, null=True,)
    sub_label       = models.CharField(_("Sub Label"), max_length=100,blank=True, null=True,)

    class Meta:
        db_table = "permissions"
        indexes = [
            models.Index(
                fields=[
                    "content_type",
                    "codename",
                ],
                name="idx_permission_content",),
        ]

    def __str__(self):
        return f"{self.codename}"



class Role(BaseModel):

    company = models.ForeignKey(
        "company.Company",
        on_delete=models.CASCADE,
        related_name="roles",
    )

    name        = models.CharField(_("Role Name"), max_length=100,blank=True,null=True)
    is_active   = models.BooleanField(default=True,)

    permissions = models.ManyToManyField(
        Permission,
        through="RolePermission",
        related_name="roles",
    )

    class Meta:
        db_table = "roles"
        indexes = [
            models.Index(
                fields=[
                    "company",
                ],
                name="idx_role_company",
            ),
            models.Index(
                fields=[
                    "company",
                    "is_active",
                ],
                name="idx_role_company_active",
            ),
        ]

    def __str__(self):
        return "{}".format(self.name)
    

class RolePermission(BaseModel):

    role = models.ForeignKey(
        Role,
        on_delete=models.CASCADE,
        related_name="role_permissions",
    )

    permission = models.ForeignKey(
        Permission,
        on_delete=models.PROTECT,
        related_name="role_permissions",
    )

    class Meta:
        db_table = "role_permissions"
        constraints = [
            models.UniqueConstraint(
                fields=["role", "permission"],
                name="uq_role_permission",
            ),
        ]

    def __str__(self):
        return f"{self.role} - {self.permission}"
    




class Group(BaseModel):

    company = models.ForeignKey(
        "company.Company",
        on_delete=models.CASCADE,
        related_name="access_groups",
    )

    name        = models.CharField(_("Group Name"), max_length=100,blank=True,null=True)
    is_active   = models.BooleanField(default=True)

    roles = models.ManyToManyField(
        Role,
        through="GroupRole",
        related_name="groups",
    )

    class Meta:
        db_table = "access_groups"
        indexes = [
            models.Index(
                fields=[
                    "company",
                ],
                name="idx_group_company",
            ),
            models.Index(
                fields=[
                    "company",
                    "is_active",
                ],
                name="idx_group_company_active",
            ),
        ]

    def __str__(self):
        return "{}".format(self.name)





class GroupRole(BaseModel):

    group = models.ForeignKey(
        Group,
        on_delete=models.CASCADE,
        related_name="group_roles",
    )

    role = models.ForeignKey(
        Role,
        on_delete=models.CASCADE,
        related_name="group_roles",
    )

    class Meta:
        db_table = "group_roles"
        constraints = [
            models.UniqueConstraint(
                fields=["group", "role"],
                name="uq_group_role",
            ),
        ]

    def __str__(self):
        return f"{self.group} - {self.role}"



class UserGroupAssignment(BaseModel):

    user = models.ForeignKey(
        "users.Users",
        on_delete=models.CASCADE,
        related_name="group_assignments",
    )

    group = models.ForeignKey(
        Group,
        on_delete=models.CASCADE,
        related_name="user_assignments",
    )

    branch = models.ForeignKey(
        "company.Branch",
        on_delete=models.CASCADE,
        related_name="user_group_assignments",
        null=True,
        blank=True,
    )

    is_active = models.BooleanField(default=True)


    class Meta:
        db_table = "user_group_assignments"
        constraints = [
            models.UniqueConstraint(
                fields=[
                    "user",
                    "group",
                    "branch",
                ],
                name="uq_user_group_branch",
                nulls_distinct=False,
            ),
        ]
        indexes = [
            models.Index(
                fields=[
                    "user",
                    "group",
                    "branch",
                ],
                name="idx_user_group_scope",
            ),
        ]


