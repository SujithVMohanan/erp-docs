import logging
import socket

from apps.background.models import (
    BackgroundJob,
    PeriodicTask,
)
from apps.background.repository import BackgroundRepository
from apps.background.services.cron_auth_service import CronAuthService
from apps.background.services.job_executor_service import JobExecutorService

logger = logging.getLogger("niyanthra.background")


class JobDispatcherService:

    @staticmethod
    def dispatch(*, periodic_code: str) -> dict:
        logger.info("dispatch_start code=%s", periodic_code)

        if not CronAuthService.is_authorized():
            logger.info("dispatch_skip reason=cron_unauthorized")
            return {"skipped": True, "reason": "cron_unauthorized"}

        periodic = BackgroundRepository.get_periodic_task_by_code(
            periodic_code
        )

        if periodic is None:
            logger.error("dispatch_skip reason=periodic_missing")
            return {"skipped": True, "reason": "periodic_missing"}

        if not periodic.is_enabled:
            logger.info("dispatch_skip reason=periodic_disabled")
            return {"skipped": True, "reason": "periodic_disabled"}

        if periodic.queue_status == PeriodicTask.QueueStatus.PAUSED:
            logger.info("dispatch_skip reason=queue_paused")
            return {"skipped": True, "reason": "queue_paused"}

        if not BackgroundRepository.try_lock_periodic_task(periodic):
            logger.info("dispatch_skip reason=queue_busy")
            return {"skipped": True, "reason": "queue_busy"}

        claimed_count = 0
        error = None

        try:
            claimed = BackgroundRepository.claim_pending_jobs(
                periodic=periodic,
                job_type=BackgroundJob.JobType.ISOLATED_DB_PROVISION,
                limit=periodic.max_workers,
                worker_hostname=socket.gethostname(),
            )
            claimed_count = len(claimed)
            logger.info(
                "dispatch_claimed count=%s max_workers=%s",
                claimed_count,
                periodic.max_workers,
            )

            JobExecutorService.execute_claimed(
                jobs=claimed,
                periodic=periodic,
            )
            logger.info("dispatch_complete claimed=%s", claimed_count)
        except Exception as exc:
            error = str(exc)
            logger.exception("dispatch_failed error=%s", exc)
            raise
        finally:
            BackgroundRepository.unlock_periodic_task(
                periodic,
                error=error,
            )

        return {
            "skipped": False,
            "claimed": claimed_count,
            "max_workers": periodic.max_workers,
        }
