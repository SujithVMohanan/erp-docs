from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated

from apps.inventory.access import ensure_inventory_enabled
from apps.inventory.schemas import (
    GetProductsApiSchema,
    GetStockApiSchema,
    GetStockDocumentsApiSchema,
    GetStockLedgerApiSchema,
    GetWarehousesApiSchema,
)
from apps.inventory.serializers import (
    AdjustStockSerializer,
    CreateProductSerializer,
    DocumentQuerySerializer,
    ImportInventorySerializer,
    LedgerQuerySerializer,
    ProductQuerySerializer,
    ProductUidsSerializer,
    ReceiveStockSerializer,
    StockQuerySerializer,
    TransferStockSerializer,
    UpdateProductSerializer,
    UpdateWarehouseSerializer,
    WarehouseQuerySerializer,
)
from apps.inventory.services.inventory_import_service import InventoryImportService
from apps.inventory.services.product_service import ProductService
from apps.inventory.services.stock_service import StockService
from apps.inventory.services.warehouse_service import WarehouseService
from apps.inventory.units import UNITS
from core.pagination import RestPagination
from core.permissions import HasMembershipAccess, IsWorkspaceAuthenticated
from core.responses import ResponseInfo
from core.tenant.workspace import workspace_scope_from_request
from core.utils.exceptions import ExceptionHandler


class InventoryBaseApiView:
    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
        IsWorkspaceAuthenticated,
    ]

    def __init__(self, **kwargs):
        self.response_format = ResponseInfo().response
        super().__init__(**kwargs)

    def initial(self, request, *args, **kwargs):
        super().initial(request, *args, **kwargs)

        self.scope = workspace_scope_from_request(request)
        ensure_inventory_enabled(self.scope.company_id)

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class GetUnitsApiView(InventoryBaseApiView, generics.GenericAPIView):

    @swagger_auto_schema(
        tags=["Inventory"],
        operation_summary="Get units",
    )
    def get(self, request, *args, **kwargs):
        try:
            return ResponseInfo.ok(
                [
                    {"code": code, "name": name}
                    for code, name in UNITS
                ],
                message="Data retrieved successfully",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class GetProductsApiView(
    InventoryBaseApiView,
    generics.ListAPIView,
):
    serializer_class = GetProductsApiSchema
    pagination_class = RestPagination

    @swagger_auto_schema(
        tags=["Inventory"],
        operation_summary="Get products",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = ProductQuerySerializer(
            data=self.request.query_params,
        )
        query.is_valid(raise_exception=True)

        return ProductService.list_products(
            scope=self.scope,
            validated_data=query.validated_data,
        )


class CreateProductApiView(
    InventoryBaseApiView,
    generics.CreateAPIView,
):
    serializer_class = CreateProductSerializer

    @swagger_auto_schema(
        request_body=CreateProductSerializer,
        tags=["Inventory"],
        operation_summary="Create product",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors,
                )

            product = ProductService.create_product(
                scope=self.scope,
                validated_data=serializer.validated_data,
            )

            return ResponseInfo.created(
                GetProductsApiSchema(product).data,
                message="Product created successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateProductApiView(
    InventoryBaseApiView,
    generics.UpdateAPIView,
):
    serializer_class = UpdateProductSerializer

    @swagger_auto_schema(
        request_body=UpdateProductSerializer,
        tags=["Inventory"],
        operation_summary="Update product",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors,
                )

            product = ProductService.update_product(
                scope=self.scope,
                validated_data=serializer.validated_data,
            )

            return ResponseInfo.ok(
                GetProductsApiSchema(product).data,
                message="Product updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteProductsApiView(
    InventoryBaseApiView,
    generics.GenericAPIView,
):
    serializer_class = ProductUidsSerializer

    @swagger_auto_schema(
        request_body=ProductUidsSerializer,
        tags=["Inventory"],
        operation_summary="Delete products",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors,
                )

            result = ProductService.delete_products(
                scope=self.scope,
                validated_data=serializer.validated_data,
            )

            return ResponseInfo.ok(
                result,
                message="Product(s) deleted successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class GetWarehousesApiView(
    InventoryBaseApiView,
    generics.ListAPIView,
):
    serializer_class = GetWarehousesApiSchema
    pagination_class = RestPagination

    @swagger_auto_schema(
        tags=["Inventory"],
        operation_summary="Get warehouses",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = WarehouseQuerySerializer(
            data=self.request.query_params,
        )
        query.is_valid(raise_exception=True)

        return WarehouseService.list_warehouses(
            scope=self.scope,
            validated_data=query.validated_data,
        )


class UpdateWarehouseApiView(
    InventoryBaseApiView,
    generics.UpdateAPIView,
):
    serializer_class = UpdateWarehouseSerializer

    @swagger_auto_schema(
        request_body=UpdateWarehouseSerializer,
        tags=["Inventory"],
        operation_summary="Update warehouse",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors,
                )

            warehouse = WarehouseService.rename(
                scope=self.scope,
                validated_data=serializer.validated_data,
            )

            return ResponseInfo.ok(
                GetWarehousesApiSchema(warehouse).data,
                message="Warehouse updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class GetStockApiView(
    InventoryBaseApiView,
    generics.ListAPIView,
):
    serializer_class = GetStockApiSchema
    pagination_class = RestPagination

    @swagger_auto_schema(
        tags=["Inventory"],
        operation_summary="Get stock",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = StockQuerySerializer(
            data=self.request.query_params,
        )
        query.is_valid(raise_exception=True)

        return StockService.list_stock(
            scope=self.scope,
            validated_data=query.validated_data,
        )


class GetStockDocumentsApiView(
    InventoryBaseApiView,
    generics.ListAPIView,
):
    serializer_class = GetStockDocumentsApiSchema
    pagination_class = RestPagination

    @swagger_auto_schema(
        tags=["Inventory"],
        operation_summary="Get stock documents",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = DocumentQuerySerializer(
            data=self.request.query_params,
        )
        query.is_valid(raise_exception=True)

        return StockService.list_documents(
            scope=self.scope,
            validated_data=query.validated_data,
        )


class GetStockLedgerApiView(
    InventoryBaseApiView,
    generics.ListAPIView,
):
    serializer_class = GetStockLedgerApiSchema
    pagination_class = RestPagination

    @swagger_auto_schema(
        tags=["Inventory"],
        operation_summary="Get stock ledger",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = LedgerQuerySerializer(
            data=self.request.query_params,
        )
        query.is_valid(raise_exception=True)

        return StockService.list_ledger(
            scope=self.scope,
            validated_data=query.validated_data,
        )


class _StockWriteApiView(
    InventoryBaseApiView,
    generics.GenericAPIView,
):
    schema = GetStockDocumentsApiSchema
    created_message = "Stock posted successfully."

    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors,
                )

            document = self.perform(
                request,
                serializer.validated_data,
            )

            if getattr(document, "_replayed", False):
                return ResponseInfo.ok(
                    self.schema(document).data,
                    message="Stock document already posted.",
                )

            return ResponseInfo.created(
                self.schema(document).data,
                message=self.created_message,
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def perform(self, request, validated_data):
        raise NotImplementedError


class ReceiveStockApiView(_StockWriteApiView):
    serializer_class = ReceiveStockSerializer
    created_message = "Stock received successfully."

    @swagger_auto_schema(
        request_body=ReceiveStockSerializer,
        tags=["Inventory"],
        operation_summary="Receive stock",
    )
    def perform(self, request, validated_data):
        return StockService.receive(
            scope=self.scope,
            validated_data=validated_data,
        )


class AdjustStockApiView(_StockWriteApiView):
    serializer_class = AdjustStockSerializer
    created_message = "Stock adjusted successfully."

    @swagger_auto_schema(
        request_body=AdjustStockSerializer,
        tags=["Inventory"],
        operation_summary="Adjust stock",
    )
    def perform(self, request, validated_data):
        return StockService.adjust(
            scope=self.scope,
            validated_data=validated_data,
        )


class TransferStockApiView(_StockWriteApiView):
    serializer_class = TransferStockSerializer
    created_message = "Stock transferred successfully."

    @swagger_auto_schema(
        request_body=TransferStockSerializer,
        tags=["Inventory"],
        operation_summary="Transfer stock",
    )
    def perform(self, request, validated_data):
        return StockService.transfer(
            scope=self.scope,
            validated_data=validated_data,
        )


class ImportInventoryApiView(
    InventoryBaseApiView,
    generics.GenericAPIView,
):
    serializer_class = ImportInventorySerializer

    @swagger_auto_schema(
        request_body=ImportInventorySerializer,
        tags=["Inventory"],
        operation_summary="Import inventory from Excel",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors,
                )

            payload = InventoryImportService.import_workbook(
                scope=self.scope,
                uploaded_file=serializer.validated_data["file"],
            )

            return ResponseInfo.ok(
                payload,
                message="Inventory import finished.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)