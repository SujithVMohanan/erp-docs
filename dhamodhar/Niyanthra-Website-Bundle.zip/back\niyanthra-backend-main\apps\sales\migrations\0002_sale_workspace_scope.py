from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("sales", "0001_initial"),
    ]

    operations = [
        migrations.RemoveIndex(
            model_name="sale",
            name="sales_tenant__7341ad_idx",
        ),
        migrations.RemoveIndex(
            model_name="sale",
            name="sales_tenant__47b88b_idx",
        ),
        migrations.RemoveField(
            model_name="sale",
            name="tenant_id",
        ),
        migrations.AddField(
            model_name="sale",
            name="company_id",
            field=models.PositiveBigIntegerField(
                db_index=True,
                default=0,
                verbose_name="company id",
            ),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name="sale",
            name="tenant_id",
            field=models.PositiveBigIntegerField(
                db_index=True,
                default=0,
                verbose_name="tenant id",
            ),
            preserve_default=False,
        ),
        migrations.AddIndex(
            model_name="sale",
            index=models.Index(
                fields=["tenant_id", "company_id", "sale_date"],
                name="sales_tenant__sale_date_idx",
            ),
        ),
        migrations.AddIndex(
            model_name="sale",
            index=models.Index(
                fields=["tenant_id", "company_id", "invoice_number"],
                name="sales_tenant__invoice_idx",
            ),
        ),
        migrations.AddConstraint(
            model_name="sale",
            constraint=models.UniqueConstraint(
                condition=models.Q(("deleted_at__isnull", True)),
                fields=("tenant_id", "company_id", "invoice_number"),
                name="sales_invoice_alive_uniq",
            ),
        ),
        migrations.AlterModelOptions(
            name="sale",
            options={
                "ordering": ("-sale_date", "-id"),
                "verbose_name": "sale",
                "verbose_name_plural": "sales",
            },
        ),
    ]
