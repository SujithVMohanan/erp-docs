from django.core.management.base import BaseCommand

from apps.background.redis import RedisHealth


class Command(BaseCommand):
    help = "Ping Redis (Celery broker) and report health."

    def handle(self, *args, **options):
        result = RedisHealth.ping()
        if result.get("ok"):
            self.stdout.write(self.style.SUCCESS(f"redis_ok: {result}"))
        else:
            self.stdout.write(self.style.WARNING(f"redis_degraded: {result}"))
