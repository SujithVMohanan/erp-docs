from django.test import TestCase, override_settings
from rest_framework.test import APIClient

from apps.company.models import (
    Branch,
    Company,
    CompanyMembership,
)
from apps.location.models import Country
from apps.organization.models import (
    Organization,
    OrganizationMembership,
)
from apps.tenant.models import Tenant
from apps.users.models import Users
from core.utils.ids import (
    decode_id,
    encode_id,
)
from core.utils.tokens import issue_tokens

PASSWORD = "ValidPassw0rd!"


@override_settings(AUTH_THROTTLE_DISABLED=True)
class WorkspaceAccessTests(TestCase):

    def setUp(self):
        self.client = APIClient()
        self.country = Country.objects.create(name="India", code="IN")
        self.admin = self._user(
            email="shell-admin@example.com",
            username="shelladmin",
            phone="+15553000001",
            is_admin=True,
        )
        self.owner = self._user(
            email="shell-owner@example.com",
            username="shellowner",
            phone="+15553000002",
        )
        self.employee = self._user(
            email="shell-employee@example.com",
            username="shellemployee",
            phone="+15553000003",
        )
        self.stranger = self._user(
            email="shell-stranger@example.com",
            username="shellstranger",
            phone="+15553000004",
        )
        self.org_a = Organization.objects.create(
            name="Acme",
            code="ACME",
            country=self.country,
            is_active=True,
        )
        self.org_b = Organization.objects.create(
            name="Other",
            code="OTHR",
            country=self.country,
            is_active=True,
        )
        OrganizationMembership.objects.create(
            organization=self.org_a,
            user=self.owner,
            role=OrganizationMembership.Role.OWNER,
            is_active=True,
        )
        OrganizationMembership.objects.create(
            organization=self.org_a,
            user=self.employee,
            role=OrganizationMembership.Role.EMPLOYEE,
            is_active=True,
        )
        self.tenant = Tenant.objects.create(
            name="Acme Retail",
            slug="acme-retail",
            tenant_type=Tenant.TenantType.SHARED,
            provisioning_status=Tenant.ProvisioningStatus.ACTIVE,
            db_alias="acme_retail_shell",
            is_active=True,
        )
        self.company_a1 = self._company(
            organization=self.org_a,
            name="Acme Retail",
            code="IMP01",
            tenant=self.tenant,
        )
        self.company_a2 = self._company(
            organization=self.org_a,
            name="Acme Wholesale",
            code="IMP02",
        )
        self.company_b = self._company(
            organization=self.org_b,
            name="Other Shop",
            code="IMP03",
        )
        CompanyMembership.objects.create(
            company=self.company_a1,
            user=self.employee,
            role=CompanyMembership.Role.EMPLOYEE,
            is_active=True,
        )
        Branch.objects.create(
            company=self.company_a1,
            name="Kochi",
            code="B1",
            status="ACTIVE",
        )

    def _user(self, *, email, username, phone, is_admin=False, is_superuser=False):
        return Users.objects.create_user(
            email=email,
            password=PASSWORD,
            username=username,
            phone_number=phone,
            is_admin=is_admin,
            is_staff=is_admin or is_superuser,
            is_superuser=is_superuser,
            profile_completed=True,
        )

    def _company(self, *, organization, name, code, tenant=None):
        return Company.objects.create(
            organization=organization,
            name=name,
            code=code,
            is_active=True,
            tenant=tenant,
        )

    def _auth(self, user):
        tokens = issue_tokens(user)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")

    def _directory_ids(self, user, **params):
        self._auth(user)
        response = self.client.get("/api/company/get-my-company/", params)
        self.assertEqual(response.status_code, 200, response.data)
        return {
            decode_id(row["value"])
            for row in response.data["data"]["results"]
        }, response

    def test_platform_admin_directory_includes_every_organization(self):
        ids, response = self._directory_ids(self.admin)
        self.assertEqual(
            ids,
            {self.company_a1.pk, self.company_a2.pk, self.company_b.pk},
        )
        retail = next(
            row for row in response.data["data"]["results"]
            if decode_id(row["value"]) == self.company_a1.pk
        )
        self.assertEqual(retail["role"], "owner")
        self.assertEqual(retail["branch_count"], 1)
        self.assertEqual(retail["tenant"]["status"], "active")
        self.assertTrue(retail["tenant"]["is_ready"])
        self.assertEqual(decode_id(retail["organization"]["value"]), self.org_a.pk)

    def test_organization_owner_sees_only_owned_companies(self):
        ids, _response = self._directory_ids(self.owner)
        self.assertEqual(ids, {self.company_a1.pk, self.company_a2.pk})

        self._auth(self.owner)
        narrowed = self.client.get(
            "/api/company/get-my-company/",
            {"organization_uid": encode_id(self.org_b.pk)},
        )
        self.assertEqual(narrowed.status_code, 200)
        self.assertEqual(narrowed.data["data"]["results"], [])

        switcher = self.client.get("/api/company/get-my-companies/")
        self.assertEqual(switcher.status_code, 200, switcher.data)
        self.assertEqual(switcher.data["data"]["companies"], [])

        self._auth(self.employee)
        member_rows = self.client.get("/api/company/get-my-companies/")
        self.assertEqual(
            {decode_id(row["value"]) for row in member_rows.data["data"]["companies"]},
            {self.company_a1.pk},
        )
        self.assertEqual(member_rows.data["data"]["companies"][0]["label"], "Acme Retail")

    def test_employee_sees_only_company_membership(self):
        ids, response = self._directory_ids(self.employee)
        self.assertEqual(ids, {self.company_a1.pk})
        self.assertEqual(response.data["data"]["results"][0]["role"], "employee")

    def test_user_without_company_membership_gets_empty_directory(self):
        ids, response = self._directory_ids(self.stranger)
        self.assertEqual(ids, set())
        self.assertEqual(response.data["data"]["count"], 0)

    def test_my_organizations_scope(self):
        self._auth(self.admin)
        admin_rows = self.client.get("/api/organization/my-organizations/")
        self.assertEqual(admin_rows.status_code, 200)
        admin_ids = {
            decode_id(row["value"])
            for row in admin_rows.data["data"]["results"]
        }
        self.assertIn(self.org_a.pk, admin_ids)
        self.assertIn(self.org_b.pk, admin_ids)
        acme = next(
            row for row in admin_rows.data["data"]["results"]
            if decode_id(row["value"]) == self.org_a.pk
        )
        self.assertEqual(acme["role"], "platform")
        self.assertEqual(acme["company_count"], 2)

        self._auth(self.owner)
        owner_rows = self.client.get("/api/organization/my-organizations/")
        self.assertEqual(len(owner_rows.data["data"]["results"]), 1)
        self.assertEqual(owner_rows.data["data"]["results"][0]["role"], "owner")
        self.assertEqual(owner_rows.data["data"]["results"][0]["company_count"], 2)
        self.assertEqual(
            decode_id(owner_rows.data["data"]["results"][0]["value"]),
            self.org_a.pk,
        )

    def test_get_my_organization_uses_membership_value_label(self):
        OrganizationMembership.objects.create(
            organization=self.org_b,
            user=self.owner,
            role=OrganizationMembership.Role.ADMIN,
            is_active=True,
        )
        OrganizationMembership.objects.create(
            organization=self.org_b,
            user=self.employee,
            role=OrganizationMembership.Role.EMPLOYEE,
            is_active=False,
        )

        self._auth(self.owner)
        listed = self.client.get("/api/organization/get-my-organization/")
        self.assertEqual(listed.status_code, 200, listed.data)
        self.assertEqual(listed.data["data"]["organizations_count"], 2)
        self.assertEqual(
            {decode_id(row["value"]) for row in listed.data["data"]["organizations"]},
            {self.org_a.pk, self.org_b.pk},
        )
        self.assertEqual(
            {row["label"] for row in listed.data["data"]["organizations"]},
            {"Acme", "Other"},
        )
        self.assertEqual(
            set(listed.data["data"]["organizations"][0].keys()),
            {"value", "label"},
        )

        by_name = self.client.get(
            "/api/organization/get-my-organization/",
            {"name": "Acm"},
        )
        self.assertEqual(by_name.data["data"]["organizations_count"], 1)
        self.assertEqual(by_name.data["data"]["organizations"][0]["label"], "Acme")

        self._auth(self.employee)
        employee_rows = self.client.get("/api/organization/get-my-organization/")
        self.assertEqual(employee_rows.data["data"]["organizations_count"], 1)
        self.assertEqual(employee_rows.data["data"]["organizations"][0]["label"], "Acme")

        self._auth(self.admin)
        admin_rows = self.client.get("/api/organization/get-my-organization/")
        self.assertEqual(admin_rows.status_code, 200, admin_rows.data)
        self.assertEqual(admin_rows.data["data"]["organizations_count"], 0)
        self.assertEqual(admin_rows.data["data"]["organizations"], [])

    def test_superuser_lists_skip_membership_and_active_filter(self):
        inactive_org = Organization.objects.create(
            name="Dormant",
            code="DRM",
            country=self.country,
            is_active=False,
        )
        inactive_company = Company.objects.create(
            organization=inactive_org,
            name="Dormant Co",
            code="DRMCO",
            is_active=False,
        )
        inactive_branch = Branch.objects.create(
            company=inactive_company,
            name="Closed",
            code="CL",
            status="INACTIVE",
        )
        superuser = self._user(
            email="shell-super@example.com",
            username="shellsuper",
            phone="+15553000005",
            is_admin=True,
            is_superuser=True,
        )
        self._auth(superuser)

        organizations = self.client.get("/api/organization/get-my-organization/")
        self.assertEqual(organizations.status_code, 200, organizations.data)
        self.assertIn(
            inactive_org.pk,
            {decode_id(row["value"]) for row in organizations.data["data"]["organizations"]},
        )
        self.assertIn(
            "Dormant",
            {row["label"] for row in organizations.data["data"]["organizations"]},
        )

        companies = self.client.get("/api/company/get-my-companies/")
        self.assertEqual(companies.status_code, 200, companies.data)
        self.assertIn(
            inactive_company.pk,
            {decode_id(row["value"]) for row in companies.data["data"]["companies"]},
        )

        branches = self.client.get("/api/company/get-my-branches/")
        self.assertEqual(branches.status_code, 200, branches.data)
        self.assertIn(
            inactive_branch.pk,
            {decode_id(row["value"]) for row in branches.data["data"]["branches"]},
        )
        self.assertIn(
            "Closed",
            {row["label"] for row in branches.data["data"]["branches"]},
        )

    def test_select_company_requires_membership_for_every_user(self):
        self._auth(self.admin)
        denied_admin = self.client.post(
            "/api/company/select-company/",
            {"company_uid": encode_id(self.company_a1.pk)},
            format="json",
        )
        self.assertEqual(denied_admin.status_code, 403, denied_admin.data)

        self._auth(self.owner)
        denied_owner = self.client.post(
            "/api/company/select-company/",
            {"company_uid": encode_id(self.company_a1.pk)},
            format="json",
        )
        self.assertEqual(denied_owner.status_code, 403, denied_owner.data)

        self._auth(self.employee)
        selected = self.client.post(
            "/api/company/select-company/",
            {"company_uid": encode_id(self.company_a1.pk)},
            format="json",
        )
        self.assertEqual(selected.status_code, 200, selected.data)
        self.assertEqual(selected.data["message"], "Company selected successfully.")
        self.assertIn("access", selected.data["data"])
        self.assertIn("refresh", selected.data["data"])
        self.assertNotIn("company", selected.data["data"])
        self.assertNotIn("user", selected.data["data"])
        self.assertNotIn("branch", selected.data["data"])

        superuser = self._user(
            email="select-super@example.com",
            username="selectsuper",
            phone="+15553000006",
            is_admin=True,
            is_superuser=True,
        )
        self._auth(superuser)
        super_selected = self.client.post(
            "/api/company/select-company/",
            {"company_uid": encode_id(self.company_a1.pk)},
            format="json",
        )
        self.assertEqual(super_selected.status_code, 200, super_selected.data)
        self.assertIn("access", super_selected.data["data"])
        self.assertNotIn("company", super_selected.data["data"])

    def test_owner_can_read_tenant_and_rename_only(self):
        self._auth(self.owner)
        listed = self.client.get(
            "/api/tenant/my-tenant/",
            {"company_uid": encode_id(self.company_a1.pk)},
        )
        self.assertEqual(listed.status_code, 200, listed.data)
        self.assertEqual(listed.data["data"]["name"], "Acme Retail")
        self.assertEqual(listed.data["data"]["status"], "active")
        self.assertNotIn("db_alias", listed.data["data"])

        renamed = self.client.put(
            "/api/tenant/update-tenant/",
            {"uid": encode_id(self.tenant.pk), "name": "Acme Retail West"},
            format="json",
        )
        self.assertEqual(renamed.status_code, 200, renamed.data)
        self.tenant.refresh_from_db()
        self.assertEqual(self.tenant.name, "Acme Retail West")
        self.assertEqual(self.tenant.tenant_type, Tenant.TenantType.SHARED)

        rejected = self.client.put(
            "/api/tenant/update-tenant/",
            {
                "uid": encode_id(self.tenant.pk),
                "tenant_type": Tenant.TenantType.ISOLATED,
            },
            format="json",
        )
        self.assertEqual(rejected.status_code, 400)
        self.tenant.refresh_from_db()
        self.assertEqual(self.tenant.tenant_type, Tenant.TenantType.SHARED)

        self._auth(self.admin)
        admin_view = self.client.get(
            "/api/tenant/my-tenant/",
            {"company_uid": encode_id(self.company_a1.pk)},
        )
        self.assertEqual(admin_view.data["data"]["db_alias"], "acme_retail_shell")

    def test_employee_cannot_read_tenant(self):
        self._auth(self.employee)
        response = self.client.get(
            "/api/tenant/my-tenant/",
            {"company_uid": encode_id(self.company_a1.pk)},
        )
        self.assertEqual(response.status_code, 403)

    def test_login_with_email_and_password_returns_tokens_and_user(self):
        response = self.client.post(
            "/api/users/login/",
            {"email": self.owner.email, "password": PASSWORD},
            format="json",
        )
        self.assertEqual(response.status_code, 200, response.data)
        self.assertTrue(response.data["status"])
        self.assertEqual(response.data["message"], "Login successful")
        self.assertEqual(response.data["errors"], {})
        data = response.data["data"]
        self.assertEqual(data["token_type"], "Bearer")
        self.assertTrue(data["access"])
        self.assertTrue(data["refresh"])
        self.assertEqual(set(data), {"token_type", "access", "refresh", "profile_completed", "user"})
        self.assertIs(data["profile_completed"], data["user"]["profile_completed"])
        self.assertEqual(data["user"]["email"], self.owner.email)
        self.assertTrue(data["user"]["uid"])
        self.assertNotIn("organization_menberships", data["user"])
