"""How email is sent (SMTP/SES). Not email HTML templates."""
