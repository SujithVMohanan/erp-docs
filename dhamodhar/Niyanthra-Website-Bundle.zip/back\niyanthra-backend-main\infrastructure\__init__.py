"""External systems: database hosts, AWS, email, workers. Not ERP screens."""
