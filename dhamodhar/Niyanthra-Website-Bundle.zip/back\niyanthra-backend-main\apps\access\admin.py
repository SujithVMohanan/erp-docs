from django.contrib import admin

from .models import (
	Group,
	GroupRole,
	Permission,
	Role,
	RolePermission,
	UserGroupAssignment,
)


@admin.register(Permission)
class PermissionAdmin(admin.ModelAdmin):
	
	list_display   = ("codename", "name", "content_type", "label", "sub_label")
	search_fields  = ("codename", "name", "content_type", "label", "sub_label")


@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
	
	list_display   = ("name", "company", "is_active", "created_at", "deleted_at")
	list_filter    = ("is_active",)
	search_fields  = ("name", "company__name", "company__code")


@admin.register(RolePermission)
class RolePermissionAdmin(admin.ModelAdmin):
	
	list_display   = ("role", "permission", "created_at")
	search_fields  = ("role__name", "permission__name", "permission__codename")


@admin.register(Group)
class GroupAdmin(admin.ModelAdmin):
	
	list_display   = ("name", "company", "is_active", "created_at", "deleted_at")
	list_filter    = ("is_active",)
	search_fields  = ("name", "company__name", "company__code")


@admin.register(GroupRole)
class GroupRoleAdmin(admin.ModelAdmin):
	
	list_display   = ("group", "role", "created_at")
	search_fields  = ("group__name", "role__name")


@admin.register(UserGroupAssignment)
class UserGroupAssignmentAdmin(admin.ModelAdmin):
	list_display   = ("user", "group", "branch", "is_active", "created_at")
	list_filter    = ("is_active",)
	search_fields  = ("user__email", "user__username", "group__name")
