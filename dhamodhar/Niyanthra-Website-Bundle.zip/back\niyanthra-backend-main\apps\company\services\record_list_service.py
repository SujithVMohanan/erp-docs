from django.db.models import Q
from rest_framework.exceptions import ValidationError

from apps.company.models import CompanyAddress, CompanyTaxRegistration
from core.utils.ids import decode_id


def _decode(uid: str, field: str) -> int:
    try:
        decoded = decode_id(uid)
    except ValueError:
        raise ValidationError({field: ["Invalid id."]})
    if not isinstance(decoded, int):
        raise ValidationError({field: ["Invalid id."]})
    return decoded


class RecordListService:

    @staticmethod
    def list_addresses(*, validated_data: dict):
        company_id = _decode(validated_data["company_uid"], "company_uid")
        filters = Q(company_id=company_id)
        if validated_data.get("uid"):
            filters &= Q(id=_decode(validated_data["uid"], "uid"))
        return (
            CompanyAddress.objects.filter(filters)
            .select_related("company", "country")
            .order_by("-is_primary", "id")
        )

    @staticmethod
    def list_tax_registrations(*, validated_data: dict):
        company_id = _decode(validated_data["company_uid"], "company_uid")
        filters = Q(company_id=company_id)
        if validated_data.get("uid"):
            filters &= Q(id=_decode(validated_data["uid"], "uid"))
        return (
            CompanyTaxRegistration.objects.filter(filters)
            .select_related("company", "country", "tax_type")
            .order_by("-is_primary", "id")
        )
