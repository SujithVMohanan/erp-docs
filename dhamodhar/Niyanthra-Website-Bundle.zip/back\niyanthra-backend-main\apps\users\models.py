from django.contrib.auth.models import (
    AbstractBaseUser,
    BaseUserManager,
    PermissionsMixin,
)
from django.core.exceptions import ValidationError
from django.db import (
    IntegrityError,
    models,
    transaction,
)
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

from core.database import (
    AllObjectsManager,
    BaseModel,
    SoftDeleteQuerySet,
    alive_unique,
)
from core.database.managers import SoftDeleteManager


class UserQuerySet(SoftDeleteQuerySet):
    def delete(self):
        now = timezone.now()
        with transaction.atomic(using=self.db):
            user_ids = list(self.alive().values_list("id", flat=True))
            count = self.alive().update(
                deleted_at=now,
                is_active=False,
                updated_at=now,
            )
            if user_ids:
                UserAuthProvider.objects.filter(user_id__in=user_ids).delete()
        return count, {self.model._meta.label: count}


class UserManager(SoftDeleteManager.from_queryset(UserQuerySet), BaseUserManager):
    use_in_migrations = True

    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError("Email is required.")
        if not password:
            raise ValueError("Password is required.")

        extra_fields.setdefault("is_admin", False)
        extra_fields.setdefault("is_staff", False)
        extra_fields.setdefault("is_superuser", False)
        extra_fields.setdefault("is_active", True)
        extra_fields.setdefault("profile_completed", False)

        using = self._db or "default"
        email = self.normalize_email(email)

        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=using)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        if not password:
            raise ValueError("Superuser must have a password.")
        if not extra_fields.get("username"):
            raise ValueError("Superuser must have a username.")
        if not extra_fields.get("phone_number"):
            raise ValueError("Superuser must have a phone number.")

        extra_fields.setdefault("is_admin", True)
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_active", True)
        extra_fields.setdefault("is_email_verified", True)
        extra_fields.setdefault("profile_completed", True)

        if extra_fields.get("is_admin") is not True:
            raise ValueError("Superuser must have is_admin=True.")
        if extra_fields.get("is_staff") is not True:
            raise ValueError("Superuser must have is_staff=True.")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser=True.")

        return self.create_user(email, password, **extra_fields)

    def create_social_user(self, email, **extra_fields):
        if not email:
            raise ValueError("Email is required.")

        extra_fields.setdefault("is_admin", False)
        extra_fields.setdefault("is_staff", False)
        extra_fields.setdefault("is_superuser", False)
        extra_fields.setdefault("is_active", True)
        extra_fields.setdefault("is_email_verified", True)
        extra_fields.setdefault("profile_completed", False)

        using = self._db or "default"
        email = self.normalize_email(email)
        extra_fields.setdefault("email_verified_at", timezone.now())

        user = self.model(email=email, **extra_fields)
        user.set_unusable_password()
        user.save(using=using)
        return user


class Users(
    BaseModel,
    AbstractBaseUser,
    PermissionsMixin,
):
   
    username            = models.CharField(_("username"), max_length=150, blank=True, null=True)
    email               = models.EmailField(_("email address"),blank=True, null=True)
    phone_number        = models.CharField(_("phone number"), max_length=30, blank=True, null=True)
    profile_image       = models.CharField(_("profile image"), max_length=500, blank=True, null=True)
    is_email_verified   = models.BooleanField(_("is email verified"), default=False)
    is_phone_verified   = models.BooleanField(_("is phone verified"), default=False)
    email_verified_at   = models.DateTimeField(_("email verified at"), blank=True, null=True)
    phone_verified_at   = models.DateTimeField(_("phone verified at"), blank=True, null=True)
    is_admin            = models.BooleanField(_("is admin"), default=False)
    is_staff            = models.BooleanField(_("is staff"), default=False)
    is_active           = models.BooleanField(_("is active"), default=True)
    profile_completed   = models.BooleanField(_("profile completed"), default=False)
    
    invited_by = models.ForeignKey(
        "self",
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name="invited_users",
        help_text="Set only when this account was invited. Self-register stays empty.",
    )

    objects     = UserManager()
    all_objects = AllObjectsManager.from_queryset(UserQuerySet)()

    USERNAME_FIELD    = "email"
    REQUIRED_FIELDS   = ["username", "phone_number"]

    class Meta:
        db_table              = "users"
        verbose_name          = _("user")
        verbose_name_plural   = _("users")
        ordering              = ("-id",)
        default_manager_name  = "objects"
        base_manager_name     = "all_objects"

        constraints = [
            alive_unique(["email"], "users_email_alive_uniq"),
            alive_unique(
                ["username"],
                "users_username_alive_uniq",
                username__isnull=False,
            ),
            alive_unique(
                ["phone_number"],
                "users_phone_alive_uniq",
                phone_number__isnull=False,
            ),
        ]

    def __str__(self) -> str:
        return f"{self.email}"

    def save(self, *args, **kwargs):

        if self.email:
            self.email = UserManager.normalize_email(self.email)

        if self.phone_number == "":
            self.phone_number = None
        if self.username == "":
            self.username = None

        self.is_staff = self.is_admin
        self.profile_completed = bool(
            (self.username or "").strip() and (self.phone_number or "").strip()
        )
        update_fields = kwargs.get("update_fields")
        if update_fields is not None:
            kwargs["update_fields"] = list(
                dict.fromkeys([*update_fields, "profile_completed"])
            )
        super().save(*args, **kwargs)

    def delete(self, using=None, keep_parents=False):
        using   = using or self._state.db or "default"
        now   = timezone.now()
        self.deleted_at = now
        self.is_active = False
        self.save(
            using=using,
            update_fields=["deleted_at", "is_active", "updated_at"],
        )
        UserAuthProvider.objects.filter(user_id=self.pk).delete()

    def restore(self):
        if not self.deleted_at:
            return

        using   = self._state.db or "default"
        manager = type(self).objects.using(using)

        if manager.filter(email=self.email).exclude(pk=self.pk).exists():
            raise ValidationError("Cannot restore: this email is already registered.")
        if self.phone_number and manager.filter(phone_number=self.phone_number).exclude(
            pk=self.pk
        ).exists():
            raise ValidationError("Cannot restore: this phone number is already registered.")
        if self.username and manager.filter(username=self.username).exclude(pk=self.pk).exists():
            raise ValidationError("Cannot restore: this username is already taken.")

        self.deleted_at = None
        self.is_active = True
        try:
            self.save(
                using=using,
                update_fields=["deleted_at", "is_active", "updated_at"],
            )
        except IntegrityError as exc:
            raise ValidationError(
                "Cannot restore: an active user already uses this email or phone number."
            ) from exc


class UserAuthProvider(BaseModel):
    class Provider(models.TextChoices):
        GOOGLE = "google", _("Google")

    user = models.ForeignKey(
        Users,
        on_delete=models.CASCADE,
        related_name="auth_providers",
    )
    provider = models.CharField(_("provider"), max_length=20, choices=Provider.choices)
    subject = models.CharField(_("subject"), max_length=255)
    email = models.EmailField(_("provider email"), blank=True, null=True)

    objects = SoftDeleteManager()
    all_objects = AllObjectsManager()

    class Meta:
        db_table = "user_auth_providers"
        verbose_name = _("user auth provider")
        verbose_name_plural = _("user auth providers")
        ordering = ("-id",)
        constraints = [
            alive_unique(
                ["provider", "subject"],
                "uap_provider_subject_alive_uniq",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.provider}:{self.subject}"













class TimeZone(BaseModel):

    name          = models.CharField(_("name"),max_length=100,unique=True,)
    code          = models.CharField(_("code"),max_length=100,unique=True,)
    utc_offset    = models.CharField(_("UTC offset"),max_length=10,blank=True,null=True,)
    is_active     = models.BooleanField(_("is active"),default=True,)
    
    objects       = SoftDeleteManager()
    all_objects   = AllObjectsManager()

    class Meta:
        db_table              = "time_zones"
        verbose_name          = _("time zone")
        verbose_name_plural   = _("time zones")
        ordering              = ("code",)
        default_manager_name  = "objects"
        base_manager_name     = "all_objects"

    def __str__(self):
        return f"{self.name} ({self.code})"