from django.db import transaction
from django.utils import timezone

from apps.background.models import (
    BackgroundJob,
    PeriodicTask,
)
from apps.tenant.models import Tenant


class BackgroundRepository:

    DISPATCH_ISOLATED_CODE = "dispatch_isolated_jobs"

    @staticmethod
    def get_periodic_task_by_code(code: str) -> PeriodicTask | None:
        return PeriodicTask.objects.filter(code=code).first()

    @staticmethod
    def upsert_periodic_task(
        *,
        public_id,
        code: str,
        name: str,
        task_path: str,
        is_enabled: bool = True,
        interval_seconds: int = 60,
        max_workers: int = 5,
        queue_status: str = PeriodicTask.QueueStatus.IDLE,
        description: str | None = None,
    ) -> tuple[PeriodicTask, bool]:
        row = PeriodicTask.all_objects.filter(code=code).first()
        if row is None:
            row = PeriodicTask(
                public_id=public_id,
                code=code,
                name=name,
                task_path=task_path,
                is_enabled=is_enabled,
                interval_seconds=interval_seconds,
                max_workers=max_workers,
                queue_status=queue_status,
                description=description,
            )
            row.save()
            return row, True

        row.name = name
        row.task_path = task_path
        row.is_enabled = is_enabled
        row.interval_seconds = interval_seconds
        row.max_workers = max_workers
        row.queue_status = queue_status
        row.description = description
        row.deleted_at = None
        row.save(
            update_fields=[
                "name",
                "task_path",
                "is_enabled",
                "interval_seconds",
                "max_workers",
                "queue_status",
                "description",
                "deleted_at",
                "updated_at",
            ]
        )
        return row, False
    @staticmethod
    def get_job_by_id(job_id: int) -> BackgroundJob | None:
        return (
            BackgroundJob.objects
            .select_related("tenant", "periodic_task")
            .filter(pk=job_id)
            .first()
        )

    @staticmethod
    def create_job(
        *,
        periodic_task: PeriodicTask,
        tenant: Tenant,
        job_type: str,
        payload: dict | None = None,
    ) -> BackgroundJob:
        return BackgroundJob.objects.create(
            periodic_task=periodic_task,
            tenant=tenant,
            job_type=job_type,
            status=BackgroundJob.Status.PENDING,
            payload=payload or {},
        )

    @staticmethod
    def try_lock_periodic_task(periodic: PeriodicTask) -> bool:
        updated = PeriodicTask.objects.filter(
            pk=periodic.pk,
            is_enabled=True,
            queue_status=PeriodicTask.QueueStatus.IDLE,
        ).update(
            queue_status=PeriodicTask.QueueStatus.PROCESSING,
            last_run_at=timezone.now(),
            last_error=None,
            updated_at=timezone.now(),
        )
        return updated == 1

    @staticmethod
    def unlock_periodic_task(
        periodic: PeriodicTask,
        *,
        error: str | None = None,
    ) -> None:
        PeriodicTask.objects.filter(pk=periodic.pk).update(
            queue_status=PeriodicTask.QueueStatus.IDLE,
            last_finished_at=timezone.now(),
            last_error=error,
            updated_at=timezone.now(),
        )

    @staticmethod
    def claim_pending_jobs(
        *,
        periodic: PeriodicTask,
        job_type: str,
        limit: int,
        worker_hostname: str,
    ) -> list[BackgroundJob]:
        if limit <= 0:
            return []

        now = timezone.now()
        claimed: list[BackgroundJob] = []

        with transaction.atomic():
            jobs = list(
                BackgroundJob.objects
                .select_for_update(skip_locked=True)
                .select_related("tenant", "periodic_task")
                .filter(
                    periodic_task=periodic,
                    job_type=job_type,
                    status=BackgroundJob.Status.PENDING,
                )
                .order_by("created_at")[:limit]
            )

            for job in jobs:
                job.status = BackgroundJob.Status.STARTED
                job.started_at = now
                job.worker_hostname = worker_hostname
                job.save(
                    update_fields=[
                        "status",
                        "started_at",
                        "worker_hostname",
                        "updated_at",
                    ]
                )
                claimed.append(job)

        return claimed

    @staticmethod
    def mark_job_completed(
        job: BackgroundJob,
        *,
        thread_name: str | None,
    ) -> None:
        BackgroundJob.objects.filter(pk=job.pk).update(
            status=BackgroundJob.Status.COMPLETED,
            completed_at=timezone.now(),
            thread_name=thread_name,
            error_message=None,
            updated_at=timezone.now(),
        )

    @staticmethod
    def mark_job_failed(
        job: BackgroundJob,
        *,
        error: str,
        thread_name: str | None,
    ) -> None:
        BackgroundJob.objects.filter(pk=job.pk).update(
            status=BackgroundJob.Status.FAILED,
            failed_at=timezone.now(),
            error_message=error,
            thread_name=thread_name,
            updated_at=timezone.now(),
        )
