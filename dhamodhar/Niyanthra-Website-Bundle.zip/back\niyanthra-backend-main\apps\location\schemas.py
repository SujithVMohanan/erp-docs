from rest_framework import serializers

from apps.location.models import (
    Location,
    State,
)
from core.utils.ids import encode_id


class GetStatesApiSchema(serializers.ModelSerializer):
    uid     = serializers.SerializerMethodField()
    country = serializers.SerializerMethodField()

    class Meta:
        model = State
        fields = [
            "uid",
            "public_id",
            "name",
            "code",
            "is_active",
            "country",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_country(self, instance) -> dict:
        country = instance.country
        return {
            "uid": encode_id(country.pk),
            "public_id": str(country.public_id),
            "name": country.name or "",
            "code": country.code or "",
        }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data


class GetLocationsApiSchema(serializers.ModelSerializer):
    uid     = serializers.SerializerMethodField()
    country = serializers.SerializerMethodField()
    state   = serializers.SerializerMethodField()

    class Meta:
        model = Location
        fields = [
            "uid",
            "public_id",
            "city",
            "postal_code",
            "address_line_1",
            "address_line_2",
            "latitude",
            "longitude",
            "place_id",
            "formatted_address",
            "country",
            "state",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def get_country(self, instance) -> dict:
        country = instance.country
        return {
            "uid": encode_id(country.pk),
            "public_id": str(country.public_id),
            "name": country.name or "",
            "code": country.code or "",
        }

    def get_state(self, instance) -> dict:
        state = instance.state
        if state is None:
            return {}
        return {
            "uid": encode_id(state.pk),
            "public_id": str(state.public_id),
            "name": state.name or "",
            "code": state.code or "",
        }

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data
