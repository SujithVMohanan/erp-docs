from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.location.repository import (
    LocationRepository,
    StateRepository,
)
from apps.organization.repository import CountryRepository
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class LocationService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})
        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})
        return decoded

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        return list(
            dict.fromkeys(
                LocationService._decode_uid(uid, field="uids")
                for uid in uids
            )
        )

    @staticmethod
    def _resolve_country(uid: str) -> int:
        country_id = LocationService._decode_uid(uid, field="country_uid")
        if CountryRepository.get_by_id(country_id) is None:
            raise AuthValidationError(
                {"country_uid": ["Country not found."]},
                code="COUNTRY_NOT_FOUND",
            )
        return country_id

    @staticmethod
    def _resolve_state(uid: str | None, *, country_id: int) -> int | None:
        if not uid:
            return None
        state_id = LocationService._decode_uid(uid, field="state_uid")
        state = StateRepository.get_by_id(state_id)
        if state is None:
            raise AuthValidationError(
                {"state_uid": ["State not found."]},
                code="STATE_NOT_FOUND",
            )
        if state.country_id != country_id:
            raise AuthValidationError(
                {"state_uid": ["State does not belong to the country."]},
                code="STATE_COUNTRY_MISMATCH",
            )
        return state_id

    @staticmethod
    def get_locations(*, validated_data: dict):
        location_id = None
        country_id = None
        state_id = None

        if validated_data.get("uid"):
            location_id = [
                LocationService._decode_uid(validated_data["uid"])
            ]

        if validated_data.get("country_uid"):
            country_id = LocationService._decode_uid(
                validated_data["country_uid"],
                field="country_uid",
            )

        if validated_data.get("state_uid"):
            state_id = LocationService._decode_uid(
                validated_data["state_uid"],
                field="state_uid",
            )

        return LocationRepository.list_locations(
            location_id=location_id,
            country_id=country_id,
            state_id=state_id,
            city=validated_data.get("city"),
        )

    @staticmethod
    def create_location(*, validated_data: dict):
        country_id = LocationService._resolve_country(
            validated_data["country_uid"]
        )
        state_id = LocationService._resolve_state(
            validated_data.get("state_uid"),
            country_id=country_id,
        )

        location = LocationRepository.create_location(
            country_id=country_id,
            state_id=state_id,
            city=validated_data["city"],
            postal_code=validated_data.get("postal_code") or "",
            address_line_1=validated_data["address_line_1"],
            address_line_2=validated_data.get("address_line_2") or "",
            latitude=validated_data.get("latitude"),
            longitude=validated_data.get("longitude"),
            place_id=validated_data.get("place_id") or "",
            formatted_address=validated_data.get("formatted_address") or "",
        )
        return LocationRepository.get_by_id(location.pk)

    @staticmethod
    def update_location(*, validated_data: dict):
        location = LocationRepository.get_by_id(
            LocationService._decode_uid(validated_data["uid"])
        )
        if location is None:
            raise NotFound("Location not found.")

        country_id = LocationService._resolve_country(
            validated_data["country_uid"]
        )
        state_id = LocationService._resolve_state(
            validated_data.get("state_uid"),
            country_id=country_id,
        )

        LocationRepository.update_location(
            location=location,
            country_id=country_id,
            state_id=state_id,
            city=validated_data["city"],
            postal_code=validated_data.get("postal_code") or "",
            address_line_1=validated_data["address_line_1"],
            address_line_2=validated_data.get("address_line_2") or "",
            latitude=validated_data.get("latitude"),
            longitude=validated_data.get("longitude"),
            place_id=validated_data.get("place_id") or "",
            formatted_address=validated_data.get("formatted_address") or "",
        )
        return LocationRepository.get_by_id(location.pk)

    @staticmethod
    def delete_locations(*, validated_data: dict) -> dict:
        location_ids = LocationService._decode_uids(validated_data["uids"])
        deleted = LocationRepository.delete_by_ids(location_ids)
        if not deleted:
            raise NotFound("Location not found.")
        return {"deleted": deleted}
