import logging

logger = logging.getLogger("niyanthra.auth")


def log_auth_event(event: str, *, public_id: str = "", provider: str = "") -> None:
    logger.info(
        "auth_event=%s public_id=%s provider=%s",
        event,
        public_id or "-",
        provider or "-",
    )
