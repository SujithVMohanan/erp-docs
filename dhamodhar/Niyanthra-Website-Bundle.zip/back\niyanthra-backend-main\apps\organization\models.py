from django.conf import settings
from django.db import models
from django.utils.translation import gettext_lazy as _

from core.database import (
    AllObjectsManager,
    BaseModel,
    SoftDeleteManager,
    alive_unique,
)


class Industry(BaseModel):

    name        = models.CharField(_("name"), max_length=150,blank=True, null=True)
    code        = models.CharField(_("code"), max_length=50, unique=True,blank=True, null=True)
    is_active   = models.BooleanField(_("is active"), default=True)

    parent      = models.ForeignKey(
            "self",
            on_delete=models.PROTECT,
            related_name="children",
            null=True,
            blank=True,
        )

    objects     = SoftDeleteManager()
    all_objects = AllObjectsManager()

    class Meta:
        db_table              = "industries"
        verbose_name          = _("industry")
        verbose_name_plural   = _("industries")
        ordering              = ("name",)
        default_manager_name  = "objects"
        base_manager_name     = "all_objects"
        constraints = [
            alive_unique(["code"], "industries_code_alive_uniq"),
        ]

    def save(self, *args, **kwargs):
        if self.code:
            self.code = self.code.strip().lower()
        super().save(*args, **kwargs)

    def __str__(self) -> str:
        return f"{self.name}-({self.code})"


class Organization(BaseModel):

    name            = models.CharField(_("name"), max_length=150,blank=True, null=True)
    code            = models.CharField(_("code"), max_length=30,blank=True, null=True)
    legal_name      = models.CharField(_("legal name"), max_length=255, blank=True, null=True)
    description     = models.TextField(_("description"), blank=True, null=True)
    logo            = models.CharField(_("logo"), max_length=500, blank=True, null=True)
    email           = models.EmailField(_("email"), blank=True, null=True)
    phone_number    = models.CharField(_("phone number"), max_length=30, blank=True, null=True)
    website         = models.URLField(_("website"), max_length=255, blank=True, null=True)
    timezone        = models.CharField(_("timezone"), max_length=64, blank=True, null=True)
    is_active       = models.BooleanField(_("is active"), default=True)
    country = models.ForeignKey(
        "location.Country",
        on_delete=models.PROTECT,
        related_name="organizations",
        verbose_name=_("country"),
        blank=True,
        null=True,
    )
    industries = models.ManyToManyField(
        Industry,
        through="OrganizationIndustry",
        related_name="organizations",
        verbose_name=_("industries"),
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name="created_organizations",
        verbose_name=_("created by"),
    )

    objects     = SoftDeleteManager()
    all_objects = AllObjectsManager()

    class Meta:
        db_table              = "organizations"
        verbose_name          = _("organization")
        verbose_name_plural   = _("organizations")
        ordering              = ("-id",)
        default_manager_name  = "objects"
        base_manager_name     = "all_objects"
        constraints = [
            alive_unique(["code"], "organizations_code_alive_uniq"),
        ]

    def save(self, *args, **kwargs):
        if self.code:
            self.code = self.code.strip().upper()
        if self.legal_name == "":
            self.legal_name = None
        if self.description == "":
            self.description = None
        if self.logo == "":
            self.logo = None
        if self.email:
            self.email = self.email.strip().lower()
        if self.email == "":
            self.email = None
        if self.phone_number == "":
            self.phone_number = None
        if self.website == "":
            self.website = None
        if self.timezone == "":
            self.timezone = None
        super().save(*args, **kwargs)

    def __str__(self) -> str:
        return f"{self.name}"


class OrganizationIndustry(BaseModel):

    organization = models.ForeignKey(
        Organization,
        on_delete=models.CASCADE,
        related_name="industry_links",
        verbose_name=_("organization"),
    )

    industry = models.ForeignKey(
        Industry,
        on_delete=models.PROTECT,
        related_name="organization_links",
        verbose_name=_("industry"),
    )
    
    is_primary = models.BooleanField(_("is primary"), default=False)

    class Meta:
        db_table              = "organization_industries"
        verbose_name          = _("organization industry")
        verbose_name_plural   = _("organization industries")
        ordering              = ("-is_primary", "id")
        constraints = [
            models.UniqueConstraint(
                fields=["organization", "industry"],
                name="org_industry_uniq",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.organization_id}:{self.industry_id}"






class OrganizationMembership(BaseModel):

    class Role(models.TextChoices):
        OWNER       = "owner", _("Owner")
        ADMIN       = "admin", _("Admin")
        EMPLOYEE    = "employee", _("Employee")

    organization = models.ForeignKey(
        Organization,
        on_delete=models.CASCADE,
        related_name="memberships",
        verbose_name=_("organization"),
    )

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="organization_memberships",
        verbose_name=_("user"),
    )

    role = models.CharField(
        max_length=20,
        choices=Role.choices,
        default=Role.EMPLOYEE,
        verbose_name=_("role"),
    )

    is_active = models.BooleanField(
        default=True,
        verbose_name=_("is active"),
    )

    class Meta:
        db_table = "organization_memberships"
        verbose_name = _("organization membership")
        verbose_name_plural = _("organization memberships")
        ordering = ("-id",)
        constraints = [
            models.UniqueConstraint(
                fields=("organization", "user"),
                name="org_user_uniq",
            ),
        ]
        indexes = [
            models.Index(
                fields=("organization", "is_active"),
                name="org_membership_active_idx",
            ),
            models.Index(
                fields=("user", "is_active"),
                name="user_membership_active_idx",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.organization_id}:{self.user_id}"




class OrganizationLocation(BaseModel):

    organization = models.ForeignKey(
        Organization,
        on_delete=models.CASCADE,
        related_name="locations",
    )

    location = models.ForeignKey(
        "location.Location",
        on_delete=models.PROTECT,
        related_name="organization_links",
    )

    location_type = models.CharField(
        _("location type"),
        max_length=30,
        default="PRIMARY",
    )

    is_primary = models.BooleanField(_("is primary"),default=False,)

    class Meta:
        db_table              = "organization_locations"
        verbose_name          = _("organization location")
        verbose_name_plural   = _("organization locations")
        ordering              = ("-is_primary", "id")

        constraints = [
            models.UniqueConstraint(
                fields=("organization", "location"),
                name="uq_organization_location",
            ),
            models.UniqueConstraint(
                fields=("organization",),
                condition=models.Q(is_primary=True),
                name="uq_organization_primary_location",
            ),
        ]

        indexes = [
            models.Index(
                fields=("organization", "is_primary"),
                name="org_location_primary_idx",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.organization} - {self.location}"