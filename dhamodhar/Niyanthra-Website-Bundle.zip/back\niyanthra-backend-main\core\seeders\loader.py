import json
from datetime import date
from pathlib import Path

from django.core.exceptions import ValidationError

from apps.access.repository import PermissionRepository
from apps.background.repository import BackgroundRepository
from apps.company.catalog_repository import (
    BusinessTypeRepository,
    CompanyTypeRepository,
    ModuleRepository,
    TaxComponentRepository,
    TaxRateComponentRepository,
    TaxRateRepository,
    TaxTypeRepository,
)
from apps.company.models import (
    TaxComponent,
    TaxRate,
    TaxType,
)
from apps.location.models import Country
from apps.location.repository import StateRepository
from apps.organization.models import Industry
from apps.organization.repository import (
    CountryRepository,
    IndustryRepository,
)
from apps.users.repository import TimeZoneRepository
from core.seeders.registry import (
    INITIAL_FIXTURES,
    SEED_GROUPS,
    fixture_path,
)


def _read_fixture(stem: str) -> list[dict]:
    path = Path(fixture_path(stem))
    if not path.is_file():
        raise ValidationError(f"Fixture not found: {path}")
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def _counts(created: int, updated: int) -> dict:
    return {
        "created": created,
        "updated": updated,
        "total": created + updated,
    }


def _parse_date(value):
    if value in (None, ""):
        return None
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value))


def _fixture_code_by_pk(stem: str) -> dict[int, str]:
    return {
        row["pk"]: row["fields"]["code"]
        for row in _read_fixture(stem)
    }


def _seed_countries(rows: list[dict]) -> dict:
    created = 0
    updated = 0
    for row in rows:
        fields = row["fields"]
        _, was_created = CountryRepository.upsert(
            public_id=fields["public_id"],
            code=fields["code"],
            name=fields["name"],
            iso3=fields.get("iso3"),
            phone_code=fields.get("phone_code"),
            currency_code=fields.get("currency_code"),
            is_active=fields.get("is_active", True),
        )
        if was_created:
            created += 1
        else:
            updated += 1
    return _counts(created, updated)


def _seed_states(rows: list[dict]) -> dict:
    country_code_by_fixture_pk = _fixture_code_by_pk("001_countries")
    country_by_code = {
        country.code: country
        for country in Country.all_objects.only("id", "code")
    }
    created = 0
    updated = 0
    for row in rows:
        fields = row["fields"]
        country_code = country_code_by_fixture_pk.get(fields["country"])
        country = country_by_code.get(country_code) if country_code else None
        if country is None:
            raise ValidationError(
                f"Country for fixture pk={fields['country']} missing. "
                "Seed countries first."
            )
        _, was_created = StateRepository.upsert(
            public_id=fields["public_id"],
            country=country,
            code=fields["code"],
            name=fields["name"],
            is_active=fields.get("is_active", True),
        )
        if was_created:
            created += 1
        else:
            updated += 1
    return _counts(created, updated)


def _seed_industries(rows: list[dict]) -> dict:
    industry_by_pk: dict[int, Industry] = {}
    created = 0
    updated = 0
    for row in rows:
        fields = row["fields"]
        parent = None
        parent_pk = fields.get("parent")
        if parent_pk is not None:
            parent = industry_by_pk.get(parent_pk)
            if parent is None:
                raise ValidationError(
                    f"Industry parent pk={parent_pk} missing. "
                    "Parents must appear before children in the fixture."
                )
        industry, was_created = IndustryRepository.upsert(
            public_id=fields["public_id"],
            code=fields["code"],
            name=fields["name"],
            parent=parent,
            is_active=fields.get("is_active", True),
        )
        industry_by_pk[row["pk"]] = industry
        if was_created:
            created += 1
        else:
            updated += 1
    return _counts(created, updated)


def _seed_company_types(rows: list[dict]) -> dict:
    created = 0
    updated = 0
    for row in rows:
        fields = row["fields"]
        _, was_created = CompanyTypeRepository.upsert(
            public_id=fields["public_id"],
            code=fields["code"],
            name=fields["name"],
            is_active=fields.get("is_active", True),
        )
        if was_created:
            created += 1
        else:
            updated += 1
    return _counts(created, updated)


def _seed_business_types(rows: list[dict]) -> dict:
    created = 0
    updated = 0
    for row in rows:
        fields = row["fields"]
        _, was_created = BusinessTypeRepository.upsert(
            public_id=fields["public_id"],
            code=fields["code"],
            name=fields["name"],
            is_active=fields.get("is_active", True),
        )
        if was_created:
            created += 1
        else:
            updated += 1
    return _counts(created, updated)


def _seed_tax_types(rows: list[dict]) -> dict:
    created = 0
    updated = 0
    for row in rows:
        fields = row["fields"]
        _, was_created = TaxTypeRepository.upsert(
            public_id=fields["public_id"],
            code=fields["code"],
            name=fields["name"],
        )
        if was_created:
            created += 1
        else:
            updated += 1
    return _counts(created, updated)


def _seed_tax_components(rows: list[dict]) -> dict:
    tax_type_code_by_pk = _fixture_code_by_pk("006_tax_types")
    tax_type_by_code = {
        row.code: row
        for row in TaxType.all_objects.only("id", "code")
    }
    created = 0
    updated = 0
    for row in rows:
        fields = row["fields"]
        tax_type_code = tax_type_code_by_pk.get(fields["tax_type"])
        tax_type = tax_type_by_code.get(tax_type_code) if tax_type_code else None
        if tax_type is None:
            raise ValidationError(
                f"TaxType for fixture pk={fields['tax_type']} missing. "
                "Seed tax types first."
            )
        _, was_created = TaxComponentRepository.upsert(
            public_id=fields["public_id"],
            tax_type=tax_type,
            code=fields["code"],
            name=fields["name"],
            component_type=fields.get("component_type"),
        )
        if was_created:
            created += 1
        else:
            updated += 1
    return _counts(created, updated)


def _seed_tax_rates(rows: list[dict]) -> dict:
    tax_type_code_by_pk = _fixture_code_by_pk("006_tax_types")
    tax_type_by_code = {
        row.code: row
        for row in TaxType.all_objects.only("id", "code")
    }
    created = 0
    updated = 0
    for row in rows:
        fields = row["fields"]
        tax_type_code = tax_type_code_by_pk.get(fields["tax_type"])
        tax_type = tax_type_by_code.get(tax_type_code) if tax_type_code else None
        if tax_type is None:
            raise ValidationError(
                f"TaxType for fixture pk={fields['tax_type']} missing. "
                "Seed tax types first."
            )
        _, was_created = TaxRateRepository.upsert(
            public_id=fields["public_id"],
            tax_type=tax_type,
            code=fields["code"],
            name=fields["name"],
            rate=fields.get("rate"),
            rate_type=fields.get("rate_type", "PERCENTAGE"),
            effective_from=_parse_date(fields.get("effective_from")),
            effective_to=_parse_date(fields.get("effective_to")),
        )
        if was_created:
            created += 1
        else:
            updated += 1
    return _counts(created, updated)


def _seed_tax_rate_components(rows: list[dict]) -> dict:
    rate_code_by_pk = _fixture_code_by_pk("008_tax_rates")
    component_code_by_pk = {
        row["pk"]: row["fields"]["code"]
        for row in _read_fixture("007_tax_components")
    }
    rate_by_code = {
        row.code: row
        for row in TaxRate.all_objects.only("id", "code")
    }
    component_by_code = {
        row.code: row
        for row in TaxComponent.all_objects.only("id", "code")
    }
    created = 0
    updated = 0
    for row in rows:
        fields = row["fields"]
        rate_code = rate_code_by_pk.get(fields["tax_rate"])
        component_code = component_code_by_pk.get(fields["tax_component"])
        tax_rate = rate_by_code.get(rate_code) if rate_code else None
        tax_component = (
            component_by_code.get(component_code) if component_code else None
        )
        if tax_rate is None or tax_component is None:
            raise ValidationError(
                "Tax rate/component missing for rate_component fixture. "
                "Seed tax rates and components first."
            )
        _, was_created = TaxRateComponentRepository.upsert(
            public_id=fields["public_id"],
            tax_rate=tax_rate,
            tax_component=tax_component,
            rate=fields["rate"],
        )
        if was_created:
            created += 1
        else:
            updated += 1
    return _counts(created, updated)


def _seed_timezones(rows: list[dict]) -> dict:
    created = 0
    updated = 0
    for row in rows:
        fields = row["fields"]
        _, was_created = TimeZoneRepository.upsert(
            public_id=fields["public_id"],
            code=fields["code"],
            name=fields["name"],
            utc_offset=fields.get("utc_offset"),
            is_active=fields.get("is_active", True),
        )
        if was_created:
            created += 1
        else:
            updated += 1
    return _counts(created, updated)


def _seed_permissions(rows: list[dict]) -> dict:
    created = 0
    updated = 0
    for row in rows:
        fields = row["fields"]
        _, was_created = PermissionRepository.upsert(
            public_id=fields["public_id"],
            codename=fields["codename"],
            name=fields["name"],
            content_type=fields["content_type"],
            label=fields.get("label"),
            sub_label=fields.get("sub_label"),
        )
        if was_created:
            created += 1
        else:
            updated += 1
    return _counts(created, updated)


def _seed_modules(rows: list[dict]) -> dict:
    created = 0
    updated = 0
    for row in rows:
        fields = row["fields"]
        _, was_created = ModuleRepository.upsert(
            public_id=fields["public_id"],
            code=fields["code"],
            name=fields["name"],
            is_active=fields.get("is_active", True),
        )
        if was_created:
            created += 1
        else:
            updated += 1
    return _counts(created, updated)


def _seed_periodic_tasks(rows: list[dict]) -> dict:
    created = 0
    updated = 0
    for row in rows:
        fields = row["fields"]
        _, was_created = BackgroundRepository.upsert_periodic_task(
            public_id=fields["public_id"],
            code=fields["code"],
            name=fields["name"],
            task_path=fields["task_path"],
            is_enabled=fields.get("is_enabled", True),
            interval_seconds=fields.get("interval_seconds", 60),
            max_workers=fields.get("max_workers", 5),
            queue_status=fields.get("queue_status", "idle"),
            description=fields.get("description"),
        )
        if was_created:
            created += 1
        else:
            updated += 1
    return _counts(created, updated)


_HANDLERS = {
    "001_countries": _seed_countries,
    "002_indian_states": _seed_states,
    "003_industries": _seed_industries,
    "004_company_types": _seed_company_types,
    "005_business_types": _seed_business_types,
    "006_tax_types": _seed_tax_types,
    "007_tax_components": _seed_tax_components,
    "008_tax_rates": _seed_tax_rates,
    "009_tax_rate_components": _seed_tax_rate_components,
    "010_timezones": _seed_timezones,
    "011_permissions": _seed_permissions,
    "012_periodic_tasks": _seed_periodic_tasks,
    "013_modules": _seed_modules,
}


def load_fixture(stem: str) -> dict:
    handler = _HANDLERS.get(stem)
    if handler is None:
        raise ValidationError(f"No seeder handler for fixture '{stem}'.")
    return handler(_read_fixture(stem))


def load_group(group: str) -> dict:
    stems = SEED_GROUPS.get(group)
    if not stems:
        raise ValidationError(
            f"Unknown seed group '{group}'. "
            f"Valid: {', '.join(sorted(SEED_GROUPS))}."
        )
    totals = {"created": 0, "updated": 0, "total": 0, "fixtures": {}}
    for stem in stems:
        result = load_fixture(stem)
        totals["fixtures"][stem] = result
        totals["created"] += result["created"]
        totals["updated"] += result["updated"]
        totals["total"] += result["total"]
    return totals


def load_all(*, only: list[str] | None = None) -> dict:
    stems = only or list(INITIAL_FIXTURES)
    unknown = [stem for stem in stems if stem not in _HANDLERS]
    if unknown:
        raise ValidationError(
            f"Unknown fixture(s): {', '.join(unknown)}. "
            f"Valid: {', '.join(INITIAL_FIXTURES)}."
        )
    totals = {"created": 0, "updated": 0, "total": 0, "fixtures": {}}
    for stem in stems:
        result = load_fixture(stem)
        totals["fixtures"][stem] = result
        totals["created"] += result["created"]
        totals["updated"] += result["updated"]
        totals["total"] += result["total"]
    return totals
