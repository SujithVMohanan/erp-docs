from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated

from core.permissions import HasOrganizationPermission
from apps.company.schemas import GetAddressesApiSchema, GetTaxRegistrationsApiSchema
from apps.company.serializer import CompanyScopedListQuerySerializer
from apps.company.services.record_list_service import RecordListService
from apps.company.views import BranchBaseApiView
from core.pagination.page import RestPagination


class GetAddressesApiView(BranchBaseApiView, generics.ListAPIView):
    serializer_class = GetAddressesApiSchema
    query_serializer_class = CompanyScopedListQuerySerializer
    pagination_class = RestPagination
    permission_classes = [IsAuthenticated, HasOrganizationPermission]
    organization_target = "company"
    organization_uid_source = "query"
    organization_uid_field = "company_uid"

    @swagger_auto_schema(tags=["Addresses"], operation_summary="Get company addresses")
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(data=self.request.query_params)
        query.is_valid(raise_exception=True)
        return RecordListService.list_addresses(validated_data=query.validated_data)


class GetTaxRegistrationsApiView(BranchBaseApiView, generics.ListAPIView):
    serializer_class = GetTaxRegistrationsApiSchema
    query_serializer_class = CompanyScopedListQuerySerializer
    pagination_class = RestPagination
    permission_classes = [IsAuthenticated, HasOrganizationPermission]
    organization_target = "company"
    organization_uid_source = "query"
    organization_uid_field = "company_uid"

    @swagger_auto_schema(tags=["Tax"], operation_summary="Get company tax registrations")
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(data=self.request.query_params)
        query.is_valid(raise_exception=True)
        return RecordListService.list_tax_registrations(validated_data=query.validated_data)
