from django.db.models import (
    BooleanField,
    Case,
    Q,
    Value,
    When,
)
from django.utils import timezone

from apps.tenant.models import (
    Tenant,
    TenantDatabase,
)


class TenantRepository:

    @staticmethod
    def _base_queryset():
        return Tenant.objects.all()

    @staticmethod
    def list_tenants(
        *,
        tenant_ids=None,
        slug=None,
        name=None,
        tenant_type=None,
        db_alias=None,
        is_active=None,
        provisioning_status=None,
    ):
        filters = Q()

        if tenant_ids:
            ids = (
                tenant_ids
                if isinstance(tenant_ids, (list, tuple, set))
                else [tenant_ids]
            )
            filters &= Q(id__in=ids)

        if slug:
            filters &= Q(slug=slug)

        if name:
            filters &= Q(name__icontains=name)

        if tenant_type:
            filters &= Q(tenant_type=tenant_type)

        if db_alias:
            filters &= Q(db_alias=db_alias)

        if is_active is not None:
            filters &= Q(is_active=is_active)

        if provisioning_status:
            filters &= Q(provisioning_status=provisioning_status)

        return (
            TenantRepository
            ._base_queryset()
            .only(
                "id",
                "public_id",
                "name",
                "slug",
                "tenant_type",
                "provisioning_status",
                "db_alias",
                "celery_queue",
                "is_active",
                "provisioned_at",
                "last_provision_error",
                "created_at",
                "updated_at",
                "deleted_at",
            )
            .filter(filters)
        )

    @staticmethod
    def get_by_id(tenant_id: int) -> Tenant | None:
        return (
            TenantRepository
            ._base_queryset()
            .filter(pk=tenant_id)
            .first()
        )

    @staticmethod
    def get_by_slug(slug: str) -> Tenant | None:
        return (
            TenantRepository
            ._base_queryset()
            .filter(slug=slug)
            .first()
        )

    @staticmethod
    def get_by_db_alias(db_alias: str) -> Tenant | None:
        return (
            TenantRepository
            ._base_queryset()
            .filter(db_alias=db_alias)
            .first()
        )

    @staticmethod
    def get_unique_conflict(
        *,
        slug: str,
        db_alias: str,
        exclude_id: int | None = None,
    ):
        filters = Q(slug=slug) | Q(db_alias=db_alias)
        queryset = Tenant.objects.filter(filters)

        if exclude_id:
            queryset = queryset.exclude(pk=exclude_id)

        return queryset.first()

    @staticmethod
    def create_tenant(
        *,
        name: str,
        slug: str,
        tenant_type: str,
        db_alias: str,
        celery_queue: str,
        provisioning_status: str,
        is_active: bool = True,
    ) -> Tenant:
        return Tenant.objects.create(
            name=name,
            slug=slug,
            tenant_type=tenant_type,
            db_alias=db_alias,
            celery_queue=celery_queue,
            provisioning_status=provisioning_status,
            is_active=is_active,
            provisioned_at=(
                timezone.now()
                if provisioning_status == Tenant.ProvisioningStatus.ACTIVE
                else None
            ),
        )

    @staticmethod
    def create_tenant_database(
        *,
        tenant: Tenant,
        db_alias: str,
        period: str | None = None,
        db_name: str | None = None,
        host: str | None = None,
        port: int | None = None,
        secret_arn: str | None = None,
        secret_name: str | None = None,
        provisioning_status: str = TenantDatabase.ProvisioningStatus.PENDING,
        is_current: bool = True,
    ) -> TenantDatabase:
        return TenantDatabase.objects.create(
            tenant=tenant,
            period=period,
            db_alias=db_alias,
            db_name=db_name,
            host=host,
            port=port,
            secret_arn=secret_arn,
            secret_name=secret_name,
            provisioning_status=provisioning_status,
            is_current=is_current,
            is_active=True,
        )

    @staticmethod
    def set_provisioning_status(
        *,
        tenant: Tenant,
        status: str,
        error: str | None = None,
    ) -> Tenant:
        tenant.provisioning_status = status
        tenant.last_provision_error = error

        update_fields = [
            "provisioning_status",
            "last_provision_error",
            "updated_at",
        ]

        if status == Tenant.ProvisioningStatus.ACTIVE:
            tenant.provisioned_at = timezone.now()
            update_fields.append("provisioned_at")

        tenant.save(update_fields=update_fields)
        return tenant

    @staticmethod
    def get_current_database(tenant: Tenant) -> TenantDatabase | None:
        return (
            TenantDatabase.objects
            .filter(tenant=tenant, is_current=True)
            .first()
        )

    @staticmethod
    def set_current_database_status(
        *,
        tenant: Tenant,
        status: str,
        error: str | None = None,
    ) -> int:
        return TenantDatabase.objects.filter(
            tenant=tenant,
            is_current=True,
        ).update(
            provisioning_status=status,
            last_error=error,
            updated_at=timezone.now(),
        )

    @staticmethod
    def update_current_database_connection(
        *,
        tenant: Tenant,
        db_name: str,
        host: str,
        port: int,
        status: str,
    ) -> int:
        return TenantDatabase.objects.filter(
            tenant=tenant,
            is_current=True,
        ).update(
            db_name=db_name,
            host=host,
            port=port,
            provisioning_status=status,
            last_error=None,
            updated_at=timezone.now(),
        )

    @staticmethod
    def update_current_database_secrets(
        *,
        tenant: Tenant,
        secret_arn: str | None,
        secret_name: str | None,
    ) -> int:
        return TenantDatabase.objects.filter(
            tenant=tenant,
            is_current=True,
        ).update(
            secret_arn=secret_arn,
            secret_name=secret_name,
            updated_at=timezone.now(),
        )

    @staticmethod
    def update_tenant(
        *,
        tenant: Tenant,
        name: str,
        slug: str,
        tenant_type: str,
        db_alias: str,
        celery_queue: str,
    ) -> Tenant:
        tenant.name = name
        tenant.slug = slug
        tenant.tenant_type = tenant_type
        tenant.db_alias = db_alias
        tenant.celery_queue = celery_queue

        tenant.save(
            update_fields=[
                "name",
                "slug",
                "tenant_type",
                "db_alias",
                "celery_queue",
                "updated_at",
            ]
        )

        return tenant

    @staticmethod
    def delete_by_ids(tenant_ids: list[int]) -> int:
        count, _ = Tenant.objects.filter(id__in=tenant_ids).delete()
        return count

    @staticmethod
    def toggle_active_by_ids(tenant_ids: list[int]) -> int:
        return Tenant.objects.filter(id__in=tenant_ids).update(
            is_active=Case(
                When(is_active=True, then=Value(False)),
                default=Value(True),
                output_field=BooleanField(),
            ),
            updated_at=timezone.now(),
        )
