"""
Local development settings.
"""

from .base import *


ENVIRONMENT = "local"

DEBUG = env_bool("DEBUG", True)


# -----------------------------------------------------------------------------
# Hosts
# -----------------------------------------------------------------------------

ALLOWED_HOSTS = env_list(
    "ALLOWED_HOSTS",
    "localhost,127.0.0.1",
)


# -----------------------------------------------------------------------------
# Database
# -----------------------------------------------------------------------------

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": env("CONTROL_DB_NAME", "niyanthra_master"),
        "USER": env("CONTROL_DB_USER", "postgres"),
        "PASSWORD": env("CONTROL_DB_PASSWORD"),
        "HOST": env("CONTROL_DB_HOST", "localhost"),
        "PORT": env("CONTROL_DB_PORT", "5432"),
        "CONN_MAX_AGE": env_int(
            "CONTROL_DB_CONN_MAX_AGE",
            60,
        ),
        "CONN_HEALTH_CHECKS": True,
    },
}

DATABASES[SHARED_DB_ALIAS] = shared_database_config()


# -----------------------------------------------------------------------------
# Security
# -----------------------------------------------------------------------------

SECURE_SSL_REDIRECT = False

SESSION_COOKIE_SECURE = False

CSRF_COOKIE_SECURE = False

SECURE_HSTS_SECONDS = 0

SECURE_CONTENT_TYPE_NOSNIFF = False


# -----------------------------------------------------------------------------
# CORS
# -----------------------------------------------------------------------------

CORS_ALLOWED_ORIGINS = env_list(
    "CORS_ALLOWED_ORIGINS",
    "http://localhost:3000,http://127.0.0.1:3000",
)


# -----------------------------------------------------------------------------
# CSRF
# -----------------------------------------------------------------------------

CSRF_TRUSTED_ORIGINS = env_list(
    "CSRF_TRUSTED_ORIGINS",
    "http://localhost:3000,http://127.0.0.1:3000",
)


# -----------------------------------------------------------------------------
# Cache
# -----------------------------------------------------------------------------

CACHES = {
    "default": {
        "BACKEND": resolve_cache_backend("locmem"),
        "LOCATION": env("CACHE_LOCATION", "niyanthra-local"),
    },
}


# -----------------------------------------------------------------------------
# Email
# -----------------------------------------------------------------------------

EMAIL_BACKEND = resolve_email_backend("console")


# -----------------------------------------------------------------------------
# Logging
# -----------------------------------------------------------------------------

LOG_LEVEL = env("LOG_LEVEL", "DEBUG")

LOGGING["loggers"]["niyanthra"]["level"] = LOG_LEVEL
LOGGING["loggers"]["niyanthra.auth"]["level"] = LOG_LEVEL