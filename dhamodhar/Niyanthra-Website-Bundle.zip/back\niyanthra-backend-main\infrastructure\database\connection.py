from django.conf import settings
from django.db import connections

from infrastructure.database.credentials import DatabaseCredentials


class ConnectionRegistry:

    @staticmethod
    def build_config(
        *,
        db_name: str,
        credentials: DatabaseCredentials,
    ) -> dict:
        return {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": db_name,
            "USER": credentials.user,
            "PASSWORD": credentials.password,
            "HOST": credentials.host,
            "PORT": str(credentials.port),
            "CONN_MAX_AGE": 60,
            "CONN_HEALTH_CHECKS": True,
            "ATOMIC_REQUESTS": False,
            "AUTOCOMMIT": True,
            "OPTIONS": {},
            "TIME_ZONE": settings.TIME_ZONE,
        }

    @staticmethod
    def register(
        *,
        alias: str,
        db_name: str,
        credentials: DatabaseCredentials,
    ) -> dict:
        config = ConnectionRegistry.build_config(
            db_name=db_name,
            credentials=credentials,
        )
        connections.databases[alias] = config

        if alias in connections:
            connections[alias].close()

        return config
