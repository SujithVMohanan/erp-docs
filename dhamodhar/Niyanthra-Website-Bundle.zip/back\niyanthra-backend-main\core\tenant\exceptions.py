class TenantContextError(RuntimeError):
    """Raised when a tenant-aware ORM operation runs without a valid tenant context."""
