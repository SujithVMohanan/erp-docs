/**
 * Company workspace — list + Details | Branches.
 * Existing company/branch fields only. No full-page remount on select.
 */
(function () {
  "use strict";

  const COMPANIES_KEY = "niyanthra_companies_v1";
  const SPLIT_KEY = "niyanthra_split_pct";
  const DEFAULT_SPLIT = 50;

  const CHOICES = {
    companyType: ["Private Limited", "LLP", "Partnership", "Sole Proprietorship"],
    businessType: ["Product", "Service", "Hybrid"],
    businessModel: ["B2B", "B2C", "B2B2C"],
    industry: ["Manufacturing", "Retail", "Hospitality", "Trading", "IT Services"],
    branchType: ["Head office", "Retail", "Warehouse", "Plant", "Mixed"],
    modules: ["Finance", "Inventory", "HR", "CRM", "Sales", "Manufacturing", "Projects"],
    financial: ["April–March, INR", "January–December, USD", "January–December, AED"],
    localization: ["India / English", "UAE / English", "US / English"],
    tax: ["Enable GST", "Skip for now", "GST", "VAT", "None"],
    status: ["Active", "Inactive"],
  };

  function seedCompanies() {
    return [
      {
        id: "bakery",
        name: "ABC Bakery Pvt Ltd",
        status: "Active",
        companyType: "Private Limited",
        businessType: "Product",
        industry: "Retail",
        businessModel: "B2C",
        profile: "Fresh bakery products across Kerala.",
        modules: ["Finance", "Inventory", "Sales"],
        financial: "April–March, INR",
        localization: "India / English",
        tax: "Enable GST",
        branches: [
          { id: "bt", name: "Thrissur", location: "Thrissur", type: "Head office", status: "Active" },
          { id: "bk", name: "Kochi", location: "Kochi", type: "Retail", status: "Active" },
        ],
      },
      {
        id: "retail",
        name: "ABC Retail Pvt Ltd",
        status: "Active",
        companyType: "Private Limited",
        businessType: "Product",
        industry: "Trading",
        businessModel: "B2B2C",
        profile: "Grocery and staples.",
        modules: ["Finance", "Inventory", "CRM", "Sales"],
        financial: "April–March, INR",
        localization: "India / English",
        tax: "Enable GST",
        branches: [
          { id: "rt", name: "Thrissur", location: "Thrissur", type: "Retail", status: "Active" },
          { id: "rb", name: "Bangalore", location: "Bangalore", type: "Warehouse", status: "Active" },
        ],
      },
    ];
  }

  function loadCompanies() {
    try {
      const raw = localStorage.getItem(COMPANIES_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    const seed = seedCompanies();
    localStorage.setItem(COMPANIES_KEY, JSON.stringify(seed));
    return seed;
  }

  function saveCompanies(list) {
    localStorage.setItem(COMPANIES_KEY, JSON.stringify(list));
  }

  const state = {
    companies: loadCompanies(),
    selectedId: null,
    filter: "",
    dirty: false,
    editingCompany: false,
    branchView: "list", // list | add | edit
    editingBranchId: null,
    showDetails: true,
    showBranches: true,
    mobileTab: "details",
    splitPct: Number(localStorage.getItem(SPLIT_KEY)) || DEFAULT_SPLIT,
  };

  const st = UI.setupState();
  if (!st.companyReady) {
    /* Prototype convenience: seed completed Profile + Organization so gallery can open workspace */
    UI.saveSetup({
      fullName: st.data.fullName || "John",
      email: st.data.email || sessionStorage.getItem("niyanthraEmail") || "john@abc.example",
      orgName: st.data.orgName || "ABC Group",
    });
  }
  UI.renderSetupProgress("company");

  const $ = (id) => document.getElementById(id);
  const rail = $("company-rail");
  const listEl = $("company-list");
  const duo = $("panel-duo");
  const resizer = $("resizer");

  function selected() {
    return state.companies.find((c) => c.id === state.selectedId) || null;
  }

  function warnIfDirty(next) {
    if (!state.dirty) {
      next();
      return;
    }
    UI.confirmDiscard(() => {
      state.dirty = false;
      state.editingCompany = false;
      state.branchView = "list";
      state.editingBranchId = null;
      next();
    });
  }

  function applySplit() {
    const pct = Math.min(60, Math.max(40, state.splitPct));
    state.splitPct = pct;
    duo.style.setProperty("--split-pct", pct + "%");
    resizer.setAttribute("aria-valuenow", String(Math.round(pct)));
    localStorage.setItem(SPLIT_KEY, String(pct));
  }

  function updatePanelVisibility() {
    const details = $("panel-details");
    const branches = $("panel-branches");
    const mobile = window.matchMedia("(max-width: 860px)").matches;

    if (!state.showDetails && !state.showBranches) state.showBranches = true;

    $("toggle-details").setAttribute("aria-pressed", String(state.showDetails));
    $("toggle-branches").setAttribute("aria-pressed", String(state.showBranches));
    $("toggle-details").disabled = state.showDetails && !state.showBranches;
    $("toggle-branches").disabled = state.showBranches && !state.showDetails;

    if (mobile) {
      details.hidden = false;
      branches.hidden = false;
      resizer.hidden = true;
      details.classList.toggle("is-mobile-hidden", state.mobileTab !== "details");
      branches.classList.toggle("is-mobile-hidden", state.mobileTab !== "branches");
      duo.classList.remove("details-only", "branches-only");
      $("tab-details").setAttribute("aria-selected", String(state.mobileTab === "details"));
      $("tab-branches").setAttribute("aria-selected", String(state.mobileTab === "branches"));
      return;
    }

    details.classList.remove("is-mobile-hidden");
    branches.classList.remove("is-mobile-hidden");
    details.hidden = !state.showDetails;
    branches.hidden = !state.showBranches;
    resizer.hidden = !(state.showDetails && state.showBranches);
    duo.classList.toggle("details-only", state.showDetails && !state.showBranches);
    duo.classList.toggle("branches-only", !state.showDetails && state.showBranches);
    if (state.showDetails && state.showBranches) applySplit();
    else {
      duo.style.removeProperty("--split-pct");
    }
  }

  function filteredCompanies() {
    const q = state.filter.trim().toLowerCase();
    if (!q) return state.companies;
    return state.companies.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        (c.industry || "").toLowerCase().includes(q) ||
        (c.status || "").toLowerCase().includes(q)
    );
  }

  function renderList() {
    const items = filteredCompanies();
    listEl.innerHTML = "";
    if (!state.companies.length) {
      listEl.innerHTML =
        '<li><div class="empty-state" style="min-height:8rem;padding:1rem"><p>No companies yet.</p><button type="button" class="btn btn-primary" id="empty-add-co">Add company</button></div></li>';
      const btn = document.getElementById("empty-add-co");
      if (btn) btn.onclick = () => $("add-company").click();
      return;
    }
    if (!items.length) {
      listEl.innerHTML =
        '<li><div class="empty-state" style="min-height:8rem;padding:1rem"><p>No search results.</p><button type="button" class="btn btn-secondary" id="clear-search">Clear filter</button></div></li>';
      document.getElementById("clear-search").onclick = () => {
        $("company-search").value = "";
        state.filter = "";
        renderList();
      };
      return;
    }
    items.forEach((c) => {
      const li = document.createElement("li");
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "company-item";
      btn.setAttribute("role", "option");
      btn.setAttribute("aria-current", c.id === state.selectedId ? "true" : "false");
      const branchCount = (c.branches || []).length;
      btn.innerHTML =
        '<span class="company-item-name"></span><span class="company-item-meta"><span></span><span class="tag ' +
        (c.status === "Active" ? "tag-ok" : "tag-warn") +
        '"></span></span>';
      btn.querySelector(".company-item-name").textContent = c.name;
      btn.querySelector(".company-item-meta span").textContent =
        branchCount + " branch" + (branchCount === 1 ? "" : "es");
      btn.querySelector(".tag").textContent = c.status || "Active";
      btn.addEventListener("click", () => selectCompany(c.id));
      li.appendChild(btn);
      listEl.appendChild(li);
    });
  }

  function selectCompany(id) {
    warnIfDirty(() => {
      state.selectedId = id;
      state.editingCompany = false;
      state.branchView = "list";
      state.editingBranchId = null;
      renderList();
      renderWorkspace();
      if (window.matchMedia("(max-width: 860px)").matches) closeRail();
    });
  }

  function optionList(values, selected) {
    return values
      .map((v) => '<option value="' + v + '"' + (v === selected ? " selected" : "") + ">" + v + "</option>")
      .join("");
  }

  function defItem(label, value, span) {
    const empty = !value;
    return (
      '<div class="def-item' +
      (span ? " def-span" : "") +
      '"><span class="def-label">' +
      label +
      '</span><div class="def-value' +
      (empty ? " is-empty" : "") +
      '">' +
      (empty ? "Not set" : escapeHtml(String(value))) +
      "</div></div>"
    );
  }

  function sectionHead(title, desc) {
    return (
      '<div class="form-section-head"><h2 class="form-section-title">' +
      title +
      "</h2>" +
      (desc ? '<p class="form-section-desc">' + desc + "</p>" : "") +
      "</div>"
    );
  }

  function renderDetails() {
    const body = $("details-body");
    const foot = $("details-foot");
    const editBtn = $("edit-company");
    const co = selected();
    if (!co) {
      editBtn.hidden = true;
      foot.hidden = true;
      body.innerHTML =
        '<div class="empty-state"><p>Select a company from the list, or add your first company.</p><button type="button" class="btn btn-primary" id="empty-pick-add">Add company</button></div>';
      const b = document.getElementById("empty-pick-add");
      if (b) b.onclick = () => $("add-company").click();
      return;
    }
    editBtn.hidden = state.editingCompany;
    if (!state.editingCompany) {
      foot.hidden = true;
      body.innerHTML =
        '<section class="form-section">' +
        sectionHead("Identity", "Legal name and registration style for this company.") +
        '<div class="def-grid">' +
        defItem("Company name", co.name, true) +
        defItem("Company type", co.companyType) +
        defItem("Status", co.status) +
        "</div></section>" +
        '<section class="form-section">' +
        sectionHead("Business", "How this company sells and which industry it operates in.") +
        '<div class="def-grid">' +
        defItem("Business type", co.businessType) +
        defItem("Industry", co.industry) +
        defItem("Business model", co.businessModel) +
        defItem("Tax", co.tax) +
        defItem("Business profile", co.profile, true) +
        "</div></section>" +
        '<section class="form-section">' +
        sectionHead("Modules & locale", "Enabled modules and financial defaults.") +
        '<div class="def-grid">' +
        defItem("Modules", (co.modules || []).join(", "), true) +
        defItem("Financial year & currency", co.financial) +
        defItem("Country / language", co.localization) +
        "</div></section>";
      return;
    }

    foot.hidden = false;
    foot.innerHTML =
      '<div class="form-actions pinned" style="border:0;margin:0">' +
      '<span class="form-actions-meta" id="co-dirty-meta"></span>' +
      '<button type="button" class="btn btn-secondary" id="cancel-company">Cancel</button>' +
      '<button type="button" class="btn btn-primary" id="save-company">Save</button></div>';

    body.innerHTML =
      '<form id="company-form" novalidate>' +
      '<div class="form-summary" hidden></div>' +
      '<section class="form-section">' +
      sectionHead("Identity", "Update the name staff see in the company list.") +
      '<div class="form-stack">' +
      '<div class="field"><label class="field-label" for="co-name">Company name</label>' +
      '<input class="field-control" id="co-name" required value="' +
      escapeAttr(co.name) +
      '" placeholder="Company legal name" />' +
      '<p class="field-hint">Shown in navigation and documents.</p>' +
      '<p class="field-error" data-default="Enter company name."></p></div>' +
      '<div class="field-row"><div class="field"><label class="field-label" for="co-type">Company type</label><select class="field-control" id="co-type">' +
      optionList(CHOICES.companyType, co.companyType) +
      '</select></div><div class="field"><label class="field-label" for="co-status">Status</label>' +
      '<div class="segmented" role="radiogroup" aria-label="Status">' +
      '<label><input type="radio" name="co-status-seg" value="Active"' +
      (co.status !== "Inactive" ? " checked" : "") +
      ' /><span>Active</span></label>' +
      '<label><input type="radio" name="co-status-seg" value="Inactive"' +
      (co.status === "Inactive" ? " checked" : "") +
      ' /><span>Inactive</span></label></div>' +
      '<select class="field-control sr-only" id="co-status" tabindex="-1" aria-hidden="true">' +
      optionList(CHOICES.status, co.status || "Active") +
      "</select></div></div></div></section>" +
      '<section class="form-section">' +
      sectionHead("Business", "Existing company profile fields — regrouped for scanning.") +
      '<div class="form-stack">' +
      '<div class="field-row"><div class="field"><label class="field-label" for="co-btype">Business type</label><select class="field-control" id="co-btype">' +
      optionList(CHOICES.businessType, co.businessType) +
      '</select></div><div class="field"><label class="field-label" for="co-industry">Industry</label><select class="field-control" id="co-industry">' +
      optionList(CHOICES.industry, co.industry) +
      "</select></div></div>" +
      '<div class="field-row"><div class="field"><label class="field-label" for="co-model">Business model</label><select class="field-control" id="co-model">' +
      optionList(CHOICES.businessModel, co.businessModel) +
      '</select></div><div class="field"><label class="field-label" for="co-tax">Tax</label><select class="field-control" id="co-tax">' +
      optionList(CHOICES.tax, co.tax) +
      "</select></div></div>" +
      '<div class="field"><label class="field-label" for="co-profile">Business profile</label>' +
      '<textarea class="field-control" id="co-profile" placeholder="Short description of what this company does">' +
      escapeHtml(co.profile || "") +
      '</textarea><p class="field-hint">Optional context for your team.</p></div></div></section>' +
      '<section class="form-section">' +
      sectionHead("Modules & locale", "Modules list and financial defaults for this company.") +
      '<div class="form-stack">' +
      '<div class="field"><label class="field-label" for="co-modules">Modules</label>' +
      '<input class="field-control" id="co-modules" value="' +
      escapeAttr((co.modules || []).join(", ")) +
      '" placeholder="Finance, Inventory, Sales" />' +
      '<p class="field-hint">Comma-separated: Finance, Inventory, HR, CRM, Sales, Manufacturing, Projects</p></div>' +
      '<div class="field-row"><div class="field"><label class="field-label" for="co-fin">Financial year &amp; currency</label><select class="field-control" id="co-fin">' +
      optionList(CHOICES.financial, co.financial) +
      '</select></div><div class="field"><label class="field-label" for="co-loc">Country / language</label><select class="field-control" id="co-loc">' +
      optionList(CHOICES.localization, co.localization) +
      "</select></div></div></div></section></form>";

    const dirtyMeta = document.getElementById("co-dirty-meta");
    const markDirty = () => {
      state.dirty = true;
      UI.markDirtyBar(dirtyMeta, true);
    };
    body.querySelectorAll("input, select, textarea").forEach((el) => {
      el.addEventListener("input", markDirty);
      el.addEventListener("change", markDirty);
    });
    body.querySelectorAll('input[name="co-status-seg"]').forEach((radio) => {
      radio.addEventListener("change", () => {
        if (radio.checked) {
          document.getElementById("co-status").value = radio.value;
          markDirty();
        }
      });
    });

    $("cancel-company").onclick = () => {
      warnIfDirty(() => {
        state.editingCompany = false;
        state.dirty = false;
        renderDetails();
      });
    };
    $("save-company").onclick = () => {
      const nameField = document.getElementById("co-name").closest(".field");
      if (!UI.validateField(nameField)) {
        document.getElementById("co-name").focus();
        const summary = body.querySelector(".form-summary");
        if (summary) {
          summary.hidden = false;
          summary.className = "form-summary is-visible banner banner-error";
          summary.innerHTML = "<strong>Fix 1 field</strong> — company name is required.";
        }
        return;
      }
      const btn = $("save-company");
      UI.setButtonLoading(btn, true);
      setTimeout(() => {
        co.name = document.getElementById("co-name").value.trim();
        co.companyType = document.getElementById("co-type").value;
        co.status = document.getElementById("co-status").value;
        co.businessType = document.getElementById("co-btype").value;
        co.industry = document.getElementById("co-industry").value;
        co.businessModel = document.getElementById("co-model").value;
        co.tax = document.getElementById("co-tax").value;
        co.profile = document.getElementById("co-profile").value.trim();
        co.modules = document
          .getElementById("co-modules")
          .value.split(",")
          .map((s) => s.trim())
          .filter(Boolean);
        co.financial = document.getElementById("co-fin").value;
        co.localization = document.getElementById("co-loc").value;
        saveCompanies(state.companies);
        state.dirty = false;
        state.editingCompany = false;
        UI.setButtonLoading(btn, false, "Save");
        UI.toast("Company saved");
        renderList();
        renderWorkspace();
      }, 650);
    };
  }

  function renderBranches() {
    const body = $("branches-body");
    const co = selected();
    $("add-branch").hidden = !co || state.branchView !== "list";

    if (!co) {
      body.innerHTML = '<div class="empty-state"><p>Select a company to manage branches.</p></div>';
      return;
    }

    if (state.branchView === "add" || state.branchView === "edit") {
      const br =
        state.branchView === "edit"
          ? (co.branches || []).find((b) => b.id === state.editingBranchId)
          : { name: "", location: "", type: "Retail", status: "Active" };
      body.classList.remove("no-pad");
      body.innerHTML =
        '<button type="button" class="back-link" id="branch-back">← Back to branches</button>' +
        '<div class="form-section-head" style="margin-bottom:1rem"><h2 class="form-section-title">' +
        (state.branchView === "edit" ? "Edit branch" : "Add branch") +
        '</h2><p class="form-section-desc">Locations for <strong>' +
        escapeHtml(co.name) +
        "</strong>. Stock and counters stay on the branch.</p></div>" +
        '<form id="branch-form" novalidate style="display:flex;flex-direction:column;min-height:calc(100% - 4rem)">' +
        '<div class="form-summary" hidden></div>' +
        '<div class="form-stack" style="flex:1">' +
        '<div class="field"><label class="field-label" for="br-name">Branch name</label>' +
        '<input class="field-control" id="br-name" required value="' +
        escapeAttr(br.name || "") +
        '" placeholder="e.g. Thrissur" />' +
        '<p class="field-hint">City or site name works well.</p>' +
        '<p class="field-error" data-default="Enter branch name."></p></div>' +
        '<div class="field"><label class="field-label" for="br-loc">Location</label>' +
        '<input class="field-control" id="br-loc" value="' +
        escapeAttr(br.location || "") +
        '" placeholder="City or address area" />' +
        '<p class="field-hint">Optional secondary location text.</p></div>' +
        '<div class="field-row"><div class="field"><label class="field-label" for="br-type">Branch type</label><select class="field-control" id="br-type">' +
        optionList(CHOICES.branchType, br.type || "Retail") +
        '</select></div><div class="field"><label class="field-label" for="br-status">Status</label>' +
        '<div class="segmented" role="radiogroup" aria-label="Status">' +
        '<label><input type="radio" name="br-status-seg" value="Active"' +
        (br.status !== "Inactive" ? " checked" : "") +
        ' /><span>Active</span></label>' +
        '<label><input type="radio" name="br-status-seg" value="Inactive"' +
        (br.status === "Inactive" ? " checked" : "") +
        ' /><span>Inactive</span></label></div>' +
        '<select class="field-control sr-only" id="br-status" tabindex="-1" aria-hidden="true">' +
        optionList(CHOICES.status, br.status || "Active") +
        "</select></div></div></div>" +
        '<div class="form-actions pinned" style="margin:1rem -0.75rem -0.75rem;">' +
        '<span class="form-actions-meta" id="br-dirty-meta"></span>' +
        '<button type="button" class="btn btn-secondary" id="br-cancel">Cancel</button>' +
        '<button type="submit" class="btn btn-primary" id="br-save">Save</button></div></form>';

      const dirtyMeta = document.getElementById("br-dirty-meta");
      const markDirty = () => {
        state.dirty = true;
        UI.markDirtyBar(dirtyMeta, true);
      };
      body.querySelectorAll("input, select").forEach((el) => {
        el.addEventListener("input", markDirty);
        el.addEventListener("change", markDirty);
      });
      body.querySelectorAll('input[name="br-status-seg"]').forEach((radio) => {
        radio.addEventListener("change", () => {
          if (radio.checked) {
            document.getElementById("br-status").value = radio.value;
            markDirty();
          }
        });
      });

      const back = () => {
        warnIfDirty(() => {
          state.branchView = "list";
          state.editingBranchId = null;
          state.dirty = false;
          renderBranches();
        });
      };
      $("branch-back").onclick = back;
      $("br-cancel").onclick = back;
      $("branch-form").onsubmit = (e) => {
        e.preventDefault();
        const nameField = document.getElementById("br-name").closest(".field");
        if (!UI.validateField(nameField)) {
          document.getElementById("br-name").focus();
          return;
        }
        const btn = $("br-save");
        UI.setButtonLoading(btn, true);
        setTimeout(() => {
          const wasEdit = state.branchView === "edit";
          const payload = {
            id: br.id || "br-" + Date.now(),
            name: document.getElementById("br-name").value.trim(),
            location: document.getElementById("br-loc").value.trim(),
            type: document.getElementById("br-type").value,
            status: document.getElementById("br-status").value,
          };
          if (wasEdit) {
            const i = co.branches.findIndex((b) => b.id === br.id);
            if (i >= 0) co.branches[i] = payload;
          } else {
            co.branches = co.branches || [];
            co.branches.push(payload);
          }
          saveCompanies(state.companies);
          state.dirty = false;
          state.branchView = "list";
          state.editingBranchId = null;
          UI.setButtonLoading(btn, false, "Save");
          UI.toast(wasEdit ? "Branch saved" : "Branch created");
          renderList();
          renderWorkspace();
        }, 550);
      };
      return;
    }

    body.classList.add("no-pad");
    const branches = co.branches || [];
    if (!branches.length) {
      body.innerHTML =
        '<div class="empty-state"><p>No branches yet — create your first branch to start managing locations for this company</p><button type="button" class="btn btn-primary" id="empty-add-br">Add Branch</button></div>';
      document.getElementById("empty-add-br").onclick = () => startAddBranch();
      return;
    }

    const ul = document.createElement("ul");
    ul.className = "branch-list";
    branches.forEach((b) => {
      const li = document.createElement("li");
      li.className = "branch-row";
      li.innerHTML =
        '<div><div class="branch-name"></div><div class="branch-meta"></div></div><span class="tag"></span><button type="button" class="btn btn-ghost">Edit</button>';
      li.querySelector(".branch-name").textContent = b.name;
      li.querySelector(".branch-meta").textContent = [b.location, b.type].filter(Boolean).join(" · ");
      const tag = li.querySelector(".tag");
      tag.textContent = b.status || "Active";
      tag.className = "tag " + (b.status === "Inactive" ? "tag-warn" : "tag-ok");
      li.querySelector("button").onclick = () => {
        warnIfDirty(() => {
          state.branchView = "edit";
          state.editingBranchId = b.id;
          state.dirty = false;
          renderBranches();
        });
      };
      ul.appendChild(li);
    });
    body.innerHTML = "";
    body.appendChild(ul);
  }

  function startAddBranch() {
    if (!selected()) return;
    warnIfDirty(() => {
      state.branchView = "add";
      state.editingBranchId = null;
      state.dirty = false;
      if (!state.showBranches) {
        state.showBranches = true;
        updatePanelVisibility();
      }
      if (window.matchMedia("(max-width: 860px)").matches) {
        state.mobileTab = "branches";
        updatePanelVisibility();
      }
      renderBranches();
    });
  }

  function renderWorkspace() {
    const co = selected();
    $("ws-title").textContent = co ? co.name : "Select a company";
    $("ws-meta").textContent = co
      ? (co.industry || "") + (co.status ? " · " + co.status : "")
      : UI.loadSetup().orgName || "";
    renderDetails();
    renderBranches();
    updatePanelVisibility();
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
  }
  function escapeAttr(s) {
    return escapeHtml(s).replace(/"/g, "&quot;");
  }

  function openRail() {
    rail.classList.add("is-open");
    const bd = $("drawer-backdrop");
    bd.hidden = false;
    bd.classList.add("is-open");
  }
  function closeRail() {
    rail.classList.remove("is-open");
    const bd = $("drawer-backdrop");
    bd.classList.remove("is-open");
    bd.hidden = true;
  }

  /* Events */
  $("company-search").addEventListener("input", (e) => {
    state.filter = e.target.value;
    renderList();
  });

  $("add-company").addEventListener("click", () => {
    warnIfDirty(() => {
      UI.openModal({
        title: "Add company",
        size: "md",
        body:
          '<form id="new-co-form" class="auth-form" novalidate>' +
          '<div class="form-callout" style="margin-bottom:0.75rem"><svg class="form-callout-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/></svg><div>Creates a company under your organization. You can finish the rest of the profile after create.</div></div>' +
          '<div class="field"><label class="field-label" for="new-name">Company name</label><input class="field-control" id="new-name" required placeholder="e.g. ABC Bakery Pvt Ltd" /><p class="field-hint">Shown in the company list immediately.</p><p class="field-error" data-default="Enter company name."></p></div>' +
          '<div class="field-row"><div class="field"><label class="field-label" for="new-type">Company type</label><select class="field-control" id="new-type">' +
          optionList(CHOICES.companyType, "Private Limited") +
          '</select></div><div class="field"><label class="field-label" for="new-industry">Industry</label><select class="field-control" id="new-industry">' +
          optionList(CHOICES.industry, "Retail") +
          "</select></div></div></form>",
        actions: [
          { label: "Cancel", className: "btn-secondary" },
          {
            label: "Create",
            className: "btn-primary",
            onClick: ({ close, setLoading }) => {
              const field = document.getElementById("new-name").closest(".field");
              if (!UI.validateField(field)) return;
              setLoading(true);
              setTimeout(() => {
                const company = {
                  id: "co-" + Date.now(),
                  name: document.getElementById("new-name").value.trim(),
                  status: "Active",
                  companyType: document.getElementById("new-type").value,
                  businessType: "Product",
                  industry: document.getElementById("new-industry").value,
                  businessModel: "B2B",
                  profile: "",
                  modules: ["Finance"],
                  financial: UI.loadSetup().financial || "April–March, INR",
                  localization: UI.loadSetup().localization || "India / English",
                  tax: "Skip for now",
                  branches: [],
                };
                state.companies.push(company);
                saveCompanies(state.companies);
                state.selectedId = company.id;
                state.editingCompany = true;
                state.dirty = false;
                setLoading(false);
                close();
                UI.toast("Company created");
                renderList();
                renderWorkspace();
              }, 500);
            },
          },
        ],
      });
    });
  });

  $("edit-company").addEventListener("click", () => {
    state.editingCompany = true;
    state.dirty = false;
    renderDetails();
  });

  $("add-branch").addEventListener("click", startAddBranch);

  $("hide-details").addEventListener("click", () => {
    if (!state.showBranches) return;
    state.showDetails = false;
    updatePanelVisibility();
  });
  $("hide-branches").addEventListener("click", () => {
    if (!state.showDetails) return;
    state.showBranches = false;
    updatePanelVisibility();
  });
  $("toggle-details").addEventListener("click", () => {
    if (state.showDetails && !state.showBranches) return;
    state.showDetails = !state.showDetails;
    if (!state.showDetails && !state.showBranches) state.showBranches = true;
    updatePanelVisibility();
  });
  $("toggle-branches").addEventListener("click", () => {
    if (state.showBranches && !state.showDetails) return;
    state.showBranches = !state.showBranches;
    if (!state.showDetails && !state.showBranches) state.showDetails = true;
    updatePanelVisibility();
  });

  $("tab-details").addEventListener("click", () => {
    state.mobileTab = "details";
    updatePanelVisibility();
  });
  $("tab-branches").addEventListener("click", () => {
    state.mobileTab = "branches";
    updatePanelVisibility();
  });

  $("open-rail").addEventListener("click", openRail);
  $("drawer-backdrop").addEventListener("click", closeRail);

  /* Resizer */
  let dragging = false;
  function setSplitFromClientX(x) {
    const rect = duo.getBoundingClientRect();
    const pct = ((x - rect.left) / rect.width) * 100;
    const minPx = 340;
    const minPct = Math.max(40, (minPx / rect.width) * 100);
    const maxPct = Math.min(60, 100 - minPct);
    state.splitPct = Math.min(maxPct, Math.max(minPct, pct));
    applySplit();
  }

  resizer.addEventListener("pointerdown", (e) => {
    dragging = true;
    resizer.classList.add("is-dragging");
    resizer.setPointerCapture(e.pointerId);
  });
  resizer.addEventListener("pointermove", (e) => {
    if (!dragging) return;
    setSplitFromClientX(e.clientX);
  });
  function endDrag(e) {
    if (!dragging) return;
    dragging = false;
    resizer.classList.remove("is-dragging");
    try {
      resizer.releasePointerCapture(e.pointerId);
    } catch (err) {}
  }
  resizer.addEventListener("pointerup", endDrag);
  resizer.addEventListener("pointercancel", endDrag);
  resizer.addEventListener("dblclick", () => {
    state.splitPct = DEFAULT_SPLIT;
    applySplit();
  });
  resizer.addEventListener("keydown", (e) => {
    const step = e.shiftKey ? 5 : 2;
    if (e.key === "ArrowLeft") {
      e.preventDefault();
      state.splitPct -= step;
      applySplit();
    } else if (e.key === "ArrowRight") {
      e.preventDefault();
      state.splitPct += step;
      applySplit();
    } else if (e.key === "Home") {
      e.preventDefault();
      state.splitPct = 40;
      applySplit();
    } else if (e.key === "End") {
      e.preventDefault();
      state.splitPct = 60;
      applySplit();
    }
  });

  window.addEventListener("resize", updatePanelVisibility);

  /* Init */
  applySplit();
  if (state.companies.length) state.selectedId = state.companies[0].id;
  renderList();
  renderWorkspace();
})();
