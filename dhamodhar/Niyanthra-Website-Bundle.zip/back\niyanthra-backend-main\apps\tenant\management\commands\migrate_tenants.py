from django.core.management.base import BaseCommand

from infrastructure.database.migration_service import DatabaseMigrationService


class Command(BaseCommand):
    help = (
        "Migrate every ACTIVE isolated and silo database. "
        "Inactive databases use migrate_inactive."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--verbosity-level",
            type=int,
            default=1,
            dest="migrate_verbosity",
        )

    def handle(self, *args, **options):
        result = DatabaseMigrationService.migrate_active_tenants(
            verbosity=options["migrate_verbosity"],
        )
        style = (
            self.style.SUCCESS
            if result.get("failures", 0) == 0
            else self.style.WARNING
        )
        self.stdout.write(style(f"migrate_tenants: {result}"))
