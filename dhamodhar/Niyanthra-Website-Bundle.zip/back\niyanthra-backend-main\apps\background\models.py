from django.db import models
from django.utils.translation import gettext_lazy as _

from core.database.models import BaseModel


class PeriodicTask(BaseModel):

    class QueueStatus(models.TextChoices):
        IDLE       = "idle", _("Idle")
        PROCESSING = "processing", _("Processing")
        PAUSED     = "paused", _("Paused")

    code             = models.CharField(_("Code"), max_length=100, unique=True)
    name             = models.CharField(_("Name"), max_length=255)
    task_path        = models.CharField(_("Celery Task Path"), max_length=255)
    is_enabled       = models.BooleanField(_("Is Enabled"), default=True, db_index=True)
    interval_seconds = models.PositiveIntegerField(_("Interval Seconds"), default=60)
    max_workers      = models.PositiveIntegerField(_("Max Workers"), default=5)
    queue_status     = models.CharField(
        _("Queue Status"),
        max_length=20,
        choices=QueueStatus.choices,
        default=QueueStatus.IDLE,
        db_index=True,
    )
    last_run_at      = models.DateTimeField(_("Last Run At"), blank=True, null=True)
    last_finished_at = models.DateTimeField(_("Last Finished At"), blank=True, null=True)
    last_error       = models.TextField(_("Last Error"), blank=True, null=True)
    description      = models.TextField(_("Description"), blank=True, null=True)

    class Meta:
        ordering            = ["code"]
        verbose_name        = _("periodic task")
        verbose_name_plural = _("periodic tasks")
        indexes = [
            models.Index(fields=["is_enabled", "queue_status"]),
        ]

    def __str__(self):
        return f"{self.code} ({'on' if self.is_enabled else 'off'})"




class BackgroundJob(BaseModel):

    class JobType(models.TextChoices):
        ISOLATED_DB_PROVISION = (
            "isolated_db_provision",
            _("Isolated DB Provision"),
        )

    class Status(models.TextChoices):
        PENDING   = "pending", _("Pending")
        STARTED   = "started", _("Started")
        COMPLETED = "completed", _("Completed")
        FAILED    = "failed", _("Failed")

    periodic_task = models.ForeignKey(
        PeriodicTask,
        on_delete=models.PROTECT,
        related_name="jobs",
    )
    tenant = models.ForeignKey(
        "tenant.Tenant",
        on_delete=models.CASCADE,
        related_name="background_jobs",
    )
    job_type = models.CharField(
        _("Job Type"),
        max_length=50,
        choices=JobType.choices,
        db_index=True,
    )
    status = models.CharField(
        _("Status"),
        max_length=20,
        choices=Status.choices,
        default=Status.PENDING,
        db_index=True,
    )
    payload       = models.JSONField(_("Payload"), default=dict, blank=True)
    started_at    = models.DateTimeField(_("Started At"), blank=True, null=True)
    completed_at  = models.DateTimeField(_("Completed At"), blank=True, null=True)
    failed_at     = models.DateTimeField(_("Failed At"), blank=True, null=True)
    error_message = models.TextField(_("Error Message"), blank=True, null=True)
    retry_count   = models.PositiveIntegerField(_("Retry Count"), default=0)
    worker_hostname = models.CharField(
        _("Worker Hostname"),
        max_length=255,
        blank=True,
        null=True,
    )
    thread_name = models.CharField(
        _("Thread Name"),
        max_length=100,
        blank=True,
        null=True,
    )

    class Meta:
        ordering            = ["id"]
        verbose_name        = _("background job")
        verbose_name_plural = _("background jobs")
        indexes = [
            models.Index(fields=["periodic_task", "status", "created_at"]),
            models.Index(fields=["job_type", "status"]),
            models.Index(fields=["tenant", "job_type", "status"]),
        ]

    def __str__(self):
        return f"{self.job_type}:{self.pk}:{self.status}"
