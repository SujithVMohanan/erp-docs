from rest_framework import serializers




class CreateCompanySerializer(serializers.Serializer):

    name                  = serializers.CharField(max_length=254, trim_whitespace=True,required=True)
    code                  = serializers.CharField(max_length=100, trim_whitespace=True,required=True)
    legal_name            = serializers.CharField(max_length=254,required=False,allow_blank=True,allow_null=True,trim_whitespace=True,)
    website               = serializers.URLField(max_length=255,required=False,allow_blank=True,allow_null=True,)
    logo                  = serializers.ImageField(required=False, allow_null=True)
    timezone_uid          = serializers.CharField(required=False,allow_blank=True,allow_null=True,trim_whitespace=True,)
    registration_number   = serializers.CharField(max_length=100,required=False,allow_blank=True,allow_null=True,trim_whitespace=True,)
    company_type_uid      = serializers.CharField(required=False,allow_blank=True,allow_null=True,trim_whitespace=True,)
    is_active             = serializers.BooleanField(required=False)
    modules               = serializers.JSONField(required=False)

    def validate_modules(self, value):
        if value in (None, ""):
            return None
        return _module_flags(value)

    def validate(self, attrs):
        rejected = {}
        for field in ("organization_uid", "tenant_uid", "tenant_id", "tenant"):
            if field in self.initial_data and self.initial_data.get(field) not in (None, ""):
                rejected[field] = ["This field is not accepted."]
        if rejected:
            raise serializers.ValidationError(rejected)
        return attrs

    

    


class UpdateCompanySerializer(CreateCompanySerializer):
    uid = serializers.CharField(trim_whitespace=True)
    name = serializers.CharField(
        max_length=254,
        required=False,
        trim_whitespace=True,
    )
    code = serializers.CharField(
        max_length=100,
        required=False,
        trim_whitespace=True,
    )


class GetCompaniesQuerySerializer(serializers.Serializer):
    uid              = serializers.CharField(required=False, allow_blank=True)
    code             = serializers.CharField(required=False, allow_blank=True, max_length=100)
    name             = serializers.CharField(required=False, allow_blank=True, max_length=254)
    organization_uid = serializers.CharField(required=False, allow_blank=True)
    is_active        = serializers.BooleanField(required=False, allow_null=True)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["code"] = (attrs.get("code") or "").strip().upper() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        attrs["organization_uid"] = (attrs.get("organization_uid") or "").strip() or None
        attrs["is_active"] = attrs.get("is_active")
        return attrs


class ImportCompaniesSerializer(serializers.Serializer):
    file = serializers.FileField()
    organization_uid = serializers.CharField(trim_whitespace=True)


class GetMyBranchesQuerySerializer(serializers.Serializer):
    company_uid = serializers.CharField(required=False, allow_blank=True)
    branch_uid = serializers.CharField(required=False, allow_blank=True)
    name = serializers.CharField(required=False, allow_blank=True, max_length=150)

    def validate(self, attrs):
        attrs["company_uid"] = (attrs.get("company_uid") or "").strip() or None
        attrs["branch_uid"] = (attrs.get("branch_uid") or "").strip() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        return attrs


class GetMyCompanyDirectoryQuerySerializer(serializers.Serializer):
    organization_uid = serializers.CharField(required=False, allow_blank=True)
    name = serializers.CharField(required=False, allow_blank=True, max_length=254)

    def validate(self, attrs):
        attrs["organization_uid"] = (attrs.get("organization_uid") or "").strip() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        return attrs


class GetMyCompaniesQuerySerializer(serializers.Serializer):
    
    organization_uid    = serializers.CharField(required=False, allow_blank=True)
    company_uid         = serializers.CharField(required=False, allow_blank=True)
    name                = serializers.CharField(required=False, allow_blank=True, max_length=254)

    def validate(self, attrs):
        attrs["organization_uid"] = (attrs.get("organization_uid") or "").strip() or None
        attrs["company_uid"] = (attrs.get("company_uid") or "").strip() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        return attrs


class CompanyUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique = []
        seen = set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one company.")
        return unique


class SelectCompanySerializer(serializers.Serializer):
    company_uid = serializers.CharField(trim_whitespace=True)

    def validate_company_uid(self, value):
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        return value


class CreateBranchSerializer(serializers.Serializer):
    name        = serializers.CharField(max_length=150, trim_whitespace=True)
    code        = serializers.CharField(max_length=50, trim_whitespace=True)
    company_uid = serializers.CharField(trim_whitespace=True)
    branch_type = serializers.CharField(
        max_length=50,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )
    status      = serializers.CharField(
        max_length=30,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )
    email       = serializers.EmailField(required=False, allow_blank=True)
    phone       = serializers.CharField(
        max_length=30,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )

    def validate_code(self, value):
        value = value.strip().upper()
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        return value

    def validate_name(self, value):
        value = value.strip()
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        return value

    def validate_branch_type(self, value):
        return (value or "").strip() or None

    def validate_status(self, value):
        normalized = (value or "").strip().upper() or "ACTIVE"
        if normalized not in {"ACTIVE", "INACTIVE"}:
            raise serializers.ValidationError(
                "Status must be ACTIVE or INACTIVE."
            )
        return normalized

    def validate_email(self, value):
        return (value or "").strip() or None

    def validate_phone(self, value):
        return (value or "").strip() or None


class UpdateBranchSerializer(CreateBranchSerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetBranchesQuerySerializer(serializers.Serializer):
    uid         = serializers.CharField(required=False, allow_blank=True)
    code        = serializers.CharField(required=False, allow_blank=True, max_length=50)
    name        = serializers.CharField(required=False, allow_blank=True, max_length=150)
    company_uid = serializers.CharField(required=False, allow_blank=True)
    status      = serializers.CharField(required=False, allow_blank=True, max_length=30)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["code"] = (attrs.get("code") or "").strip().upper() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        attrs["company_uid"] = (attrs.get("company_uid") or "").strip() or None
        status = (attrs.get("status") or "").strip().upper() or None
        if status and status not in {"ACTIVE", "INACTIVE"}:
            raise serializers.ValidationError(
                {"status": ["Status must be ACTIVE or INACTIVE."]}
            )
        attrs["status"] = status
        return attrs


class BranchUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique = []
        seen = set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one branch.")
        return unique


class CreateBranchMembershipSerializer(serializers.Serializer):
    branch_uid = serializers.CharField(trim_whitespace=True)
    user_uid   = serializers.CharField(trim_whitespace=True)
    role       = serializers.CharField(
        max_length=20,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )
    is_active  = serializers.BooleanField(required=False, default=True)

    def validate_role(self, value):
        normalized = (value or "").strip().lower() or "staff"
        if normalized not in {"manager", "staff"}:
            raise serializers.ValidationError(
                "Role must be manager or staff."
            )
        return normalized


class UpdateBranchMembershipSerializer(CreateBranchMembershipSerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetBranchMembershipsQuerySerializer(serializers.Serializer):
    uid         = serializers.CharField(required=False, allow_blank=True)
    branch_uid  = serializers.CharField(required=False, allow_blank=True)
    user_uid    = serializers.CharField(required=False, allow_blank=True)
    company_uid = serializers.CharField(required=False, allow_blank=True)
    email       = serializers.CharField(required=False, allow_blank=True, max_length=254)
    name        = serializers.CharField(required=False, allow_blank=True, max_length=150)
    role        = serializers.CharField(required=False, allow_blank=True, max_length=20)
    audience    = serializers.ChoiceField(
        choices=["admin", "employee"],
        required=False,
        allow_null=True,
    )
    is_active   = serializers.BooleanField(required=False, allow_null=True)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["branch_uid"] = (attrs.get("branch_uid") or "").strip() or None
        attrs["user_uid"] = (attrs.get("user_uid") or "").strip() or None
        attrs["company_uid"] = (attrs.get("company_uid") or "").strip() or None
        attrs["email"] = (attrs.get("email") or "").strip() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        role = (attrs.get("role") or "").strip().lower() or None
        if role and role not in {"manager", "staff"}:
            raise serializers.ValidationError(
                {"role": ["Role must be manager or staff."]}
            )
        attrs["role"] = role
        attrs["audience"] = attrs.get("audience") or None
        if "is_active" not in attrs:
            attrs["is_active"] = None
        return attrs


class BranchMembershipUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique = []
        seen = set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError(
                "Select at least one branch membership."
            )
        return unique


class CreateCompanyMembershipSerializer(serializers.Serializer):
    company_uid = serializers.CharField(trim_whitespace=True)
    user_uid    = serializers.CharField(trim_whitespace=True)
    role        = serializers.CharField(
        max_length=20,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )
    is_active   = serializers.BooleanField(required=False, default=True)

    def validate_role(self, value):
        normalized = (value or "").strip().lower() or "employee"
        if normalized not in {"owner", "admin", "employee"}:
            raise serializers.ValidationError(
                "Role must be owner, admin, or employee."
            )
        return normalized


class UpdateCompanyMembershipSerializer(CreateCompanyMembershipSerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetCompanyMembershipsQuerySerializer(serializers.Serializer):
    uid         = serializers.CharField(required=False, allow_blank=True)
    company_uid = serializers.CharField(required=False, allow_blank=True)
    user_uid    = serializers.CharField(required=False, allow_blank=True)
    email       = serializers.CharField(required=False, allow_blank=True, max_length=254)
    name        = serializers.CharField(required=False, allow_blank=True, max_length=150)
    role        = serializers.CharField(required=False, allow_blank=True, max_length=20)
    audience    = serializers.ChoiceField(
        choices=["admin", "employee"],
        required=False,
        allow_null=True,
    )
    is_active   = serializers.BooleanField(required=False, allow_null=True)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["company_uid"] = (attrs.get("company_uid") or "").strip() or None
        attrs["user_uid"] = (attrs.get("user_uid") or "").strip() or None
        attrs["email"] = (attrs.get("email") or "").strip() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        role = (attrs.get("role") or "").strip().lower() or None
        if role and role not in {"owner", "admin", "employee"}:
            raise serializers.ValidationError(
                {"role": ["Role must be owner, admin, or employee."]}
            )
        attrs["role"] = role
        attrs["audience"] = attrs.get("audience") or None
        if "is_active" not in attrs:
            attrs["is_active"] = None
        return attrs


class CompanyMembershipUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique = []
        seen = set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError(
                "Select at least one company membership."
            )
        return unique


class CreateCompanyMembershipInviteSerializer(serializers.Serializer):
    company_uid = serializers.CharField(trim_whitespace=True)
    audience    = serializers.ChoiceField(
        choices=["admin", "employee"],
        default="employee",
    )
    role        = serializers.CharField(
        max_length=20,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )

    def validate(self, attrs):
        audience = attrs.get("audience") or "employee"
        role = (attrs.get("role") or "").strip().lower()
        if audience == "admin":
            role = role or "admin"
            if role not in {"owner", "admin"}:
                raise serializers.ValidationError(
                    {
                        "role": [
                            "Admin invites allow only owner or admin roles.",
                        ]
                    }
                )
        else:
            role = "employee"
        attrs["audience"] = audience
        attrs["role"] = role
        return attrs


class CreateBranchMembershipInviteSerializer(serializers.Serializer):
    branch_uid = serializers.CharField(trim_whitespace=True)
    audience   = serializers.ChoiceField(
        choices=["admin", "employee"],
        default="employee",
    )
    role       = serializers.CharField(
        max_length=20,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )

    def validate(self, attrs):
        audience = attrs.get("audience") or "employee"
        if audience == "admin":
            role = "manager"
        else:
            role = "staff"
        attrs["audience"] = audience
        attrs["role"] = role
        return attrs


class AcceptMembershipInviteSerializer(serializers.Serializer):
    token = serializers.CharField(trim_whitespace=True)

    def validate_token(self, value):
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        return value

class CreateCompanyTypeSerializer(serializers.Serializer):
    name      = serializers.CharField(max_length=100, trim_whitespace=True)
    code      = serializers.CharField(max_length=50, trim_whitespace=True)
    is_active = serializers.BooleanField(required=False, default=True)

    def validate_code(self, value):
        normalized = value.strip().upper()
        if not normalized:
            raise serializers.ValidationError("This field may not be blank.")
        return normalized


class UpdateCompanyTypeSerializer(CreateCompanyTypeSerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetCompanyTypesQuerySerializer(serializers.Serializer):
    uid       = serializers.CharField(required=False, allow_blank=True)
    code      = serializers.CharField(required=False, allow_blank=True, max_length=50)
    name      = serializers.CharField(required=False, allow_blank=True, max_length=100)
    is_active = serializers.BooleanField(required=False, allow_null=True)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["code"] = (attrs.get("code") or "").strip().upper() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        if "is_active" not in attrs:
            attrs["is_active"] = None
        return attrs


class CompanyTypeUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique, seen = [], set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one company type.")
        return unique


class CreateBusinessTypeSerializer(CreateCompanyTypeSerializer):
    pass


class UpdateBusinessTypeSerializer(UpdateCompanyTypeSerializer):
    pass


class GetBusinessTypesQuerySerializer(GetCompanyTypesQuerySerializer):
    pass


class CompanyScopedListQuerySerializer(serializers.Serializer):
    company_uid = serializers.CharField(required=True, allow_blank=False)
    uid = serializers.CharField(required=False, allow_blank=True)
    page = serializers.IntegerField(required=False, min_value=1)
    limit = serializers.IntegerField(required=False, min_value=1, max_value=100)

    def validate(self, attrs):
        attrs["company_uid"] = attrs["company_uid"].strip()
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        if not attrs["company_uid"]:
            raise serializers.ValidationError({"company_uid": ["Select a company."]})
        return attrs


def _module_flags(value):
    if not isinstance(value, dict) or not value:
        raise serializers.ValidationError("Send module flags.")
    cleaned = {}
    for raw_key, flag in value.items():
        code = str(raw_key).strip().lower()
        if not code:
            continue
        if not isinstance(flag, bool):
            raise serializers.ValidationError(
                "Each module value must be true or false."
            )
        cleaned[code] = flag
    if not cleaned:
        raise serializers.ValidationError("Send module flags.")
    return cleaned


class CreateCompanyModuleSerializer(serializers.Serializer):
    company_uid = serializers.CharField(trim_whitespace=True)
    modules     = serializers.JSONField(required=False)

    def validate_modules(self, value):
        if value in (None, ""):
            return None
        return _module_flags(value)


class UpdateCompanyModuleSerializer(serializers.Serializer):
    uid         = serializers.CharField(trim_whitespace=True)
    company_uid = serializers.CharField(trim_whitespace=True)
    modules     = serializers.JSONField()

    def validate_modules(self, value):
        return _module_flags(value)


class BusinessTypeUidsSerializer(CompanyTypeUidsSerializer):
    def validate_uids(self, value):
        unique, seen = [], set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one business type.")
        return unique
