from django.db import transaction

from apps.company.repository import (
    BranchMembershipRepository,
    BranchRepository,
    CompanyMembershipRepository,
    CompanyRepository,
)
from apps.company.services.company_membership_service import (
    CompanyMembershipService,
)
from apps.organization.repository import (
    OrganizationMembershipRepository,
    OrganizationRepository,
)
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class MembershipService:
    """
    Single control point for invite-scope membership grants.

    organization_code / company_code / branch_code are encoded public uids
    (same as API uid), not business string codes.
    """

    @staticmethod
    def create_membership(
        *,
        validated_data: dict,
        user,
    ):
        if not MembershipService.has_membership_scope(
            validated_data=validated_data,
        ):
            return None

        organization_uid = (
            validated_data.get("organization_code") or ""
        ).strip() or None
        company_uid = (
            validated_data.get("company_code") or ""
        ).strip() or None
        branch_uid = (
            validated_data.get("branch_code") or ""
        ).strip() or None

        organization_id = MembershipService._decode_optional_uid(
            organization_uid,
            field="organization_code",
        )
        company_id = MembershipService._decode_optional_uid(
            company_uid,
            field="company_code",
        )
        branch_id = MembershipService._decode_optional_uid(
            branch_uid,
            field="branch_code",
        )

        organization = None
        company = None
        branch = None

        if organization_id is not None:
            organization = OrganizationRepository.get_by_id(organization_id)
            if organization is None or not organization.is_active:
                raise AuthValidationError(
                    {"organization_code": ["Organization not found."]},
                    code="ORGANIZATION_NOT_FOUND",
                )

        if company_id is not None:
            company = CompanyRepository.get_by_id(company_id)
            if company is None or not company.is_active:
                raise AuthValidationError(
                    {"company_code": ["Company not found."]},
                    code="COMPANY_NOT_FOUND",
                )

        if branch_id is not None:
            branch = BranchRepository.get_by_id(branch_id)
            if branch is None or branch.status != "ACTIVE":
                raise AuthValidationError(
                    {"branch_code": ["Branch not found."]},
                    code="BRANCH_NOT_FOUND",
                )
            if company is None:
                company = CompanyRepository.get_by_id(branch.company_id)
                if company is None or not company.is_active:
                    raise AuthValidationError(
                        {"branch_code": ["Branch company not found."]},
                        code="COMPANY_NOT_FOUND",
                    )
                company_id = company.pk
            elif branch.company_id != company.pk:
                raise AuthValidationError(
                    {
                        "branch_code": [
                            "Branch does not belong to the given company.",
                        ]
                    },
                    code="BRANCH_COMPANY_MISMATCH",
                )

        if (
            organization is not None
            and company is not None
            and company.organization_id != organization.pk
        ):
            raise AuthValidationError(
                {
                    "company_code": [
                        "Company does not belong to the given organization.",
                    ]
                },
                code="COMPANY_ORGANIZATION_MISMATCH",
            )

        if organization is None and company is not None:
            organization_id = company.organization_id

        with transaction.atomic():
            if organization_id is not None:
                MembershipService.ensure_organization_membership(
                    organization_id=organization_id,
                    user_id=user.pk,
                    role="employee",
                )

            if company_id is not None:
                CompanyMembershipService.ensure_membership(
                    company_id=company_id,
                    user_id=user.pk,
                    role="employee",
                )

            if branch_id is not None:
                MembershipService.ensure_branch_membership(
                    branch_id=branch_id,
                    user_id=user.pk,
                    role="staff",
                )

        return None

    @staticmethod
    def has_membership_scope(*, validated_data: dict) -> bool:
        return any(
            (validated_data.get(key) or "").strip()
            for key in (
                "organization_code",
                "company_code",
                "branch_code",
            )
        )

    @staticmethod
    def ensure_organization_membership(
        *,
        organization_id: int,
        user_id: int,
        role: str = "employee",
    ):
        role_rank = {
            "employee": 1,
            "admin": 2,
            "owner": 3,
        }
        requested = (role or "employee").strip().lower()
        if requested not in role_rank:
            requested = "employee"

        existing = OrganizationMembershipRepository.get_conflict(
            organization_id=organization_id,
            user_id=user_id,
        )
        if existing is None:
            OrganizationMembershipRepository.create_membership(
                organization_id=organization_id,
                user_id=user_id,
                role=requested,
                is_active=True,
            )
            return

        current = (existing.role or "employee").strip().lower()
        needs_role_upgrade = (
            role_rank.get(requested, 1) > role_rank.get(current, 1)
        )
        if needs_role_upgrade or not existing.is_active:
            OrganizationMembershipRepository.update_membership(
                membership=existing,
                organization_id=organization_id,
                user_id=user_id,
                role=requested if needs_role_upgrade else existing.role,
                is_active=True,
            )

    @staticmethod
    def ensure_branch_membership(
        *,
        branch_id: int,
        user_id: int,
        role: str = "staff",
    ):
        requested = (role or "staff").strip().lower()
        if requested not in {"manager", "staff"}:
            requested = "staff"

        existing = BranchMembershipRepository.get_conflict(
            branch_id=branch_id,
            user_id=user_id,
        )
        if existing is None:
            BranchMembershipRepository.create_membership(
                branch_id=branch_id,
                user_id=user_id,
                role=requested,
                is_active=True,
            )
            return

        role_rank = {"staff": 1, "manager": 2}
        current = (existing.role or "staff").strip().lower()
        needs_role_upgrade = (
            role_rank.get(requested, 1) > role_rank.get(current, 1)
        )
        if needs_role_upgrade or not existing.is_active:
            BranchMembershipRepository.update_membership(
                membership=existing,
                branch_id=branch_id,
                user_id=user_id,
                role=requested if needs_role_upgrade else existing.role,
                is_active=True,
            )

    @staticmethod
    def grant_company_to_org_principals(
        *,
        company_id: int,
        organization_id: int,
        actor_id: int | None = None,
    ):
        """
        On company create: actor + active org owners/admins get CompanyMembership.
        """
        principals = OrganizationMembershipRepository.list_memberships(
            organization_id=organization_id,
            is_active=True,
        ).filter(role__in=["owner", "admin"])

        for membership in principals:
            company_role = (
                "owner" if membership.role == "owner" else "admin"
            )
            CompanyMembershipService.ensure_membership(
                company_id=company_id,
                user_id=membership.user_id,
                role=company_role,
            )

        if actor_id is not None:
            CompanyMembershipService.ensure_membership(
                company_id=company_id,
                user_id=actor_id,
                role="admin",
            )
            MembershipService.ensure_organization_membership(
                organization_id=organization_id,
                user_id=actor_id,
                role="employee",
            )

    @staticmethod
    def grant_branch_to_principals(
        *,
        branch_id: int,
        company_id: int,
        organization_id: int,
        actor_id: int | None = None,
    ):
        """
        On branch create: actor becomes org, company, and branch admin.
        Active organization and company owners and admins get branch admin access.
        """
        user_ids = set()
        org_principals = OrganizationMembershipRepository.list_memberships(
            organization_id=organization_id,
            is_active=True,
        ).filter(role__in=["owner", "admin"])
        user_ids.update(org_principals.values_list("user_id", flat=True))

        company_principals = CompanyMembershipRepository.list_memberships(
            company_id=company_id,
            roles=["owner", "admin"],
            is_active=True,
        )
        user_ids.update(company_principals.values_list("user_id", flat=True))

        if actor_id is not None:
            user_ids.add(actor_id)
            MembershipService.ensure_organization_membership(
                organization_id=organization_id,
                user_id=actor_id,
                role="admin",
            )
            CompanyMembershipService.ensure_membership(
                company_id=company_id,
                user_id=actor_id,
                role="admin",
            )

        for user_id in user_ids:
            MembershipService.ensure_branch_membership(
                branch_id=branch_id,
                user_id=user_id,
                role="manager",
            )

    @staticmethod
    def _decode_optional_uid(uid: str | None, *, field: str) -> int | None:
        if not uid:
            return None
        try:
            decoded = decode_id(uid)
        except (TypeError, ValueError):
            raise AuthValidationError(
                {field: ["Invalid id."]},
                code="INVALID_SCOPE_ID",
            ) from None

        if not isinstance(decoded, int):
            raise AuthValidationError(
                {field: ["Invalid id."]},
                code="INVALID_SCOPE_ID",
            )
        return decoded
