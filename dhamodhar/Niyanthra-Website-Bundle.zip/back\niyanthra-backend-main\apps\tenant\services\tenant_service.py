from django.db import (
    IntegrityError,
    transaction,
)
from rest_framework.exceptions import (
    NotFound,
    PermissionDenied,
    ValidationError,
)

from apps.company.services.company_service import CompanyService
from apps.tenant.models import Tenant
from apps.tenant.repository import TenantRepository
from apps.tenant.services.provisioning_service import TenantProvisioningService
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class TenantService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            tenant_id = decode_id(uid)
        except (TypeError, ValueError):
            raise ValidationError({field: ["Invalid id."]}) from None

        if not isinstance(tenant_id, int):
            raise ValidationError({field: ["Invalid id."]})

        return tenant_id

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        tenant_ids = [
            TenantService._decode_uid(uid, field="uids")
            for uid in uids
        ]
        return list(dict.fromkeys(tenant_ids))

    @staticmethod
    def _validate_unique(
        *,
        slug: str,
        db_alias: str,
        exclude_id: int | None = None,
    ):
        conflict = TenantRepository.get_unique_conflict(
            slug=slug,
            db_alias=db_alias,
            exclude_id=exclude_id,
        )

        if conflict is None:
            return

        errors = {}

        if conflict.slug == slug:
            errors["slug"] = ["This tenant slug already exists."]

        if conflict.db_alias == db_alias:
            errors["db_alias"] = ["This database alias already exists."]

        raise AuthValidationError(errors, code="TENANT_EXISTS")

    @staticmethod
    def _initial_provisioning_status(tenant_type: str) -> str:
        if tenant_type == Tenant.TenantType.SHARED:
            return Tenant.ProvisioningStatus.ACTIVE
        return Tenant.ProvisioningStatus.PENDING

    @staticmethod
    def get_tenants(*, validated_data: dict):
        tenant_ids = None

        if validated_data.get("uid"):
            tenant_ids = [
                TenantService._decode_uid(validated_data["uid"])
            ]

        return TenantRepository.list_tenants(
            tenant_ids=tenant_ids,
            slug=validated_data.get("slug"),
            name=validated_data.get("name"),
            tenant_type=validated_data.get("tenant_type"),
            db_alias=validated_data.get("db_alias"),
            is_active=validated_data.get("is_active"),
            provisioning_status=validated_data.get("provisioning_status"),
        )

    @staticmethod
    def create_tenant(*, validated_data: dict):
        tenant_type = validated_data["tenant_type"]
        provisioning_status = TenantService._initial_provisioning_status(
            tenant_type
        )

        values = {
            "name": validated_data["name"],
            "slug": validated_data["slug"],
            "tenant_type": tenant_type,
            "db_alias": validated_data["db_alias"],
            "celery_queue": validated_data.get("celery_queue", "default"),
            "provisioning_status": provisioning_status,
            "is_active": True,
        }

        TenantService._validate_unique(
            slug=values["slug"],
            db_alias=values["db_alias"],
        )

        try:
            with transaction.atomic():
                tenant = TenantRepository.create_tenant(**values)

                TenantRepository.create_tenant_database(
                    tenant=tenant,
                    db_alias=values["db_alias"],
                    provisioning_status=provisioning_status,
                    is_current=True,
                )

                CompanyService.update_company_tenant(
                    company_uid=validated_data["company"],
                    tenant_id=tenant.pk,
                )
        except IntegrityError:
            raise AuthValidationError(
                {
                    "slug": [
                        "This tenant slug or database alias already exists."
                    ]
                },
                code="TENANT_EXISTS",
            ) from None

        tenant = TenantProvisioningService.provision(tenant=tenant)
        from apps.inventory.services.warehouse_service import WarehouseService

        company_id = TenantService._decode_uid(
            validated_data["company"],
            field="company",
        )
        WarehouseService.ensure_for_company_id(company_id)
        return tenant

    @staticmethod
    def _user_owns_tenant_company(*, user, tenant) -> bool:
        from apps.company.models import Company
        from apps.organization.models import OrganizationMembership

        return Company.objects.filter(
            tenant_id=tenant.pk,
            is_active=True,
            organization__is_active=True,
            organization__memberships__user_id=user.pk,
            organization__memberships__is_active=True,
            organization__memberships__role=OrganizationMembership.Role.OWNER,
        ).exists()

    @staticmethod
    def get_tenant_for_company(*, user, company_uid: str):
        from apps.company.models import Company
        from apps.organization.models import OrganizationMembership

        company_id = TenantService._decode_uid(company_uid, field="company_uid")
        company = (
            Company.objects
            .select_related("tenant", "organization")
            .filter(pk=company_id, is_active=True)
            .first()
        )
        if company is None:
            raise NotFound("Company not found.")

        is_owner = OrganizationMembership.objects.filter(
            user_id=user.pk,
            organization_id=company.organization_id,
            role=OrganizationMembership.Role.OWNER,
            is_active=True,
            organization__is_active=True,
        ).exists()
        if not user.is_admin and not is_owner:
            raise PermissionDenied("You do not have access to this company.")
        if company.tenant_id is None or company.tenant is None:
            raise NotFound("Tenant not found.")
        return company.tenant

    @staticmethod
    def update_tenant(*, validated_data: dict, user):
        tenant_id = TenantService._decode_uid(validated_data["uid"])
        tenant = TenantRepository.get_by_id(tenant_id)

        if tenant is None:
            raise NotFound("Tenant not found.")

        if not user.is_admin:
            if not TenantService._user_owns_tenant_company(user=user, tenant=tenant):
                raise PermissionDenied("You do not have access to this tenant.")
            locked = [
                field
                for field in ("slug", "tenant_type", "db_alias", "celery_queue")
                if field in validated_data
            ]
            if locked:
                raise ValidationError({
                    field: ["You can update the tenant name only."]
                    for field in locked
                })

        values = {
            "name": validated_data.get("name", tenant.name),
            "slug": validated_data.get("slug", tenant.slug),
            "tenant_type": validated_data.get(
                "tenant_type",
                tenant.tenant_type,
            ),
            "db_alias": validated_data.get("db_alias", tenant.db_alias),
            "celery_queue": validated_data.get(
                "celery_queue",
                tenant.celery_queue,
            ),
        }

        TenantService._validate_unique(
            slug=values["slug"],
            db_alias=values["db_alias"],
            exclude_id=tenant.pk,
        )

        try:
            with transaction.atomic():
                TenantRepository.update_tenant(tenant=tenant, **values)
        except IntegrityError:
            raise AuthValidationError(
                {
                    "slug": [
                        "This tenant slug or database alias already exists."
                    ]
                },
                code="TENANT_EXISTS",
            ) from None

        return tenant

    @staticmethod
    def delete_tenants(*, validated_data: dict) -> dict:
        tenant_ids = TenantService._decode_uids(validated_data["uids"])
        deleted = TenantRepository.delete_by_ids(tenant_ids)

        if not deleted:
            raise NotFound("Tenant not found.")

        return {"deleted": deleted}

    @staticmethod
    def toggle_tenants(*, validated_data: dict):
        tenant_ids = TenantService._decode_uids(validated_data["uids"])
        updated = TenantRepository.toggle_active_by_ids(tenant_ids)

        if not updated:
            raise NotFound("Tenant not found.")

        return TenantRepository.list_tenants(tenant_ids=tenant_ids)
