"""Generic field validators reused across apps."""
