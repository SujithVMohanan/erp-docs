import logging
import threading
from concurrent.futures import (
    ThreadPoolExecutor,
    as_completed,
)

from apps.background.models import (
    BackgroundJob,
    PeriodicTask,
)
from apps.background.repository import BackgroundRepository
from apps.background.services.handlers import get_handler

logger = logging.getLogger("niyanthra.background")


class JobExecutorService:

    @staticmethod
    def _run_one(*, job: BackgroundJob) -> None:
        thread_name = threading.current_thread().name

        try:
            handler = get_handler(job.job_type)
            handler.execute(job=job)
            BackgroundRepository.mark_job_completed(
                job,
                thread_name=thread_name,
            )
            logger.info(
                "job_completed job_id=%s type=%s",
                job.pk,
                job.job_type,
            )
        except Exception as exc:
            BackgroundRepository.mark_job_failed(
                job,
                error=str(exc),
                thread_name=thread_name,
            )
            logger.exception(
                "job_failed job_id=%s type=%s error=%s",
                job.pk,
                job.job_type,
                exc,
            )

    @staticmethod
    def execute_claimed(
        *,
        jobs: list[BackgroundJob],
        periodic: PeriodicTask,
    ) -> None:
        if not jobs:
            return

        max_workers = max(1, periodic.max_workers)

        with ThreadPoolExecutor(
            max_workers=max_workers,
            thread_name_prefix="bg-job",
        ) as executor:
            futures = [
                executor.submit(JobExecutorService._run_one, job=job)
                for job in jobs
            ]
            for future in as_completed(futures):
                future.result()
