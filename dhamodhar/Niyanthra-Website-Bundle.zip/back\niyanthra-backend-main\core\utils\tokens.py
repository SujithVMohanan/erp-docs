"""JWT issue/refresh helpers. Registration tokens never grant app access."""

from datetime import timedelta

from django.conf import settings
from rest_framework_simplejwt.exceptions import TokenError
from rest_framework_simplejwt.settings import api_settings
from rest_framework_simplejwt.tokens import (
    AccessToken,
    RefreshToken,
)

from core.utils.ids import encode_id

TOKEN_USE_ACCESS = "access"
TOKEN_USE_REGISTRATION = "registration"

WORKSPACE_CLAIM_KEYS = (
    "company_uid",
    "tenant_uid",
    "db_alias",
    "branch_uid",
)


def _public_id(user) -> str:
    return str(user.public_id)


def _set_claims(token, user, *, token_use: str) -> None:
    token["public_id"] = _public_id(user)
    token["token_use"] = token_use


def _copy_workspace_claims(source, target) -> None:
    for key in WORKSPACE_CLAIM_KEYS:
        value = source.get(key)
        if value is not None:
            target[key] = value


def issue_registration_token(user) -> dict:
    token = AccessToken.for_user(user)
    _set_claims(token, user, token_use=TOKEN_USE_REGISTRATION)
    lifetime = getattr(
        settings,
        "REGISTRATION_TOKEN_LIFETIME",
        timedelta(minutes=30),
    )
    token.set_exp(lifetime=lifetime)

    return {
        "token_type": "Bearer",
        "access": str(token),
    }


def issue_tokens(user) -> dict:
    refresh = RefreshToken.for_user(user)
    _set_claims(refresh, user, token_use=TOKEN_USE_ACCESS)
    access = refresh.access_token
    _set_claims(access, user, token_use=TOKEN_USE_ACCESS)
    return {
        "token_type": "Bearer",
        "access": str(access),
        "refresh": str(refresh),
    }


def issue_workspace_tokens(
    user,
    *,
    company,
    tenant,
    branch=None,
) -> dict:
    refresh = RefreshToken.for_user(user)
    _set_claims(refresh, user, token_use=TOKEN_USE_ACCESS)
    refresh["company_uid"] = encode_id(company.pk)
    refresh["tenant_uid"] = encode_id(tenant.pk)
    refresh["db_alias"] = tenant.db_alias
    if branch is not None:
        refresh["branch_uid"] = encode_id(branch.pk)

    access = refresh.access_token
    _set_claims(access, user, token_use=TOKEN_USE_ACCESS)
    _copy_workspace_claims(refresh, access)

    return {
        "token_type": "Bearer",
        "access": str(access),
        "refresh": str(refresh),
        "profile_completed": True,
    }


def session_for_user(user) -> dict:
    if user.profile_completed and user.is_active:
        return issue_tokens(user)
    return issue_registration_token(user)


def refresh_tokens(refresh_token: str) -> dict:
    refresh = RefreshToken(refresh_token)
    if refresh.get("token_use") == TOKEN_USE_REGISTRATION:
        raise TokenError("Registration tokens cannot be refreshed.")

    access = refresh.access_token
    public_id = refresh.get("public_id")
    if public_id:
        access["public_id"] = public_id
    access["token_use"] = TOKEN_USE_ACCESS
    _copy_workspace_claims(refresh, access)

    payload = {
        "token_type": "Bearer",
        "access": str(access),
        "profile_completed": True,
    }

    if api_settings.ROTATE_REFRESH_TOKENS:
        if api_settings.BLACKLIST_AFTER_ROTATION:
            try:
                refresh.blacklist()
            except AttributeError:
                pass
        refresh.set_jti()
        refresh.set_exp()
        refresh.set_iat()
        if public_id:
            refresh["public_id"] = public_id
        refresh["token_use"] = TOKEN_USE_ACCESS
        _copy_workspace_claims(access, refresh)
        payload["refresh"] = str(refresh)
    else:
        payload["refresh"] = str(refresh)

    return payload


def get_workspace_claims(token) -> dict:
    if token is None or not hasattr(token, "get"):
        return {}

    return {
        key: token.get(key)
        for key in WORKSPACE_CLAIM_KEYS
        if token.get(key) is not None
    }
