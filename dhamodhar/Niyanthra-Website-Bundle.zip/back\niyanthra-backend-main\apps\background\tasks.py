from celery import shared_task

from apps.background.repository import BackgroundRepository
from apps.background.services.dispatcher_service import JobDispatcherService


@shared_task(name="background.dispatch_isolated_jobs")
def dispatch_isolated_jobs() -> dict:
    return JobDispatcherService.dispatch(
        periodic_code=BackgroundRepository.DISPATCH_ISOLATED_CODE,
    )
