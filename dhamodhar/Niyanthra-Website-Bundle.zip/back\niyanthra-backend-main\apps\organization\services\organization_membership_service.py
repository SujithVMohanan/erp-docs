from django.conf import settings
from django.db import (
    IntegrityError,
    transaction,
)
from rest_framework.exceptions import (
    NotFound,
    PermissionDenied,
    ValidationError,
)

from apps.organization.models import OrganizationMembership
from apps.organization.repository import (
    OrganizationMembershipRepository,
    OrganizationRepository,
)
from apps.users.repository import UserRepository
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id
from core.utils.membership_invite import (
    KIND_ORGANIZATION,
    create_membership_invite_token,
    invite_max_age_seconds,
)


class OrganizationMembershipService:

    MANAGER_ROLES = frozenset({"owner", "admin"})
    ROLE_RANK = {
        "employee": 1,
        "admin": 2,
        "owner": 3,
    }

    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})
        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})
        return decoded

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        return list(
            dict.fromkeys(
                OrganizationMembershipService._decode_uid(uid, field="uids")
                for uid in uids
            )
        )

    @staticmethod
    def _resolve_organization(uid: str) -> int:
        organization_id = OrganizationMembershipService._decode_uid(
            uid,
            field="organization_uid",
        )
        if OrganizationRepository.get_by_id(organization_id) is None:
            raise AuthValidationError(
                {"organization_uid": ["Organization not found."]},
                code="ORGANIZATION_NOT_FOUND",
            )
        return organization_id

    @staticmethod
    def _resolve_user(uid: str) -> int:
        user_id = OrganizationMembershipService._decode_uid(
            uid,
            field="user_uid",
        )
        users = list(UserRepository.list_users(user_id=[user_id]))
        if not users:
            raise AuthValidationError(
                {"user_uid": ["User not found."]},
                code="USER_NOT_FOUND",
            )
        return user_id

    @staticmethod
    def _require_org_manager(*, actor, organization_id: int):
        if getattr(actor, "pk", None) is None:
            raise PermissionDenied("Authentication required.")

        membership = OrganizationMembershipRepository.get_conflict(
            organization_id=organization_id,
            user_id=actor.pk,
        )
        if (
            membership is None
            or not membership.is_active
            or membership.role not in OrganizationMembershipService.MANAGER_ROLES
        ):
            raise PermissionDenied(
                "Only organization owners and admins can manage members."
            )
        return membership

    @staticmethod
    def _assert_can_assign_role(*, actor_membership, role: str):
        if actor_membership.role == "owner":
            return
        if role == "owner":
            raise PermissionDenied(
                "Admins cannot assign the owner role."
            )

    @staticmethod
    def _assert_can_manage_target(*, actor_membership, target):
        if actor_membership.role == "owner":
            return
        if target.role == "owner":
            raise PermissionDenied(
                "Admins cannot manage organization owners."
            )

    @staticmethod
    def _assert_not_last_owner(*, membership: OrganizationMembership):
        if membership.role != "owner" or not membership.is_active:
            return
        owner_count = OrganizationMembershipRepository.count_active_owners(
            organization_id=membership.organization_id,
        )
        if owner_count <= 1:
            raise AuthValidationError(
                {"uid": ["Cannot remove or demote the last organization owner."]},
                code="LAST_OWNER_PROTECTED",
            )

    @staticmethod
    def get_my_organizations(*, user, validated_data: dict | None = None):
        if getattr(user, "pk", None) is None:
            raise PermissionDenied("Authentication required.")

        validated_data = validated_data or {}
        name = validated_data.get("name")
        if user.is_superuser:
            return OrganizationRepository.superuser_list(name=name)
        return OrganizationMembershipRepository.list_my_organizations(
            user_id=user.pk,
            name=name,
        )

    @staticmethod
    def get_memberships(*, validated_data: dict, actor=None):
        organization_id = None
        if validated_data.get("organization_uid"):
            organization_id = OrganizationMembershipService._decode_uid(
                validated_data["organization_uid"],
                field="organization_uid",
            )
        else:
            raise AuthValidationError(
                {"organization_uid": ["This field is required."]},
                code="ORGANIZATION_UID_REQUIRED",
            )

        OrganizationMembershipService._require_org_manager(
            actor=actor,
            organization_id=organization_id,
        )

        membership_id = None
        user_id = None
        if validated_data.get("uid"):
            membership_id = [
                OrganizationMembershipService._decode_uid(validated_data["uid"])
            ]
        if validated_data.get("user_uid"):
            user_id = OrganizationMembershipService._decode_uid(
                validated_data["user_uid"],
                field="user_uid",
            )

        return OrganizationMembershipRepository.list_memberships(
            membership_id=membership_id,
            organization_id=organization_id,
            user_id=user_id,
            role=validated_data.get("role"),
            roles=(
                ["owner", "admin"]
                if validated_data.get("audience") == "admin"
                and not validated_data.get("role")
                else (
                    ["employee"]
                    if validated_data.get("audience") == "employee"
                    and not validated_data.get("role")
                    else None
                )
            ),
            is_active=validated_data.get("is_active"),
            email=validated_data.get("email"),
            name=validated_data.get("name"),
        )

    @staticmethod
    def create_membership(*, validated_data: dict, actor=None) -> OrganizationMembership:
        organization_id = OrganizationMembershipService._resolve_organization(
            validated_data["organization_uid"]
        )
        actor_membership = OrganizationMembershipService._require_org_manager(
            actor=actor,
            organization_id=organization_id,
        )
        role = validated_data.get("role") or "employee"
        OrganizationMembershipService._assert_can_assign_role(
            actor_membership=actor_membership,
            role=role,
        )

        user_id = OrganizationMembershipService._resolve_user(
            validated_data["user_uid"]
        )
        if OrganizationMembershipRepository.get_conflict(
            organization_id=organization_id,
            user_id=user_id,
        ):
            raise AuthValidationError(
                {"user_uid": ["This user is already a member of the organization."]},
                code="ORGANIZATION_MEMBERSHIP_EXISTS",
            )
        try:
            with transaction.atomic():
                membership = OrganizationMembershipRepository.create_membership(
                    organization_id=organization_id,
                    user_id=user_id,
                    role=role,
                    is_active=validated_data.get("is_active", True),
                )
        except IntegrityError:
            raise AuthValidationError(
                {"user_uid": ["This user is already a member of the organization."]},
                code="ORGANIZATION_MEMBERSHIP_EXISTS",
            ) from None
        return OrganizationMembershipRepository.get_by_id(membership.pk)

    @staticmethod
    def create_invite(*, validated_data: dict, actor=None) -> dict:
        organization_id = OrganizationMembershipService._resolve_organization(
            validated_data["organization_uid"]
        )
        actor_membership = OrganizationMembershipService._require_org_manager(
            actor=actor,
            organization_id=organization_id,
        )
        role = validated_data.get("role") or "admin"
        if role not in {"owner", "admin", "employee"}:
            raise AuthValidationError(
                {"role": ["Role must be owner, admin, or employee."]},
                code="INVALID_ROLE",
            )
        audience = validated_data.get("audience") or "admin"
        if audience == "admin" and role not in {"owner", "admin"}:
            raise PermissionDenied(
                "Admin invites allow only owner or admin roles."
            )
        if audience == "employee":
            role = "employee"
        OrganizationMembershipService._assert_can_assign_role(
            actor_membership=actor_membership,
            role=role,
        )

        token = create_membership_invite_token(
            kind=KIND_ORGANIZATION,
            organization_id=organization_id,
            role=role,
        )
        expires_in = invite_max_age_seconds()
        base = (getattr(settings, "FRONTEND_BASE_URL", "") or "").rstrip("/")
        path = f"/join?invite={token}"
        return {
            "token": token,
            "kind": KIND_ORGANIZATION,
            "role": role,
            "organization_uid": validated_data["organization_uid"],
            "expires_in_seconds": expires_in,
            "invite_path": path,
            "invite_url": f"{base}{path}" if base else path,
        }

    @staticmethod
    def update_membership(*, validated_data: dict, actor=None) -> OrganizationMembership:
        membership = OrganizationMembershipRepository.get_by_id(
            OrganizationMembershipService._decode_uid(validated_data["uid"])
        )
        if membership is None:
            raise NotFound("Organization membership not found.")

        actor_membership = OrganizationMembershipService._require_org_manager(
            actor=actor,
            organization_id=membership.organization_id,
        )
        OrganizationMembershipService._assert_can_manage_target(
            actor_membership=actor_membership,
            target=membership,
        )

        organization_id = OrganizationMembershipService._resolve_organization(
            validated_data["organization_uid"]
        )
        if organization_id != membership.organization_id:
            raise AuthValidationError(
                {
                    "organization_uid": [
                        "Organization does not match this membership.",
                    ]
                },
                code="ORGANIZATION_MISMATCH",
            )

        user_id = OrganizationMembershipService._resolve_user(
            validated_data["user_uid"]
        )
        role = validated_data.get("role") or membership.role
        OrganizationMembershipService._assert_can_assign_role(
            actor_membership=actor_membership,
            role=role,
        )

        if membership.role == "owner" and role != "owner":
            OrganizationMembershipService._assert_not_last_owner(
                membership=membership,
            )
        if membership.is_active and not validated_data.get(
            "is_active",
            membership.is_active,
        ):
            OrganizationMembershipService._assert_not_last_owner(
                membership=membership,
            )

        if OrganizationMembershipRepository.get_conflict(
            organization_id=organization_id,
            user_id=user_id,
            exclude_id=membership.pk,
        ):
            raise AuthValidationError(
                {"user_uid": ["This user is already a member of the organization."]},
                code="ORGANIZATION_MEMBERSHIP_EXISTS",
            )
        try:
            with transaction.atomic():
                OrganizationMembershipRepository.update_membership(
                    membership=membership,
                    organization_id=organization_id,
                    user_id=user_id,
                    role=role,
                    is_active=validated_data.get("is_active", membership.is_active),
                )
        except IntegrityError:
            raise AuthValidationError(
                {"user_uid": ["This user is already a member of the organization."]},
                code="ORGANIZATION_MEMBERSHIP_EXISTS",
            ) from None
        return OrganizationMembershipRepository.get_by_id(membership.pk)

    @staticmethod
    def delete_memberships(*, validated_data: dict, actor=None) -> dict:
        membership_ids = OrganizationMembershipService._decode_uids(
            validated_data["uids"]
        )
        memberships = list(
            OrganizationMembershipRepository.list_memberships(
                membership_id=membership_ids,
            )
        )
        if not memberships:
            raise NotFound("Organization membership not found.")

        organization_ids = {item.organization_id for item in memberships}
        if len(organization_ids) != 1:
            raise AuthValidationError(
                {"uids": ["All memberships must belong to the same organization."]},
                code="MIXED_ORGANIZATION_MEMBERSHIPS",
            )
        organization_id = next(iter(organization_ids))
        actor_membership = OrganizationMembershipService._require_org_manager(
            actor=actor,
            organization_id=organization_id,
        )

        for membership in memberships:
            OrganizationMembershipService._assert_can_manage_target(
                actor_membership=actor_membership,
                target=membership,
            )
            OrganizationMembershipService._assert_not_last_owner(
                membership=membership,
            )

        deleted = OrganizationMembershipRepository.soft_delete_by_ids(membership_ids)
        if not deleted:
            raise NotFound("Organization membership not found.")
        return {"deleted": deleted}

    @staticmethod
    def toggle_memberships(*, validated_data: dict, actor=None):
        membership_ids = OrganizationMembershipService._decode_uids(
            validated_data["uids"]
        )
        memberships = list(
            OrganizationMembershipRepository.list_memberships(
                membership_id=membership_ids,
            )
        )
        if not memberships:
            raise NotFound("Organization membership not found.")

        organization_ids = {item.organization_id for item in memberships}
        if len(organization_ids) != 1:
            raise AuthValidationError(
                {"uids": ["All memberships must belong to the same organization."]},
                code="MIXED_ORGANIZATION_MEMBERSHIPS",
            )
        organization_id = next(iter(organization_ids))
        actor_membership = OrganizationMembershipService._require_org_manager(
            actor=actor,
            organization_id=organization_id,
        )

        for membership in memberships:
            OrganizationMembershipService._assert_can_manage_target(
                actor_membership=actor_membership,
                target=membership,
            )
            if membership.is_active:
                OrganizationMembershipService._assert_not_last_owner(
                    membership=membership,
                )

        updated = OrganizationMembershipRepository.toggle_active_by_ids(membership_ids)
        if not updated:
            raise NotFound("Organization membership not found.")
        return OrganizationMembershipRepository.list_memberships(
            membership_id=membership_ids
        )
