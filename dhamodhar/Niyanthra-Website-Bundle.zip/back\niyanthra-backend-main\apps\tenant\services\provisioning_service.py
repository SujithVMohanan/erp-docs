from rest_framework.exceptions import ValidationError

from apps.tenant.models import Tenant
from apps.tenant.services.provisioners import get_provisioner


class TenantProvisioningService:

    @staticmethod
    def provision(*, tenant: Tenant) -> Tenant:
        try:
            provisioner = get_provisioner(tenant.tenant_type)
        except ValueError as exc:
            raise ValidationError({"tenant_type": [str(exc)]}) from None

        return provisioner.provision(tenant=tenant)
