from django.test import TestCase
from rest_framework.test import APIClient

from apps.company.models import (
    Branch,
    BranchMembership,
    Company,
    CompanyMembership,
)
from apps.location.models import Country
from apps.organization.models import Organization, OrganizationMembership
from apps.users.models import Users
from core.utils.ids import encode_id
from core.utils.tokens import issue_tokens

PASSWORD = "ValidPassw0rd!"


class BranchApiTests(TestCase):

    def setUp(self):
        self.client = APIClient()
        self.admin = Users.objects.create_user(
            email="admin@example.com",
            password=PASSWORD,
            username="adminuser",
            phone_number="+15551110001",
            is_admin=True,
            profile_completed=True,
        )
        tokens = issue_tokens(self.admin)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")

        self.country = Country.objects.create(name="India", code="IN")
        self.organization = Organization.objects.create(
            name="Branch Org",
            code="BORG",
            legal_name="Branch Org Pvt",
            country=self.country,
        )
        self.company = Company.objects.create(
            name="Branch Co",
            code="BCO",
            organization=self.organization,
            is_active=True,
        )
        self.company_uid = encode_id(self.company.pk)
        OrganizationMembership.objects.create(
            organization=self.organization,
            user=self.admin,
            role=OrganizationMembership.Role.OWNER,
            is_active=True,
        )
        CompanyMembership.objects.create(
            company=self.company,
            user=self.admin,
            role=CompanyMembership.Role.OWNER,
            is_active=True,
        )

    def _create(self, **overrides):
        payload = {
            "name": "Main Branch",
            "code": "MAIN",
            "company_uid": self.company_uid,
            "branch_type": "retail",
            "status": "ACTIVE",
            "email": "main@example.com",
            "phone": "+911234567890",
        }
        payload.update(overrides)
        return self.client.post(
            "/api/company/create-branch/",
            payload,
            format="json",
        )

    def test_create_branch(self):
        response = self._create()
        self.assertEqual(response.status_code, 201)
        data = response.data["data"]
        self.assertEqual(data["code"], "MAIN")
        self.assertEqual(data["name"], "Main Branch")
        self.assertEqual(data["status"], "ACTIVE")
        self.assertEqual(data["company"]["code"], "BCO")
        self.assertTrue(data["uid"])
        self.assertNotIn("id", data)

    def test_create_branch_grants_admin_memberships(self):
        org_admin = Users.objects.create_user(
            email="org-admin@example.com",
            password=PASSWORD,
            username="orgadmin",
            phone_number="+15551110002",
            profile_completed=True,
        )
        company_admin = Users.objects.create_user(
            email="co-admin@example.com",
            password=PASSWORD,
            username="coadmin",
            phone_number="+15551110003",
            profile_completed=True,
        )
        employee = Users.objects.create_user(
            email="employee@example.com",
            password=PASSWORD,
            username="employee",
            phone_number="+15551110004",
            profile_completed=True,
        )
        OrganizationMembership.objects.create(
            organization=self.organization,
            user=org_admin,
            role=OrganizationMembership.Role.ADMIN,
            is_active=True,
        )
        CompanyMembership.objects.create(
            company=self.company,
            user=company_admin,
            role=CompanyMembership.Role.ADMIN,
            is_active=True,
        )
        CompanyMembership.objects.create(
            company=self.company,
            user=employee,
            role=CompanyMembership.Role.EMPLOYEE,
            is_active=True,
        )

        response = self._create()
        self.assertEqual(response.status_code, 201, response.data)
        branch = Branch.objects.get(code="MAIN")

        self.assertTrue(
            OrganizationMembership.objects.filter(
                organization=self.organization,
                user=self.admin,
                role=OrganizationMembership.Role.OWNER,
                is_active=True,
            ).exists()
        )
        self.assertTrue(
            CompanyMembership.objects.filter(
                company=self.company,
                user=self.admin,
                role=CompanyMembership.Role.OWNER,
                is_active=True,
            ).exists()
        )
        for user in (self.admin, org_admin, company_admin):
            self.assertTrue(
                BranchMembership.objects.filter(
                    branch=branch,
                    user=user,
                    role=BranchMembership.Role.MANAGER,
                    is_active=True,
                ).exists()
            )
        self.assertFalse(
            BranchMembership.objects.filter(
                branch=branch,
                user=employee,
            ).exists()
        )

    def test_duplicate_code(self):
        self._create()
        response = self._create(name="Other")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data.get("code"), "BRANCH_CODE_EXISTS")

    def test_list_branches(self):
        self._create()
        response = self.client.get(
            "/api/company/get-branches/",
            {"company_uid": self.company_uid},
        )
        self.assertEqual(response.status_code, 200)
        self.assertGreaterEqual(response.data["data"]["count"], 1)

    def test_update_branch(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.put(
            "/api/company/update-branch/",
            {
                "uid": uid,
                "name": "Main Branch Updated",
                "code": "MAIN",
                "company_uid": self.company_uid,
                "branch_type": "warehouse",
                "status": "ACTIVE",
                "email": "updated@example.com",
                "phone": "+911111111111",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["data"]["name"], "Main Branch Updated")
        self.assertEqual(response.data["data"]["branch_type"], "warehouse")

    def test_toggle_branch_status(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.post(
            "/api/company/inactive-active-branches/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["data"][0]["status"], "INACTIVE")
        branch = Branch.objects.get(code="MAIN")
        self.assertEqual(branch.status, "INACTIVE")

    def test_delete_branch(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.delete(
            "/api/company/delete-branches/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["data"]["deleted"], 1)
        self.assertFalse(Branch.objects.filter(code="MAIN").exists())
