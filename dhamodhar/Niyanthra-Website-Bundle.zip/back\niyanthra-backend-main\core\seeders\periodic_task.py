from core.seeders.base import run_group

GROUP = "periodic_task"


def run() -> dict:
    return run_group(GROUP)
