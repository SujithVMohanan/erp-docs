from django.test import TestCase
from rest_framework.test import APIClient

from apps.company.models import (
    Branch,
    Company,
    CompanyMembership,
)
from apps.location.models import Country
from apps.organization.models import (
    Organization,
    OrganizationMembership,
)
from apps.users.models import Users
from core.utils.ids import (
    decode_id,
    encode_id,
)
from core.utils.tokens import issue_tokens

PASSWORD = "ValidPassw0rd!"


class CompanyMembershipApiTests(TestCase):

    def setUp(self):
        self.client = APIClient()
        self.admin = Users.objects.create_user(
            email="cm-admin@example.com",
            password=PASSWORD,
            username="cmadmin",
            phone_number="+15552220001",
            is_admin=True,
            profile_completed=True,
        )
        self.member = Users.objects.create_user(
            email="cm-member@example.com",
            password=PASSWORD,
            username="cmmember",
            phone_number="+15552220002",
            profile_completed=True,
        )
        tokens = issue_tokens(self.admin)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")

        self.country = Country.objects.create(name="India", code="IN")
        self.organization = Organization.objects.create(
            name="CM Org",
            code="CMORG",
            legal_name="CM Org Pvt",
            country=self.country,
        )
        self.company = Company.objects.create(
            name="CM Co",
            code="CMCO",
            organization=self.organization,
            is_active=True,
        )
        self.company_uid = encode_id(self.company.pk)
        self.user_uid = encode_id(self.member.pk)
        CompanyMembership.objects.create(
            company=self.company,
            user=self.admin,
            role=CompanyMembership.Role.ADMIN,
            is_active=True,
        )

    def _create(self, **overrides):
        payload = {
            "company_uid": self.company_uid,
            "user_uid": self.user_uid,
            "role": "employee",
            "is_active": True,
        }
        payload.update(overrides)
        return self.client.post(
            "/api/company/create-company-membership/",
            payload,
            format="json",
        )

    def test_create_membership(self):
        response = self._create()
        self.assertEqual(response.status_code, 201)
        data = response.data["data"]
        self.assertEqual(data["role"], "employee")
        self.assertTrue(data["is_active"])
        self.assertEqual(data["company"]["code"], "CMCO")
        self.assertEqual(data["user"]["email"], "cm-member@example.com")
        self.assertTrue(data["uid"])
        self.assertNotIn("id", data)
        self.assertTrue(
            OrganizationMembership.objects.filter(
                organization=self.organization,
                user=self.member,
                is_active=True,
            ).exists()
        )
        self.assertEqual(
            OrganizationMembership.objects.filter(user=self.member).count(),
            1,
        )

    def test_company_membership_does_not_open_branches(self):
        branch = Branch.objects.create(
            company=self.company,
            name="HQ",
            code="HQ",
            status="ACTIVE",
        )
        response = self._create()
        self.assertEqual(response.status_code, 201)
        self.assertFalse(
            branch.memberships.filter(user=self.member).exists()
        )

    def test_duplicate_membership(self):
        self._create()
        response = self._create(role="admin")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data.get("code"), "COMPANY_MEMBERSHIP_EXISTS")

    def test_list_memberships(self):
        self._create()
        response = self.client.get(
            "/api/company/get-company-memberships/",
            {"company_uid": self.company_uid},
        )
        self.assertEqual(response.status_code, 200)
        self.assertGreaterEqual(response.data["data"]["count"], 1)

    def test_update_membership(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.put(
            "/api/company/update-company-membership/",
            {
                "uid": uid,
                "company_uid": self.company_uid,
                "user_uid": self.user_uid,
                "role": "admin",
                "is_active": True,
            },
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["data"]["role"], "admin")

    def test_toggle_membership(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.post(
            "/api/company/inactive-active-company-memberships/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.data["data"][0]["is_active"])

    def test_delete_membership(self):
        created = self._create()
        uid = created.data["data"]["uid"]
        response = self.client.delete(
            "/api/company/delete-company-memberships/",
            {"uids": [uid]},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["data"]["deleted"], 1)
        self.assertFalse(
            CompanyMembership.objects.filter(
                company=self.company,
                user=self.member,
            ).exists()
        )

    def test_my_companies_returns_value_label_and_filters(self):
        self._create()
        other_org = Organization.objects.create(
            name="Other Org",
            code="OTORG",
            legal_name="Other Org Pvt",
            country=self.country,
        )
        other = Company.objects.create(
            name="Other Co",
            code="OTCO",
            organization=other_org,
            is_active=True,
        )
        CompanyMembership.objects.create(
            company=other,
            user=self.member,
            role="employee",
            is_active=True,
        )
        tokens = issue_tokens(self.member)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")

        listed = self.client.get("/api/company/get-my-companies/")
        self.assertEqual(listed.status_code, 200)
        self.assertEqual(listed.data["data"]["companies_count"], 2)
        self.assertEqual(
            {decode_id(row["value"]) for row in listed.data["data"]["companies"]},
            {self.company.pk, other.pk},
        )
        self.assertEqual(
            {row["label"] for row in listed.data["data"]["companies"]},
            {"CM Co", "Other Co"},
        )

        by_name = self.client.get(
            "/api/company/get-my-companies/",
            {"name": "CM"},
        )
        self.assertEqual(by_name.data["data"]["companies_count"], 1)
        self.assertEqual(by_name.data["data"]["companies"][0]["label"], "CM Co")

        by_company = self.client.get(
            "/api/company/get-my-companies/",
            {"company_uid": str(self.company.public_id)},
        )
        self.assertEqual(len(by_company.data["data"]["companies"]), 1)
        self.assertEqual(by_company.data["data"]["companies"][0]["label"], "CM Co")
        self.assertEqual(
            decode_id(by_company.data["data"]["companies"][0]["value"]),
            self.company.pk,
        )

        by_org = self.client.get(
            "/api/company/get-my-companies/",
            {"organization_uid": str(self.organization.public_id)},
        )
        self.assertEqual(by_org.data["data"]["companies_count"], 1)
        self.assertEqual(
            decode_id(by_org.data["data"]["companies"][0]["value"]),
            self.company.pk,
        )
