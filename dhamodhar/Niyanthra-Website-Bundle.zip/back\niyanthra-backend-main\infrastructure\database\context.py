import threading

_thread_locals = threading.local()


def set_current_db_alias(alias: str | None) -> None:
    _thread_locals.db_alias = alias


def get_current_db_alias() -> str | None:
    return getattr(_thread_locals, "db_alias", None)


def clear_current_db_alias() -> None:
    if hasattr(_thread_locals, "db_alias"):
        delattr(_thread_locals, "db_alias")
