from django.db.models import (
    BooleanField,
    Case,
    Q,
    Value,
    When,
)
from django.utils import timezone

from apps.users.models import TimeZone


class TimeZoneRepository:

    @staticmethod
    def list_timezones(
        *,
        timezone_id=None,
        code=None,
        name=None,
        is_active=None,
    ):
        filters = Q()
        if timezone_id is not None:
            ids = (
                timezone_id
                if isinstance(timezone_id, (list, tuple, set))
                else [timezone_id]
            )
            filters &= Q(id__in=ids)
        if code:
            filters &= Q(code=code)
        if name:
            filters &= Q(name__icontains=name)
        if is_active is not None:
            filters &= Q(is_active=is_active)
        return TimeZone.objects.only(
            "id",
            "public_id",
            "name",
            "code",
            "utc_offset",
            "is_active",
            "created_at",
            "updated_at",
        ).filter(filters)

    @staticmethod
    def get_by_id(timezone_id: int) -> TimeZone | None:
        return TimeZone.objects.filter(pk=timezone_id).first()

    @staticmethod
    def get_code_conflict(*, code: str, exclude_id=None) -> TimeZone | None:
        qs = TimeZone.objects.filter(code=code)
        if exclude_id is not None:
            qs = qs.exclude(pk=exclude_id)
        return qs.first()

    @staticmethod
    def create_timezone(*, name, code, utc_offset=None, is_active=True) -> TimeZone:
        return TimeZone.objects.create(
            name=name,
            code=code,
            utc_offset=utc_offset,
            is_active=is_active,
        )

    @staticmethod
    def update_timezone(*, tz: TimeZone, name, code, utc_offset, is_active) -> TimeZone:
        tz.name = name
        tz.code = code
        tz.utc_offset = utc_offset
        tz.is_active = is_active
        tz.save(
            update_fields=["name", "code", "utc_offset", "is_active", "updated_at"]
        )
        return tz

    @staticmethod
    def delete_by_ids(ids: list[int]) -> int:
        if not ids:
            return 0
        count, _ = TimeZone.objects.filter(id__in=ids).delete()
        return count

    @staticmethod
    def toggle_active_by_ids(ids: list[int]) -> int:
        if not ids:
            return 0
        return TimeZone.objects.filter(id__in=ids).update(
            is_active=Case(
                When(is_active=True, then=Value(False)),
                default=Value(True),
                output_field=BooleanField(),
            ),
            updated_at=timezone.now(),
        )
