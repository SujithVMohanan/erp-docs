from django.db import (
    IntegrityError,
    transaction,
)
from rest_framework.exceptions import (
    NotFound,
    PermissionDenied,
    ValidationError,
)

from apps.company.models import CompanyMembership
from apps.company.repository import (
    CompanyMembershipRepository,
    CompanyRepository,
)
from apps.users.repository import UserRepository
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class CompanyMembershipService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})

        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})

        return decoded

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        return list(
            dict.fromkeys(
                CompanyMembershipService._decode_uid(uid, field="uids")
                for uid in uids
            )
        )

    @staticmethod
    def _resolve_company(uid: str) -> int:
        company_id = CompanyMembershipService._decode_uid(
            uid,
            field="company_uid",
        )
        if CompanyRepository.get_by_id(company_id) is None:
            raise AuthValidationError(
                {"company_uid": ["Company not found."]},
                code="COMPANY_NOT_FOUND",
            )
        return company_id

    @staticmethod
    def _resolve_user(uid: str) -> int:
        user_id = CompanyMembershipService._decode_uid(
            uid,
            field="user_uid",
        )
        users = list(UserRepository.list_users(user_id=[user_id]))
        if not users:
            raise AuthValidationError(
                {"user_uid": ["User not found."]},
                code="USER_NOT_FOUND",
            )
        return user_id

    @staticmethod
    def _validate_unique(
        *,
        company_id: int,
        user_id: int,
        exclude_id: int | None = None,
    ) -> None:
        if CompanyMembershipRepository.get_conflict(
            company_id=company_id,
            user_id=user_id,
            exclude_id=exclude_id,
        ):
            raise AuthValidationError(
                {
                    "user_uid": [
                        "This user is already a member of the company.",
                    ]
                },
                code="COMPANY_MEMBERSHIP_EXISTS",
            )

    @staticmethod
    def _ensure_organization_membership(*, company_id: int, user_id: int) -> None:
        """A company member also belongs to that company's organization. Once only."""
        company = CompanyRepository.get_by_id(company_id)
        if company is None:
            return
        from apps.users.services.membership_service import MembershipService

        MembershipService.ensure_organization_membership(
            organization_id=company.organization_id,
            user_id=user_id,
            role="employee",
        )

    @staticmethod
    def ensure_membership(
        *,
        company_id: int,
        user_id: int,
        role: str = "employee",
    ) -> CompanyMembership:
        role_rank = {
            "employee": 1,
            "admin": 2,
            "owner": 3,
        }
        requested = role.strip().lower() if role else "employee"
        if requested not in role_rank:
            requested = "employee"

        existing = CompanyMembershipRepository.get_conflict(
            company_id=company_id,
            user_id=user_id,
        )
        if existing is not None:
            current = (existing.role or "employee").strip().lower()
            needs_role_upgrade = (
                role_rank.get(requested, 1) > role_rank.get(current, 1)
            )
            if needs_role_upgrade or not existing.is_active:
                CompanyMembershipRepository.update_membership(
                    membership=existing,
                    company_id=company_id,
                    user_id=user_id,
                    role=requested if needs_role_upgrade else existing.role,
                    is_active=True,
                )
            membership = CompanyMembershipRepository.get_by_id(existing.pk)
            CompanyMembershipService._ensure_organization_membership(
                company_id=company_id,
                user_id=user_id,
            )
            return membership

        membership = CompanyMembershipRepository.create_membership(
            company_id=company_id,
            user_id=user_id,
            role=requested,
            is_active=True,
        )
        CompanyMembershipService._ensure_organization_membership(
            company_id=company_id,
            user_id=user_id,
        )
        return CompanyMembershipRepository.get_by_id(membership.pk)

    @staticmethod
    def get_my_companies(*, user, validated_data: dict | None = None):
        from apps.company.models import Company
        from apps.company.services.workspace_service import WorkspaceService
        from apps.organization.models import Organization

        if getattr(user, "pk", None) is None:
            raise PermissionDenied("Authentication required.")

        validated_data = validated_data or {}
        organization_id = WorkspaceService._resolve_filter_id(
            validated_data.get("organization_uid"),
            model=Organization,
            field="organization_uid",
        )
        company_id = WorkspaceService._resolve_filter_id(
            validated_data.get("company_uid"),
            model=Company,
            field="company_uid",
        )
        name = validated_data.get("name")
        if user.is_superuser:
            return CompanyRepository.superuser_list(
                organization_id=organization_id,
                company_id=company_id,
                name=name,
            )
        return CompanyMembershipRepository.list_my_companies(
            user_id=user.pk,
            organization_id=organization_id,
            company_id=company_id,
            name=name,
        )

    @staticmethod
    def get_memberships(*, validated_data: dict):
        membership_id = None
        company_id = None
        user_id = None

        if validated_data.get("uid"):
            membership_id = [
                CompanyMembershipService._decode_uid(validated_data["uid"])
            ]

        if validated_data.get("company_uid"):
            company_id = CompanyMembershipService._decode_uid(
                validated_data["company_uid"],
                field="company_uid",
            )

        if validated_data.get("user_uid"):
            user_id = CompanyMembershipService._decode_uid(
                validated_data["user_uid"],
                field="user_uid",
            )

        return CompanyMembershipRepository.list_memberships(
            membership_id=membership_id,
            company_id=company_id,
            user_id=user_id,
            role=validated_data.get("role"),
            roles=(
                ["owner", "admin"]
                if validated_data.get("audience") == "admin"
                and not validated_data.get("role")
                else (
                    ["employee"]
                    if validated_data.get("audience") == "employee"
                    and not validated_data.get("role")
                    else None
                )
            ),
            is_active=validated_data.get("is_active"),
            email=validated_data.get("email"),
            name=validated_data.get("name"),
        )

    @staticmethod
    def create_membership(*, validated_data: dict) -> CompanyMembership:
        company_id = CompanyMembershipService._resolve_company(
            validated_data["company_uid"]
        )
        user_id = CompanyMembershipService._resolve_user(
            validated_data["user_uid"]
        )
        CompanyMembershipService._validate_unique(
            company_id=company_id,
            user_id=user_id,
        )

        try:
            with transaction.atomic():
                membership = CompanyMembershipRepository.create_membership(
                    company_id=company_id,
                    user_id=user_id,
                    role=validated_data.get("role") or "employee",
                    is_active=validated_data.get("is_active", True),
                )
                CompanyMembershipService._ensure_organization_membership(
                    company_id=company_id,
                    user_id=user_id,
                )
        except IntegrityError:
            raise AuthValidationError(
                {
                    "user_uid": [
                        "This user is already a member of the company.",
                    ]
                },
                code="COMPANY_MEMBERSHIP_EXISTS",
            ) from None

        return CompanyMembershipRepository.get_by_id(membership.pk)

    @staticmethod
    def update_membership(*, validated_data: dict) -> CompanyMembership:
        membership_id = CompanyMembershipService._decode_uid(
            validated_data["uid"]
        )
        membership = CompanyMembershipRepository.get_by_id(membership_id)
        if membership is None:
            raise NotFound("Company membership not found.")

        company_id = CompanyMembershipService._resolve_company(
            validated_data["company_uid"]
        )
        user_id = CompanyMembershipService._resolve_user(
            validated_data["user_uid"]
        )
        CompanyMembershipService._validate_unique(
            company_id=company_id,
            user_id=user_id,
            exclude_id=membership.pk,
        )

        try:
            with transaction.atomic():
                CompanyMembershipRepository.update_membership(
                    membership=membership,
                    company_id=company_id,
                    user_id=user_id,
                    role=validated_data.get("role") or membership.role,
                    is_active=validated_data.get(
                        "is_active",
                        membership.is_active,
                    ),
                )
                CompanyMembershipService._ensure_organization_membership(
                    company_id=company_id,
                    user_id=user_id,
                )
        except IntegrityError:
            raise AuthValidationError(
                {
                    "user_uid": [
                        "This user is already a member of the company.",
                    ]
                },
                code="COMPANY_MEMBERSHIP_EXISTS",
            ) from None

        return CompanyMembershipRepository.get_by_id(membership.pk)

    @staticmethod
    def delete_memberships(*, validated_data: dict) -> dict:
        membership_ids = CompanyMembershipService._decode_uids(
            validated_data["uids"]
        )
        deleted = CompanyMembershipRepository.soft_delete_by_ids(
            membership_ids
        )
        if not deleted:
            raise NotFound("Company membership not found.")
        return {"deleted": deleted}

    @staticmethod
    def toggle_memberships(*, validated_data: dict):
        membership_ids = CompanyMembershipService._decode_uids(
            validated_data["uids"]
        )
        updated = CompanyMembershipRepository.toggle_active_by_ids(
            membership_ids
        )
        if not updated:
            raise NotFound("Company membership not found.")
        return CompanyMembershipRepository.list_memberships(
            membership_id=membership_ids
        )
