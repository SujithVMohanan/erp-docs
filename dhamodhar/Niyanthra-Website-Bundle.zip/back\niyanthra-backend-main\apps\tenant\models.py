from django.db import models
from django.utils.translation import gettext_lazy as _

from core.database.models import BaseModel


class Tenant(BaseModel):

    class TenantType(models.TextChoices):
        SHARED   = "shared", _("Shared")
        ISOLATED = "isolated", _("Isolated")
        SILO     = "silo", _("Silo")

    class ProvisioningStatus(models.TextChoices):
        PENDING      = "pending", _("Pending")
        PROVISIONING = "provisioning", _("Provisioning")
        ACTIVE       = "active", _("Active")
        FAILED       = "failed", _("Failed")

    name                 = models.CharField(_("Tenant Name"), max_length=255, blank=True, null=True)
    slug                 = models.SlugField(_("Slug"), max_length=255, unique=True)
    tenant_type          = models.CharField(
        _("Tenant Type"),
        max_length=20,
        choices=TenantType.choices,
        default=TenantType.SHARED,
        db_index=True,
    )
    provisioning_status  = models.CharField(
        _("Provisioning Status"),
        max_length=20,
        choices=ProvisioningStatus.choices,
        default=ProvisioningStatus.PENDING,
        db_index=True,
    )
    db_alias             = models.CharField(_("Database Alias"), max_length=100, unique=True)
    celery_queue         = models.CharField(_("Celery Queue"), max_length=100, default="default")
    is_active            = models.BooleanField(default=True, db_index=True)
    provisioned_at       = models.DateTimeField(_("Provisioned At"), blank=True, null=True)
    last_provision_error = models.TextField(_("Last Provision Error"), blank=True, null=True)

    class Meta:
        ordering            = ["id"]
        verbose_name        = _("tenant")
        verbose_name_plural = _("tenants")
        indexes = [
            models.Index(fields=["tenant_type", "provisioning_status"]),
            models.Index(fields=["tenant_type", "is_active"]),
        ]

    def __str__(self):
        return f"{self.name}-{self.slug}"

    @property
    def is_ready(self) -> bool:
        return (
            self.provisioning_status == self.ProvisioningStatus.ACTIVE
            and self.is_active
            and self.deleted_at is None
        )


class TenantDatabase(BaseModel):

    class ProvisioningStatus(models.TextChoices):
        PENDING      = "pending", _("Pending")
        PROVISIONING = "provisioning", _("Provisioning")
        ACTIVE       = "active", _("Active")
        FAILED       = "failed", _("Failed")

    tenant = models.ForeignKey(
        Tenant,
        on_delete=models.CASCADE,
        related_name="databases",
    )
    period              = models.CharField(_("Period"), max_length=9, blank=True, null=True)
    db_alias            = models.CharField(_("Database Alias"), max_length=100, unique=True)
    db_name             = models.CharField(_("Database Name"), max_length=100, blank=True, null=True)
    host                = models.CharField(_("Host"), max_length=255, blank=True, null=True)
    port                = models.PositiveIntegerField(_("Port"), blank=True, null=True)
    # Staging/prod: Secrets Manager reference only — never store password here
    secret_arn          = models.CharField(_("Secret ARN"), max_length=512, blank=True, null=True)
    secret_name         = models.CharField(_("Secret Name"), max_length=255, blank=True, null=True)
    provisioning_status = models.CharField(
        _("Provisioning Status"),
        max_length=20,
        choices=ProvisioningStatus.choices,
        default=ProvisioningStatus.PENDING,
        db_index=True,
    )
    is_active           = models.BooleanField(_("Is Active"), default=True)
    is_current          = models.BooleanField(_("Is Current"), default=False)
    last_error          = models.TextField(_("Last Error"), blank=True, null=True)

    class Meta:
        ordering = ["id"]
        constraints = [
            models.UniqueConstraint(
                fields=["tenant", "period"],
                name="unique_tenant_period",
            ),
        ]
        indexes = [
            models.Index(fields=["tenant", "is_active"]),
            models.Index(fields=["tenant", "period", "is_active", "is_current"]),
            models.Index(fields=["provisioning_status", "is_current"]),
        ]

    def __str__(self):
        return f"{self.tenant.name}-{self.period or self.db_alias}"
