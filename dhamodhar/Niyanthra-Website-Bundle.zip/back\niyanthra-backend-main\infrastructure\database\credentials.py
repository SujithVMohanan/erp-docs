from dataclasses import dataclass

from django.conf import settings

from infrastructure.aws.secrets import SecretsManagerClient


@dataclass(frozen=True)
class DatabaseCredentials:
    host: str
    port: int
    user: str
    password: str
    admin_db: str
    secret_arn: str | None = None
    secret_name: str | None = None


class CredentialResolver:
    """
    Resolve Postgres credentials for ISOLATED / SILO databases.

    Local (ENVIRONMENT=local):
        TENANT_DB_ADMIN_* / TENANT_DB_RUNTIME_* from settings/env.

    Stage / production:
        AWS Secrets Manager via TENANT_DB_*_SECRET_NAME or per-tenant
        secret_arn / secret_name on TenantDatabase.

    SHARED uses SHARED_DB_* (alias `shared`), not the control database.
    This resolver is for ISOLATED / SILO only.
    """

    _REMOTE_ENVIRONMENTS = frozenset(
        {
            "stage",
            "staging",
            "production",
            "prod",
        }
    )

    @staticmethod
    def _is_remote() -> bool:
        environment = getattr(settings, "ENVIRONMENT", "local").lower()
        return environment in CredentialResolver._REMOTE_ENVIRONMENTS

    @staticmethod
    def is_remote() -> bool:
        return CredentialResolver._is_remote()

    @staticmethod
    def _from_secret_dict(
        data: dict,
        *,
        secret_arn: str | None = None,
        secret_name: str | None = None,
    ) -> DatabaseCredentials:
        host = data.get("host") or data.get("hostname")
        user = data.get("username") or data.get("user")
        password = data.get("password")
        port = int(data.get("port") or 5432)
        admin_db = (
            data.get("admin_database")
            or data.get("dbname")
            or data.get("database")
            or "postgres"
        )

        if not host or not user or password is None:
            raise ValueError(
                "Secret must include host, username, and password."
            )

        return DatabaseCredentials(
            host=host,
            port=port,
            user=user,
            password=password,
            admin_db=admin_db,
            secret_arn=secret_arn,
            secret_name=secret_name,
        )

    @staticmethod
    def _from_secrets_manager(
        *,
        secret_arn: str | None = None,
        secret_name: str | None = None,
        default_secret_name: str = "",
    ) -> DatabaseCredentials:
        secret_id = secret_arn or secret_name or default_secret_name

        if not secret_id:
            raise ValueError(
                "No secret_arn, secret_name, or default secret configured. "
                "Set TENANT_DB_ADMIN_SECRET_NAME / "
                "TENANT_DB_RUNTIME_SECRET_NAME on stage/production."
            )

        client = SecretsManagerClient()
        data = client.get_secret_dict(secret_id=secret_id)

        return CredentialResolver._from_secret_dict(
            data,
            secret_arn=secret_arn or None,
            secret_name=secret_name or default_secret_name or None,
        )

    @staticmethod
    def _from_local_admin() -> dict:
        admin = getattr(settings, "TENANT_DB_ADMIN", None) or {}
        host = admin.get("HOST") or ""
        user = admin.get("USER") or ""
        password = admin.get("PASSWORD")
        if not host or not user or password is None:
            raise ValueError(
                "Local tenant credentials missing. "
                "Set TENANT_DB_ADMIN_HOST, TENANT_DB_ADMIN_USER, "
                "and TENANT_DB_ADMIN_PASSWORD."
            )
        return admin

    @staticmethod
    def resolve(
        *,
        secret_arn: str | None = None,
        secret_name: str | None = None,
    ) -> DatabaseCredentials:
        """Runtime (app) credentials for an isolated/silo database."""
        if CredentialResolver._is_remote():
            return CredentialResolver._from_secrets_manager(
                secret_arn=secret_arn,
                secret_name=secret_name,
                default_secret_name=getattr(
                    settings,
                    "TENANT_DB_RUNTIME_SECRET_NAME",
                    "",
                ),
            )

        admin = CredentialResolver._from_local_admin()
        return DatabaseCredentials(
            host=admin["HOST"],
            port=int(admin.get("PORT") or 5432),
            user=settings.TENANT_DB_RUNTIME_USER,
            password=settings.TENANT_DB_RUNTIME_PASSWORD,
            admin_db=admin.get("NAME") or "postgres",
        )

    @staticmethod
    def admin_credentials() -> DatabaseCredentials:
        """Admin credentials used for CREATE DATABASE."""
        if CredentialResolver._is_remote():
            return CredentialResolver._from_secrets_manager(
                default_secret_name=getattr(
                    settings,
                    "TENANT_DB_ADMIN_SECRET_NAME",
                    "",
                ),
            )

        admin = CredentialResolver._from_local_admin()
        return DatabaseCredentials(
            host=admin["HOST"],
            port=int(admin.get("PORT") or 5432),
            user=admin["USER"],
            password=admin["PASSWORD"],
            admin_db=admin.get("NAME") or "postgres",
        )
