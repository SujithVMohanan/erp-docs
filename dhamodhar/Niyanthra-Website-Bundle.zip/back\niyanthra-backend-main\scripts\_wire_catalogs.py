"""Wire CompanyType/BusinessType CRUD into company app + TimeZone + Access mount."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def append_once(path: Path, marker: str, content: str) -> None:
    text = path.read_text(encoding="utf-8")
    if marker in text:
        print("skip", path.name, marker)
        return
    path.write_text(text.rstrip() + "\n\n" + content.lstrip("\n"), encoding="utf-8")
    print("appended", path.name, marker)


# serializers
append_once(
    ROOT / "apps/company/serializer.py",
    "CreateCompanyTypeSerializer",
    '''
class CreateCompanyTypeSerializer(serializers.Serializer):
    name      = serializers.CharField(max_length=100, trim_whitespace=True)
    code      = serializers.CharField(max_length=50, trim_whitespace=True)
    is_active = serializers.BooleanField(required=False, default=True)

    def validate_code(self, value):
        normalized = value.strip().upper()
        if not normalized:
            raise serializers.ValidationError("This field may not be blank.")
        return normalized


class UpdateCompanyTypeSerializer(CreateCompanyTypeSerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetCompanyTypesQuerySerializer(serializers.Serializer):
    uid       = serializers.CharField(required=False, allow_blank=True)
    code      = serializers.CharField(required=False, allow_blank=True, max_length=50)
    name      = serializers.CharField(required=False, allow_blank=True, max_length=100)
    is_active = serializers.BooleanField(required=False, allow_null=True)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["code"] = (attrs.get("code") or "").strip().upper() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        if "is_active" not in attrs:
            attrs["is_active"] = None
        return attrs


class CompanyTypeUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique, seen = [], set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one company type.")
        return unique


class CreateBusinessTypeSerializer(CreateCompanyTypeSerializer):
    pass


class UpdateBusinessTypeSerializer(UpdateCompanyTypeSerializer):
    pass


class GetBusinessTypesQuerySerializer(GetCompanyTypesQuerySerializer):
    pass


class BusinessTypeUidsSerializer(CompanyTypeUidsSerializer):
    def validate_uids(self, value):
        unique, seen = [], set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one business type.")
        return unique
''',
)

# schemas
schemas = ROOT / "apps/company/schemas.py"
st = schemas.read_text(encoding="utf-8")
if "CompanyType" not in st:
    st = st.replace(
        "from apps.company.models import (\n    Branch,\n    BranchMembership,\n    Company,\n    CompanyMembership,\n)",
        "from apps.company.models import (\n    Branch,\n    BranchMembership,\n    BusinessType,\n    Company,\n    CompanyMembership,\n    CompanyType,\n)",
    )
    schemas.write_text(st, encoding="utf-8")

append_once(
    schemas,
    "GetCompanyTypesApiSchema",
    '''
class GetCompanyTypesApiSchema(serializers.ModelSerializer):
    uid = serializers.SerializerMethodField()

    class Meta:
        model = CompanyType
        fields = [
            "uid",
            "public_id",
            "name",
            "code",
            "is_active",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data


class GetBusinessTypesApiSchema(serializers.ModelSerializer):
    uid = serializers.SerializerMethodField()

    class Meta:
        model = BusinessType
        fields = [
            "uid",
            "public_id",
            "name",
            "code",
            "is_active",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields

    def get_uid(self, instance) -> str:
        return encode_id(instance.pk)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        for key, value in data.items():
            if value is None:
                data[key] = ""
        return data
''',
)

# Compact catalog views module (keeps company/views.py smaller)
(ROOT / "apps/company/catalog_views.py").write_text(
    '''
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated

from apps.company.schemas import (
    GetBusinessTypesApiSchema,
    GetCompanyTypesApiSchema,
)
from apps.company.serializer import (
    BusinessTypeUidsSerializer,
    CompanyTypeUidsSerializer,
    CreateBusinessTypeSerializer,
    CreateCompanyTypeSerializer,
    GetBusinessTypesQuerySerializer,
    GetCompanyTypesQuerySerializer,
    UpdateBusinessTypeSerializer,
    UpdateCompanyTypeSerializer,
)
from apps.company.services.catalog_service import (
    BusinessTypeService,
    CompanyTypeService,
)
from core.pagination import RestPagination
from core.permissions import (
    IsAppAuthenticated,
    IsPlatformAdmin,
)
from core.responses import ResponseInfo
from core.utils.exceptions import ExceptionHandler


def _make_catalog_views(*, tag, schema, query_ser, create_ser, update_ser, uids_ser, service, label):
    class Base:
        response_schema = schema

        def handle_exception_response(self, exc, request):
            return ExceptionHandler.handle(exc, request=request, view=self)

    class GetView(Base, generics.ListAPIView):
        serializer_class = schema
        query_serializer_class = query_ser
        pagination_class = RestPagination
        permission_classes = [IsAuthenticated, IsAppAuthenticated]

        @swagger_auto_schema(
            tags=[tag],
            manual_parameters=[
                openapi.Parameter("uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
                openapi.Parameter("code", openapi.IN_QUERY, type=openapi.TYPE_STRING),
                openapi.Parameter("name", openapi.IN_QUERY, type=openapi.TYPE_STRING),
                openapi.Parameter("is_active", openapi.IN_QUERY, type=openapi.TYPE_BOOLEAN),
            ],
            operation_summary=f"Get {label}",
        )
        def get(self, request, *args, **kwargs):
            try:
                return super().get(request, *args, **kwargs)
            except Exception as exc:
                return self.handle_exception_response(exc, request)

        def get_queryset(self):
            query = self.query_serializer_class(data=self.request.query_params)
            query.is_valid(raise_exception=True)
            return service.list_items(validated_data=query.validated_data)

    class CreateView(Base, generics.CreateAPIView):
        permission_classes = [IsAuthenticated, IsAppAuthenticated, IsPlatformAdmin]
        serializer_class = create_ser

        @swagger_auto_schema(
            request_body=create_ser,
            tags=[tag],
            operation_summary=f"Create {label}",
        )
        def post(self, request, *args, **kwargs):
            try:
                serializer = self.get_serializer(data=request.data)
                if not serializer.is_valid():
                    return ResponseInfo.validation_error(serializer.errors)
                item = service.create_item(validated_data=serializer.validated_data)
                return ResponseInfo.created(
                    self.response_schema(item).data,
                    message=f"{label} created successfully.",
                )
            except Exception as exc:
                return self.handle_exception_response(exc, request)

    class UpdateView(Base, generics.GenericAPIView):
        permission_classes = [IsAuthenticated, IsAppAuthenticated, IsPlatformAdmin]
        serializer_class = update_ser

        @swagger_auto_schema(
            request_body=update_ser,
            tags=[tag],
            operation_summary=f"Update {label}",
        )
        def put(self, request, *args, **kwargs):
            try:
                serializer = self.get_serializer(data=request.data)
                if not serializer.is_valid():
                    return ResponseInfo.validation_error(serializer.errors)
                item = service.update_item(validated_data=serializer.validated_data)
                return ResponseInfo.ok(
                    self.response_schema(item).data,
                    message=f"{label} updated successfully.",
                )
            except Exception as exc:
                return self.handle_exception_response(exc, request)

    class DeleteView(Base, generics.GenericAPIView):
        permission_classes = [IsAuthenticated, IsAppAuthenticated, IsPlatformAdmin]
        serializer_class = uids_ser

        @swagger_auto_schema(
            request_body=uids_ser,
            tags=[tag],
            operation_summary=f"Delete {label}",
        )
        def delete(self, request, *args, **kwargs):
            try:
                serializer = self.get_serializer(data=request.data)
                if not serializer.is_valid():
                    return ResponseInfo.validation_error(serializer.errors)
                payload = service.delete_items(validated_data=serializer.validated_data)
                return ResponseInfo.ok(
                    payload,
                    message=f"{label} deleted successfully.",
                )
            except Exception as exc:
                return self.handle_exception_response(exc, request)

    class ToggleView(Base, generics.GenericAPIView):
        permission_classes = [IsAuthenticated, IsAppAuthenticated, IsPlatformAdmin]
        serializer_class = uids_ser

        @swagger_auto_schema(
            request_body=uids_ser,
            tags=[tag],
            operation_summary=f"Toggle {label} active status",
        )
        def post(self, request, *args, **kwargs):
            try:
                serializer = self.get_serializer(data=request.data)
                if not serializer.is_valid():
                    return ResponseInfo.validation_error(serializer.errors)
                items = service.toggle_items(validated_data=serializer.validated_data)
                return ResponseInfo.ok(
                    self.response_schema(items, many=True).data,
                    message=f"{label} status updated successfully.",
                )
            except Exception as exc:
                return self.handle_exception_response(exc, request)

    return GetView, CreateView, UpdateView, DeleteView, ToggleView


(
    GetCompanyTypesApiView,
    CreateCompanyTypeApiView,
    UpdateCompanyTypeApiView,
    DeleteCompanyTypesApiView,
    InactiveActiveCompanyTypesApiView,
) = _make_catalog_views(
    tag="Company Types",
    schema=GetCompanyTypesApiSchema,
    query_ser=GetCompanyTypesQuerySerializer,
    create_ser=CreateCompanyTypeSerializer,
    update_ser=UpdateCompanyTypeSerializer,
    uids_ser=CompanyTypeUidsSerializer,
    service=CompanyTypeService,
    label="company type",
)

(
    GetBusinessTypesApiView,
    CreateBusinessTypeApiView,
    UpdateBusinessTypeApiView,
    DeleteBusinessTypesApiView,
    InactiveActiveBusinessTypesApiView,
) = _make_catalog_views(
    tag="Business Types",
    schema=GetBusinessTypesApiSchema,
    query_ser=GetBusinessTypesQuerySerializer,
    create_ser=CreateBusinessTypeSerializer,
    update_ser=UpdateBusinessTypeSerializer,
    uids_ser=BusinessTypeUidsSerializer,
    service=BusinessTypeService,
    label="business type",
)
'''.lstrip("\n"),
    encoding="utf-8",
)
print("wrote catalog_views.py")

# Patch company urls
urls = ROOT / "apps/company/urls.py"
ut = urls.read_text(encoding="utf-8")
if "get-company-types" not in ut:
    ut = ut.replace(
        "from apps.company.views import (",
        "from apps.company.catalog_views import (\n"
        "    CreateBusinessTypeApiView,\n"
        "    CreateCompanyTypeApiView,\n"
        "    DeleteBusinessTypesApiView,\n"
        "    DeleteCompanyTypesApiView,\n"
        "    GetBusinessTypesApiView,\n"
        "    GetCompanyTypesApiView,\n"
        "    InactiveActiveBusinessTypesApiView,\n"
        "    InactiveActiveCompanyTypesApiView,\n"
        "    UpdateBusinessTypeApiView,\n"
        "    UpdateCompanyTypeApiView,\n"
        ")\n"
        "from apps.company.views import (",
    )
    ut = ut.rstrip().rstrip("]") + ''',
    path("get-company-types/", GetCompanyTypesApiView.as_view(), name="get-company-types"),
    path("create-company-type/", CreateCompanyTypeApiView.as_view(), name="create-company-type"),
    path("update-company-type/", UpdateCompanyTypeApiView.as_view(), name="update-company-type"),
    path("delete-company-types/", DeleteCompanyTypesApiView.as_view(), name="delete-company-types"),
    path(
        "inactive-active-company-types/",
        InactiveActiveCompanyTypesApiView.as_view(),
        name="inactive-active-company-types",
    ),
    path("get-business-types/", GetBusinessTypesApiView.as_view(), name="get-business-types"),
    path("create-business-type/", CreateBusinessTypeApiView.as_view(), name="create-business-type"),
    path("update-business-type/", UpdateBusinessTypeApiView.as_view(), name="update-business-type"),
    path("delete-business-types/", DeleteBusinessTypesApiView.as_view(), name="delete-business-types"),
    path(
        "inactive-active-business-types/",
        InactiveActiveBusinessTypesApiView.as_view(),
        name="inactive-active-business-types",
    ),
]
'''
    urls.write_text(ut, encoding="utf-8")
    print("patched company urls")
else:
    print("company urls already have catalogs")

# Mount access in config urls
cfg = ROOT / "config/urls.py"
ct = cfg.read_text(encoding="utf-8")
if 'path("access/"' not in ct:
    ct = ct.replace(
        'path("location/", include("apps.location.urls")),',
        'path("location/", include("apps.location.urls")),\n'
        '                path("access/", include("apps.access.urls")),',
    )
    cfg.write_text(ct, encoding="utf-8")
    print("mounted access urls")
else:
    print("access already mounted")

print("done wire catalogs")
