from core.exceptions.auth import AuthFailed
from core.providers.identity import SocialIdentity

__all__ = ["SocialIdentity", "verify_social_token"]


def verify_social_token(
    *,
    provider    : str,
    id_token    : str,
    nonce       : str | None = None,
    
) -> SocialIdentity:
    if provider == "google":
        from core.providers.google import verify_google_token
        return verify_google_token(
                id_token    = id_token,
                nonce       = nonce
                )
    
    raise AuthFailed(
            "Unsupported auth provider.", 
            code="UNSUPPORTED_PROVIDER"
            )
