"""Shared statuses, permission names, and choices."""
