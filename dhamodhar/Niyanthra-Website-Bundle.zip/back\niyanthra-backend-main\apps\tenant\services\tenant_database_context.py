from django.conf import settings

from apps.tenant.models import Tenant
from apps.tenant.repository import TenantRepository
from infrastructure.database.context import (
    clear_current_db_alias,
    get_current_db_alias,
    set_current_db_alias,
)
from infrastructure.database.loader import TenantConnectionLoader


class TenantDatabaseContext:

    @staticmethod
    def activate(*, tenant: Tenant) -> str | None:
        """
        Bind the data-plane database for this tenant.

        SHARED  → settings.SHARED_DB_ALIAS (never default)
        ISOLATED / SILO → that tenant's db_alias
        Not ready → no alias. Do not fall back to the control database.
        """
        if not tenant.is_ready:
            clear_current_db_alias()
            return None

        if tenant.tenant_type == Tenant.TenantType.SHARED:
            alias = settings.SHARED_DB_ALIAS
            set_current_db_alias(alias)
            return alias

        if tenant.db_alias == "default":
            clear_current_db_alias()
            return None

        if not TenantConnectionLoader.ensure_alias(tenant.db_alias):
            current_db = TenantRepository.get_current_database(tenant)
            if (
                current_db
                and current_db.db_name
                and current_db.host
                and current_db.port
            ):
                TenantConnectionLoader.register_tenant_database(
                    db_alias=tenant.db_alias,
                    db_name=current_db.db_name,
                    host=current_db.host,
                    port=current_db.port,
                    secret_arn=current_db.secret_arn,
                    secret_name=current_db.secret_name,
                )

        set_current_db_alias(tenant.db_alias)
        return tenant.db_alias

    @staticmethod
    def clear() -> None:
        from core.tenant import clear_current_tenant

        clear_current_tenant()
        clear_current_db_alias()

    @staticmethod
    def current() -> str | None:
        return get_current_db_alias()
