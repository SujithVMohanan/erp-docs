from django.urls import path

from apps.sales.views import (
    CreateSaleApiView,
    DeleteSalesApiView,
    GetSalesApiView,
    UpdateSaleApiView,
)

app_name = "sales"

urlpatterns = [
    path("get-sales/", GetSalesApiView.as_view(), name="get-sales"),
    path("create-sale/", CreateSaleApiView.as_view(), name="create-sale"),
    path("update-sale/", UpdateSaleApiView.as_view(), name="update-sale"),
    path("delete-sales/", DeleteSalesApiView.as_view(), name="delete-sales"),
]
