"""Shared platform code used by more than one app. No company or sales workflows."""
