import uuid

from rest_framework.exceptions import (
    NotFound,
    PermissionDenied,
    ValidationError,
)

from apps.company.models import Company
from apps.company.repository import CompanyRepository
from apps.organization.models import Organization
from apps.tenant.models import Tenant
from core.utils.ids import (
    decode_id,
    encode_id,
)
from core.utils.tokens import issue_workspace_tokens


class WorkspaceService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except (TypeError, ValueError):
            raise ValidationError({field: ["Invalid id."]}) from None

        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})

        return decoded

    @staticmethod
    def _company_payload(company, *, role: str | None = None) -> dict:
        tenant = company.tenant
        tenant_ready = bool(tenant and tenant.is_ready)
        payload = {
            "uid": encode_id(company.pk),
            "public_id": str(company.public_id),
            "name": company.name or "",
            "code": company.code or "",
            "tenant_ready": tenant_ready,
            "tenant": (
                {
                    "uid": encode_id(tenant.pk),
                    "public_id": str(tenant.public_id),
                    "name": tenant.name or "",
                    "tenant_type": tenant.tenant_type,
                    "is_ready": tenant_ready,
                }
                if tenant
                else None
            ),
        }
        if role is not None:
            payload["role"] = role or ""
        return payload

    @staticmethod
    def list_my_companies(*, user) -> list[dict]:
        memberships = CompanyRepository.list_accessible_companies_for_user(
            user_id=user.pk
        )
        return [
            WorkspaceService._company_payload(
                membership.company,
                role=membership.role,
            )
            for membership in memberships
        ]

    @staticmethod
    def _resolve_filter_id(raw: str | None, *, model, field: str) -> int | None:
        if not raw:
            return None
        try:
            decoded = decode_id(raw)
        except (TypeError, ValueError):
            decoded = None
        if isinstance(decoded, int):
            return decoded
        try:
            parsed = uuid.UUID(raw)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]}) from None
        row = model.objects.filter(public_id=parsed).only("id").first()
        if row is None:
            return -1
        return row.pk

    @staticmethod
    def list_my_company_options(*, user, validated_data: dict):
        organization_id = WorkspaceService._resolve_filter_id(
            validated_data.get("organization_uid"),
            model=Organization,
            field="organization_uid",
        )
        company_id = WorkspaceService._resolve_filter_id(
            validated_data.get("company_uid"),
            model=Company,
            field="company_uid",
        )
        name = validated_data.get("name")
        return CompanyRepository.visible_companies(
            user=user,
            organization_id=organization_id,
            company_id=company_id,
            name=name,
        ).only("id", "name")

    @staticmethod
    def list_my_branch_options(*, user, validated_data: dict):
        from apps.company.models import Branch

        company_id = WorkspaceService._resolve_filter_id(
            validated_data.get("company_uid"),
            model=Company,
            field="company_uid",
        )
        branch_id = WorkspaceService._resolve_filter_id(
            validated_data.get("branch_uid"),
            model=Branch,
            field="branch_uid",
        )
        name = validated_data.get("name")
        if user.is_admin:
            return CompanyRepository.list_branch_options(
                company_id=company_id,
                branch_id=branch_id,
                name=name,
            )
        return CompanyRepository.list_accessible_branches_for_company(
            user_id=user.pk,
            company_id=company_id,
            branch_id=branch_id,
            name=name,
        )

    @staticmethod
    def select_company(*, user, validated_data: dict, company=None) -> dict:
        company_id = WorkspaceService._decode_uid(
            validated_data["company_uid"],
            field="company_uid",
        )

        if company is None or company.pk != company_id:
            if user.is_superuser:
                company = CompanyRepository.get_company_for_superuser(
                    company_id=company_id,
                )
                if company is None:
                    raise NotFound("Company not found.")
            else:
                company = CompanyRepository.get_company_for_member(
                    user_id=user.pk,
                    company_id=company_id,
                )
                if company is None:
                    raise PermissionDenied("You do not have access to this company.")

        tenant = company.tenant
        if tenant is None:
            raise ValidationError(
                {"company_uid": ["Company has no tenant assigned."]}
            )

        if not tenant.is_ready:
            raise PermissionDenied("Tenant is not ready.")

        tokens = issue_workspace_tokens(
            user,
            company=company,
            tenant=tenant,
        )

        from apps.company.services.workspace_context_service import (
            WorkspaceContextService,
        )

        WorkspaceContextService.remember_access(
            user_id=user.pk,
            company_id=company.pk,
            tenant=tenant,
        )

        return {
            "token_type": tokens["token_type"],
            "access": tokens["access"],
            "refresh": tokens["refresh"],
        }

    @staticmethod
    def _login_organizations(*, user) -> list[dict]:
        from apps.organization.models import OrganizationMembership

        rows = (
            OrganizationMembership.objects
            .filter(
                user_id=user.pk,
                is_active=True,
                organization__is_active=True,
            )
            .values("organization_id", "organization__name", "role")
            .order_by("organization__name")
        )
        seen = set()
        organizations = []
        for row in rows:
            organization_id = row["organization_id"]
            if organization_id in seen:
                continue
            seen.add(organization_id)
            organizations.append({
                "value": encode_id(organization_id),
                "label": row["organization__name"] or "",
                "role": row["role"] or "",
            })
        return organizations

    @staticmethod
    def build_login_workspace(*, user, tokens: dict) -> dict:
        
        return {
            **tokens,
            "scope": "workspace",
        }

    @staticmethod
    def list_company_directory(*, user, validated_data: dict):
        organization_id = WorkspaceService._resolve_filter_id(
            validated_data.get("organization_uid"),
            model=Organization,
            field="organization_uid",
        )
        return CompanyRepository.company_directory(
            user=user,
            organization_id=organization_id,
            name=validated_data.get("name"),
        )
