from django.db import models
from django.db.models import Q
from django.utils.translation import gettext_lazy as _

from core.database.constraints import alive_unique
from core.database.models import TenantScopedModel


class Warehouse(TenantScopedModel):

    company_id    = models.PositiveBigIntegerField(_("company id"), db_index=True)
    branch_id     = models.PositiveBigIntegerField(_("branch id"), db_index=True)
    name          = models.CharField(_("name"), max_length=150)
    code          = models.CharField(_("code"), max_length=50, blank=True, default="")
    name_custom   = models.BooleanField(_("custom name"), default=False)
    is_default    = models.BooleanField(_("default"), default=True)
    status        = models.CharField(_("status"), max_length=30, default="ACTIVE")

    class Meta:
        db_table = "warehouses"
        verbose_name = _("warehouse")
        verbose_name_plural = _("warehouses")
        ordering = ("name", "id")
        constraints = [
            alive_unique(
                ["tenant_id", "company_id", "branch_id"],
                "warehouse_branch_alive_uniq",
            ),
        ]

    def __str__(self):
        return self.name


class Product(TenantScopedModel):

    company_id    = models.PositiveBigIntegerField(_("company id"), db_index=True)
    sku           = models.CharField(_("sku"), max_length=100)
    name          = models.CharField(_("name"), max_length=255)
    name_key      = models.CharField(_("name key"), max_length=255, db_index=True)
    uom_code      = models.CharField(_("unit"), max_length=10, default="PCS")
    hsn_code      = models.CharField(_("hsn"), max_length=20, blank=True, default="")
    tax_rate_id = models.PositiveBigIntegerField(
        _("tax rate id"),
        null=True,
        blank=True,
    )
    tax_percent = models.DecimalField(
        _("tax percent"),
        max_digits=8,
        decimal_places=4,
        default=0,
    )
    cost_price = models.DecimalField(
        _("cost price"),
        max_digits=18,
        decimal_places=4,
        default=0,
    )
    selling_price = models.DecimalField(
        _("selling price"),
        max_digits=18,
        decimal_places=4,
        default=0,
    )
    track_stock = models.BooleanField(_("track stock"), default=True)
    is_active = models.BooleanField(_("active"), default=True)

    class Meta:
        db_table = "products"
        verbose_name = _("product")
        verbose_name_plural = _("products")
        ordering = ("name", "id")
        indexes = [
            models.Index(fields=["tenant_id", "company_id", "name_key"]),
        ]
        constraints = [
            alive_unique(
                ["tenant_id", "company_id", "sku"],
                "product_sku_alive_uniq",
            ),
        ]

    def __str__(self):
        return f"{self.sku} {self.name}"


class StockDocument(TenantScopedModel):

    class DocType(models.TextChoices):
        OPENING       = "OPENING", _("Opening")
        RECEIPT       = "RECEIPT", _("Receipt")
        ADJUSTMENT    = "ADJUSTMENT", _("Adjustment")
        TRANSFER      = "TRANSFER", _("Transfer")

    class Status(models.TextChoices):
        POSTED = "POSTED", _("Posted")

    company_id    = models.PositiveBigIntegerField(_("company id"), db_index=True)
    doc_type      = models.CharField(_("type"), max_length=20, choices=DocType.choices)
    doc_number    = models.CharField(_("number"), max_length=30)
    client_ref = models.CharField(
        _("client reference"),
        max_length=100,
        null=True,
        blank=True,
    )
    doc_date = models.DateField(_("date"))
    status = models.CharField(
        _("status"),
        max_length=20,
        choices=Status.choices,
        default=Status.POSTED,
    )
    warehouse = models.ForeignKey(
        Warehouse,
        on_delete=models.PROTECT,
        related_name="documents",
    )
    to_warehouse = models.ForeignKey(
        Warehouse,
        on_delete=models.PROTECT,
        related_name="incoming_documents",
        null=True,
        blank=True,
    )
    notes = models.CharField(_("notes"), max_length=255, blank=True, default="")

    class Meta:
        db_table = "stock_documents"
        verbose_name = _("stock document")
        verbose_name_plural = _("stock documents")
        ordering = ("-doc_date", "-id")
        indexes = [
            models.Index(fields=["tenant_id", "company_id", "doc_type", "doc_date"]),
        ]
        constraints = [
            alive_unique(
                ["tenant_id", "company_id", "doc_number"],
                "stock_doc_number_alive_uniq",
            ),
            alive_unique(
                ["tenant_id", "company_id", "client_ref"],
                "stock_doc_client_ref_alive_uniq",
                client_ref__isnull=False,
            ),
        ]

    def __str__(self):
        return self.doc_number


class StockDocumentLine(TenantScopedModel):

    class Direction(models.TextChoices):
        IN  = "IN", _("In")
        OUT = "OUT", _("Out")

    company_id = models.PositiveBigIntegerField(_("company id"), db_index=True)
    document = models.ForeignKey(
        StockDocument,
        on_delete=models.PROTECT,
        related_name="lines",
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
        related_name="document_lines",
    )
    quantity = models.DecimalField(_("quantity"), max_digits=18, decimal_places=4)
    direction = models.CharField(
        _("direction"),
        max_length=3,
        choices=Direction.choices,
    )
    unit_cost = models.DecimalField(
        _("unit cost"),
        max_digits=18,
        decimal_places=4,
        default=0,
    )

    class Meta:
        db_table = "stock_document_lines"
        ordering = ("id",)

    def __str__(self):
        return f"{self.document_id}:{self.product_id}"


class StockSummary(TenantScopedModel):

    company_id = models.PositiveBigIntegerField(_("company id"), db_index=True)
    warehouse = models.ForeignKey(
        Warehouse,
        on_delete=models.PROTECT,
        related_name="summaries",
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
        related_name="summaries",
    )
    qty_on_hand = models.DecimalField(
        _("on hand"),
        max_digits=18,
        decimal_places=4,
        default=0,
    )
    qty_reserved = models.DecimalField(
        _("reserved"),
        max_digits=18,
        decimal_places=4,
        default=0,
    )

    class Meta:
        db_table = "stock_summaries"
        ordering = ("id",)
        constraints = [
            alive_unique(
                ["tenant_id", "company_id", "warehouse", "product"],
                "stock_summary_alive_uniq",
            ),
            models.CheckConstraint(
                condition=Q(qty_on_hand__gte=0),
                name="stock_on_hand_nonneg",
            ),
            models.CheckConstraint(
                condition=Q(qty_reserved__gte=0),
                name="stock_reserved_nonneg",
            ),
        ]

    def __str__(self):
        return f"{self.warehouse_id}:{self.product_id}"


class StockLedger(TenantScopedModel):

    class Movement(models.TextChoices):
        OPENING       = "OPENING", _("Opening")
        RECEIPT       = "RECEIPT", _("Receipt")
        ISSUE         = "ISSUE", _("Issue")
        ADJUSTMENT    = "ADJUSTMENT", _("Adjustment")
        TRANSFER_IN   = "TRANSFER_IN", _("Transfer in")
        TRANSFER_OUT  = "TRANSFER_OUT", _("Transfer out")
        RESERVE       = "RESERVE", _("Reserve")
        RELEASE       = "RELEASE", _("Release")

    company_id = models.PositiveBigIntegerField(_("company id"), db_index=True)
    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
        related_name="ledger_entries",
    )
    warehouse = models.ForeignKey(
        Warehouse,
        on_delete=models.PROTECT,
        related_name="ledger_entries",
    )
    document = models.ForeignKey(
        StockDocument,
        on_delete=models.PROTECT,
        related_name="ledger_entries",
        null=True,
        blank=True,
    )
    movement = models.CharField(
        _("movement"),
        max_length=20,
        choices=Movement.choices,
    )
    qty_delta = models.DecimalField(_("quantity change"), max_digits=18, decimal_places=4)
    qty_on_hand_after = models.DecimalField(
        _("on hand after"),
        max_digits=18,
        decimal_places=4,
    )
    unit_cost = models.DecimalField(
        _("unit cost"),
        max_digits=18,
        decimal_places=4,
        default=0,
    )
    occurred_at = models.DateTimeField(_("occurred at"))

    class Meta:
        db_table = "stock_ledger"
        ordering = ("-occurred_at", "-id")
        indexes = [
            models.Index(
                fields=["tenant_id", "company_id", "product", "warehouse", "occurred_at"],
                name="stock_ledger_product_idx",
            ),
        ]

    def __str__(self):
        return f"{self.movement} {self.qty_delta}"
