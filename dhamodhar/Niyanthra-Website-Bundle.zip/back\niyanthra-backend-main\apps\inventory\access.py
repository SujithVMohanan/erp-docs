from rest_framework.exceptions import PermissionDenied

from apps.company.models import CompanyModule


class InventoryDisabled(PermissionDenied):
    auth_code = "MODULE_DISABLED"
    default_detail = "Inventory module is turned off."


def ensure_inventory_enabled(company_id: int) -> None:
    modules = (
        CompanyModule.objects.filter(company_id=company_id)
        .values_list("modules", flat=True)
        .first()
    )
    if not modules or not modules.get("inventory"):
        raise InventoryDisabled()
