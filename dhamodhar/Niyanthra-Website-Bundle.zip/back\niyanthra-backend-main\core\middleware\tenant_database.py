from core.tenant import clear_current_tenant
from infrastructure.database.context import clear_current_db_alias


class TenantDatabaseMiddleware:
    """
    Clears tenant identity + DB alias after each request.

    Workspace binding (IsWorkspaceAuthenticated) sets:
      - tenant identity (core.tenant) → ORM row isolation
      - db alias (infrastructure.database.context) → DB routing
    Never from client ID headers.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        try:
            return self.get_response(request)
        finally:
            clear_current_tenant()
            clear_current_db_alias()
