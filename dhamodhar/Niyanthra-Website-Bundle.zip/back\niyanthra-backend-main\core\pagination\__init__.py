"""List pagination for all APIs."""

from core.pagination.page import RestPagination

__all__ = ["RestPagination"]
