from django.urls import path

from apps.location.views import (
    CreateLocationApiView,
    CreateStateApiView,
    DeleteLocationsApiView,
    DeleteStatesApiView,
    GetLocationsApiView,
    GetStatesApiView,
    InactiveActiveStatesApiView,
    UpdateLocationApiView,
    UpdateStateApiView,
)

app_name = "location"

urlpatterns = [
    path("get-states/", GetStatesApiView.as_view(), name="get-states"),
    path("create-state/", CreateStateApiView.as_view(), name="create-state"),
    path("update-state/", UpdateStateApiView.as_view(), name="update-state"),
    path("delete-states/", DeleteStatesApiView.as_view(), name="delete-states"),
    path(
        "inactive-active-states/",
        InactiveActiveStatesApiView.as_view(),
        name="inactive-active-states",
    ),
    path("get-locations/", GetLocationsApiView.as_view(), name="get-locations"),
    path("create-location/", CreateLocationApiView.as_view(), name="create-location"),
    path("update-location/", UpdateLocationApiView.as_view(), name="update-location"),
    path(
        "delete-locations/",
        DeleteLocationsApiView.as_view(),
        name="delete-locations",
    ),
]
