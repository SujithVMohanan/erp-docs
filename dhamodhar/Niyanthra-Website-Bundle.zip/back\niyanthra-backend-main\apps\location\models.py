from django.db import models
from django.utils.translation import gettext_lazy as _

from core.database import (
    AllObjectsManager,
    BaseModel,
    SoftDeleteManager,
    alive_unique,
)


class Country(BaseModel):
    name = models.CharField(_("name"), max_length=150)
    code = models.CharField(_("ISO 3166-1 alpha-2"), max_length=2)
    iso3 = models.CharField(_("ISO 3166-1 alpha-3"), max_length=3, blank=True, null=True)
    phone_code = models.CharField(_("phone code"), max_length=8, blank=True, null=True)
    currency_code = models.CharField(_("currency code"), max_length=3, blank=True, null=True)
    is_active = models.BooleanField(_("is active"), default=True)

    objects = SoftDeleteManager()
    all_objects = AllObjectsManager()

    class Meta:
        db_table = "countries"
        verbose_name = _("country")
        verbose_name_plural = _("countries")
        ordering = ("name",)
        default_manager_name = "objects"
        base_manager_name = "all_objects"
        constraints = [
            alive_unique(["code"], "countries_code_alive_uniq"),
        ]

    def save(self, *args, **kwargs):
        if self.code:
            self.code = self.code.strip().upper()
        if self.iso3:
            self.iso3 = self.iso3.strip().upper()
        if self.iso3 == "":
            self.iso3 = None
        if self.phone_code == "":
            self.phone_code = None
        if self.currency_code:
            self.currency_code = self.currency_code.strip().upper()
        if self.currency_code == "":
            self.currency_code = None
        super().save(*args, **kwargs)

    def __str__(self) -> str:
        return f"{self.name} ({self.code})"


class State(BaseModel):
    country = models.ForeignKey(
        Country,
        on_delete=models.PROTECT,
        related_name="states",
        verbose_name=_("country"),
    )
    name = models.CharField(_("name"), max_length=150)
    code = models.CharField(_("code"), max_length=20)
    is_active = models.BooleanField(_("is active"), default=True)

    objects = SoftDeleteManager()
    all_objects = AllObjectsManager()

    class Meta:
        db_table = "states"
        verbose_name = _("state")
        verbose_name_plural = _("states")
        ordering = ("country", "name")
        default_manager_name = "objects"
        base_manager_name = "all_objects"
        constraints = [
            alive_unique(
                ["country", "code"],
                "states_country_code_alive_uniq",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.name} ({self.code})"


class Location(BaseModel):

    country = models.ForeignKey(
        Country,
        on_delete=models.PROTECT,
        related_name="locations",
    )

    state = models.ForeignKey(
        State,
        on_delete=models.PROTECT,
        related_name="locations",
        blank=True,
        null=True,
    )

    city = models.CharField(
        max_length=100,
    )

    postal_code = models.CharField(
        max_length=20,
        blank=True,
    )

    address_line_1 = models.CharField(
        max_length=255,
    )

    address_line_2 = models.CharField(
        max_length=255,
        blank=True,
    )

    latitude = models.DecimalField(
        max_digits=10,
        decimal_places=7,
        null=True,
        blank=True,
    )

    longitude = models.DecimalField(
        max_digits=10,
        decimal_places=7,
        null=True,
        blank=True,
    )

    place_id = models.CharField(
        max_length=255,
        blank=True,
    )

    formatted_address = models.CharField(
        max_length=500,
        blank=True,
    )

    class Meta:
        db_table = "locations"

    def __str__(self):
        return self.formatted_address or self.address_line_1