from rest_framework import serializers


class CreatePermissionSerializer(serializers.Serializer):
    codename     = serializers.CharField(max_length=100, trim_whitespace=True)
    name         = serializers.CharField(max_length=150, trim_whitespace=True)
    content_type = serializers.CharField(max_length=100, trim_whitespace=True)
    label        = serializers.CharField(
        max_length=100, required=False, allow_blank=True, trim_whitespace=True
    )
    sub_label    = serializers.CharField(
        max_length=100, required=False, allow_blank=True, trim_whitespace=True
    )


class UpdatePermissionSerializer(CreatePermissionSerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetPermissionsQuerySerializer(serializers.Serializer):
    uid          = serializers.CharField(required=False, allow_blank=True)
    codename     = serializers.CharField(required=False, allow_blank=True, max_length=100)
    content_type = serializers.CharField(required=False, allow_blank=True, max_length=100)
    name         = serializers.CharField(required=False, allow_blank=True, max_length=150)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["codename"] = (attrs.get("codename") or "").strip() or None
        attrs["content_type"] = (attrs.get("content_type") or "").strip() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        return attrs


class PermissionUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique, seen = [], set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one permission.")
        return unique


class CreateRoleSerializer(serializers.Serializer):
    company_uid     = serializers.CharField(trim_whitespace=True)
    name            = serializers.CharField(max_length=100, trim_whitespace=True)
    is_active       = serializers.BooleanField(required=False, default=True)
    permission_uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        required=False,
        allow_empty=True,
        max_length=200,
    )


class UpdateRoleSerializer(CreateRoleSerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetRolesQuerySerializer(serializers.Serializer):
    uid         = serializers.CharField(required=False, allow_blank=True)
    company_uid = serializers.CharField(required=False, allow_blank=True)
    name        = serializers.CharField(required=False, allow_blank=True, max_length=100)
    is_active   = serializers.BooleanField(required=False, allow_null=True)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["company_uid"] = (attrs.get("company_uid") or "").strip() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        if "is_active" not in attrs:
            attrs["is_active"] = None
        return attrs


class RoleUidsSerializer(PermissionUidsSerializer):
    def validate_uids(self, value):
        unique, seen = [], set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one role.")
        return unique


class CreateGroupSerializer(serializers.Serializer):
    company_uid = serializers.CharField(trim_whitespace=True)
    name        = serializers.CharField(max_length=100, trim_whitespace=True)
    is_active   = serializers.BooleanField(required=False, default=True)
    role_uids   = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        required=False,
        allow_empty=True,
        max_length=200,
    )


class UpdateGroupSerializer(CreateGroupSerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetGroupsQuerySerializer(GetRolesQuerySerializer):
    pass


class CreateUserGroupSerializer(serializers.Serializer):
    user_uid    = serializers.CharField(trim_whitespace=True)
    company_uid = serializers.CharField(trim_whitespace=True)
    group_uids  = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )
    is_active   = serializers.BooleanField(required=False, default=True)

    def validate_group_uids(self, value):
        unique, seen = [], set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one group.")
        return unique


class GroupUidsSerializer(PermissionUidsSerializer):
    def validate_uids(self, value):
        unique, seen = [], set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one group.")
        return unique
