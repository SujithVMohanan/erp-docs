from django.conf import settings
from django.db import transaction
from rest_framework.exceptions import ValidationError

from apps.company.repository import (
    BranchMembershipRepository,
    BranchRepository,
    CompanyRepository,
)
from apps.company.services.company_membership_service import (
    CompanyMembershipService,
)
from apps.users.services.membership_service import MembershipService
from core.exceptions.auth import AuthValidationError
from core.utils.ids import (
    decode_id,
    encode_id,
)
from core.utils.membership_invite import (
    KIND_BRANCH,
    KIND_COMPANY,
    KIND_ORGANIZATION,
    create_membership_invite_token,
    invite_max_age_seconds,
    verify_membership_invite_token,
)


class MembershipInviteService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str) -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})
        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})
        return decoded

    @staticmethod
    def _build_invite_payload(*, token: str, kind: str) -> dict:
        expires_in = invite_max_age_seconds()
        base = (getattr(settings, "FRONTEND_BASE_URL", "") or "").rstrip("/")
        path = f"/join?invite={token}"
        return {
            "token": token,
            "kind": kind,
            "expires_in_seconds": expires_in,
            "invite_path": path,
            "invite_url": f"{base}{path}" if base else path,
        }

    @staticmethod
    def create_company_invite(*, validated_data: dict) -> dict:
        company_id = MembershipInviteService._decode_uid(
            validated_data["company_uid"],
            field="company_uid",
        )
        if CompanyRepository.get_by_id(company_id) is None:
            raise AuthValidationError(
                {"company_uid": ["Company not found."]},
                code="COMPANY_NOT_FOUND",
            )

        role = validated_data.get("role") or "employee"
        token = create_membership_invite_token(
            kind=KIND_COMPANY,
            company_id=company_id,
            role=role,
        )
        return MembershipInviteService._build_invite_payload(
            token=token,
            kind=KIND_COMPANY,
        )

    @staticmethod
    def create_branch_invite(*, validated_data: dict) -> dict:
        branch_id = MembershipInviteService._decode_uid(
            validated_data["branch_uid"],
            field="branch_uid",
        )
        branch = BranchRepository.get_by_id(branch_id)
        if branch is None:
            raise AuthValidationError(
                {"branch_uid": ["Branch not found."]},
                code="BRANCH_NOT_FOUND",
            )

        role = validated_data.get("role") or "staff"
        token = create_membership_invite_token(
            kind=KIND_BRANCH,
            company_id=branch.company_id,
            branch_id=branch.pk,
            role=role,
        )
        return MembershipInviteService._build_invite_payload(
            token=token,
            kind=KIND_BRANCH,
        )

    @staticmethod
    def accept_invite(*, user, validated_data: dict) -> dict:
        try:
            payload = verify_membership_invite_token(validated_data["token"])
        except ValueError as exc:
            raise AuthValidationError(
                {"token": [str(exc)]},
                code="INVALID_INVITE",
            ) from exc

        kind = payload["kind"]
        role = payload["role"]

        with transaction.atomic():
            if kind == KIND_ORGANIZATION:
                organization_id = payload["organization_id"]
                if role not in {"owner", "admin", "employee"}:
                    raise AuthValidationError(
                        {"token": ["Invalid invite role."]},
                        code="INVALID_INVITE",
                    )
                MembershipService.ensure_organization_membership(
                    organization_id=organization_id,
                    user_id=user.pk,
                    role=role,
                )
                return {
                    "kind": KIND_ORGANIZATION,
                    "organization_uid": encode_id(organization_id),
                    "role": role,
                }

            company_id = payload["company_id"]
            if kind == KIND_COMPANY:
                if role not in {"owner", "admin", "employee"}:
                    raise AuthValidationError(
                        {"token": ["Invalid invite role."]},
                        code="INVALID_INVITE",
                    )
                membership = CompanyMembershipService.ensure_membership(
                    company_id=company_id,
                    user_id=user.pk,
                    role=role,
                )
                return {
                    "kind": KIND_COMPANY,
                    "company_membership_uid": encode_id(membership.pk),
                    "role": membership.role,
                }

            branch_id = payload["branch_id"]
            branch = BranchRepository.get_by_id(branch_id)
            if branch is None or branch.company_id != company_id:
                raise AuthValidationError(
                    {"token": ["Invalid invite link."]},
                    code="INVALID_INVITE",
                )
            if role not in {"manager", "staff"}:
                raise AuthValidationError(
                    {"token": ["Invalid invite role."]},
                    code="INVALID_INVITE",
                )

            CompanyMembershipService.ensure_membership(
                company_id=company_id,
                user_id=user.pk,
                role="employee",
            )

            existing = BranchMembershipRepository.get_conflict(
                branch_id=branch_id,
                user_id=user.pk,
            )
            if existing is None:
                branch_membership = BranchMembershipRepository.create_membership(
                    branch_id=branch_id,
                    user_id=user.pk,
                    role=role,
                    is_active=True,
                )
                branch_membership = BranchMembershipRepository.get_by_id(
                    branch_membership.pk
                )
            else:
                if not existing.is_active or existing.role != role:
                    existing.is_active = True
                    existing.role = role
                    existing.save(
                        update_fields=["is_active", "role", "updated_at"]
                    )
                branch_membership = BranchMembershipRepository.get_by_id(
                    existing.pk
                )

            return {
                "kind": KIND_BRANCH,
                "branch_membership_uid": encode_id(branch_membership.pk),
                "role": branch_membership.role,
            }
