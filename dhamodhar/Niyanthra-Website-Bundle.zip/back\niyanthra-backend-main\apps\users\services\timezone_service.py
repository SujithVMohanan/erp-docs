from django.db import IntegrityError
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.users.timezone_repository import TimeZoneRepository
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class TimeZoneService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})
        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})
        return decoded

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        return list(
            dict.fromkeys(
                TimeZoneService._decode_uid(uid, field="uids") for uid in uids
            )
        )

    @staticmethod
    def get_timezones(*, validated_data: dict):
        timezone_id = None
        if validated_data.get("uid"):
            timezone_id = [TimeZoneService._decode_uid(validated_data["uid"])]
        return TimeZoneRepository.list_timezones(
            timezone_id=timezone_id,
            code=validated_data.get("code"),
            name=validated_data.get("name"),
            is_active=validated_data.get("is_active"),
        )

    @staticmethod
    def create_timezone(*, validated_data: dict):
        code = validated_data["code"]
        if TimeZoneRepository.get_code_conflict(code=code):
            raise AuthValidationError(
                {"code": ["This timezone code already exists."]},
                code="TIMEZONE_CODE_EXISTS",
            )
        try:
            return TimeZoneRepository.create_timezone(
                name=validated_data["name"],
                code=code,
                utc_offset=validated_data.get("utc_offset"),
                is_active=validated_data.get("is_active", True),
            )
        except IntegrityError:
            raise AuthValidationError(
                {"code": ["This timezone code already exists."]},
                code="TIMEZONE_CODE_EXISTS",
            ) from None

    @staticmethod
    def update_timezone(*, validated_data: dict):
        tz = TimeZoneRepository.get_by_id(
            TimeZoneService._decode_uid(validated_data["uid"])
        )
        if tz is None:
            raise NotFound("Timezone not found.")
        code = validated_data["code"]
        if TimeZoneRepository.get_code_conflict(code=code, exclude_id=tz.pk):
            raise AuthValidationError(
                {"code": ["This timezone code already exists."]},
                code="TIMEZONE_CODE_EXISTS",
            )
        try:
            return TimeZoneRepository.update_timezone(
                tz=tz,
                name=validated_data["name"],
                code=code,
                utc_offset=validated_data.get("utc_offset"),
                is_active=validated_data.get("is_active", tz.is_active),
            )
        except IntegrityError:
            raise AuthValidationError(
                {"code": ["This timezone code already exists."]},
                code="TIMEZONE_CODE_EXISTS",
            ) from None

    @staticmethod
    def delete_timezones(*, validated_data: dict) -> dict:
        ids = TimeZoneService._decode_uids(validated_data["uids"])
        deleted = TimeZoneRepository.delete_by_ids(ids)
        if not deleted:
            raise NotFound("Timezone not found.")
        return {"deleted": deleted}

    @staticmethod
    def toggle_timezones(*, validated_data: dict):
        ids = TimeZoneService._decode_uids(validated_data["uids"])
        updated = TimeZoneRepository.toggle_active_by_ids(ids)
        if not updated:
            raise NotFound("Timezone not found.")
        return TimeZoneRepository.list_timezones(timezone_id=ids)
