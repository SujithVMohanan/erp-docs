from django.db import transaction
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.access.repository import RoleRepository
from apps.company.repository import CompanyRepository
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class RoleService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})

        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})

        return decoded

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        return list(
            dict.fromkeys(
                RoleService._decode_uid(uid, field="uids")
                for uid in uids
            )
        )

    @staticmethod
    def _resolve_company(uid: str) -> int:
        company_id = RoleService._decode_uid(
            uid,
            field="company_uid",
        )
        if CompanyRepository.get_by_id(company_id) is None:
            raise AuthValidationError(
                {
                    "company_uid": [
                        "Company not found.",
                    ]
                },
                code="COMPANY_NOT_FOUND",
            )
        return company_id

    @staticmethod
    def _permission_ids(uids: list[str] | None) -> list[int]:
        return [
            RoleService._decode_uid(uid, field="permission_uids")
            for uid in (uids or [])
        ]

    @staticmethod
    def get_roles(*, validated_data: dict):
        role_id = None
        company_id = None

        if validated_data.get("uid"):
            role_id = [
                RoleService._decode_uid(validated_data["uid"])
            ]

        if validated_data.get("company_uid"):
            company_id = RoleService._decode_uid(
                validated_data["company_uid"],
                field="company_uid",
            )

        return RoleRepository.list_roles(
            role_id=role_id,
            company_id=company_id,
            name=validated_data.get("name"),
            is_active=validated_data.get("is_active"),
        )

    @staticmethod
    def create_role(*, validated_data: dict):
        company_id = RoleService._resolve_company(
            validated_data["company_uid"]
        )
        permission_ids = RoleService._permission_ids(
            validated_data.get("permission_uids")
        )

        with transaction.atomic():
            role = RoleRepository.create(
                company_id=company_id,
                name=validated_data["name"],
                is_active=validated_data.get("is_active", True),
            )
            if permission_ids:
                RoleRepository.set_permissions(
                    role=role,
                    permission_ids=permission_ids,
                )

        return RoleRepository.get_by_id(role.pk)

    @staticmethod
    def update_role(*, validated_data: dict):
        role = RoleRepository.get_by_id(
            RoleService._decode_uid(validated_data["uid"])
        )
        if role is None:
            raise NotFound("Role not found.")

        company_id = RoleService._resolve_company(
            validated_data["company_uid"]
        )
        permission_ids = RoleService._permission_ids(
            validated_data.get("permission_uids")
        )

        with transaction.atomic():
            RoleRepository.update(
                role=role,
                company_id=company_id,
                name=validated_data["name"],
                is_active=validated_data.get("is_active", role.is_active),
            )
            RoleRepository.set_permissions(
                role=role,
                permission_ids=permission_ids,
            )

        return RoleRepository.get_by_id(role.pk)

    @staticmethod
    def delete_roles(*, validated_data: dict) -> dict:
        deleted = RoleRepository.delete_by_ids(
            RoleService._decode_uids(validated_data["uids"])
        )
        if not deleted:
            raise NotFound("Role not found.")

        return {
            "deleted": deleted
        }

    @staticmethod
    def toggle_roles(*, validated_data: dict):
        role_ids = RoleService._decode_uids(validated_data["uids"])
        updated = RoleRepository.toggle_active_by_ids(role_ids)
        if not updated:
            raise NotFound("Role not found.")

        return RoleRepository.list_roles(role_id=role_ids)
