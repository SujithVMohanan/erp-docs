from django.utils import timezone

from rest_framework.exceptions import NotFound

from apps.company.models import Company
from apps.inventory.models import Warehouse
from apps.inventory.repository import InventoryRepository
from apps.inventory.services.scope import (
    decode_uid,
    workspace_context,
)
from apps.tenant.services.tenant_database_context import TenantDatabaseContext
from core.tenant import tenant_context
from core.tenant.context import require_current_tenant
from core.tenant.workspace import WorkspaceScope
from infrastructure.database.context import (
    clear_current_db_alias,
    get_current_db_alias,
    set_current_db_alias,
)


class WarehouseService:

    @staticmethod
    def list_warehouses(
        *,
        scope: WorkspaceScope,
        validated_data: dict,
    ):
        warehouse_ids = None
        branch_id = None

        with workspace_context(scope):
            if validated_data.get("uid"):
                warehouse_ids = [
                    decode_uid(validated_data["uid"])
                ]

            if validated_data.get("branch_uid"):
                branch_id = decode_uid(
                    validated_data["branch_uid"],
                    field="branch_uid",
                )

            return InventoryRepository.list_warehouses(
                warehouse_ids=warehouse_ids,
                branch_id=branch_id,
            )

    @staticmethod
    def rename(
        *,
        scope: WorkspaceScope,
        validated_data: dict,
    ) -> Warehouse:
        with workspace_context(scope):
            warehouse = (
                Warehouse.objects
                .filter(
                    pk=decode_uid(validated_data["uid"]),
                )
                .first()
            )

            if warehouse is None:
                raise NotFound("Warehouse not found.")

            warehouse.name = validated_data["name"].strip()
            warehouse.name_custom = True

            warehouse.save(
                update_fields=[
                    "name",
                    "name_custom",
                    "updated_at",
                ]
            )

            return warehouse

    @staticmethod
    def ensure_for_company_id(company_id: int) -> None:
        """
        Open the company's tenant database, synchronize warehouses,
        and restore the caller's database alias afterward.

        Does nothing when the company has no ready tenant.
        """
        company = (
            Company.objects
            .select_related("tenant")
            .filter(pk=company_id)
            .first()
        )

        if company is None:
            return

        tenant = company.tenant

        if tenant is None or not tenant.is_ready:
            return

        previous_alias = get_current_db_alias()

        try:
            TenantDatabaseContext.activate(tenant=tenant)

            with tenant_context(
                tenant_id=tenant.pk,
                company_id=company.pk,
            ):
                WarehouseService.sync_current()

        finally:
            if previous_alias:
                set_current_db_alias(previous_alias)
            else:
                clear_current_db_alias()

    @staticmethod
    def sync_current() -> None:
        identity = require_current_tenant()

        branches = InventoryRepository.branches_for_company(
            identity.company_id
        )

        existing = {
            warehouse.branch_id: warehouse
            for warehouse in (
                Warehouse.objects
                .only(
                    "id",
                    "branch_id",
                    "name",
                    "code",
                    "status",
                    "name_custom",
                    "tenant_id",
                    "company_id",
                )
            )
        }

        seen_branch_ids = set()
        warehouses_to_create = []
        warehouses_to_update = []
        now = timezone.now()

        for branch in branches:
            branch_id = branch.pk
            seen_branch_ids.add(branch_id)

            branch_status = (
                (branch.status or "")
                .strip()
                .upper()
            )

            status = (
                "ACTIVE"
                if branch_status == "ACTIVE"
                else "INACTIVE"
            )

            name = (
                branch.name
                or branch.code
                or "Warehouse"
            ).strip()

            code = (branch.code or "").strip()
            warehouse = existing.get(branch_id)

            if warehouse is None:
                warehouses_to_create.append(
                    Warehouse(
                        company_id=identity.company_id,
                        branch_id=branch_id,
                        name=name,
                        code=code,
                        status=status,
                        is_default=True,
                        name_custom=False,
                    )
                )
                continue

            changed = False

            if warehouse.code != code:
                warehouse.code = code
                changed = True

            if warehouse.status != status:
                warehouse.status = status
                changed = True

            if (
                not warehouse.name_custom
                and warehouse.name != name
            ):
                warehouse.name = name
                changed = True

            if changed:
                warehouse.updated_at = now
                warehouses_to_update.append(warehouse)

        for branch_id, warehouse in existing.items():
            if (
                branch_id in seen_branch_ids
                or warehouse.status == "INACTIVE"
            ):
                continue

            warehouse.status = "INACTIVE"
            warehouse.updated_at = now
            warehouses_to_update.append(warehouse)

        if warehouses_to_create:
            Warehouse.objects.bulk_create(
                warehouses_to_create,
                batch_size=500,
            )

        if warehouses_to_update:
            Warehouse.objects.bulk_update(
                warehouses_to_update,
                [
                    "name",
                    "code",
                    "status",
                    "updated_at",
                ],
                batch_size=500,
            )
