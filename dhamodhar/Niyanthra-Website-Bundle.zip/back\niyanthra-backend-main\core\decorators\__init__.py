"""Small reusable decorators. Not large workflows."""
