from django.conf import settings


def _label_from_app_path(app_path: str) -> str:
    """
    Convert AppConfig path to app label.
    Example: apps.sales.apps.SalesConfig -> sales
    """
    if ".apps." in app_path:
        package = app_path.split(".apps.", 1)[0]
        return package.rsplit(".", 1)[-1]
    return app_path.rsplit(".", 1)[-1]


def tenant_app_labels() -> list[str]:
    configured = getattr(settings, "TENANT_DATABASE_APPS", None)
    if configured:
        return [
            label.rsplit(".", 1)[-1]
            for label in configured
        ]

    return [
        _label_from_app_path(path)
        for path in getattr(settings, "TENANT_APPS", [])
    ]


def control_app_labels() -> list[str]:
    return [
        _label_from_app_path(path)
        for path in getattr(settings, "CONTROL_APPS", [])
    ]


def tenant_support_app_labels() -> list[str]:
    return list(getattr(settings, "TENANT_SUPPORT_APPS", []))


def control_migrate_labels() -> list[str]:
    """Apps that belong on the control database. No tenant apps."""
    return [
        "contenttypes",
        "auth",
        "admin",
        "sessions",
        "token_blacklist",
        *control_app_labels(),
    ]
