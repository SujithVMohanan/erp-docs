from django.db import transaction
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.access.repository import GroupRepository
from apps.company.repository import CompanyRepository
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class GroupService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})

        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})

        return decoded

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        return list(
            dict.fromkeys(
                GroupService._decode_uid(uid, field="uids")
                for uid in uids
            )
        )

    @staticmethod
    def _resolve_company(uid: str) -> int:
        company_id = GroupService._decode_uid(
            uid,
            field="company_uid",
        )
        if CompanyRepository.get_by_id(company_id) is None:
            raise AuthValidationError(
                {
                    "company_uid": [
                        "Company not found.",
                    ]
                },
                code="COMPANY_NOT_FOUND",
            )
        return company_id

    @staticmethod
    def _role_ids(uids: list[str] | None) -> list[int]:
        return [
            GroupService._decode_uid(uid, field="role_uids")
            for uid in (uids or [])
        ]

    @staticmethod
    def get_groups(*, validated_data: dict):
        group_id = None
        company_id = None

        if validated_data.get("uid"):
            group_id = [
                GroupService._decode_uid(validated_data["uid"])
            ]

        if validated_data.get("company_uid"):
            company_id = GroupService._decode_uid(
                validated_data["company_uid"],
                field="company_uid",
            )

        return GroupRepository.list_groups(
            group_id=group_id,
            company_id=company_id,
            name=validated_data.get("name"),
            is_active=validated_data.get("is_active"),
        )

    @staticmethod
    def create_group(*, validated_data: dict):
        company_id = GroupService._resolve_company(
            validated_data["company_uid"]
        )
        role_ids = GroupService._role_ids(
            validated_data.get("role_uids")
        )

        with transaction.atomic():
            group = GroupRepository.create(
                company_id=company_id,
                name=validated_data["name"],
                is_active=validated_data.get("is_active", True),
            )
            if role_ids:
                GroupRepository.set_roles(
                    group=group,
                    role_ids=role_ids,
                )

        return GroupRepository.get_by_id(group.pk)

    @staticmethod
    def update_group(*, validated_data: dict):
        group = GroupRepository.get_by_id(
            GroupService._decode_uid(validated_data["uid"])
        )
        if group is None:
            raise NotFound("Group not found.")

        company_id = GroupService._resolve_company(
            validated_data["company_uid"]
        )
        role_ids = GroupService._role_ids(
            validated_data.get("role_uids")
        )

        with transaction.atomic():
            GroupRepository.update(
                group=group,
                company_id=company_id,
                name=validated_data["name"],
                is_active=validated_data.get("is_active", group.is_active),
            )
            GroupRepository.set_roles(
                group=group,
                role_ids=role_ids,
            )

        return GroupRepository.get_by_id(group.pk)

    @staticmethod
    def delete_groups(*, validated_data: dict) -> dict:
        deleted = GroupRepository.delete_by_ids(
            GroupService._decode_uids(validated_data["uids"])
        )
        if not deleted:
            raise NotFound("Group not found.")

        return {
            "deleted": deleted
        }

    @staticmethod
    def toggle_groups(*, validated_data: dict):
        group_ids = GroupService._decode_uids(validated_data["uids"])
        updated = GroupRepository.toggle_active_by_ids(group_ids)
        if not updated:
            raise NotFound("Group not found.")

        return GroupRepository.list_groups(group_id=group_ids)
