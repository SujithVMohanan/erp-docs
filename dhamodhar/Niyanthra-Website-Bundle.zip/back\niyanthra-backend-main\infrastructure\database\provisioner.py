from infrastructure.database.connection import ConnectionRegistry
from infrastructure.database.creator import DatabaseCreator
from infrastructure.database.credentials import CredentialResolver
from infrastructure.database.migrator import TenantMigrator


class IsolatedDatabaseProvisioner:
    """Infra-only: create DB, register connection, migrate. No domain models."""

    @staticmethod
    def provision(
        *,
        db_alias: str,
        db_name: str,
        secret_arn: str | None = None,
        secret_name: str | None = None,
    ) -> dict:
        runtime = CredentialResolver.resolve(
            secret_arn=secret_arn,
            secret_name=secret_name,
        )
        admin = CredentialResolver.admin_credentials()

        created_name = DatabaseCreator.create(
            db_name=db_name,
            credentials=admin,
        )

        ConnectionRegistry.register(
            alias=db_alias,
            db_name=created_name,
            credentials=runtime,
        )

        TenantMigrator.migrate(alias=db_alias)

        return {
            "db_alias": db_alias,
            "db_name": created_name,
            "host": runtime.host,
            "port": runtime.port,
            "secret_arn": runtime.secret_arn,
            "secret_name": runtime.secret_name,
        }
