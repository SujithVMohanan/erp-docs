from django.contrib import admin

from apps.background.models import (
    BackgroundJob,
    PeriodicTask,
)


@admin.register(PeriodicTask)
class PeriodicTaskAdmin(admin.ModelAdmin):
    list_display = (
        "code",
        "name",
        "is_enabled",
        "queue_status",
        "max_workers",
        "interval_seconds",
        "last_run_at",
    )
    list_filter = (
        "is_enabled",
        "queue_status",
    )
    search_fields = (
        "code",
        "name",
        "task_path",
    )


@admin.register(BackgroundJob)
class BackgroundJobAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "job_type",
        "status",
        "tenant",
        "periodic_task",
        "started_at",
        "completed_at",
        "failed_at",
    )
    list_filter = (
        "job_type",
        "status",
    )
    search_fields = (
        "tenant__slug",
        "error_message",
    )
    raw_id_fields = (
        "tenant",
        "periodic_task",
    )
