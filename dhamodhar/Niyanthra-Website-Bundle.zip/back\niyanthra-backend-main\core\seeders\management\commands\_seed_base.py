from django.core.management.base import (
    BaseCommand,
    CommandError,
)


class SeedGroupCommand(BaseCommand):
    """Thin base for single-group seed management commands."""

    group_label = "Master data"
    seeder_run = None

    def handle(self, *args, **options):
        if self.seeder_run is None:
            raise CommandError(f"{self.__class__.__name__}.seeder_run is not set.")
        try:
            result = self.seeder_run()
        except Exception as exc:
            raise CommandError(str(exc)) from exc

        fixtures = result.get("fixtures") or {}
        if len(fixtures) > 1:
            for stem, fixture in fixtures.items():
                self.stdout.write(
                    f"  {stem}: "
                    f"created={fixture['created']} "
                    f"updated={fixture['updated']} "
                    f"total={fixture['total']}"
                )

        self.stdout.write(
            self.style.SUCCESS(
                f"{self.group_label} seeder finished: "
                f"created={result['created']} "
                f"updated={result['updated']} "
                f"total={result['total']}"
            )
        )
