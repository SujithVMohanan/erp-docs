from django.urls import path

from apps.users.views import (
    CompleteProfileApiView,
    CreateTimeZoneApiView,
    CurrentUserApiView,
    DeleteTimeZonesApiView,
    DeleteUsersApiView,
    GetTimeZonesApiView,
    GetUsersApiView,
    HardDeleteUsersApiView,
    InactiveActiveTimeZonesApiView,
    LoginUserApiView,
    LogoutUserApiView,
    RefreshTokenApiView,
    RegisterUserApiView,
    RegistrationStatusApiView,
    SocialLoginApiView,
    UpdateTimeZoneApiView,
)

app_name = "users"

urlpatterns = [
    path("register/", RegisterUserApiView.as_view(), name="register"),
    path("social-login/", SocialLoginApiView.as_view(), name="social-login"),
    path("login/", LoginUserApiView.as_view(), name="login"),
    path("logout/", LogoutUserApiView.as_view(), name="logout"),
    path("refresh/", RefreshTokenApiView.as_view(), name="refresh"),
    path("me/", CurrentUserApiView.as_view(), name="me"),
    path("complete-profile/", CompleteProfileApiView.as_view(), name="complete-profile"),
    path(
        "registration-status/",
        RegistrationStatusApiView.as_view(),
        name="registration-status",
    ),
    path("get-users/", GetUsersApiView.as_view(), name="get-users"),
    path("delete-users/", DeleteUsersApiView.as_view(), name="delete-users"),
    path("get-time-zones/", GetTimeZonesApiView.as_view(), name="get-time-zones"),
    path("create-time-zone/", CreateTimeZoneApiView.as_view(), name="create-time-zone"),
    path("update-time-zone/", UpdateTimeZoneApiView.as_view(), name="update-time-zone"),
    path("delete-time-zones/", DeleteTimeZonesApiView.as_view(), name="delete-time-zones"),
    path(
        "inactive-active-time-zones/",
        InactiveActiveTimeZonesApiView.as_view(),
        name="inactive-active-time-zones",
    ),
]
