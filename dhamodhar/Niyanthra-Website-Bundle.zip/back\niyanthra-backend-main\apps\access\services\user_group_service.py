from django.db import transaction
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.access.repository import UserGroupAssignmentRepository
from apps.company.repository import CompanyRepository
from apps.users.repository import UserRepository
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class UserGroupService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str) -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})

        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})

        return decoded

    @staticmethod
    def replace_assignments(*, validated_data: dict):
        company_id = UserGroupService._decode_uid(
            validated_data["company_uid"],
            field="company_uid",
        )
        if CompanyRepository.get_by_id(company_id) is None:
            raise NotFound("Company not found.")

        user_id = UserGroupService._decode_uid(
            validated_data["user_uid"],
            field="user_uid",
        )
        if not list(UserRepository.list_users(user_id=[user_id])):
            raise NotFound("User not found.")

        group_ids = list(
            dict.fromkeys(
                UserGroupService._decode_uid(uid, field="group_uids")
                for uid in validated_data["group_uids"]
            )
        )
        groups = UserGroupAssignmentRepository.groups_by_ids(group_ids)
        if len(groups) != len(group_ids):
            raise NotFound("Group not found.")

        if any(group.company_id != company_id for group in groups):
            raise AuthValidationError(
                {
                    "group_uids": [
                        "Each group must belong to the selected company.",
                    ]
                },
                code="GROUP_COMPANY_MISMATCH",
            )

        is_active = validated_data.get("is_active", True)
        keep = set(group_ids)

        with transaction.atomic():
            existing = UserGroupAssignmentRepository.rows_for_user_company(
                user_id=user_id,
                company_id=company_id,
            )
            delete_ids = []
            alive_ids = []
            restore_ids = []
            held_groups = set()

            for row in existing:
                company_wide = row.branch_id is None
                if row.group_id not in keep or not company_wide:
                    if row.deleted_at is None:
                        delete_ids.append(row.pk)
                    continue

                held_groups.add(row.group_id)
                if row.deleted_at is None:
                    alive_ids.append(row.pk)
                else:
                    restore_ids.append(row.pk)

            UserGroupAssignmentRepository.delete_by_ids(delete_ids)
            UserGroupAssignmentRepository.touch_active(
                assignment_ids=alive_ids,
                is_active=is_active,
            )
            UserGroupAssignmentRepository.restore_active(
                assignment_ids=restore_ids,
                is_active=is_active,
            )
            UserGroupAssignmentRepository.create_many(
                user_id=user_id,
                group_ids=[
                    group_id
                    for group_id in group_ids
                    if group_id not in held_groups
                ],
                is_active=is_active,
            )

        return UserGroupAssignmentRepository.list_for_user_groups(
            user_id=user_id,
            group_ids=group_ids,
        )
