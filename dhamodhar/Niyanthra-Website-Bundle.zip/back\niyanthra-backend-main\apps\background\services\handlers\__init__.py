from apps.background.models import BackgroundJob
from apps.background.services.handlers.base import BaseJobHandler
from apps.background.services.handlers.isolated_db_provision import (
    IsolatedDbProvisionHandler,
)

HANDLERS: dict[str, BaseJobHandler] = {
    BackgroundJob.JobType.ISOLATED_DB_PROVISION: IsolatedDbProvisionHandler(),
}


def get_handler(job_type: str) -> BaseJobHandler:
    handler = HANDLERS.get(job_type)

    if handler is None:
        raise ValueError(f"Unsupported job_type: {job_type}")

    return handler
