from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError as DjangoValidationError
from rest_framework import serializers

from core.utils.normalize import normalize_phone


class LoginUserSerializer(serializers.Serializer):
    email    = serializers.EmailField(max_length=254)
    password = serializers.CharField(
        write_only=True,
        trim_whitespace=False,
        min_length=1,
        max_length=128,
        style={"input_type": "password"},
    )
    organization_code = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=254,
        default="",
        help_text="Encoded organization uid from invite link.",
    )
    company_code = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=254,
        default="",
        help_text="Encoded company uid from invite link.",
    )
    branch_code = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=254,
        default="",
        help_text="Encoded branch uid from invite link.",
    )

    def validate(self, attrs):
        for key in (
            "organization_code",
            "company_code",
            "branch_code",
        ):
            attrs[key] = (attrs.get(key) or "").strip() or None
        return attrs


class RegisterUserSerializer(serializers.Serializer):
    email            = serializers.EmailField(max_length=254)
    full_name        = serializers.CharField(max_length=150, trim_whitespace=True,required=False, allow_blank=True)
    phone_number     = serializers.CharField(max_length=30, trim_whitespace=True, required=False, allow_blank=True)
    password         = serializers.CharField(
        write_only=True,
        trim_whitespace=False,
        max_length=128,
        style={"input_type": "password"},
    )
    confirm_password = serializers.CharField(
        write_only=True,
        trim_whitespace=False,
        max_length=128,
        style={"input_type": "password"},
    )
    organization_code = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=254,
        help_text="Encoded organization uid from invite link.",
    )
    company_code = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=254,
        help_text="Encoded company uid from invite link.",
    )
    branch_code = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=254,
        help_text="Encoded branch uid from invite link.",
    )

    def validate_password(self, value):
        try:
            validate_password(value)
        except DjangoValidationError as exc:
            raise serializers.ValidationError(list(exc.messages))
        return value

    def validate(self, attrs):
        if attrs["password"] != attrs["confirm_password"]:
            raise serializers.ValidationError(
                {"confirm_password": "Passwords do not match."}
            )
        attrs.pop("confirm_password")
        for key in (
            "organization_code",
            "company_code",
            "branch_code",
        ):
            attrs[key] = (attrs.get(key) or "").strip() or None
        return attrs


class GetUsersQuerySerializer(serializers.Serializer):
    uid   = serializers.CharField(required=False, allow_blank=True, help_text="Encoded user id")
    email = serializers.CharField(required=False, allow_blank=True, max_length=254)
    name  = serializers.CharField(required=False, allow_blank=True, max_length=150)

    def validate(self, attrs):
        for key in ("uid", "email", "name"):
            attrs[key] = (attrs.get(key) or "").strip() or None
        return attrs


class DeleteUsersSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique = []
        seen = set()
        for raw in value:
            item = str(raw).strip()
            if not item or item in seen:
                continue
            seen.add(item)
            unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one user.")
        return unique


class LogoutUserSerializer(serializers.Serializer):
    refresh = serializers.CharField(required=False, allow_blank=True)
    access  = serializers.CharField(required=False, allow_blank=True)

    def validate(self, attrs):
        attrs["refresh"] = (attrs.get("refresh") or "").strip() or None
        attrs["access"] = (attrs.get("access") or "").strip() or None
        if not attrs["refresh"] and not attrs["access"]:
            raise serializers.ValidationError(
                "Refresh or access token is required."
            )
        return attrs


class RefreshTokenSerializer(serializers.Serializer):
    refresh = serializers.CharField()

    def validate_refresh(self, value):
        refresh = (value or "").strip()
        if not refresh:
            raise serializers.ValidationError("This field may not be blank.")
        return refresh


class SocialLoginSerializer(serializers.Serializer):
    provider = serializers.ChoiceField(choices=["google"])
    id_token = serializers.CharField(trim_whitespace=True)
    nonce    = serializers.CharField(required=False, allow_blank=True)
    organization_code = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=254,
        help_text="Encoded organization uid from invite link.",
    )
    company_code = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=254,
        help_text="Encoded company uid from invite link.",
    )
    branch_code = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=254,
        help_text="Encoded branch uid from invite link.",
    )

    def validate(self, attrs):
        attrs["id_token"] = attrs["id_token"].strip()
        if not attrs["id_token"]:
            raise serializers.ValidationError({"id_token": "This field may not be blank."})
        attrs["nonce"] = (attrs.get("nonce") or "").strip() or None
        for key in (
            "organization_code",
            "company_code",
            "branch_code",
        ):
            attrs[key] = (attrs.get(key) or "").strip() or None
        return attrs


class CompleteProfileSerializer(serializers.Serializer):
    username         = serializers.CharField(
        max_length=150,
        trim_whitespace=True,
    )
    phone_number     = serializers.CharField(
        max_length=30,
        trim_whitespace=True,
    )
    password         = serializers.CharField(
        write_only=True,
        required=False,
        allow_blank=True,
        trim_whitespace=False,
        max_length=128,
        style={"input_type": "password"},
    )
    confirm_password = serializers.CharField(
        write_only=True,
        required=False,
        allow_blank=True,
        trim_whitespace=False,
        max_length=128,
        style={"input_type": "password"},
    )

    def validate_username(self, value):
        username = (value or "").strip()
        if not username:
            raise serializers.ValidationError("This field may not be blank.")
        return username

    def validate_phone_number(self, value):
        phone_number = normalize_phone(value)
        if not phone_number:
            raise serializers.ValidationError("This field may not be blank.")
        return phone_number

    def validate_password(self, value):
        if not value:
            return value
        user = None
        request = self.context.get("request")
        if request is not None and getattr(request, "user", None):
            if request.user.is_authenticated:
                user = request.user
        try:
            validate_password(value, user=user)
        except DjangoValidationError as exc:
            raise serializers.ValidationError(list(exc.messages))
        return value

    def validate(self, attrs):
        password = attrs.get("password") or ""
        confirm = attrs.get("confirm_password") or ""
        if password or confirm:
            if not password:
                raise serializers.ValidationError(
                    {"password": "This field is required."}
                )
            if password != confirm:
                raise serializers.ValidationError(
                    {"confirm_password": "Passwords do not match."}
                )
            attrs["password"] = password
        else:
            attrs["password"] = None
        attrs.pop("confirm_password", None)
        return attrs


class CreateTimeZoneSerializer(serializers.Serializer):
    name       = serializers.CharField(max_length=100, trim_whitespace=True)
    code       = serializers.CharField(max_length=100, trim_whitespace=True)
    utc_offset = serializers.CharField(
        max_length=10,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )
    is_active  = serializers.BooleanField(required=False, default=True)

    def validate_code(self, value):
        normalized = value.strip()
        if not normalized:
            raise serializers.ValidationError("This field may not be blank.")
        return normalized

    def validate_utc_offset(self, value):
        return (value or "").strip() or None


class UpdateTimeZoneSerializer(CreateTimeZoneSerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetTimeZonesQuerySerializer(serializers.Serializer):
    uid       = serializers.CharField(required=False, allow_blank=True)
    code      = serializers.CharField(required=False, allow_blank=True, max_length=100)
    name      = serializers.CharField(required=False, allow_blank=True, max_length=100)
    is_active = serializers.BooleanField(required=False, allow_null=True)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["code"] = (attrs.get("code") or "").strip() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        if "is_active" not in attrs:
            attrs["is_active"] = None
        return attrs


class TimeZoneUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique, seen = [], set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one timezone.")
        return unique
