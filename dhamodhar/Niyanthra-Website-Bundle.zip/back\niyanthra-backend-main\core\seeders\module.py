from core.seeders.base import run_group

GROUP = "module"


def run() -> dict:
    return run_group(GROUP)
