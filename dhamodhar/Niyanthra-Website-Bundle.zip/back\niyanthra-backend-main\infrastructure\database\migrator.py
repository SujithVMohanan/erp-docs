import logging

from django.core.management import call_command

from infrastructure.database.labels import tenant_app_labels

logger = logging.getLogger("niyanthra")


class TenantMigrator:
    """Run migrations for a registered tenant DB alias only."""

    @staticmethod
    def migrate(*, alias: str, verbosity: int = 1) -> None:
        if alias == "default":
            raise ValueError(
                "TenantMigrator cannot migrate the control database."
            )

        apps = tenant_app_labels()

        if not apps:
            raise ValueError("TENANT_DATABASE_APPS / TENANT_APPS is empty.")

        for label in apps:
            logger.info("migrate tenant app=%s alias=%s", label, alias)
            call_command(
                "migrate",
                label,
                database=alias,
                interactive=False,
                verbosity=verbosity,
            )
