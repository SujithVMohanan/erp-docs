from django.test import TestCase
from rest_framework.test import APIClient

from apps.access.models import (
    Group,
    UserGroupAssignment,
)
from apps.company.models import (
    Company,
    CompanyMembership,
)
from apps.location.models import Country
from apps.organization.models import Organization
from apps.users.models import Users
from core.utils.ids import encode_id
from core.utils.tokens import issue_tokens

PASSWORD = "ValidPassw0rd!"


class CreateUserGroupApiTests(TestCase):

    def setUp(self):
        self.client = APIClient()
        self.admin = Users.objects.create_user(
            email="ug-admin@example.com",
            password=PASSWORD,
            username="ugadmin",
            phone_number="+15553330001",
            is_admin=True,
            profile_completed=True,
        )
        self.member = Users.objects.create_user(
            email="ug-member@example.com",
            password=PASSWORD,
            username="ugmember",
            phone_number="+15553330002",
            profile_completed=True,
        )
        tokens = issue_tokens(self.admin)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")

        country = Country.objects.create(name="India", code="IN")
        organization = Organization.objects.create(
            name="UG Org",
            code="UGORG",
            legal_name="UG Org Pvt",
            country=country,
        )
        self.company = Company.objects.create(
            name="UG Co",
            code="UGCO",
            organization=organization,
            is_active=True,
        )
        self.other = Company.objects.create(
            name="UG Other",
            code="UGOT",
            organization=organization,
            is_active=True,
        )
        CompanyMembership.objects.create(
            company=self.company,
            user=self.admin,
            role=CompanyMembership.Role.ADMIN,
            is_active=True,
        )
        self.sales = Group.objects.create(company=self.company, name="Sales")
        self.store = Group.objects.create(company=self.company, name="Store")
        self.foreign = Group.objects.create(company=self.other, name="Other")

    def test_assigns_multiple_groups(self):
        response = self.client.post(
            "/api/access/create-user-group/",
            {
                "user_uid": encode_id(self.member.pk),
                "company_uid": encode_id(self.company.pk),
                "group_uids": [
                    encode_id(self.sales.pk),
                    encode_id(self.store.pk),
                ],
            },
            format="json",
        )

        self.assertEqual(response.status_code, 201)
        body = response.json()
        self.assertEqual(body["message"], "User groups added successfully.")
        self.assertEqual(len(body["data"]), 2)
        names = {row["group"]["name"] for row in body["data"]}
        self.assertEqual(names, {"Sales", "Store"})
        self.assertEqual(body["data"][0]["user"]["email"], "ug-member@example.com")
        self.assertNotIn("branch", body["data"][0])

    def test_rejects_group_from_another_company(self):
        response = self.client.post(
            "/api/access/create-user-group/",
            {
                "user_uid": encode_id(self.member.pk),
                "company_uid": encode_id(self.company.pk),
                "group_uids": [encode_id(self.foreign.pk)],
            },
            format="json",
        )

        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json()["code"], "GROUP_COMPANY_MISMATCH")

    def test_replaces_existing_company_groups(self):
        payload = {
            "user_uid": encode_id(self.member.pk),
            "company_uid": encode_id(self.company.pk),
        }
        first = self.client.post(
            "/api/access/create-user-group/",
            {
                **payload,
                "group_uids": [
                    encode_id(self.sales.pk),
                    encode_id(self.store.pk),
                ],
            },
            format="json",
        )
        second = self.client.put(
            "/api/access/update-user-group/",
            {
                **payload,
                "group_uids": [encode_id(self.store.pk)],
            },
            format="json",
        )

        self.assertEqual(first.status_code, 201)
        self.assertEqual(second.status_code, 200)
        body = second.json()
        self.assertEqual(body["message"], "User groups updated successfully.")
        self.assertEqual(
            [row["group"]["name"] for row in body["data"]],
            ["Store"],
        )
        self.assertFalse(
            UserGroupAssignment.objects.filter(
                user=self.member,
                group=self.sales,
            ).exists()
        )
