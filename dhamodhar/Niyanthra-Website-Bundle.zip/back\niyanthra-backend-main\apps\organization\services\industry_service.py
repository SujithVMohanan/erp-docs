from django.db import IntegrityError
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.organization.repository import IndustryRepository
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class IndustryService:
    @staticmethod
    def _decode_uid(uid: str) -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({"uid": ["Invalid industry id."]})
        if not isinstance(decoded, int):
            raise ValidationError({"uid": ["Invalid industry id."]})
        return decoded

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        industry_ids = []
        for uid in uids:
            try:
                decoded = decode_id(uid)
            except ValueError:
                raise ValidationError({"uids": ["One or more industry ids are invalid."]})
            if not isinstance(decoded, int):
                raise ValidationError({"uids": ["One or more industry ids are invalid."]})
            industry_ids.append(decoded)
        return list(dict.fromkeys(industry_ids))

    @staticmethod
    def get_industries(*, validated_data: dict):
        industry_id = None
        uid         = validated_data.get("uid")
        if uid:
            industry_id = [IndustryService._decode_uid(uid)]

        return IndustryRepository.list_industries(
            industry_id   = industry_id,
            code          = validated_data.get("code"),
            name          = validated_data.get("name"),
            is_active     = validated_data.get("is_active"),
        )

    @staticmethod
    def create_industry(*, validated_data: dict):
        code = validated_data["code"]
        if IndustryRepository.get_code_conflict(code=code):
            raise AuthValidationError(
                {"code": ["This industry code already exists."]},
                code="INDUSTRY_CODE_EXISTS",
            )
        try:
            return IndustryRepository.create_industry(
                name=validated_data["name"],
                code=code,
            )
        except IntegrityError:
            raise AuthValidationError(
                {"code": ["This industry code already exists."]},
                code="INDUSTRY_CODE_EXISTS",
            ) from None

    @staticmethod
    def update_industry(*, validated_data: dict):
        industry = IndustryRepository.get_by_id(
            IndustryService._decode_uid(validated_data["uid"])
        )
        if industry is None:
            raise NotFound("Industry not found.")

        code = validated_data["code"]
        if IndustryRepository.get_code_conflict(code=code, exclude_id=industry.pk):
            raise AuthValidationError(
                {"code": ["This industry code already exists."]},
                code="INDUSTRY_CODE_EXISTS",
            )
        try:
            return IndustryRepository.update_industry(
                industry    = industry,
                name        = validated_data["name"],
                code        = code,
            )
        except IntegrityError:
            raise AuthValidationError(
                {"code": ["This industry code already exists."]},
                code="INDUSTRY_CODE_EXISTS",
            ) from None

    @staticmethod
    def delete_industries(*, validated_data: dict) -> dict:
        industry_ids = IndustryService._decode_uids(validated_data["uids"])
        if IndustryRepository.industries_in_use(industry_ids):
            raise AuthValidationError(
                {"uids": ["Cannot delete: one or more industries are in use."]},
                code="INDUSTRY_IN_USE",
            )
        deleted = IndustryRepository.soft_delete_by_ids(industry_ids)
        if not deleted:
            raise NotFound("Industry not found.")
        return {"deleted": deleted}

    @staticmethod
    def toggle_industries(*, validated_data: dict):
        industry_ids = IndustryService._decode_uids(validated_data["uids"])
        updated      = IndustryRepository.toggle_active_by_ids(industry_ids)
        if not updated:
            raise NotFound("Industry not found.")
        return IndustryRepository.list_industries(industry_id=industry_ids)
