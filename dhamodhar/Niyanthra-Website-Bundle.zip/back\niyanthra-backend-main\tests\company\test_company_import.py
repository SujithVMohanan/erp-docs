from io import BytesIO

from django.conf import settings
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from openpyxl import Workbook
from rest_framework.test import APIClient

from apps.company.models import (
    Branch,
    Company,
    CompanyAddress,
    CompanyTaxRegistration,
    CompanyModule,
    CompanyType,
    Module,
    TaxType,
)
from apps.location.models import Country
from apps.organization.models import (
    Organization,
    OrganizationMembership,
)
from apps.tenant.models import Tenant
from apps.users.models import (
    TimeZone,
    Users,
)
from core.utils.ids import encode_id
from core.utils.tokens import issue_tokens

PASSWORD = "ValidPassw0rd!"


def _workbook(company_name="Import One"):
    book = Workbook()
    sheets = {
        "companies": [
            ["company_code", "name", "legal_name", "company_type_code", "timezone_code", "is_active"],
            ["IMP01", company_name, "Import One Pvt", "private_limited", "Asia/Kolkata", "true"],
        ],
        "branches": [
            ["company_code", "branch_code", "name", "status"],
            ["IMP01", "HQ", "Head Office", "ACTIVE"],
            ["IMP01", "PLT", "Plant", "ACTIVE"],
        ],
        "addresses": [
            ["company_code", "address_type", "country_code", "address_line_1", "city", "is_primary"],
            ["IMP01", "registered", "IN", "12 MG Road", "Kochi", "true"],
        ],
        "tax_registrations": [
            ["company_code", "country_code", "tax_type_code", "registration_number", "registration_name", "status"],
            ["IMP01", "IN", "gst", "32AAAAA0000A1Z5", "Import One Pvt", "ACTIVE"],
        ],
        "branch_taxes": [
            ["company_code", "branch_code", "tax_type_code", "registration_number", "is_primary"],
            ["IMP01", "HQ", "gst", "32AAAAA0000A1Z5", "true"],
        ],
        "company_modules": [
            ["company_code", "sales", "product"],
            ["IMP01", "true", "false"],
        ],
        "tenants": [
            ["company_code", "name", "slug", "tenant_type", "db_alias"],
            ["IMP01", "Import One", "import-one", "shared", "shared_imp01"],
        ],
    }
    first = True
    for title, rows in sheets.items():
        worksheet = book.active if first else book.create_sheet(title)
        if first:
            worksheet.title = title
            first = False
        for row in rows:
            worksheet.append(row)
    handle = BytesIO()
    book.save(handle)
    handle.seek(0)
    return handle.getvalue()


class CompanyImportApiTests(TestCase):

    databases = {"default", settings.SHARED_DB_ALIAS}

    def setUp(self):
        self.client = APIClient()
        self.admin = Users.objects.create_user(
            email="import-admin@example.com",
            password=PASSWORD,
            username="importadmin",
            phone_number="+15553330001",
            is_admin=True,
            profile_completed=True,
        )
        tokens = issue_tokens(self.admin)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")
        self.country = Country.objects.create(name="India", code="IN")
        self.organization = Organization.objects.create(
            name="Import Org",
            code="IMPORG",
            legal_name="Import Org Pvt",
            country=self.country,
        )
        OrganizationMembership.objects.create(
            organization=self.organization,
            user=self.admin,
            role="owner",
            is_active=True,
        )
        CompanyType.objects.create(name="Private Limited", code="private_limited", is_active=True)
        TimeZone.objects.create(name="India Standard Time", code="Asia/Kolkata", utc_offset="+05:30")
        TaxType.objects.create(name="GST", code="gst")
        Module.objects.create(name="Sales", code="sales", is_active=True)
        Module.objects.create(name="Product", code="product", is_active=True)
        self.organization_uid = encode_id(self.organization.pk)

    def _upload(self, content=None, organization_uid=None):
        upload = SimpleUploadedFile(
            "companies.xlsx",
            content if content is not None else _workbook(),
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        return self.client.post(
            "/api/company/import-companies/",
            {
                "file": upload,
                "organization_uid": organization_uid or self.organization_uid,
            },
            format="multipart",
        )

    def test_import_creates_then_updates_without_a_second_tenant(self):
        created = self._upload()
        self.assertEqual(created.status_code, 200, created.data)
        self.assertEqual(created.data["data"]["companies"]["created"], 1)
        self.assertEqual(created.data["data"]["branches"]["created"], 2)
        self.assertEqual(created.data["data"]["addresses"]["created"], 1)
        self.assertEqual(created.data["data"]["tax_registrations"]["created"], 1)
        self.assertEqual(created.data["data"]["branch_taxes"]["created"], 1)
        self.assertEqual(created.data["data"]["tenants"]["created"], 1)
        self.assertEqual(created.data["data"]["company_modules"]["created"], 1)
        self.assertEqual(created.data["data"]["company_modules"]["updated"], 1)
        modules = CompanyModule.objects.get(company__code="IMP01")
        self.assertTrue(modules.modules["sales"])
        self.assertFalse(modules.modules["product"])

        company = Company.objects.get(code="IMP01", organization=self.organization)
        self.assertEqual(company.tenant.tenant_type, Tenant.TenantType.SHARED)
        self.assertEqual(Branch.objects.filter(company=company).count(), 2)
        self.assertEqual(CompanyAddress.objects.filter(company=company).count(), 1)
        self.assertEqual(CompanyTaxRegistration.objects.filter(company=company).count(), 1)

        updated = self._upload(content=_workbook("Import Renamed"))
        self.assertEqual(updated.status_code, 200, updated.data)
        self.assertEqual(updated.data["data"]["companies"]["created"], 0)
        self.assertEqual(updated.data["data"]["companies"]["updated"], 1)
        self.assertEqual(updated.data["data"]["company_modules"]["created"], 0)
        self.assertEqual(updated.data["data"]["company_modules"]["updated"], 1)
        self.assertEqual(updated.data["data"]["tenants"]["created"], 0)
        company.refresh_from_db()
        self.assertEqual(company.name, "Import Renamed")
        self.assertEqual(Tenant.objects.filter(companies=company).count(), 1)

    def test_import_rejects_another_organization(self):
        other = Organization.objects.create(
            name="Other Import Org",
            code="OTIMP",
            legal_name="Other",
            country=self.country,
        )
        member = Users.objects.create_user(
            email="import-member@example.com",
            password=PASSWORD,
            username="importmember",
            phone_number="+15553330002",
            profile_completed=True,
        )
        tokens = issue_tokens(member)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")
        response = self._upload(organization_uid=encode_id(other.pk))
        self.assertEqual(response.status_code, 400)
        self.assertFalse(Company.objects.filter(code="IMP01").exists())
