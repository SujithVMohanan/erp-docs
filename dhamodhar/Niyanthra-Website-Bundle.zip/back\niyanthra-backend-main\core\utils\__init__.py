"""Generic helpers. Import submodules directly — do not load DRF from this package init."""
