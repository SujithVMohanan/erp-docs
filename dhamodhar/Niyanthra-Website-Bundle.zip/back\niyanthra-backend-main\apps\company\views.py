from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import (
    generics,
    serializers,
)
from rest_framework.permissions import IsAuthenticated

from apps.company.schemas import (
    GetBranchMembershipsApiSchema,
    GetBranchesApiSchema,
    GetCompaniesApiSchema,
    GetCompanyMembershipsApiSchema,
    GetMyBranchesApiSchema,
    GetMyCompaniesApiSchema,
    GetMyCompanyDirectoryApiSchema,
)
from apps.company.serializer import (
    AcceptMembershipInviteSerializer,
    BranchMembershipUidsSerializer,
    BranchUidsSerializer,
    CompanyMembershipUidsSerializer,
    CompanyUidsSerializer,
    CreateBranchMembershipInviteSerializer,
    CreateBranchMembershipSerializer,
    CreateBranchSerializer,
    CreateCompanyMembershipInviteSerializer,
    CreateCompanyMembershipSerializer,
    CreateCompanySerializer,
    GetBranchMembershipsQuerySerializer,
    GetBranchesQuerySerializer,
    GetCompaniesQuerySerializer,
    ImportCompaniesSerializer,
    GetMyBranchesQuerySerializer,
    GetMyCompaniesQuerySerializer,
    GetMyCompanyDirectoryQuerySerializer,
    GetCompanyMembershipsQuerySerializer,
    SelectCompanySerializer,
    UpdateBranchMembershipSerializer,
    UpdateBranchSerializer,
    UpdateCompanyMembershipSerializer,
    UpdateCompanySerializer,
)
from apps.company.services.branch_membership_service import (
    BranchMembershipService,
)
from apps.company.services.branch_service import BranchService
from apps.company.services.company_membership_service import (
    CompanyMembershipService,
)
from apps.company.services.company_import_service import CompanyImportService
from apps.company.services.company_service import CompanyService
from apps.company.services.membership_invite_service import (
    MembershipInviteService,
)
from apps.company.services.workspace_service import WorkspaceService
from core.pagination import RestPagination
from core.permissions import (
    HasMembershipAccess,
    HasOrganizationPermission,
    IsAppAuthenticated,
    IsCompanySelectable,
)
from core.responses import ResponseInfo
from core.utils.exceptions import ExceptionHandler


class CompanyBaseApiView:
    response_schema = GetCompaniesApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class GetCompaniesApiView(CompanyBaseApiView, generics.ListAPIView):

    serializer_class       = GetCompaniesApiSchema
    query_serializer_class = GetCompaniesQuerySerializer
    pagination_class       = RestPagination
    permission_classes     = [
        IsAuthenticated,
        HasOrganizationPermission,
    ]
    organization_target = "company_list"

    @swagger_auto_schema(
        tags=["Companies"],
        manual_parameters=[
            openapi.Parameter(
                "uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "code",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "name",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "organization_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "is_active",
                openapi.IN_QUERY,
                type=openapi.TYPE_BOOLEAN,
            ),
        ],
        operation_summary="Get companies",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(
            data=self.request.query_params
        )
        query.is_valid(raise_exception=True)

        return CompanyService.get_companies(
            validated_data=query.validated_data
        )


class CreateCompanyApiView(CompanyBaseApiView, generics.CreateAPIView):

    permission_classes = [
        IsAuthenticated,
        HasOrganizationPermission,
    ]
    organization_target = "actor"
    serializer_class = CreateCompanySerializer

    @swagger_auto_schema(
        request_body=CreateCompanySerializer,
        tags=["Companies"],
        operation_summary="Create company",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            company = CompanyService.create_company(
                validated_data=serializer.validated_data,
                actor=request.user,
            )

            return ResponseInfo.created(
                self.response_schema(company).data,
                message="Company created successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateCompanyApiView(CompanyBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasOrganizationPermission,
    ]
    organization_target = "company"
    organization_uid_source = "data"
    organization_uid_field = "uid"
    serializer_class = UpdateCompanySerializer

    @swagger_auto_schema(
        request_body=UpdateCompanySerializer,
        tags=["Companies"],
        operation_summary="Update company",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            company = CompanyService.update_company(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(company).data,
                message="Company updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteCompaniesApiView(CompanyBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasOrganizationPermission,
    ]
    organization_target = "company"
    organization_uid_source = "data"
    organization_uid_field = "uids"
    serializer_class = CompanyUidsSerializer

    @swagger_auto_schema(
        request_body=CompanyUidsSerializer,
        tags=["Companies"],
        operation_summary="Delete companies",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = CompanyService.delete_companies(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                payload,
                message="Company(s) deleted successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class InactiveActiveCompaniesApiView(
    CompanyBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        HasOrganizationPermission,
    ]
    organization_target = "company"
    organization_uid_source = "data"
    organization_uid_field = "uids"
    serializer_class = CompanyUidsSerializer

    @swagger_auto_schema(
        request_body=CompanyUidsSerializer,
        tags=["Companies"],
        operation_summary="Toggle company active status",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            companies = CompanyService.toggle_companies(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(companies, many=True).data,
                message="Company status updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)



class GetMyCompaniesApiView(CompanyBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsCompanySelectable,
    ]
    serializer_class = GetMyCompaniesQuerySerializer

    @swagger_auto_schema(
        tags=["Workspace"],
        manual_parameters=[
            openapi.Parameter(
                "organization_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
                description="Organization UUID or uid",
            ),
            openapi.Parameter(
                "company_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
                description="Company UUID or uid",
            ),
            openapi.Parameter(
                "name",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
        ],
        operation_summary="List companies for the current user via company membership",
    )
    def get(self, request, *args, **kwargs):
        try:
            query = GetMyCompaniesQuerySerializer(data=request.query_params)
            if not query.is_valid():
                return ResponseInfo.validation_error(query.errors)

            memberships = CompanyMembershipService.get_my_companies(
                user=request.user,
                validated_data=query.validated_data,
            )
            rows = list(memberships)
            return ResponseInfo.ok(
                {
                    "companies_count": len(rows),
                    "companies": GetMyCompaniesApiSchema(rows, many=True).data,
                },
                message="Companies retrieved successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class GetMyCompanyApiView(CompanyBaseApiView, generics.ListAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = GetMyCompanyDirectoryApiSchema
    pagination_class = RestPagination

    @swagger_auto_schema(
        tags=["Workspace"],
        manual_parameters=[
            openapi.Parameter(
                "organization_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "name",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "page",
                openapi.IN_QUERY,
                type=openapi.TYPE_INTEGER,
            ),
            openapi.Parameter(
                "limit",
                openapi.IN_QUERY,
                type=openapi.TYPE_INTEGER,
            ),
        ],
        operation_summary="List company cards for the current user",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = GetMyCompanyDirectoryQuerySerializer(data=self.request.query_params)
        query.is_valid(raise_exception=True)
        return WorkspaceService.list_company_directory(
            user=self.request.user,
            validated_data=query.validated_data,
        )


class ImportCompaniesApiView(CompanyBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = ImportCompaniesSerializer

    @swagger_auto_schema(
        request_body=ImportCompaniesSerializer,
        tags=["Companies"],
        operation_summary="Import companies from Excel",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            payload = CompanyImportService.import_workbook(
                actor=request.user,
                uploaded_file=serializer.validated_data["file"],
                organization_uid=serializer.validated_data["organization_uid"],
            )
            return ResponseInfo.ok(
                payload,
                message="Company import finished.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class GetMyBranchesApiView(CompanyBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsCompanySelectable,
    ]
    serializer_class = GetMyBranchesQuerySerializer

    @swagger_auto_schema(
        tags=["Workspace"],
        manual_parameters=[
            openapi.Parameter(
                "company_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "branch_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "name",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
        ],
        operation_summary="List branches for the current user via branch membership",
    )
    def get(self, request, *args, **kwargs):
        try:
            query = GetMyBranchesQuerySerializer(data=request.query_params)
            if not query.is_valid():
                return ResponseInfo.validation_error(query.errors)
            memberships = BranchMembershipService.get_my_branches(
                user=request.user,
                validated_data=query.validated_data,
            )
            rows = list(memberships)
            return ResponseInfo.ok(
                {
                    "branches_count": len(rows),
                    "branches": GetMyBranchesApiSchema(rows, many=True).data,
                },
                message="Branches retrieved successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class SelectCompanyApiView(CompanyBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsCompanySelectable,
        HasMembershipAccess,
    ]
    membership_uid_source = "data"
    serializer_class = SelectCompanySerializer

    @swagger_auto_schema(
        request_body=SelectCompanySerializer,
        tags=["Workspace"],
        operation_summary="Select company and bind its tenant",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = WorkspaceService.select_company(
                user=request.user,
                validated_data=serializer.validated_data,
                company=getattr(request, "_membership_company", None),
            )
            return ResponseInfo.ok(
                payload,
                message="Company selected successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class BranchBaseApiView:
    response_schema = GetBranchesApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class GetBranchesApiView(BranchBaseApiView, generics.ListAPIView):

    serializer_class = GetBranchesApiSchema
    query_serializer_class = GetBranchesQuerySerializer
    pagination_class = RestPagination
    permission_classes = [
        IsAuthenticated,
        HasOrganizationPermission,
    ]
    organization_target = "branch_list"

    @swagger_auto_schema(
        tags=["Branches"],
        manual_parameters=[
            openapi.Parameter(
                "uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "code",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "name",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "company_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "status",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
        ],
        operation_summary="Get branches",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(
            data=self.request.query_params
        )
        query.is_valid(raise_exception=True)

        return BranchService.get_branches(
            validated_data=query.validated_data
        )


class CreateBranchApiView(BranchBaseApiView, generics.CreateAPIView):

    permission_classes = [
        IsAuthenticated,
        HasOrganizationPermission,
    ]
    organization_target = "company"
    organization_uid_source = "data"
    organization_uid_field = "company_uid"
    serializer_class = CreateBranchSerializer

    @swagger_auto_schema(
        request_body=CreateBranchSerializer,
        tags=["Branches"],
        operation_summary="Create branch",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            branch = BranchService.create_branch(
                validated_data=serializer.validated_data,
                actor=request.user,
            )

            return ResponseInfo.created(
                self.response_schema(branch).data,
                message="Branch created successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateBranchApiView(BranchBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasOrganizationPermission,
    ]
    organization_target = "company"
    organization_uid_source = "data"
    organization_uid_field = "company_uid"
    serializer_class = UpdateBranchSerializer

    @swagger_auto_schema(
        request_body=UpdateBranchSerializer,
        tags=["Branches"],
        operation_summary="Update branch",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            branch = BranchService.update_branch(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(branch).data,
                message="Branch updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteBranchesApiView(BranchBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasOrganizationPermission,
    ]
    organization_target = "branch"
    organization_uid_source = "data"
    organization_uid_field = "uids"
    serializer_class = BranchUidsSerializer

    @swagger_auto_schema(
        request_body=BranchUidsSerializer,
        tags=["Branches"],
        operation_summary="Delete branches",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = BranchService.delete_branches(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                payload,
                message="Branch(es) deleted successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class InactiveActiveBranchesApiView(
    BranchBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        HasOrganizationPermission,
    ]
    organization_target = "branch"
    organization_uid_source = "data"
    organization_uid_field = "uids"
    serializer_class = BranchUidsSerializer

    @swagger_auto_schema(
        request_body=BranchUidsSerializer,
        tags=["Branches"],
        operation_summary="Toggle branch status",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            branches = BranchService.toggle_branches(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(branches, many=True).data,
                message="Branch status updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class BranchMembershipBaseApiView:
    response_schema = GetBranchMembershipsApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class GetBranchMembershipsApiView(
    BranchMembershipBaseApiView,
    generics.ListAPIView,
):

    serializer_class = GetBranchMembershipsApiSchema
    query_serializer_class = GetBranchMembershipsQuerySerializer
    pagination_class = RestPagination
    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]

    @swagger_auto_schema(
        tags=["Branch Memberships"],
        manual_parameters=[
            openapi.Parameter(
                "uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "branch_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "user_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "company_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "role",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "is_active",
                openapi.IN_QUERY,
                type=openapi.TYPE_BOOLEAN,
            ),
        ],
        operation_summary="Get branch memberships",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(
            data=self.request.query_params
        )
        query.is_valid(raise_exception=True)

        return BranchMembershipService.get_memberships(
            validated_data=query.validated_data
        )


class CreateBranchMembershipApiView(
    BranchMembershipBaseApiView,
    generics.CreateAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = CreateBranchMembershipSerializer

    @swagger_auto_schema(
        request_body=CreateBranchMembershipSerializer,
        tags=["Branch Memberships"],
        operation_summary="Create branch membership",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            membership = BranchMembershipService.create_membership(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.created(
                self.response_schema(membership).data,
                message="Branch membership created successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateBranchMembershipApiView(
    BranchMembershipBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "branch"
    serializer_class = UpdateBranchMembershipSerializer

    @swagger_auto_schema(
        request_body=UpdateBranchMembershipSerializer,
        tags=["Branch Memberships"],
        operation_summary="Update branch membership",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            membership = BranchMembershipService.update_membership(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(membership).data,
                message="Branch membership updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteBranchMembershipsApiView(
    BranchMembershipBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "branch_membership_uids"
    serializer_class = BranchMembershipUidsSerializer

    @swagger_auto_schema(
        request_body=BranchMembershipUidsSerializer,
        tags=["Branch Memberships"],
        operation_summary="Delete branch memberships",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = BranchMembershipService.delete_memberships(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                payload,
                message="Branch membership(s) deleted successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class InactiveActiveBranchMembershipsApiView(
    BranchMembershipBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "branch_membership_uids"
    serializer_class = BranchMembershipUidsSerializer

    @swagger_auto_schema(
        request_body=BranchMembershipUidsSerializer,
        tags=["Branch Memberships"],
        operation_summary="Toggle branch membership active status",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            memberships = BranchMembershipService.toggle_memberships(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(memberships, many=True).data,
                message="Branch membership status updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class CompanyMembershipBaseApiView:
    response_schema = GetCompanyMembershipsApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class GetCompanyMembershipsApiView(
    CompanyMembershipBaseApiView,
    generics.ListAPIView,
):

    serializer_class = GetCompanyMembershipsApiSchema
    query_serializer_class = GetCompanyMembershipsQuerySerializer
    pagination_class = RestPagination
    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]

    @swagger_auto_schema(
        tags=["Company Memberships"],
        manual_parameters=[
            openapi.Parameter(
                "uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "company_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "user_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "role",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "is_active",
                openapi.IN_QUERY,
                type=openapi.TYPE_BOOLEAN,
            ),
        ],
        operation_summary="Get company memberships",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(
            data=self.request.query_params
        )
        query.is_valid(raise_exception=True)

        return CompanyMembershipService.get_memberships(
            validated_data=query.validated_data
        )


class CreateCompanyMembershipApiView(
    CompanyMembershipBaseApiView,
    generics.CreateAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = CreateCompanyMembershipSerializer

    @swagger_auto_schema(
        request_body=CreateCompanyMembershipSerializer,
        tags=["Company Memberships"],
        operation_summary="Create company membership",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            membership = CompanyMembershipService.create_membership(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.created(
                self.response_schema(membership).data,
                message="Company membership created successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateCompanyMembershipApiView(
    CompanyMembershipBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "data"
    membership_company_field = "company_uid"
    serializer_class = UpdateCompanyMembershipSerializer

    @swagger_auto_schema(
        request_body=UpdateCompanyMembershipSerializer,
        tags=["Company Memberships"],
        operation_summary="Update company membership",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            membership = CompanyMembershipService.update_membership(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(membership).data,
                message="Company membership updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteCompanyMembershipsApiView(
    CompanyMembershipBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "company_membership_uids"
    serializer_class = CompanyMembershipUidsSerializer

    @swagger_auto_schema(
        request_body=CompanyMembershipUidsSerializer,
        tags=["Company Memberships"],
        operation_summary="Delete company memberships",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = CompanyMembershipService.delete_memberships(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                payload,
                message="Company membership(s) deleted successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class InactiveActiveCompanyMembershipsApiView(
    CompanyMembershipBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "company_membership_uids"
    serializer_class = CompanyMembershipUidsSerializer

    @swagger_auto_schema(
        request_body=CompanyMembershipUidsSerializer,
        tags=["Company Memberships"],
        operation_summary="Toggle company membership active status",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            memberships = CompanyMembershipService.toggle_memberships(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(memberships, many=True).data,
                message="Company membership status updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class MembershipInviteBaseApiView:

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class CreateCompanyMembershipInviteApiView(
    MembershipInviteBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "data"
    membership_company_field = "company_uid"
    serializer_class = CreateCompanyMembershipInviteSerializer

    @swagger_auto_schema(
        request_body=CreateCompanyMembershipInviteSerializer,
        tags=["Membership Invites"],
        operation_summary="Create company membership invite link",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = MembershipInviteService.create_company_invite(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.created(
                payload,
                message="Company membership invite created successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class CreateBranchMembershipInviteApiView(
    MembershipInviteBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "branch"
    serializer_class = CreateBranchMembershipInviteSerializer

    @swagger_auto_schema(
        request_body=CreateBranchMembershipInviteSerializer,
        tags=["Membership Invites"],
        operation_summary="Create branch membership invite link",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = MembershipInviteService.create_branch_invite(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.created(
                payload,
                message="Branch membership invite created successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class AcceptMembershipInviteApiView(
    MembershipInviteBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = AcceptMembershipInviteSerializer

    @swagger_auto_schema(
        request_body=AcceptMembershipInviteSerializer,
        tags=["Membership Invites"],
        operation_summary="Accept membership invite",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = MembershipInviteService.accept_invite(
                user=request.user,
                validated_data=serializer.validated_data,
            )

            return ResponseInfo.ok(
                payload,
                message="Membership invite accepted successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)

