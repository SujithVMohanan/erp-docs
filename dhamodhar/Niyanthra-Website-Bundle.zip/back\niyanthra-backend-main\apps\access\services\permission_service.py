from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.access.repository import PermissionRepository
from core.utils.ids import decode_id


class PermissionService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})

        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})

        return decoded

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        return list(
            dict.fromkeys(
                PermissionService._decode_uid(uid, field="uids")
                for uid in uids
            )
        )

    @staticmethod
    def get_permissions(*, validated_data: dict):
        permission_id = None

        if validated_data.get("uid"):
            permission_id = [
                PermissionService._decode_uid(
                    validated_data["uid"]
                )
            ]

        return PermissionRepository.list_permissions(
            permission_id=permission_id,
            codename=validated_data.get("codename"),
            content_type=validated_data.get("content_type"),
            name=validated_data.get("name"),
        )

    @staticmethod
    def create_permission(*, validated_data: dict):
        return PermissionRepository.create(
            codename=validated_data["codename"],
            name=validated_data["name"],
            content_type=validated_data["content_type"],
            label=validated_data.get("label") or "",
            sub_label=validated_data.get("sub_label") or "",
        )

    @staticmethod
    def update_permission(*, validated_data: dict):
        permission = PermissionRepository.get_by_id(
            PermissionService._decode_uid(validated_data["uid"])
        )
        if permission is None:
            raise NotFound("Permission not found.")

        return PermissionRepository.update(
            permission,
            codename=validated_data["codename"],
            name=validated_data["name"],
            content_type=validated_data["content_type"],
            label=validated_data.get("label") or "",
            sub_label=validated_data.get("sub_label") or "",
        )

    @staticmethod
    def delete_permissions(*, validated_data: dict) -> dict:
        deleted = PermissionRepository.delete_by_ids(
            PermissionService._decode_uids(validated_data["uids"])
        )
        if not deleted:
            raise NotFound("Permission not found.")

        return {
            "deleted": deleted
        }
