"""
Shared tenant-plane helpers (not Django app code).

- context / managers → ORM row isolation
- workspace → JWT workspace scope helpers

App CRUD stays in apps.*; AWS/secrets stay in infrastructure.aws.
"""

from core.tenant.context import (
    TenantIdentity,
    clear_current_tenant,
    get_current_tenant,
    get_current_tenant_id,
    require_current_tenant,
    reset_current_tenant,
    set_current_tenant,
    tenant_context,
)
from core.tenant.exceptions import TenantContextError
from core.tenant.managers import (
    TenantAwareManager,
    TenantAwareQuerySet,
    TenantUnscopedManager,
    TenantUnscopedQuerySet,
)

__all__ = [
    "TenantAwareManager",
    "TenantAwareQuerySet",
    "TenantContextError",
    "TenantIdentity",
    "TenantUnscopedManager",
    "TenantUnscopedQuerySet",
    "clear_current_tenant",
    "get_current_tenant",
    "get_current_tenant_id",
    "require_current_tenant",
    "reset_current_tenant",
    "set_current_tenant",
    "tenant_context",
]
