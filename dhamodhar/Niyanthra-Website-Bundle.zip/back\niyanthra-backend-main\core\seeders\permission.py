from core.seeders.base import run_group

GROUP = "permission"


def run() -> dict:
    return run_group(GROUP)
