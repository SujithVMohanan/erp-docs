from django.db.models import Q
from django.db.models.query import QuerySet
from django.utils import timezone
from rest_framework_simplejwt.token_blacklist.models import (
    BlacklistedToken,
    OutstandingToken,
)

from apps.users.models import (
    TimeZone,
    UserAuthProvider,
    UserManager,
    Users,
)


def integrity_field_errors(exc) -> tuple[dict, str]:
    message = str(exc)
    errors = {}
    code = "CONFLICT"
    if "users_email_alive_uniq" in message:
        errors["email"] = ["This email is already registered."]
        code = "EMAIL_ALREADY_EXISTS"
    if "users_phone_alive_uniq" in message:
        errors["phone_number"] = ["This phone number is already registered."]
        code = "PHONE_ALREADY_EXISTS" if "email" not in errors else "VALIDATION_ERROR"
    if "users_username_alive_uniq" in message:
        errors["username"] = ["This username is already taken."]
        code = "USERNAME_ALREADY_TAKEN" if not errors else "VALIDATION_ERROR"
    if "uap_provider_subject_alive_uniq" in message:
        errors["detail"] = ["This Google account is already linked."]
        code = "GOOGLE_ACCOUNT_EXISTS"
    if not errors:
        errors = {"detail": ["Request could not be completed."]}
    return errors, code


class UserRepository:
    @staticmethod
    def get_alive_by_email(email: str) -> Users | None:
        normalized = UserManager.normalize_email(email)
        return Users.objects.filter(email=normalized).first()

    @staticmethod
    def get_for_login(email: str) -> Users | None:
        """One indexed lookup. Only the columns the login response and password check use."""
        normalized = UserManager.normalize_email(email)
        return (
            Users.objects.filter(email=normalized)
            .only(
                "id",
                "password",
                "public_id",
                "username",
                "email",
                "phone_number",
                "profile_image",
                "profile_completed",
                "is_active",
                "is_admin",
                "is_staff",
                "is_superuser",
                "is_email_verified",
                "is_phone_verified",
                "created_at",
                "updated_at",
                "last_login",
            )
            .first()
        )

    @staticmethod
    def get_alive_by_public_id(public_id: str) -> Users | None:
        return Users.objects.filter(public_id=public_id).first()

    @staticmethod
    def lock_alive_by_id(user_id: int) -> Users:
        return Users.objects.select_for_update().get(pk=user_id)

    @staticmethod
    def update_last_login(user: Users) -> None:
        Users.objects.filter(pk=user.pk).update(last_login=timezone.now())

    @staticmethod
    def list_alive_conflicts(
        *,
        email: str | None = None,
        username: str | None = None,
        phone_number: str | None = None,
        exclude_user_id: int | None = None,
    ):
        q = Q()
        if email:
            q |= Q(email=UserManager.normalize_email(email))
        if username:
            q |= Q(username=username)
        if phone_number:
            q |= Q(phone_number=phone_number)
        query = Users.objects.filter(q).only("email", "username", "phone_number")
        if exclude_user_id:
            query = query.exclude(pk=exclude_user_id)
        return query



    @staticmethod
    def create_user(
        *,
        email: str,
        password: str,
        username: str | None = None,
        phone_number: str | None = None,
    ) -> Users:
        
        return Users.objects.create_user(
            email               = email,
            password            = password,
            username            = username,
            phone_number        = phone_number,
            profile_completed   = all([
                username,
                password,
                phone_number,
                email,
            ]),
        )
    

    @staticmethod
    def list_users(
        *,
        user_id: int | list[int] | None = None,
        email: str | None = None,
        name: str | None = None,
    ):
        filters = Q()

        if user_id:
            ids = user_id if isinstance(user_id, (list, tuple, set)) else [user_id]
            filters &= Q(id__in=ids)

        if email:
            filters &= Q(email__icontains=email)

        if name:
            filters &= Q(username__icontains=name)

        return (
            Users.objects.select_related("invited_by")
            .only(
                "id",
                "public_id",
                "username",
                "email",
                "phone_number",
                "profile_image",
                "profile_completed",
                "is_active",
                "is_admin",
                "is_staff",
                "is_email_verified",
                "is_phone_verified",
                "created_at",
                "updated_at",
                "invited_by_id",
                "invited_by__public_id",
            )
            .filter(filters)
        )

    @staticmethod
    def revoke_outstanding_tokens(user_ids: list[int]) -> int:
        outstanding_tokens = OutstandingToken.objects.filter(
            user_id__in=user_ids,
        )

        blacklisted_tokens = [
            BlacklistedToken(token=token)
            for token in outstanding_tokens
        ]

        created = BlacklistedToken.objects.bulk_create(
            blacklisted_tokens,
            ignore_conflicts=True,
        )

        return len(created)

    @staticmethod
    def soft_delete_by_ids(user_ids: list[int]) -> int:
        count, _ = Users.objects.filter(id__in=user_ids).delete()
        return count

    @staticmethod
    def hard_delete_by_ids(user_ids: list[int]) -> int:
        queryset = Users.all_objects.filter(
            id__in=user_ids,
            is_superuser=False,
        )
        count, _ = QuerySet.delete(queryset)
        return count

    @staticmethod
    def list_superuser_ids(user_ids: list[int]) -> list[int]:
        return list(
            Users.all_objects.filter(id__in=user_ids, is_superuser=True).values_list(
                "id",
                flat=True,
            )
        )

    @staticmethod
    def get_by_provider_subject(
        *, 
        provider: str, 
        subject: str
        ) -> UserAuthProvider | None:
        
        link = (
            UserAuthProvider.objects
            .select_related("user")
            .filter(provider=provider, subject=subject)
            .first()
        )

        if link is None:
            return None
        
        if link.user.deleted_at is not None:
            link.delete()
            return None
        
        return link

    @staticmethod
    def create_social_user(*, email: str, username: str | None = None) -> Users:
        return Users.objects.create_social_user(
            email=email,
            username=username,
        )

    @staticmethod
    def link_provider(
        *,
        user: Users,
        provider: str,
        subject: str,
        email: str | None = None,
    ) -> UserAuthProvider:
        return UserAuthProvider.objects.create(
            user=user,
            provider=provider,
            subject=subject,
            email=email,
        )

    @staticmethod
    def mark_email_verified(user: Users) -> Users:

        if user.is_email_verified:
            return user
        
        now = timezone.now()
        Users.objects.filter(pk=user.pk).update(
            is_email_verified=True,
            email_verified_at=now,
        )
        user.is_email_verified = True
        user.email_verified_at = now
        return user

    @staticmethod
    def get_username_conflict(*, username: str, exclude_user_id: int | None = None) -> Users | None:
        query = Users.objects.filter(username=username)
        if exclude_user_id:
            query = query.exclude(pk=exclude_user_id)
        return query.first()

    @staticmethod
    def get_phone_conflict(*, phone_number: str, exclude_user_id: int | None = None) -> Users | None:
        query = Users.objects.filter(phone_number=phone_number)
        if exclude_user_id:
            query = query.exclude(pk=exclude_user_id)
        return query.first()

    @staticmethod
    def get_email_conflict(*, email: str, exclude_user_id: int | None = None) -> Users | None:
        query = Users.objects.filter(email=UserManager.normalize_email(email))
        if exclude_user_id:
            query = query.exclude(pk=exclude_user_id)
        return query.first()

    @staticmethod
    def update_user_profile(
        *,
        user: Users,
        username: str | None = None,
        phone_number: str | None = None,
        password: str | None = None,
    ) -> Users:
        update_fields = ["updated_at"]
        if username is not None:
            user.username = username
            update_fields.append("username")
        if phone_number is not None:
            user.phone_number = phone_number
            update_fields.append("phone_number")
        if password:
            user.set_password(password)
            update_fields.append("password")
        user.save(update_fields=update_fields)
        return user


class TimeZoneRepository:
    @staticmethod
    def upsert(
        *,
        public_id,
        code: str,
        name: str,
        utc_offset: str | None = None,
        is_active: bool = True,
    ) -> tuple[TimeZone, bool]:
        normalized = code.strip()
        row = TimeZone.all_objects.filter(code=normalized).first()
        if row is None:
            row = TimeZone(
                public_id=public_id,
                code=normalized,
                name=name,
                utc_offset=utc_offset,
                is_active=is_active,
            )
            row.save()
            return row, True

        row.name = name
        row.utc_offset = utc_offset
        row.is_active = is_active
        row.deleted_at = None
        row.save(
            update_fields=[
                "name",
                "utc_offset",
                "is_active",
                "deleted_at",
                "updated_at",
            ]
        )
        return row, False
