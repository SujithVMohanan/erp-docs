from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated

from apps.organization.schemas import (
    GetCountriesApiSchema,
    GetIndustriesApiSchema,
    GetOrganizationLocationsApiSchema,
    GetOrganizationMembershipsApiSchema,
    GetOrganizationsApiSchema,
    GetMyOrganizationApiSchema,
    GetMyOrganizationsApiSchema,
)
from apps.organization.serializers import (
    CountryUidsSerializer,
    CreateCountrySerializer,
    CreateIndustrySerializer,
    CreateOrganizationLocationSerializer,
    CreateOrganizationMembershipInviteSerializer,
    CreateOrganizationMembershipSerializer,
    CreateOrganizationSerializer,
    GetCountriesQuerySerializer,
    GetIndustriesQuerySerializer,
    GetOrganizationLocationsQuerySerializer,
    GetOrganizationMembershipsQuerySerializer,
    GetOrganizationsQuerySerializer,
    GetMyOrganizationsQuerySerializer,
    IndustryUidsSerializer,
    OrganizationLocationUidsSerializer,
    OrganizationMembershipUidsSerializer,
    OrganizationUidsSerializer,
    SkipOrganizationSerializer,
    UpdateCountrySerializer,
    UpdateIndustrySerializer,
    UpdateOrganizationLocationSerializer,
    UpdateOrganizationMembershipSerializer,
    UpdateOrganizationSerializer,
)
from apps.organization.services.country_service import CountryService
from apps.organization.services.industry_service import IndustryService
from apps.organization.services.organization_location_service import (
    OrganizationLocationService,
)
from apps.organization.services.organization_membership_service import (
    OrganizationMembershipService,
)
from apps.organization.repository import OrganizationRepository
from apps.organization.services.organization_service import OrganizationService
from core.pagination import RestPagination
from core.permissions import (
    IsAppAuthenticated,
    IsPlatformAdmin,
)
from core.responses import ResponseInfo
from core.utils.exceptions import ExceptionHandler


class CountryBaseApiView:
    response_schema = GetCountriesApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class IndustryBaseApiView:
    response_schema = GetIndustriesApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class OrganizationBaseApiView:
    response_schema = GetOrganizationsApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


# ── Countries ────────────────────────────────────────────────────────────────


class GetCountriesApiView(CountryBaseApiView, generics.ListAPIView):

    serializer_class       = GetCountriesApiSchema
    query_serializer_class = GetCountriesQuerySerializer
    pagination_class       = RestPagination
    permission_classes     = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]

    @swagger_auto_schema(
        tags=["Countries"],
        manual_parameters=[
            openapi.Parameter(
                "uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "code",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "name",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "is_active",
                openapi.IN_QUERY,
                type=openapi.TYPE_BOOLEAN,
            ),
        ],
        operation_summary="Get countries",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(
            data=self.request.query_params
        )
        query.is_valid(raise_exception=True)

        return CountryService.get_countries(
            validated_data=query.validated_data
        )


class CreateCountryApiView(CountryBaseApiView, generics.CreateAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = CreateCountrySerializer

    @swagger_auto_schema(
        request_body=CreateCountrySerializer,
        tags=["Countries"],
        operation_summary="Create country",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            country = CountryService.create_country(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.created(
                self.response_schema(country).data,
                message="Country created successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateCountryApiView(CountryBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = UpdateCountrySerializer

    @swagger_auto_schema(
        request_body=UpdateCountrySerializer,
        tags=["Countries"],
        operation_summary="Update country",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            country = CountryService.update_country(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(country).data,
                message="Country updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteCountriesApiView(CountryBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = CountryUidsSerializer

    @swagger_auto_schema(
        request_body=CountryUidsSerializer,
        tags=["Countries"],
        operation_summary="Delete countries",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = CountryService.delete_countries(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                payload,
                message="Country(s) deleted successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class InactiveActiveCountriesApiView(
    CountryBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = CountryUidsSerializer

    @swagger_auto_schema(
        request_body=CountryUidsSerializer,
        tags=["Countries"],
        operation_summary="Toggle country active status",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            countries = CountryService.toggle_countries(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(countries, many=True).data,
                message="Country status updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


# ── Industries ───────────────────────────────────────────────────────────────


class GetIndustriesApiView(IndustryBaseApiView, generics.ListAPIView):

    serializer_class       = GetIndustriesApiSchema
    query_serializer_class = GetIndustriesQuerySerializer
    pagination_class       = RestPagination
    permission_classes     = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]

    @swagger_auto_schema(
        tags=["Industries"],
        manual_parameters=[
            openapi.Parameter(
                "uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "code",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "name",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "is_active",
                openapi.IN_QUERY,
                type=openapi.TYPE_BOOLEAN,
            ),
        ],
        operation_summary="Get industries",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(
            data=self.request.query_params
        )
        query.is_valid(raise_exception=True)

        return IndustryService.get_industries(
            validated_data=query.validated_data
        )


class CreateIndustryApiView(IndustryBaseApiView, generics.CreateAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = CreateIndustrySerializer

    @swagger_auto_schema(
        request_body=CreateIndustrySerializer,
        tags=["Industries"],
        operation_summary="Create industry",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            industry = IndustryService.create_industry(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.created(
                self.response_schema(industry).data,
                message="Industry created successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateIndustryApiView(IndustryBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = UpdateIndustrySerializer

    @swagger_auto_schema(
        request_body=UpdateIndustrySerializer,
        tags=["Industries"],
        operation_summary="Update industry",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            industry = IndustryService.update_industry(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(industry).data,
                message="Industry updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteIndustriesApiView(IndustryBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = IndustryUidsSerializer

    @swagger_auto_schema(
        request_body=IndustryUidsSerializer,
        tags=["Industries"],
        operation_summary="Delete industries",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = IndustryService.delete_industries(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                payload,
                message="Industry(s) deleted successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class InactiveActiveIndustriesApiView(
    IndustryBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = IndustryUidsSerializer

    @swagger_auto_schema(
        request_body=IndustryUidsSerializer,
        tags=["Industries"],
        operation_summary="Toggle industry active status",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            industries = IndustryService.toggle_industries(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(industries, many=True).data,
                message="Industry status updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


# ── Organizations ────────────────────────────────────────────────────────────


class GetOrganizationsApiView(OrganizationBaseApiView, generics.ListAPIView):

    serializer_class       = GetOrganizationsApiSchema
    query_serializer_class = GetOrganizationsQuerySerializer
    pagination_class       = RestPagination
    permission_classes     = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]

    @swagger_auto_schema(
        tags=["Organizations"],
        manual_parameters=[
            openapi.Parameter(
                "uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "code",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "name",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "is_active",
                openapi.IN_QUERY,
                type=openapi.TYPE_BOOLEAN,
            ),
            openapi.Parameter(
                "country_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "industry_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
        ],
        operation_summary="Get organizations",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(
            data=self.request.query_params
        )
        query.is_valid(raise_exception=True)

        return OrganizationService.get_organizations(
            validated_data=query.validated_data
        )


class CreateOrganizationApiView(
    OrganizationBaseApiView,
    generics.CreateAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = CreateOrganizationSerializer

    @swagger_auto_schema(
        request_body=CreateOrganizationSerializer,
        tags=["Organizations"],
        operation_summary="Create organization",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            organization = OrganizationService.create_organization(
                validated_data=serializer.validated_data,
                actor=request.user,
            )

            return ResponseInfo.created(
                self.response_schema(organization).data,
                message="Organization created successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateOrganizationApiView(
    OrganizationBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = UpdateOrganizationSerializer

    @swagger_auto_schema(
        request_body=UpdateOrganizationSerializer,
        tags=["Organizations"],
        operation_summary="Update organization",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            organization = OrganizationService.update_organization(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(organization).data,
                message="Organization updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteOrganizationsApiView(
    OrganizationBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = OrganizationUidsSerializer

    @swagger_auto_schema(
        request_body=OrganizationUidsSerializer,
        tags=["Organizations"],
        operation_summary="Delete organizations",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = OrganizationService.delete_organizations(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                payload,
                message="Organization(s) deleted successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class InactiveActiveOrganizationsApiView(
    OrganizationBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = OrganizationUidsSerializer

    @swagger_auto_schema(
        request_body=OrganizationUidsSerializer,
        tags=["Organizations"],
        operation_summary="Toggle organization active status",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            organizations = OrganizationService.toggle_organizations(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(organizations, many=True).data,
                message="Organization status updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class OrganizationMembershipBaseApiView:
    response_schema = GetOrganizationMembershipsApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class GetOrganizationMembershipsApiView(
    OrganizationMembershipBaseApiView,
    generics.ListAPIView,
):

    serializer_class = GetOrganizationMembershipsApiSchema
    query_serializer_class = GetOrganizationMembershipsQuerySerializer
    pagination_class = RestPagination
    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]

    @swagger_auto_schema(
        tags=["Organization Memberships"],
        manual_parameters=[
            openapi.Parameter("uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("organization_uid", openapi.IN_QUERY, type=openapi.TYPE_STRING, required=True),
            openapi.Parameter("user_uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("email", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("name", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("role", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter(
                "audience",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
                description="admin | employee",
            ),
            openapi.Parameter("is_active", openapi.IN_QUERY, type=openapi.TYPE_BOOLEAN),
        ],
        operation_summary="Get organization memberships (Admin section)",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(data=self.request.query_params)
        query.is_valid(raise_exception=True)
        return OrganizationMembershipService.get_memberships(
            validated_data=query.validated_data,
            actor=self.request.user,
        )


class CreateOrganizationMembershipApiView(
    OrganizationMembershipBaseApiView,
    generics.CreateAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = CreateOrganizationMembershipSerializer

    @swagger_auto_schema(
        request_body=CreateOrganizationMembershipSerializer,
        tags=["Organization Memberships"],
        operation_summary="Add organization member (Admin section)",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            membership = OrganizationMembershipService.create_membership(
                validated_data=serializer.validated_data,
                actor=request.user,
            )
            return ResponseInfo.created(
                self.response_schema(membership).data,
                message="Organization membership created successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class CreateOrganizationMembershipInviteApiView(
    OrganizationMembershipBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = CreateOrganizationMembershipInviteSerializer

    @swagger_auto_schema(
        request_body=CreateOrganizationMembershipInviteSerializer,
        tags=["Organization Memberships"],
        operation_summary="Create organization membership invite link",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            payload = OrganizationMembershipService.create_invite(
                validated_data=serializer.validated_data,
                actor=request.user,
            )
            return ResponseInfo.created(
                payload,
                message="Organization membership invite created successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateOrganizationMembershipApiView(
    OrganizationMembershipBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = UpdateOrganizationMembershipSerializer

    @swagger_auto_schema(
        request_body=UpdateOrganizationMembershipSerializer,
        tags=["Organization Memberships"],
        operation_summary="Update organization membership",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            membership = OrganizationMembershipService.update_membership(
                validated_data=serializer.validated_data,
                actor=request.user,
            )
            return ResponseInfo.ok(
                self.response_schema(membership).data,
                message="Organization membership updated successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteOrganizationMembershipsApiView(
    OrganizationMembershipBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = OrganizationMembershipUidsSerializer

    @swagger_auto_schema(
        request_body=OrganizationMembershipUidsSerializer,
        tags=["Organization Memberships"],
        operation_summary="Delete organization memberships",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            payload = OrganizationMembershipService.delete_memberships(
                validated_data=serializer.validated_data,
                actor=request.user,
            )
            return ResponseInfo.ok(
                payload,
                message="Organization membership(s) deleted successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class InactiveActiveOrganizationMembershipsApiView(
    OrganizationMembershipBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = OrganizationMembershipUidsSerializer

    @swagger_auto_schema(
        request_body=OrganizationMembershipUidsSerializer,
        tags=["Organization Memberships"],
        operation_summary="Toggle organization membership active status",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            memberships = OrganizationMembershipService.toggle_memberships(
                validated_data=serializer.validated_data,
                actor=request.user,
            )
            return ResponseInfo.ok(
                self.response_schema(memberships, many=True).data,
                message="Organization membership status updated successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class OrganizationLocationBaseApiView:
    response_schema = GetOrganizationLocationsApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class GetOrganizationLocationsApiView(
    OrganizationLocationBaseApiView,
    generics.ListAPIView,
):

    serializer_class = GetOrganizationLocationsApiSchema
    query_serializer_class = GetOrganizationLocationsQuerySerializer
    pagination_class = RestPagination
    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]

    @swagger_auto_schema(
        tags=["Organization Locations"],
        manual_parameters=[
            openapi.Parameter("uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("organization_uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("location_uid", openapi.IN_QUERY, type=openapi.TYPE_STRING),
            openapi.Parameter("is_primary", openapi.IN_QUERY, type=openapi.TYPE_BOOLEAN),
        ],
        operation_summary="Get organization locations",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(data=self.request.query_params)
        query.is_valid(raise_exception=True)
        return OrganizationLocationService.get_links(
            validated_data=query.validated_data
        )


class CreateOrganizationLocationApiView(
    OrganizationLocationBaseApiView,
    generics.CreateAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = CreateOrganizationLocationSerializer

    @swagger_auto_schema(
        request_body=CreateOrganizationLocationSerializer,
        tags=["Organization Locations"],
        operation_summary="Create organization location",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            link = OrganizationLocationService.create_link(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.created(
                self.response_schema(link).data,
                message="Organization location created successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateOrganizationLocationApiView(
    OrganizationLocationBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = UpdateOrganizationLocationSerializer

    @swagger_auto_schema(
        request_body=UpdateOrganizationLocationSerializer,
        tags=["Organization Locations"],
        operation_summary="Update organization location",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            link = OrganizationLocationService.update_link(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                self.response_schema(link).data,
                message="Organization location updated successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteOrganizationLocationsApiView(
    OrganizationLocationBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = OrganizationLocationUidsSerializer

    @swagger_auto_schema(
        request_body=OrganizationLocationUidsSerializer,
        tags=["Organization Locations"],
        operation_summary="Delete organization locations",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            payload = OrganizationLocationService.delete_links(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                payload,
                message="Organization location(s) deleted successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)



class SkipNowOrganizationApiView(
    OrganizationBaseApiView,
    generics.CreateAPIView,
):
    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = SkipOrganizationSerializer

    @swagger_auto_schema(
        request_body=SkipOrganizationSerializer,
        tags=["Organizations"],
        operation_summary="Skip organization setup",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            organization = OrganizationService.create_default_organization(
                    actor=request.user,
                )

            return ResponseInfo.created(
                self.response_schema(organization).data,
                message="Default organization created successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class GetMyOrganizationApiView(OrganizationMembershipBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = GetMyOrganizationsQuerySerializer

    @swagger_auto_schema(
        tags=["Organizations"],
        manual_parameters=[
            openapi.Parameter(
                "name",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
        ],
        operation_summary="List organizations for the current user via membership",
    )
    def get(self, request, *args, **kwargs):
        try:
            query = GetMyOrganizationsQuerySerializer(data=request.query_params)
            if not query.is_valid():
                return ResponseInfo.validation_error(query.errors)

            memberships = OrganizationMembershipService.get_my_organizations(
                user=request.user,
                validated_data=query.validated_data,
            )
            rows = list(memberships)
            return ResponseInfo.ok(
                {
                    "organizations_count": len(rows),
                    "organizations": GetMyOrganizationApiSchema(rows, many=True).data,
                },
                message="Organizations retrieved successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class MyOrganizationsApiView(OrganizationBaseApiView, generics.ListAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = GetMyOrganizationsApiSchema
    pagination_class = RestPagination

    @swagger_auto_schema(
        tags=["Organizations"],
        manual_parameters=[
            openapi.Parameter(
                "name",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "page",
                openapi.IN_QUERY,
                type=openapi.TYPE_INTEGER,
            ),
            openapi.Parameter(
                "limit",
                openapi.IN_QUERY,
                type=openapi.TYPE_INTEGER,
            ),
        ],
        operation_summary="List organizations for the current user",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = GetMyOrganizationsQuerySerializer(data=self.request.query_params)
        query.is_valid(raise_exception=True)
        return OrganizationRepository.list_directory(
            user=self.request.user,
            name=query.validated_data.get("name"),
        )