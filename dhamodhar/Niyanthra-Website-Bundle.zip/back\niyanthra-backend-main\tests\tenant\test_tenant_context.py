from unittest.mock import patch

from django.test import TestCase

from apps.tenant.models import (
    Tenant,
    TenantDatabase,
)
from apps.tenant.services.silo_activation_service import SiloActivationService
from apps.tenant.services.tenant_database_context import TenantDatabaseContext
from core.utils.ids import encode_id
from infrastructure.database.context import (
    clear_current_db_alias,
    get_current_db_alias,
)
from infrastructure.database.router import TenantDatabaseRouter


class TenantDatabaseContextTests(TestCase):

    def tearDown(self):
        clear_current_db_alias()

    def _make_tenant(self, **overrides):
        values = {
            "name": "Ctx Tenant",
            "slug": "ctx-tenant",
            "tenant_type": Tenant.TenantType.SHARED,
            "db_alias": "default",
            "provisioning_status": Tenant.ProvisioningStatus.ACTIVE,
            "is_active": True,
        }
        values.update(overrides)
        return Tenant.objects.create(**values)

    def test_shared_activates_shared_database(self):
        from django.conf import settings

        tenant = self._make_tenant(
            tenant_type=Tenant.TenantType.SHARED,
            db_alias="shared_ctx",
        )

        alias = TenantDatabaseContext.activate(tenant=tenant)

        self.assertEqual(alias, settings.SHARED_DB_ALIAS)
        self.assertNotEqual(alias, "default")
        self.assertEqual(get_current_db_alias(), settings.SHARED_DB_ALIAS)
        self.assertEqual(
            TenantDatabaseContext.current(),
            settings.SHARED_DB_ALIAS,
        )

    def test_isolated_not_ready_does_not_use_control_db(self):
        tenant = self._make_tenant(
            tenant_type=Tenant.TenantType.ISOLATED,
            db_alias="tenant_acme",
            slug="acme-ctx",
            provisioning_status=Tenant.ProvisioningStatus.PROVISIONING,
        )

        alias = TenantDatabaseContext.activate(tenant=tenant)

        self.assertIsNone(alias)
        self.assertIsNone(get_current_db_alias())

    @patch(
        "apps.tenant.services.tenant_database_context."
        "TenantConnectionLoader.ensure_alias",
        return_value=True,
    )
    def test_isolated_ready_sets_alias(self, _ensure):
        tenant = self._make_tenant(
            tenant_type=Tenant.TenantType.ISOLATED,
            db_alias="tenant_acme",
            slug="acme-ready",
            provisioning_status=Tenant.ProvisioningStatus.ACTIVE,
        )

        alias = TenantDatabaseContext.activate(tenant=tenant)

        self.assertEqual(alias, "tenant_acme")
        self.assertEqual(get_current_db_alias(), "tenant_acme")

    @patch(
        "apps.tenant.services.tenant_database_context."
        "TenantConnectionLoader.register_tenant_database"
    )
    @patch(
        "apps.tenant.services.tenant_database_context."
        "TenantConnectionLoader.ensure_alias",
        return_value=False,
    )
    def test_silo_registers_from_tenant_database(self, _ensure, register):
        tenant = self._make_tenant(
            tenant_type=Tenant.TenantType.SILO,
            db_alias="tenant_vip",
            slug="vip-ctx",
            provisioning_status=Tenant.ProvisioningStatus.ACTIVE,
        )
        TenantDatabase.objects.create(
            tenant=tenant,
            db_alias="tenant_vip",
            db_name="tenant_vip",
            host="vip.example.com",
            port=5432,
            secret_name="niyanthra/prod/tenant-vip",
            provisioning_status=TenantDatabase.ProvisioningStatus.ACTIVE,
            is_current=True,
            is_active=True,
        )

        alias = TenantDatabaseContext.activate(tenant=tenant)

        self.assertEqual(alias, "tenant_vip")
        register.assert_called_once_with(
            db_alias="tenant_vip",
            db_name="tenant_vip",
            host="vip.example.com",
            port=5432,
            secret_arn=None,
            secret_name="niyanthra/prod/tenant-vip",
        )


class SiloActivationServiceTests(TestCase):

    def setUp(self):
        self.tenant = Tenant.objects.create(
            name="VIP Silo",
            slug="vip-silo",
            tenant_type=Tenant.TenantType.SILO,
            db_alias="tenant_vip",
            provisioning_status=Tenant.ProvisioningStatus.PENDING,
            is_active=True,
        )
        TenantDatabase.objects.create(
            tenant=self.tenant,
            db_alias="tenant_vip",
            provisioning_status=TenantDatabase.ProvisioningStatus.PENDING,
            is_current=True,
        )

    @patch(
        "apps.tenant.services.silo_activation_service.TenantMigrator.migrate"
    )
    @patch(
        "apps.tenant.services.silo_activation_service."
        "TenantConnectionLoader.register_tenant_database"
    )
    def test_activate_silo_marks_active(self, register, migrate):
        tenant = SiloActivationService.activate(
            validated_data={
                "uid": encode_id(self.tenant.pk),
                "db_name": "tenant_vip",
                "host": "vip.example.com",
                "port": 5432,
                "secret_name": "niyanthra/prod/tenant-vip",
                "run_migrations": True,
            }
        )

        self.assertEqual(
            tenant.provisioning_status,
            Tenant.ProvisioningStatus.ACTIVE,
        )
        self.assertTrue(tenant.is_ready)
        register.assert_called_once()
        migrate.assert_called_once_with(alias="tenant_vip")

        current_db = TenantDatabase.objects.get(
            tenant=tenant,
            is_current=True,
        )
        self.assertEqual(current_db.db_name, "tenant_vip")
        self.assertEqual(current_db.host, "vip.example.com")
        self.assertEqual(current_db.secret_name, "niyanthra/prod/tenant-vip")
        self.assertEqual(
            current_db.provisioning_status,
            TenantDatabase.ProvisioningStatus.ACTIVE,
        )

    def test_activate_rejects_non_silo(self):
        shared = Tenant.objects.create(
            name="Shared",
            slug="shared-one",
            tenant_type=Tenant.TenantType.SHARED,
            db_alias="shared_one",
            provisioning_status=Tenant.ProvisioningStatus.ACTIVE,
        )
        from rest_framework.exceptions import ValidationError

        with self.assertRaises(ValidationError):
            SiloActivationService.activate(
                validated_data={
                    "uid": encode_id(shared.pk),
                    "db_name": "x",
                    "host": "h",
                    "port": 5432,
                }
            )


class TenantRouterTests(TestCase):

    def tearDown(self):
        clear_current_db_alias()

    def test_control_app_always_default(self):
        router = TenantDatabaseRouter()
        self.assertEqual(router._route("tenant"), "default")
        self.assertEqual(router._route("company"), "default")

    def test_tenant_app_uses_context_alias(self):
        from infrastructure.database.context import set_current_db_alias
        from infrastructure.database.labels import tenant_app_labels

        labels = tenant_app_labels()
        if not labels:
            self.skipTest("No TENANT_DATABASE_APPS configured")

        app_label = next(iter(labels))
        set_current_db_alias("tenant_acme")
        router = TenantDatabaseRouter()
        self.assertEqual(router._route(app_label), "tenant_acme")

    def test_allow_migrate_splits_control_and_tenant_apps(self):
        from django.conf import settings

        router = TenantDatabaseRouter()
        shared = settings.SHARED_DB_ALIAS
        self.assertTrue(router.allow_migrate("default", "tenant"))
        self.assertTrue(router.allow_migrate("default", "company"))
        self.assertFalse(router.allow_migrate("default", "sales"))
        self.assertTrue(router.allow_migrate(shared, "sales"))
        self.assertFalse(router.allow_migrate(shared, "company"))
        self.assertFalse(router.allow_migrate(shared, "users"))
        self.assertFalse(router.allow_migrate("tenant_acme", "tenant"))
        self.assertFalse(router.allow_migrate("tenant_acme", "company"))
        self.assertTrue(router.allow_migrate("tenant_acme", "sales"))

    def test_tenant_app_without_alias_refuses_control_db(self):
        from core.tenant.exceptions import TenantContextError

        router = TenantDatabaseRouter()
        with self.assertRaises(TenantContextError):
            router._route("sales")
