from django.core.management import call_command
from django.test import TestCase

from apps.access.models import Permission
from apps.background.models import PeriodicTask
from apps.company.models import (
    BusinessType,
    CompanyType,
    Module,
    TaxRate,
    TaxType,
)
from apps.location.models import (
    Country,
    State,
)
from apps.organization.models import Industry
from apps.users.models import TimeZone
from core.seeders import (
    business_type as business_type_seeder,
    company_type as company_type_seeder,
    country as country_seeder,
    industry as industry_seeder,
    module as module_seeder,
    permission as permission_seeder,
    periodic_task as periodic_task_seeder,
    state as state_seeder,
    tax as tax_seeder,
    timezone as timezone_seeder,
)
from core.seeders.loader import load_all
from core.seeders.registry import (
    INITIAL_FIXTURES,
    SEED_GROUPS,
)


class SingleSeederTests(TestCase):
    def test_country_seeder(self):
        result = country_seeder.run()
        self.assertEqual(result["created"], 30)
        self.assertEqual(Country.objects.filter(is_active=True).count(), 1)

    def test_state_seeder(self):
        country_seeder.run()
        result = state_seeder.run()
        self.assertEqual(result["created"], 36)
        self.assertEqual(State.objects.count(), 36)

    def test_industry_seeder(self):
        result = industry_seeder.run()
        self.assertGreater(result["created"], 0)
        self.assertEqual(
            Industry.objects.get(code="ecommerce").parent.code,
            "retail",
        )

    def test_company_type_seeder(self):
        result = company_type_seeder.run()
        self.assertEqual(result["created"], 12)
        self.assertTrue(CompanyType.objects.filter(code="private_limited").exists())

    def test_business_type_seeder(self):
        result = business_type_seeder.run()
        self.assertEqual(result["created"], 12)
        self.assertTrue(BusinessType.objects.filter(code="b2b").exists())

    def test_tax_seeder(self):
        result = tax_seeder.run()
        self.assertGreater(result["created"], 0)
        self.assertEqual(TaxType.objects.count(), 5)
        self.assertTrue(TaxRate.objects.filter(code="gst_18").exists())

    def test_timezone_seeder(self):
        result = timezone_seeder.run()
        self.assertEqual(result["created"], 15)
        self.assertTrue(TimeZone.objects.filter(code="Asia/Kolkata").exists())

    def test_permission_seeder(self):
        result = permission_seeder.run()
        self.assertEqual(result["created"], 19)
        self.assertTrue(Permission.objects.filter(codename="sales.view").exists())

    def test_module_seeder(self):
        result = module_seeder.run()
        self.assertEqual(result["created"], 12)
        self.assertTrue(Module.objects.filter(code="sales").exists())
        self.assertTrue(Module.objects.filter(code="company_management").exists())
        self.assertTrue(Module.objects.filter(code="access_control").exists())
        self.assertTrue(Module.objects.filter(code="team_management").exists())

    def test_periodic_task_seeder(self):
        result = periodic_task_seeder.run()
        self.assertEqual(result["total"], 1)
        self.assertTrue(
            PeriodicTask.objects.filter(code="dispatch_isolated_jobs").exists()
        )


class InitialLoadDataTests(TestCase):
    def test_registry_covers_all_groups(self):
        self.assertEqual(len(INITIAL_FIXTURES), 13)
        self.assertEqual(len(SEED_GROUPS), 10)

    def test_load_all_seeds_everything(self):
        result = load_all()
        self.assertEqual(len(result["fixtures"]), 13)
        self.assertEqual(Module.objects.count(), 12)
        self.assertEqual(Country.objects.filter(is_active=True).count(), 1)
        self.assertEqual(State.objects.count(), 36)
        self.assertEqual(Industry.objects.count(), 36)
        self.assertEqual(CompanyType.objects.count(), 12)
        self.assertEqual(BusinessType.objects.count(), 12)
        self.assertEqual(TaxType.objects.count(), 5)
        self.assertTrue(TimeZone.objects.filter(code="Asia/Kolkata").exists())
        self.assertTrue(Permission.objects.filter(codename="sales.view").exists())
        self.assertTrue(
            PeriodicTask.objects.filter(code="dispatch_isolated_jobs").exists()
        )

    def test_load_all_is_idempotent(self):
        load_all()
        second = load_all()
        self.assertEqual(second["created"], 0)
        self.assertGreater(second["updated"], 0)

    def test_initial_loaddata_command(self):
        call_command("initial_loaddata")
        self.assertEqual(CompanyType.objects.count(), 12)
        call_command("seed_tax")
        self.assertTrue(TaxRate.objects.filter(code="gst_18").exists())
