from apps.tenant.models import (
    Tenant,
    TenantDatabase,
)
from apps.tenant.repository import TenantRepository
from apps.tenant.services.provisioners.base import BaseTenantProvisioner


class SharedTenantProvisioner(BaseTenantProvisioner):
    """Mark the tenant active. Data lives on SHARED_DB, not the control database."""

    def provision(self, *, tenant: Tenant) -> Tenant:
        tenant = TenantRepository.set_provisioning_status(
            tenant=tenant,
            status=Tenant.ProvisioningStatus.ACTIVE,
            error=None,
        )

        TenantRepository.set_current_database_status(
            tenant=tenant,
            status=TenantDatabase.ProvisioningStatus.ACTIVE,
            error=None,
        )

        return tenant
