from django.db import (
    IntegrityError,
    transaction,
)
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.organization.repository import (
    CountryRepository,
    IndustryRepository,
    OrganizationMembershipRepository,
    OrganizationRepository,
)
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class OrganizationService:
    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})
        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})
        return decoded

    @staticmethod
    def _decode_uids(uids: list[str], *, field: str = "uids") -> list[int]:
        decoded_ids = []
        for uid in uids:
            try:
                decoded = decode_id(uid)
            except ValueError:
                raise ValidationError({field: ["One or more ids are invalid."]})
            if not isinstance(decoded, int):
                raise ValidationError({field: ["One or more ids are invalid."]})
            decoded_ids.append(decoded)
        return list(dict.fromkeys(decoded_ids))

    @staticmethod
    def _resolve_country(country_uid: str) -> int:
        country_id = OrganizationService._decode_uid(country_uid, field="country_uid")
        if CountryRepository.get_active_by_id(country_id) is None:
            raise AuthValidationError(
                {"country_uid": ["Country not found or inactive."]},
                code="COUNTRY_NOT_FOUND",
            )
        return country_id

    @staticmethod
    def _resolve_industries(industry_uids: list[str]) -> list[int]:
        industry_ids = OrganizationService._decode_uids(
            industry_uids,
            field="industry_uids",
        )
        active_ids = IndustryRepository.get_active_ids(industry_ids)
        if len(active_ids) != len(industry_ids):
            raise AuthValidationError(
                {"industry_uids": ["One or more industries are missing or inactive."]},
                code="INDUSTRY_NOT_FOUND",
            )
        return active_ids

    @staticmethod
    def get_organizations(*, validated_data: dict):
        organization_id   = None
        country_id        = None
        industry_id       = None
        uid               = validated_data.get("uid")

        if uid:
            organization_id = [OrganizationService._decode_uid(uid)]

        country_uid = validated_data.get("country_uid")
        if country_uid:
            country_id = OrganizationService._decode_uid(country_uid, field="country_uid")

        industry_uid = validated_data.get("industry_uid")
        if industry_uid:
            industry_id = [OrganizationService._decode_uid(industry_uid, field="industry_uid")]

        return OrganizationRepository.list_organizations(
            organization_id   = organization_id,
            code              = validated_data.get("code"),
            name              = validated_data.get("name"),
            is_active         = validated_data.get("is_active"),
            country_id        = country_id,
            industry_id       = industry_id,
        )

    @staticmethod
    def create_organization(*, validated_data: dict, actor):

        country_id    = OrganizationService._resolve_country(validated_data["country_uid"])
        industry_ids  = OrganizationService._resolve_industries(validated_data["industry_uids"])
        code          = validated_data["code"]
        
        if OrganizationRepository.get_code_conflict(code=code):
            raise AuthValidationError(
                {"code": ["This organization code already exists."]},
                code="ORGANIZATION_CODE_EXISTS",
            )
        try:
            with transaction.atomic():
                organization = OrganizationRepository.create_organization(
                    name          = validated_data["name"],
                    code          = code,
                    legal_name    = validated_data["legal_name"],
                    country_id    = country_id,
                    created_by_id = getattr(actor, "pk", None),
                    description   = validated_data.get("description"),
                    logo          = validated_data.get("logo"),
                    email         = validated_data.get("email"),
                    phone_number  = validated_data.get("phone_number"),
                    website       = validated_data.get("website"),
                    timezone      = validated_data.get("timezone"),
                )
                OrganizationRepository.replace_industries(
                    organization=organization,
                    industry_ids=industry_ids,
                )
                if getattr(actor, "pk", None):
                    existing = OrganizationMembershipRepository.get_conflict(
                        organization_id=organization.pk,
                        user_id=actor.pk,
                    )
                    if existing is None:
                        OrganizationMembershipRepository.create_membership(
                            organization_id=organization.pk,
                            user_id=actor.pk,
                            role="owner",
                            is_active=True,
                        )
                    elif existing.role != "owner" or not existing.is_active:
                        OrganizationMembershipRepository.update_membership(
                            membership=existing,
                            organization_id=organization.pk,
                            user_id=actor.pk,
                            role="owner",
                            is_active=True,
                        )

        except IntegrityError:
            raise AuthValidationError(
                {"code": ["This organization code already exists."]},
                code="ORGANIZATION_CODE_EXISTS",
            ) from None
        return OrganizationRepository.get_by_id(organization.pk)

    @staticmethod
    def update_organization(*, validated_data: dict):
        organization = OrganizationRepository.get_by_id(
            OrganizationService._decode_uid(validated_data["uid"])
        )
        if organization is None:
            raise NotFound("Organization not found.")

        country_id   = OrganizationService._resolve_country(validated_data["country_uid"])
        industry_ids = OrganizationService._resolve_industries(validated_data["industry_uids"])
        code         = validated_data["code"]
        if OrganizationRepository.get_code_conflict(code=code, exclude_id=organization.pk):
            raise AuthValidationError(
                {"code": ["This organization code already exists."]},
                code="ORGANIZATION_CODE_EXISTS",
            )
        try:
            with transaction.atomic():
                OrganizationRepository.update_organization(
                    organization    = organization,
                    name            = validated_data["name"],
                    code            = code,
                    legal_name      = validated_data["legal_name"],
                    country_id      = country_id,
                    description     = validated_data.get("description"),
                    logo            = validated_data.get("logo"),
                    email           = validated_data.get("email"),
                    phone_number    = validated_data.get("phone_number"),
                    website         = validated_data.get("website"),
                    timezone        = validated_data.get("timezone"),
                )
                OrganizationRepository.replace_industries(
                    organization=organization,
                    industry_ids=industry_ids,
                )
        except IntegrityError:
            raise AuthValidationError(
                {"code": ["This organization code already exists."]},
                code="ORGANIZATION_CODE_EXISTS",
            ) from None
        return OrganizationRepository.get_by_id(organization.pk)

    @staticmethod
    def delete_organizations(*, validated_data: dict) -> dict:
        organization_ids = OrganizationService._decode_uids(validated_data["uids"])
        deleted          = OrganizationRepository.soft_delete_by_ids(organization_ids)
        if not deleted:
            raise NotFound("Organization not found.")
        return {"deleted": deleted}

    @staticmethod
    def toggle_organizations(*, validated_data: dict):
        organization_ids = OrganizationService._decode_uids(validated_data["uids"])
        updated          = OrganizationRepository.toggle_active_by_ids(organization_ids)
        if not updated:
            raise NotFound("Organization not found.")
        return OrganizationRepository.list_organizations(organization_id=organization_ids)

        
    @staticmethod
    def create_default_organization(*, actor, name="My Organization"):
        try:
            with transaction.atomic():
                organization = OrganizationRepository.create_organization(
                    name          = name,
                    code          = None,
                    legal_name    = name,
                    country_id    = None,
                    created_by_id = getattr(actor, "pk", None),
                    description   = None,
                    logo          = None,
                    email         = None,
                    phone_number  = None,
                    website       = None,
                    timezone      = None,
                )

                if getattr(actor, "pk", None):
                    OrganizationMembershipRepository.create_membership(
                        organization_id=organization.pk,
                        user_id=actor.pk,
                        role="owner",
                        is_active=True,
                    )

            return OrganizationRepository.get_by_id(organization.pk)
        
        except IntegrityError:
            raise AuthValidationError(
                {"code": ["This organization code already exists."]},
                code="ORGANIZATION_CODE_EXISTS",
            ) from None