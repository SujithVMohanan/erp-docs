from abc import (
    ABC,
    abstractmethod,
)

from apps.background.models import BackgroundJob


class BaseJobHandler(ABC):

    @abstractmethod
    def execute(self, *, job: BackgroundJob) -> None:
        raise NotImplementedError
