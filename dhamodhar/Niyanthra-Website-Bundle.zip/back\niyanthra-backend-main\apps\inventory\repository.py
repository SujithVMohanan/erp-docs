from django.db.models import Q
from django.utils import timezone

from apps.company.models import Branch
from apps.inventory.models import (
    Product,
    StockDocument,
    StockDocumentLine,
    StockLedger,
    StockSummary,
    Warehouse,
)


class InventoryRepository:

    @staticmethod
    def list_products(*, product_ids=None, sku=None, name=None):
        filters = Q()

        if product_ids:
            filters &= Q(id__in=product_ids)

        if sku:
            filters &= Q(sku__icontains=sku)

        if name:
            filters &= Q(name__icontains=name)

        return (
            Product.objects.filter(filters)
            .only(
                "id",
                "public_id",
                "sku",
                "name",
                "uom_code",
                "hsn_code",
                "tax_rate_id",
                "tax_percent",
                "cost_price",
                "selling_price",
                "track_stock",
                "is_active",
                "created_at",
                "updated_at",
            )
            .order_by("name", "id")
        )

    @staticmethod
    def products_by_ids(product_ids: list[int]) -> dict[int, Product]:
        if not product_ids:
            return {}

        return {
            product.pk: product
            for product in Product.objects.filter(id__in=product_ids)
        }

    @staticmethod
    def sku_exists(sku: str) -> bool:
        return Product.objects.filter(sku=sku).exists()

    @staticmethod
    def next_sku(company_code_value: str) -> str:
        prefix = f"{company_code_value}-"

        last = (
            Product.objects.filter(sku__startswith=prefix)
            .order_by("-id")
            .values_list("sku", flat=True)
            .first()
        )

        sequence = 0

        if last:
            suffix = last[len(prefix):]

            if suffix.isdigit():
                sequence = int(suffix)

        return f"{prefix}{sequence + 1:05d}"

    @staticmethod
    def products_for_import(
        *,
        skus: set[str],
        name_keys: set[str],
    ) -> list:
        filters = Q()

        if skus:
            filters |= Q(sku__in=skus)

        if name_keys:
            filters |= Q(name_key__in=name_keys)

        if not filters:
            return []

        return list(
            Product.objects
            .filter(filters)
            .order_by("id")
        )

    @staticmethod
    def skus_with_prefix(prefix: str) -> set[str]:
        return set(
            Product.objects
            .filter(sku__startswith=prefix)
            .values_list("sku", flat=True)
        )

    @staticmethod
    def products_by_sku(skus: set[str]) -> dict[str, Product]:
        if not skus:
            return {}

        return {
            product.sku: product
            for product in Product.objects.filter(sku__in=skus)
        }

    @staticmethod
    def products_by_name_key(keys: set[str]) -> dict[str, Product]:
        if not keys:
            return {}

        rows = (
            Product.objects
            .filter(name_key__in=keys)
            .order_by("id")
        )

        found = {}

        for product in rows:
            found.setdefault(product.name_key, product)

        return found

    @staticmethod
    def list_warehouses(*, warehouse_ids=None, branch_id=None):
        filters = Q()

        if warehouse_ids:
            filters &= Q(id__in=warehouse_ids)

        if branch_id:
            filters &= Q(branch_id=branch_id)

        return (
            Warehouse.objects
            .filter(filters)
            .only(
                "id",
                "public_id",
                "branch_id",
                "name",
                "code",
                "status",
                "is_default",
                "name_custom",
                "created_at",
                "updated_at",
            )
            .order_by("name", "id")
        )

    @staticmethod
    def warehouse_for_branch(branch_id: int) -> Warehouse | None:
        return (
            Warehouse.objects
            .filter(branch_id=branch_id)
            .first()
        )

    @staticmethod
    def branches_for_company(company_id: int):
        return list(
            Branch.objects
            .filter(company_id=company_id)
            .only(
                "id",
                "name",
                "code",
                "status",
            )
        )

    @staticmethod
    def active_branch_ids(
        company_id: int,
        *,
        limit: int = 2,
    ) -> list[int]:
        return list(
            Branch.objects
            .filter(
                company_id=company_id,
                status__iexact="ACTIVE",
            )
            .values_list("id", flat=True)[:limit]
        )

    @staticmethod
    def branch_in_company(
        *,
        branch_id: int,
        company_id: int,
    ) -> bool:
        return Branch.objects.filter(
            pk=branch_id,
            company_id=company_id,
        ).exists()

    @staticmethod
    def list_stock(*, product_id=None, warehouse_id=None):
        filters = Q()

        if product_id:
            filters &= Q(product_id=product_id)

        if warehouse_id:
            filters &= Q(warehouse_id=warehouse_id)

        return (
            StockSummary.objects
            .filter(filters)
            .select_related("product", "warehouse")
            .only(
                "id",
                "public_id",
                "qty_on_hand",
                "qty_reserved",
                "product_id",
                "warehouse_id",
                "product__id",
                "product__sku",
                "product__name",
                "product__cost_price",
                "warehouse__id",
                "warehouse__name",
                "warehouse__branch_id",
                "created_at",
                "updated_at",
            )
            .order_by(
                "product__name",
                "warehouse__name",
                "id",
            )
        )

    @staticmethod
    def list_documents(
        *,
        document_ids=None,
        doc_type=None,
        doc_number=None,
        date_from=None,
        date_to=None,
    ):
        filters = Q()

        if document_ids:
            filters &= Q(id__in=document_ids)

        if doc_type:
            filters &= Q(doc_type=doc_type)

        if doc_number:
            filters &= Q(doc_number__icontains=doc_number)

        if date_from:
            filters &= Q(doc_date__gte=date_from)

        if date_to:
            filters &= Q(doc_date__lte=date_to)

        return (
            StockDocument.objects
            .filter(filters)
            .select_related(
                "warehouse",
                "to_warehouse",
            )
            .prefetch_related(
                "lines",
                "lines__product",
            )
            .order_by("-doc_date", "-id")
        )

    @staticmethod
    def document_by_client_ref(
        client_ref: str,
    ) -> StockDocument | None:
        return (
            InventoryRepository
            .list_documents()
            .filter(client_ref=client_ref)
            .first()
        )

    @staticmethod
    def list_ledger(
        *,
        product_id=None,
        warehouse_id=None,
        doc_type=None,
        date_from=None,
        date_to=None,
    ):
        filters = Q()

        if product_id:
            filters &= Q(product_id=product_id)

        if warehouse_id:
            filters &= Q(warehouse_id=warehouse_id)

        if doc_type:
            filters &= Q(document__doc_type=doc_type)

        if date_from:
            filters &= Q(occurred_at__date__gte=date_from)

        if date_to:
            filters &= Q(occurred_at__date__lte=date_to)

        return (
            StockLedger.objects
            .filter(filters)
            .select_related(
                "product",
                "warehouse",
                "document",
            )
            .only(
                "id",
                "public_id",
                "product_id",
                "warehouse_id",
                "document_id",
                "movement",
                "qty_delta",
                "qty_on_hand_after",
                "unit_cost",
                "occurred_at",
                "product__id",
                "product__sku",
                "product__name",
                "warehouse__id",
                "warehouse__name",
                "warehouse__branch_id",
                "document__id",
                "document__doc_number",
                "document__doc_type",
                "created_at",
            )
            .order_by("-occurred_at", "-id")
        )

    @staticmethod
    def ledger_pairs(
        *,
        product_ids,
        warehouse_ids,
    ) -> set[tuple[int, int]]:
        if not product_ids or not warehouse_ids:
            return set()

        return set(
            StockLedger.objects
            .filter(
                product_id__in=product_ids,
                warehouse_id__in=warehouse_ids,
            )
            .values_list(
                "product_id",
                "warehouse_id",
            )
            .distinct()
        )

    @staticmethod
    def stock_blocks_delete(product_ids: list[int]) -> bool:
        if not product_ids:
            return False

        return (
            StockSummary.objects
            .filter(product_id__in=product_ids)
            .filter(
                Q(qty_on_hand__gt=0)
                | Q(qty_reserved__gt=0)
            )
            .exists()
        )

    @staticmethod
    def soft_delete_products(product_ids: list[int]) -> int:
        if not product_ids:
            return 0

        count, _ = (
            Product.objects
            .filter(id__in=product_ids)
            .delete()
        )

        return count

    @staticmethod
    def next_doc_number(
        doc_type: str,
        prefix: str,
    ) -> str:
        last = (
            StockDocument.objects
            .filter(doc_number__startswith=f"{prefix}-")
            .order_by("-id")
            .values_list("doc_number", flat=True)
            .first()
        )

        sequence = 1

        if last:
            suffix = last.rsplit("-", 1)[-1]

            if suffix.isdigit():
                sequence = int(suffix) + 1

        return f"{prefix}-{sequence:05d}"

    @staticmethod
    def touch(instance):
        instance.updated_at = timezone.now()
        return instance