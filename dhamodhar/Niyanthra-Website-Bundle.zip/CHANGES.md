# New design — change summary

HTML/CSS/JS prototypes for an enterprise-grade management workspace. Original files in the parent folder are unchanged.

## What changed (layout / interaction only)

| Area | Redesign |
|------|----------|
| **Login** | Centered auth card on plain themed background. SSO (Google, Microsoft, Apple) first, then divider, then email/password. Inline error banner for auth failures. |
| **Setup** | Progressive screens: Profile → Organization → Company. Header progress with Completed / Current / Ready / Locked. Completed steps remain editable; locked steps cannot open. |
| **Company workspace** | Persistent left company list (search, status, branch count, Add company). Right: single reusable Details \| Branches workspace with resizable, hideable panels, unsaved-change warnings, empty states. |
| **Dashboard** | Compact stat tiles + bordered widgets (existing metrics/actions only). Shell scrolls; widgets scroll if needed. |
| **Data table** | Toolbar search + per-field filter popovers, removable chips, sticky header, sort, row selection, overflow actions, pinned pagination, skeleton/empty states. |
| **Forms** | Sectioned fields, label/helper/error pattern, pinned Save/Cancel, discard confirm, button loading + toast on success. |
| **Overlays** | Shared modal (sm/md/lg) and popover patterns with focus trap, Esc/outside rules, focus return, `prefers-reduced-motion`. |

## Visual system

- **Same color tokens** as existing designs (`--sky-*`, `--muted`, `--border`, `--ok` / `--warn` / `--hot`).
- Compact, information-dense, desktop-app feel: small radii, subtle borders, minimal shadows, **no gradients**, no large decorative cards.
- Shared primitives: buttons, fields, toast, empty state, table, modal, popover.

## Confirmation — logic surface unchanged

- **No new fields, actions, or validations** beyond regrouping/relayout of existing onboarding and Control Center concepts (name, email, org name, company type/business/industry/model/profile/modules/financial/localization/tax, branch name/location/type/status; dashboard metrics and inbox/sale/purchase/payment actions; bakery parties).
- **Auth providers unchanged**: Google, Microsoft, Apple + email/password only.
- **No API, auth provider, or permission logic** was altered — this folder is presentation HTML only.
- Sample data (ABC Bakery / Retail) matches the existing Control Center prototype for walkthrough continuity.

## How to open

Open `new-design/index.html` in a browser, or start at `new-design/login.html` and walk Profile → Organization → Company workspace.
