from django.contrib import admin

from .models import Country, Location, State


@admin.register(Country)
class CountryAdmin(admin.ModelAdmin):
	list_display = ("name", "code", "iso3", "currency_code", "is_active", "deleted_at")
	list_filter = ("is_active",)
	search_fields = ("name", "code", "iso3", "phone_code", "currency_code")


@admin.register(State)
class StateAdmin(admin.ModelAdmin):
	list_display = ("name", "code", "country", "is_active", "deleted_at")
	list_filter = ("is_active", "country")
	search_fields = ("name", "code", "country__name", "country__code")


@admin.register(Location)
class LocationAdmin(admin.ModelAdmin):
	list_display = ("formatted_address", "city", "state", "country", "postal_code")
	list_filter = ("country", "state")
	search_fields = ("formatted_address", "address_line_1", "city", "postal_code", "place_id")
