"""
Base Django settings for Niyanthra.

Shared settings used by local, stage, and production.
Environment-specific settings belong in the respective settings file.
"""

from datetime import timedelta
from pathlib import Path
import os


# -----------------------------------------------------------------------------
# Paths
# -----------------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent.parent


# -----------------------------------------------------------------------------
# Environment helpers
# -----------------------------------------------------------------------------

def load_env_file(path: Path) -> None:
    if not path.is_file():
        return

    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()

        if not line or line.startswith("#") or "=" not in line:
            continue

        key, _, value = line.partition("=")

        os.environ.setdefault(
            key.strip(),
            value.strip().strip("'").strip('"'),
        )


load_env_file(BASE_DIR / ".env")


def env(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


def env_bool(name: str, default: bool = False) -> bool:
    value = env(name)

    if not value:
        return default

    return value.lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def env_int(name: str, default: int) -> int:
    value = env(name)

    if not value:
        return default

    try:
        return int(value)
    except ValueError:
        return default


def env_list(
    name: str,
    default: str = "",
) -> list[str]:
    return [
        item.strip()
        for item in env(name, default).split(",")
        if item.strip()
    ]


_CACHE_DRIVERS = {
    "locmem": "django.core.cache.backends.locmem.LocMemCache",
    "redis": "django.core.cache.backends.redis.RedisCache",
}

_EMAIL_DRIVERS = {
    "console": "django.core.mail.backends.console.EmailBackend",
    "smtp": "django.core.mail.backends.smtp.EmailBackend",
    "file": "django.core.mail.backends.filebased.EmailBackend",
}


def resolve_cache_backend(default: str = "locmem") -> str:
    """
    Env: CACHE_DRIVER=locmem|redis
    Full dotted paths still accepted for rare overrides.
    """
    raw = env("CACHE_DRIVER", default)
    mapped = _CACHE_DRIVERS.get(raw.lower())
    return mapped or raw


def resolve_email_backend(default: str = "console") -> str:
    """
    Env: EMAIL_DRIVER=console|smtp|file
    Full dotted paths still accepted for rare overrides.
    """
    raw = env("EMAIL_DRIVER", default)
    mapped = _EMAIL_DRIVERS.get(raw.lower())
    return mapped or raw


# -----------------------------------------------------------------------------
# Environment
# -----------------------------------------------------------------------------

# local | stage | production — selects settings via config.environment
# (manage.py / wsgi / asgi / celery set the process settings module internally)
ENVIRONMENT = env("ENVIRONMENT", "local").lower()


# -----------------------------------------------------------------------------
# Core
# -----------------------------------------------------------------------------

# Prefer APP_SECRET_KEY; SECRET_KEY kept as fallback for older local .env files
SECRET_KEY = env("APP_SECRET_KEY") or env("SECRET_KEY")

if not SECRET_KEY:
    raise RuntimeError(
        "APP_SECRET_KEY is missing. "
        "Set APP_SECRET_KEY in .env or the environment."
    )


DEBUG = env_bool("DEBUG", False)

ALLOWED_HOSTS = env_list(
    "ALLOWED_HOSTS",
    "localhost,127.0.0.1",
)

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

ROOT_URLCONF = "config.urls"

WSGI_APPLICATION = "config.wsgi.application"

ASGI_APPLICATION = "config.asgi.application"

TEST_RUNNER = "config.test_runner.ProjectDiscoverRunner"


# -----------------------------------------------------------------------------
# Applications
# -----------------------------------------------------------------------------

FRAMEWORK_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
]

THIRD_PARTY_APPS = [
    "corsheaders",
    "rest_framework",
    "rest_framework_simplejwt",
    "rest_framework_simplejwt.token_blacklist",
    "drf_yasg",
]

CONTROL_APPS = [
    "core.seeders.apps.SeedersConfig",
    "apps.users.apps.UsersConfig",
    "apps.location.apps.LocationConfig",
    "apps.organization.apps.OrganizationConfig",
    "apps.company.apps.CompanyConfig",
    "apps.tenant.apps.TenantConfig",
    "apps.access.apps.AccessConfig",
    "apps.background.apps.BackgroundConfig",
]

TENANT_APPS = [
    "apps.sales.apps.SalesConfig",
    "apps.inventory.apps.InventoryConfig",
]

INSTALLED_APPS = (
    FRAMEWORK_APPS
    + THIRD_PARTY_APPS
    + CONTROL_APPS
    + TENANT_APPS
)


def _app_label_from_config(app_path: str) -> str:
    if ".apps." in app_path:
        package = app_path.split(".apps.", 1)[0]
        return package.rsplit(".", 1)[-1]
    return app_path.rsplit(".", 1)[-1]


# Labels used by router + tenant DB migrations (derived from TENANT_APPS).
TENANT_DATABASE_APPS = [
    _app_label_from_config(path)
    for path in TENANT_APPS
]

# Tenant databases only receive TENANT_APPS (sales, …).
# Do not add auth/users here — that copies control tables into tenant DBs.
TENANT_SUPPORT_APPS = []

CONTROL_DATABASE_APPS = [
    _app_label_from_config(path)
    for path in CONTROL_APPS
]


# -----------------------------------------------------------------------------
# Authentication
# -----------------------------------------------------------------------------

AUTH_USER_MODEL = "users.Users"

SILENCED_SYSTEM_CHECKS = [
    "auth.E003",
]


# -----------------------------------------------------------------------------
# Middleware
# -----------------------------------------------------------------------------

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "corsheaders.middleware.CorsMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "core.middleware.tenant_database.TenantDatabaseMiddleware",

    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]


# -----------------------------------------------------------------------------
# Templates
# -----------------------------------------------------------------------------

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]


# -----------------------------------------------------------------------------
# Database
# -----------------------------------------------------------------------------

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": env("CONTROL_DB_NAME", "niyanthra_master"),
        "USER": env("CONTROL_DB_USER", "postgres"),
        "PASSWORD": env("CONTROL_DB_PASSWORD"),
        "HOST": env("CONTROL_DB_HOST", "localhost"),
        "PORT": env("CONTROL_DB_PORT", "5432"),
        "CONN_MAX_AGE": env_int(
            "CONTROL_DB_CONN_MAX_AGE",
            60,
        ),
        "CONN_HEALTH_CHECKS": True,
    },
}

DATABASE_ROUTERS = [
    "infrastructure.database.router.TenantDatabaseRouter",
]


# -----------------------------------------------------------------------------
# Databases
#   default — control plane only (users, organization, company, tenant, …)
#   shared  — one data-plane DB for every SHARED tenant (row filter by tenant_id)
#   isolated / silo aliases are registered at runtime, one database each
# -----------------------------------------------------------------------------
#
# Local:   CredentialResolver reads TENANT_DB_ADMIN_* / TENANT_DB_RUNTIME_*
# Stage/Prod: CredentialResolver reads Secrets Manager only
#             (TENANT_DB_*_SECRET_NAME). Direct TENANT_DB_* passwords are unused.
#
# SHARED_DB_* is a real database, never CONTROL_DB / alias `default`.

SHARED_DB_ALIAS = env("SHARED_DB_ALIAS", "shared")


def shared_database_config(*, required: bool = False) -> dict:
    if required:
        name = env("SHARED_DB_NAME")
        user = env("SHARED_DB_USER")
        password = env("SHARED_DB_PASSWORD")
        host = env("SHARED_DB_HOST")
    else:
        name = env("SHARED_DB_NAME", "niyanthra_shared")
        user = env("SHARED_DB_USER", env("CONTROL_DB_USER", "postgres"))
        password = env("SHARED_DB_PASSWORD", env("CONTROL_DB_PASSWORD", ""))
        host = env("SHARED_DB_HOST", env("CONTROL_DB_HOST", "localhost"))

    options = {}
    sslmode = env("SHARED_DB_SSLMODE", "")
    if sslmode:
        options["sslmode"] = sslmode
    if required:
        options["connect_timeout"] = 10

    return {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": name,
        "USER": user,
        "PASSWORD": password,
        "HOST": host,
        "PORT": env("SHARED_DB_PORT", env("CONTROL_DB_PORT", "5432")),
        "CONN_MAX_AGE": env_int(
            "SHARED_DB_CONN_MAX_AGE",
            env_int("CONTROL_DB_CONN_MAX_AGE", 60),
        ),
        "CONN_HEALTH_CHECKS": True,
        "OPTIONS": options,
    }


DATABASES[SHARED_DB_ALIAS] = shared_database_config()

TENANT_DB_ADMIN = {
    "HOST": env("TENANT_DB_ADMIN_HOST", env("CONTROL_DB_HOST", "localhost")),
    "PORT": env("TENANT_DB_ADMIN_PORT", env("CONTROL_DB_PORT", "5432")),
    "USER": env("TENANT_DB_ADMIN_USER", env("CONTROL_DB_USER", "postgres")),
    "PASSWORD": env(
        "TENANT_DB_ADMIN_PASSWORD",
        env("CONTROL_DB_PASSWORD", ""),
    ),
    "NAME": env("TENANT_DB_ADMIN_NAME", "postgres"),
}

TENANT_DB_RUNTIME_USER = env(
    "TENANT_DB_RUNTIME_USER",
    env("CONTROL_DB_USER", "postgres"),
)
TENANT_DB_RUNTIME_PASSWORD = env(
    "TENANT_DB_RUNTIME_PASSWORD",
    env("CONTROL_DB_PASSWORD", ""),
)

TENANT_DB_ADMIN_SECRET_NAME = env("TENANT_DB_ADMIN_SECRET_NAME", "")
TENANT_DB_RUNTIME_SECRET_NAME = env("TENANT_DB_RUNTIME_SECRET_NAME", "")


# -----------------------------------------------------------------------------
# AWS
# -----------------------------------------------------------------------------

AWS_REGION = env("AWS_REGION", "ap-south-1")
AWS_ACCESS_KEY_ID = env("AWS_ACCESS_KEY_ID", "")
AWS_SECRET_ACCESS_KEY = env("AWS_SECRET_ACCESS_KEY", "")


# -----------------------------------------------------------------------------
# Celery
# -----------------------------------------------------------------------------

CELERY_BROKER_URL = env(
    "CELERY_BROKER_URL",
    "redis://127.0.0.1:6379/0",
)
CELERY_RESULT_BACKEND = env(
    "CELERY_RESULT_BACKEND",
    CELERY_BROKER_URL,
)
CELERY_TASK_TRACK_STARTED = True
CELERY_TASK_TIME_LIMIT = env_int("CELERY_TASK_TIME_LIMIT", 60 * 15)
CELERY_TASK_SOFT_TIME_LIMIT = env_int("CELERY_TASK_SOFT_TIME_LIMIT", 60 * 10)
CELERY_ACCEPT_CONTENT = ["json"]
CELERY_TASK_SERIALIZER = "json"
CELERY_RESULT_SERIALIZER = "json"
CELERY_TASK_DEFAULT_QUEUE = env("CELERY_TASK_DEFAULT_QUEUE", "default")
CELERY_TASK_ALWAYS_EAGER = env_bool("CELERY_TASK_ALWAYS_EAGER", False)
CELERY_TASK_EAGER_PROPAGATES = True

# Only the designated cron/worker host may run periodic dispatchers
CRON_SERVER_ENABLED = env_bool("CRON_SERVER_ENABLED", False)
CRON_SERVER_HOSTNAME = env("CRON_SERVER_HOSTNAME", "")


# -----------------------------------------------------------------------------
# Password validation
# -----------------------------------------------------------------------------

AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": (
            "django.contrib.auth.password_validation."
            "UserAttributeSimilarityValidator"
        ),
    },
    {
        "NAME": (
            "django.contrib.auth.password_validation."
            "MinimumLengthValidator"
        ),
    },
    {
        "NAME": (
            "django.contrib.auth.password_validation."
            "CommonPasswordValidator"
        ),
    },
    {
        "NAME": (
            "django.contrib.auth.password_validation."
            "NumericPasswordValidator"
        ),
    },
]


PASSWORD_HASHERS = [
    "django.contrib.auth.hashers.Argon2PasswordHasher",
    "django.contrib.auth.hashers.PBKDF2PasswordHasher",
    "django.contrib.auth.hashers.PBKDF2SHA1PasswordHasher",
    "django.contrib.auth.hashers.BCryptSHA256PasswordHasher",
    "django.contrib.auth.hashers.ScryptPasswordHasher",
]


# -----------------------------------------------------------------------------
# Internationalization
# -----------------------------------------------------------------------------

LANGUAGE_CODE = "en-us"

TIME_ZONE = "UTC"

USE_I18N = True

USE_TZ = True


# -----------------------------------------------------------------------------
# Static / Media
# -----------------------------------------------------------------------------

STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"

MEDIA_URL = "media/"
MEDIA_ROOT = BASE_DIR / "media"


# -----------------------------------------------------------------------------
# Django REST Framework
# -----------------------------------------------------------------------------

REST_FRAMEWORK = {
    "DEFAULT_PAGINATION_CLASS": "core.pagination.page.RestPagination",
    "DEFAULT_AUTHENTICATION_CLASSES": (
        "core.utils.jwt_auth.JWTAccessBlacklistAuthentication",
    ),
    "EXCEPTION_HANDLER": "core.exceptions.handlers.handle_exception",
    "DEFAULT_THROTTLE_RATES": {
        "anon": "60/min",
        "user": "300/min",
        "auth": "30/min",
    },
}


# -----------------------------------------------------------------------------
# JWT
# -----------------------------------------------------------------------------

SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME": timedelta(minutes=15),
    "REFRESH_TOKEN_LIFETIME": timedelta(days=30),
    "ROTATE_REFRESH_TOKENS": True,
    "BLACKLIST_AFTER_ROTATION": True,
    "UPDATE_LAST_LOGIN": False,
    "ALGORITHM": "HS256",
    "AUTH_HEADER_TYPES": ("Bearer",),
    "AUTH_HEADER_NAME": "HTTP_AUTHORIZATION",
    "USER_ID_FIELD": "public_id",
    "USER_ID_CLAIM": "public_id",
    "AUTH_TOKEN_CLASSES": (
        "rest_framework_simplejwt.tokens.AccessToken",
    ),
    "TOKEN_TYPE_CLAIM": "token_type",
}


REGISTRATION_TOKEN_LIFETIME = timedelta(minutes=30)

AUTH_THROTTLE_DISABLED = False


# -----------------------------------------------------------------------------
# Cache
# -----------------------------------------------------------------------------

CACHES = {
    "default": {
        "BACKEND": resolve_cache_backend("locmem"),
        "LOCATION": env(
            "CACHE_LOCATION",
            "niyanthra-default",
        ),
    },
}


# -----------------------------------------------------------------------------
# CORS
# -----------------------------------------------------------------------------

CORS_ALLOWED_ORIGINS = env_list(
    "CORS_ALLOWED_ORIGINS",
    "http://localhost:3000,http://127.0.0.1:3000",
)

CORS_ALLOW_CREDENTIALS = True


# -----------------------------------------------------------------------------
# CSRF
# -----------------------------------------------------------------------------

CSRF_TRUSTED_ORIGINS = env_list(
    "CSRF_TRUSTED_ORIGINS",
)


# -----------------------------------------------------------------------------
# Swagger
# -----------------------------------------------------------------------------

SWAGGER_SETTINGS = {
    "DEFAULT_API_URL": env("SWAGGER_DEFAULT_API_URL"),
    "USE_SESSION_AUTH": False,
    "SECURITY_DEFINITIONS": {
        "Bearer": {
            "type": "apiKey",
            "name": "Authorization",
            "in": "header",
        },
    },
}


# -----------------------------------------------------------------------------
# Email
# -----------------------------------------------------------------------------

EMAIL_BACKEND = resolve_email_backend("console")

EMAIL_HOST = env("EMAIL_HOST")
EMAIL_PORT = env_int("EMAIL_PORT", 587)
EMAIL_HOST_USER = env("EMAIL_HOST_USER")
EMAIL_HOST_PASSWORD = env("EMAIL_HOST_PASSWORD")

EMAIL_USE_TLS = env_bool(
    "EMAIL_USE_TLS",
    True,
)

EMAIL_USE_SSL = env_bool(
    "EMAIL_USE_SSL",
    False,
)

DEFAULT_FROM_EMAIL = env(
    "DEFAULT_FROM_EMAIL",
    "Niyanthra <noreply@localhost>",
)


# -----------------------------------------------------------------------------
# Authentication providers
# -----------------------------------------------------------------------------

AUTH_PROVIDERS = {
    "google": {
        "client_id": env("GOOGLE_CLIENT_ID"),
    },
    "microsoft": {
        "client_id": env("MICROSOFT_CLIENT_ID"),
    },
    "apple": {
        "client_id": env("APPLE_CLIENT_ID"),
    },
}


# -----------------------------------------------------------------------------
# Initial master-data fixtures / seeders
# -----------------------------------------------------------------------------

SEEDERS_FIXTURE_DIR = BASE_DIR / "core" / "seeders" / "fixtures"

SEEDERS = {
    "country": "core.seeders.country",
    "state": "core.seeders.state",
    "industry": "core.seeders.industry",
    "company_type": "core.seeders.company_type",
    "business_type": "core.seeders.business_type",
    "tax": "core.seeders.tax",
    "timezone": "core.seeders.timezone",
    "permission": "core.seeders.permission",
    "periodic_task": "core.seeders.periodic_task",
}


# -----------------------------------------------------------------------------
# Membership invites (signed opaque tokens — no email yet)
# -----------------------------------------------------------------------------

MEMBERSHIP_INVITE_MAX_AGE_SECONDS = env_int(
    "MEMBERSHIP_INVITE_MAX_AGE_SECONDS",
    60 * 60 * 24 * 7,
)
FRONTEND_BASE_URL = env("FRONTEND_BASE_URL", "http://localhost:3000")


# -----------------------------------------------------------------------------
# Logging
# -----------------------------------------------------------------------------

LOG_LEVEL = env("LOG_LEVEL", "INFO")

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "default": {
            "format": (
                "{asctime} | {levelname} | "
                "{name} | {levelname} | {message}"
            ),
            "style": "{",
        },
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "default",
        },
    },
    "loggers": {
        "niyanthra": {
            "handlers": ["console"],
            "level": LOG_LEVEL,
            "propagate": False,
        },
        "niyanthra.auth": {
            "handlers": ["console"],
            "level": LOG_LEVEL,
            "propagate": False,
        },
        "niyanthra.background": {
            "handlers": ["console"],
            "level": LOG_LEVEL,
            "propagate": False,
        },
    },
}