from django.core.management.base import (
    BaseCommand,
    CommandError,
)

from infrastructure.database.migration_service import DatabaseMigrationService


class Command(BaseCommand):
    help = (
        "Migrate one isolated or silo database by db_alias. "
        "Shared data uses migrate_shared. Control data uses migrate_control."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--alias",
            required=True,
            help="Tenant db_alias to migrate.",
        )
        parser.add_argument(
            "--require-active",
            action="store_true",
            help="Fail if tenant is not ACTIVE/ready.",
        )
        parser.add_argument(
            "--verbosity-level",
            type=int,
            default=1,
            dest="migrate_verbosity",
        )

    def handle(self, *args, **options):
        try:
            result = DatabaseMigrationService.migrate_tenant_by_alias(
                db_alias=options["alias"],
                verbosity=options["migrate_verbosity"],
                require_active=options["require_active"],
            )
        except ValueError as exc:
            raise CommandError(str(exc)) from exc

        self.stdout.write(self.style.SUCCESS(f"migrate_tenant: {result}"))
