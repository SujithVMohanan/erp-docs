from core.seeders.business_type import run
from core.seeders.management.commands._seed_base import SeedGroupCommand


class Command(SeedGroupCommand):
    help = "Seed BusinessType master data. Safe to run multiple times."
    group_label = "BusinessType"
    seeder_run = staticmethod(run)
