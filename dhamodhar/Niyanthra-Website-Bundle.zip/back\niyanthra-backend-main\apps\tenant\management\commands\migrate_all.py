from django.core.management.base import BaseCommand

from infrastructure.database.migration_service import DatabaseMigrationService


class Command(BaseCommand):
    help = (
        "Migrate the control database, the shared database, "
        "and every ACTIVE isolated and silo database."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--verbosity-level",
            type=int,
            default=1,
            dest="migrate_verbosity",
        )

    def handle(self, *args, **options):
        result = DatabaseMigrationService.migrate_all(
            verbosity=options["migrate_verbosity"],
        )
        style = self.style.SUCCESS if result.get("ok") else self.style.WARNING
        self.stdout.write(style(f"migrate_all: {result}"))
