from django.urls import path

from apps.access.views import (
    CreateGroupApiView,
    CreateUserGroupApiView,
    CreatePermissionApiView,
    CreateRoleApiView,
    DeleteGroupsApiView,
    DeletePermissionsApiView,
    DeleteRolesApiView,
    GetGroupsApiView,
    GetPermissionsApiView,
    GetRolesApiView,
    InactiveActiveGroupsApiView,
    InactiveActiveRolesApiView,
    UpdateGroupApiView,
    UpdateUserGroupApiView,
    UpdatePermissionApiView,
    UpdateRoleApiView,
)

app_name = "access"

urlpatterns = [
    path("get-permissions/", GetPermissionsApiView.as_view(), name="get-permissions"),
    path("create-permission/", CreatePermissionApiView.as_view(), name="create-permission"),
    path("update-permission/", UpdatePermissionApiView.as_view(), name="update-permission"),
    path("delete-permissions/", DeletePermissionsApiView.as_view(), name="delete-permissions"),
    path("get-roles/", GetRolesApiView.as_view(), name="get-roles"),
    path("create-role/", CreateRoleApiView.as_view(), name="create-role"),
    path("update-role/", UpdateRoleApiView.as_view(), name="update-role"),
    path("delete-roles/", DeleteRolesApiView.as_view(), name="delete-roles"),
    path(
        "inactive-active-roles/",
        InactiveActiveRolesApiView.as_view(),
        name="inactive-active-roles",
    ),
    path("get-groups/", GetGroupsApiView.as_view(), name="get-groups"),
    path("create-group/", CreateGroupApiView.as_view(), name="create-group"),
    path("update-group/", UpdateGroupApiView.as_view(), name="update-group"),
    path("delete-groups/", DeleteGroupsApiView.as_view(), name="delete-groups"),
    path(
        "inactive-active-groups/",
        InactiveActiveGroupsApiView.as_view(),
        name="inactive-active-groups",
    ),
    path(
        "create-user-group/",
        CreateUserGroupApiView.as_view(),
        name="create-user-group",
    ),
    path(
        "update-user-group/",
        UpdateUserGroupApiView.as_view(),
        name="update-user-group",
    ),
]
