from rest_framework import serializers


class CreateCountrySerializer(serializers.Serializer):
    name          = serializers.CharField(max_length=150, trim_whitespace=True)
    code          = serializers.CharField(max_length=2, min_length=2, trim_whitespace=True)
    iso3          = serializers.CharField(
        max_length=3,
        min_length=3,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )
    phone_code    = serializers.CharField(
        max_length=8,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )
    currency_code = serializers.CharField(
        max_length=3,
        min_length=3,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )

    def validate_code(self, value):
        return value.strip().upper()

    def validate_iso3(self, value):
        return (value or "").strip().upper() or None

    def validate_phone_code(self, value):
        return (value or "").strip() or None

    def validate_currency_code(self, value):
        return (value or "").strip().upper() or None


class UpdateCountrySerializer(CreateCountrySerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetCountriesQuerySerializer(serializers.Serializer):
    uid       = serializers.CharField(required=False, allow_blank=True)
    code      = serializers.CharField(required=False, allow_blank=True, max_length=2)
    name      = serializers.CharField(required=False, allow_blank=True, max_length=150)
    is_active = serializers.BooleanField(required=False, allow_null=True)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["code"] = (attrs.get("code") or "").strip().upper() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        if "is_active" not in attrs:
            attrs["is_active"] = None
        return attrs


class CountryUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique = []
        seen = set()
        for raw in value:
            item = str(raw).strip()
            if not item or item in seen:
                continue
            seen.add(item)
            unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one country.")
        return unique


class CreateIndustrySerializer(serializers.Serializer):
    name = serializers.CharField(max_length=150, trim_whitespace=True)
    code = serializers.CharField(max_length=50, trim_whitespace=True)

    def validate_code(self, value):
        return value.strip().lower()


class UpdateIndustrySerializer(CreateIndustrySerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetIndustriesQuerySerializer(serializers.Serializer):
    uid       = serializers.CharField(required=False, allow_blank=True)
    code      = serializers.CharField(required=False, allow_blank=True, max_length=50)
    name      = serializers.CharField(required=False, allow_blank=True, max_length=150)
    is_active = serializers.BooleanField(required=False, allow_null=True)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["code"] = (attrs.get("code") or "").strip().lower() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        if "is_active" not in attrs:
            attrs["is_active"] = None
        return attrs


class IndustryUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique = []
        seen = set()
        for raw in value:
            item = str(raw).strip()
            if not item or item in seen:
                continue
            seen.add(item)
            unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one industry.")
        return unique


class CreateOrganizationSerializer(serializers.Serializer):
    name           = serializers.CharField(max_length=150, trim_whitespace=True)
    code           = serializers.CharField(max_length=30, trim_whitespace=True)
    legal_name     = serializers.CharField(max_length=255, trim_whitespace=True)
    description    = serializers.CharField(required=False, allow_blank=True)
    logo           = serializers.CharField(required=False, allow_blank=True, max_length=500)
    email          = serializers.EmailField(required=False, allow_blank=True)
    phone_number   = serializers.CharField(required=False, allow_blank=True, max_length=30)
    website        = serializers.URLField(required=False, allow_blank=True, max_length=255)
    timezone       = serializers.CharField(required=False, allow_blank=True, max_length=64)
    country_uid    = serializers.CharField(trim_whitespace=True)
    industry_uids  = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=50,
    )

    def validate_code(self, value):
        code = value.strip().upper()
        if not code:
            raise serializers.ValidationError("This field may not be blank.")
        return code

    def validate_legal_name(self, value):
        legal_name = (value or "").strip()
        if not legal_name:
            raise serializers.ValidationError("This field may not be blank.")
        return legal_name

    def validate_description(self, value):
        return (value or "").strip() or None

    def validate_logo(self, value):
        return (value or "").strip() or None

    def validate_email(self, value):
        return (value or "").strip().lower() or None

    def validate_phone_number(self, value):
        return (value or "").strip() or None

    def validate_website(self, value):
        return (value or "").strip() or None

    def validate_timezone(self, value):
        return (value or "").strip() or None

    def validate_industry_uids(self, value):
        unique = []
        seen = set()
        for raw in value:
            item = str(raw).strip()
            if not item or item in seen:
                continue
            seen.add(item)
            unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one industry.")
        return unique


class UpdateOrganizationSerializer(CreateOrganizationSerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetOrganizationsQuerySerializer(serializers.Serializer):
    uid           = serializers.CharField(required=False, allow_blank=True)
    code          = serializers.CharField(required=False, allow_blank=True, max_length=30)
    name          = serializers.CharField(required=False, allow_blank=True, max_length=150)
    is_active     = serializers.BooleanField(required=False, allow_null=True)
    country_uid   = serializers.CharField(required=False, allow_blank=True)
    industry_uid  = serializers.CharField(required=False, allow_blank=True)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["code"] = (attrs.get("code") or "").strip().upper() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        attrs["country_uid"] = (attrs.get("country_uid") or "").strip() or None
        attrs["industry_uid"] = (attrs.get("industry_uid") or "").strip() or None
        if "is_active" not in attrs:
            attrs["is_active"] = None
        return attrs


class OrganizationUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique = []
        seen = set()
        for raw in value:
            item = str(raw).strip()
            if not item or item in seen:
                continue
            seen.add(item)
            unique.append(item)
        if not unique:
            raise serializers.ValidationError("Select at least one organization.")
        return unique

class CreateOrganizationMembershipSerializer(serializers.Serializer):
    organization_uid = serializers.CharField(trim_whitespace=True)
    user_uid         = serializers.CharField(trim_whitespace=True)
    role             = serializers.CharField(
        max_length=20,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )
    is_active        = serializers.BooleanField(required=False, default=True)

    def validate_role(self, value):
        normalized = (value or "").strip().lower() or "employee"
        if normalized not in {"owner", "admin", "employee"}:
            raise serializers.ValidationError(
                "Role must be owner, admin, or employee."
            )
        return normalized


class UpdateOrganizationMembershipSerializer(CreateOrganizationMembershipSerializer):
    uid = serializers.CharField(trim_whitespace=True)


class CreateOrganizationMembershipInviteSerializer(serializers.Serializer):
    organization_uid = serializers.CharField(trim_whitespace=True)
    audience         = serializers.ChoiceField(
        choices=["admin", "employee"],
        default="admin",
    )
    role             = serializers.CharField(
        max_length=20,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )

    def validate(self, attrs):
        audience = attrs.get("audience") or "admin"
        role = (attrs.get("role") or "").strip().lower()
        if audience == "admin":
            role = role or "admin"
            if role not in {"owner", "admin"}:
                raise serializers.ValidationError(
                    {
                        "role": [
                            "Admin invites allow only owner or admin roles.",
                        ]
                    }
                )
        else:
            role = "employee"
        attrs["audience"] = audience
        attrs["role"] = role
        return attrs


class GetOrganizationMembershipsQuerySerializer(serializers.Serializer):
    uid              = serializers.CharField(required=False, allow_blank=True)
    organization_uid = serializers.CharField(required=False, allow_blank=True)
    user_uid         = serializers.CharField(required=False, allow_blank=True)
    email            = serializers.CharField(required=False, allow_blank=True, max_length=254)
    name             = serializers.CharField(required=False, allow_blank=True, max_length=150)
    role             = serializers.CharField(required=False, allow_blank=True, max_length=20)
    audience         = serializers.ChoiceField(
        choices=["admin", "employee"],
        required=False,
        allow_null=True,
    )
    is_active        = serializers.BooleanField(required=False, allow_null=True)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["organization_uid"] = (attrs.get("organization_uid") or "").strip() or None
        attrs["user_uid"] = (attrs.get("user_uid") or "").strip() or None
        attrs["email"] = (attrs.get("email") or "").strip() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        role = (attrs.get("role") or "").strip().lower() or None
        if role and role not in {"owner", "admin", "employee"}:
            raise serializers.ValidationError(
                {"role": ["Role must be owner, admin, or employee."]}
            )
        attrs["role"] = role
        attrs["audience"] = attrs.get("audience") or None
        if "is_active" not in attrs:
            attrs["is_active"] = None
        return attrs


class OrganizationMembershipUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique = []
        seen = set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError(
                "Select at least one organization membership."
            )
        return unique


class CreateOrganizationLocationSerializer(serializers.Serializer):
    organization_uid = serializers.CharField(trim_whitespace=True)
    location_uid     = serializers.CharField(trim_whitespace=True)
    location_type    = serializers.CharField(
        max_length=30,
        required=False,
        allow_blank=True,
        trim_whitespace=True,
    )
    is_primary       = serializers.BooleanField(required=False, default=False)

    def validate_location_type(self, value):
        return (value or "").strip().upper() or "PRIMARY"


class UpdateOrganizationLocationSerializer(CreateOrganizationLocationSerializer):
    uid = serializers.CharField(trim_whitespace=True)


class GetOrganizationLocationsQuerySerializer(serializers.Serializer):
    uid              = serializers.CharField(required=False, allow_blank=True)
    organization_uid = serializers.CharField(required=False, allow_blank=True)
    location_uid     = serializers.CharField(required=False, allow_blank=True)
    is_primary       = serializers.BooleanField(required=False, allow_null=True)

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["organization_uid"] = (attrs.get("organization_uid") or "").strip() or None
        attrs["location_uid"] = (attrs.get("location_uid") or "").strip() or None
        if "is_primary" not in attrs:
            attrs["is_primary"] = None
        return attrs


class OrganizationLocationUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique = []
        seen = set()
        for raw in value:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                unique.append(item)
        if not unique:
            raise serializers.ValidationError(
                "Select at least one organization location."
            )
        return unique




class GetMyOrganizationsQuerySerializer(serializers.Serializer):
    name = serializers.CharField(required=False, allow_blank=True, max_length=150)

    def validate(self, attrs):
        attrs["name"] = (attrs.get("name") or "").strip() or None
        return attrs


class SkipOrganizationSerializer(serializers.Serializer):
    name = serializers.CharField(
        required=False,
        default="My Organization",
        max_length=255,
    )