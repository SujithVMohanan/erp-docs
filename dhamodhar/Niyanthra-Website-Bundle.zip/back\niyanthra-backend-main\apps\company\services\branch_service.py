from django.db import (
    IntegrityError,
    transaction,
)
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.company.models import Branch
from apps.company.repository import (
    BranchRepository,
    CompanyRepository,
)
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class BranchService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})

        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})

        return decoded

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        return list(
            dict.fromkeys(
                BranchService._decode_uid(uid, field="uids")
                for uid in uids
            )
        )

    @staticmethod
    def _resolve_company(uid: str) -> int:
        company_id = BranchService._decode_uid(
            uid,
            field="company_uid",
        )
        company = CompanyRepository.get_by_id(company_id)
        if company is None:
            raise AuthValidationError(
                {
                    "company_uid": [
                        "Company not found or inactive.",
                    ]
                },
                code="COMPANY_NOT_FOUND",
            )
        return company_id

    @staticmethod
    def _validate_code(
        *,
        code: str,
        company_id: int,
        exclude_id: int | None = None,
    ) -> None:
        if BranchRepository.get_code_conflict(
            code=code,
            company_id=company_id,
            exclude_id=exclude_id,
        ):
            raise AuthValidationError(
                {
                    "code": [
                        "This branch code already exists in the company.",
                    ]
                },
                code="BRANCH_CODE_EXISTS",
            )

    @staticmethod
    def get_branches(*, validated_data: dict):
        branch_id = None
        company_id = None

        if validated_data.get("uid"):
            branch_id = [
                BranchService._decode_uid(validated_data["uid"])
            ]

        if validated_data.get("company_uid"):
            company_id = BranchService._decode_uid(
                validated_data["company_uid"],
                field="company_uid",
            )

        return BranchRepository.list_branches(
            branch_id=branch_id,
            company_id=company_id,
            code=validated_data.get("code"),
            name=validated_data.get("name"),
            status=validated_data.get("status"),
        )

    @staticmethod
    def create_branch(*, validated_data: dict, actor=None) -> Branch:
        company_id = BranchService._resolve_company(
            validated_data["company_uid"]
        )
        code = validated_data["code"]
        BranchService._validate_code(
            code=code,
            company_id=company_id,
        )

        try:
            with transaction.atomic():
                branch = BranchRepository.create_branch(
                    company_id=company_id,
                    name=validated_data["name"],
                    code=code,
                    branch_type=validated_data.get("branch_type"),
                    status=validated_data.get("status") or "ACTIVE",
                    email=validated_data.get("email"),
                    phone=validated_data.get("phone"),
                    created_by_id=getattr(actor, "pk", None),
                )
                from apps.users.services.membership_service import (
                    MembershipService,
                )

                company = CompanyRepository.get_by_id(company_id)
                MembershipService.grant_branch_to_principals(
                    branch_id=branch.pk,
                    company_id=company_id,
                    organization_id=company.organization_id,
                    actor_id=getattr(actor, "pk", None),
                )
        except IntegrityError:
            raise AuthValidationError(
                {
                    "code": [
                        "This branch code already exists in the company.",
                    ]
                },
                code="BRANCH_CODE_EXISTS",
            ) from None

        BranchService._sync_warehouses([company_id])
        return BranchRepository.get_by_id(branch.pk)

    @staticmethod
    def update_branch(*, validated_data: dict) -> Branch:
        branch_id = BranchService._decode_uid(validated_data["uid"])
        branch = BranchRepository.get_by_id(branch_id)
        if branch is None:
            raise NotFound("Branch not found.")

        company_id = BranchService._resolve_company(
            validated_data["company_uid"]
        )
        code = validated_data["code"]
        BranchService._validate_code(
            code=code,
            company_id=company_id,
            exclude_id=branch.pk,
        )

        try:
            with transaction.atomic():
                BranchRepository.update_branch(
                    branch=branch,
                    company_id=company_id,
                    name=validated_data["name"],
                    code=code,
                    branch_type=validated_data.get("branch_type"),
                    status=validated_data.get("status") or branch.status,
                    email=validated_data.get("email"),
                    phone=validated_data.get("phone"),
                )
        except IntegrityError:
            raise AuthValidationError(
                {
                    "code": [
                        "This branch code already exists in the company.",
                    ]
                },
                code="BRANCH_CODE_EXISTS",
            ) from None

        BranchService._sync_warehouses([company_id])
        return BranchRepository.get_by_id(branch.pk)

    @staticmethod
    def delete_branches(*, validated_data: dict) -> dict:
        branch_ids = BranchService._decode_uids(validated_data["uids"])
        company_ids = list(
            Branch.objects.filter(pk__in=branch_ids)
            .values_list("company_id", flat=True)
            .distinct()
        )
        deleted = BranchRepository.soft_delete_by_ids(branch_ids)
        if not deleted:
            raise NotFound("Branch not found.")
        BranchService._sync_warehouses(company_ids)
        return {"deleted": deleted}

    @staticmethod
    def toggle_branches(*, validated_data: dict):
        branch_ids = BranchService._decode_uids(validated_data["uids"])
        updated = BranchRepository.toggle_status_by_ids(branch_ids)
        if not updated:
            raise NotFound("Branch not found.")
        company_ids = list(
            Branch.objects.filter(pk__in=branch_ids)
            .values_list("company_id", flat=True)
            .distinct()
        )
        BranchService._sync_warehouses(company_ids)
        return BranchRepository.list_branches(branch_id=branch_ids)

    @staticmethod
    def _sync_warehouses(company_ids) -> None:
        from apps.inventory.services.warehouse_service import WarehouseService

        for company_id in dict.fromkeys(company_ids):
            if company_id:
                WarehouseService.ensure_for_company_id(company_id)
