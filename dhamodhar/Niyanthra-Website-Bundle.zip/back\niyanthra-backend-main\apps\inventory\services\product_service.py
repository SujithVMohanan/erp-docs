from decimal import Decimal

from django.db import IntegrityError, transaction
from rest_framework.exceptions import NotFound

from apps.inventory.models import Product
from apps.inventory.repository import InventoryRepository
from apps.inventory.services.scope import (
    decode_uid,
    decode_uids,
    workspace_context,
)
from apps.inventory.services.stock_service import (
    StockService,
    company_code,
    money,
    name_key,
    normalize_unit,
    tax_snapshot,
)
from core.exceptions.auth import AuthValidationError
from core.tenant.workspace import WorkspaceScope
from infrastructure.database.context import get_current_db_alias


_ZERO = Decimal("0.0000")


def _sku_exists() -> AuthValidationError:
    return AuthValidationError(
        {"sku": ["This SKU already exists."]},
        code="PRODUCT_SKU_EXISTS",
    )


class ProductService:

    @staticmethod
    def list_products(
        *,
        scope: WorkspaceScope,
        validated_data: dict,
    ):
        product_ids = None

        with workspace_context(scope):
            if validated_data.get("uid"):
                product_ids = [
                    decode_uid(validated_data["uid"])
                ]

            return InventoryRepository.list_products(
                product_ids=product_ids,
                sku=validated_data.get("sku"),
                name=validated_data.get("name"),
            )

    @staticmethod
    def create_product(
        *,
        scope: WorkspaceScope,
        validated_data: dict,
    ) -> Product:
        alias = get_current_db_alias()

        with workspace_context(scope):
            with transaction.atomic(using=alias):
                product = ProductService._insert(
                    scope,
                    validated_data,
                )

                opening_qty = validated_data.get("opening_qty")

                if opening_qty and money(opening_qty) > 0:
                    warehouse = StockService.resolve_warehouse(
                        scope,
                        branch_uid=validated_data.get("branch_uid"),
                    )

                    StockService.post_opening(
                        warehouse=warehouse,
                        lines=[
                            StockService.opening_line(
                                product=product,
                                warehouse_id=warehouse.pk,
                                quantity=opening_qty,
                                unit_cost=validated_data.get(
                                    "unit_cost"
                                ),
                            )
                        ],
                        client_ref=validated_data.get("client_ref"),
                        products={
                            product.pk: product,
                        },
                    )

                return product

    @staticmethod
    def update_product(
        *,
        scope: WorkspaceScope,
        validated_data: dict,
    ) -> Product:
        with workspace_context(scope):
            product = (
                Product.objects
                .filter(
                    pk=decode_uid(validated_data["uid"])
                )
                .first()
            )

            if product is None:
                raise NotFound("Product not found.")

            values = ProductService._master_values(
                validated_data,
                current=product,
            )

            sku = values.get("sku")

            if sku:
                existing = (
                    InventoryRepository
                    .products_by_sku({sku})
                    .get(sku)
                )

                if existing is not None and existing.pk != product.pk:
                    raise _sku_exists()

            for field, value in values.items():
                setattr(product, field, value)

            try:
                product.save()
            except IntegrityError:
                raise _sku_exists() from None

            return product

    @staticmethod
    def delete_products(
        *,
        scope: WorkspaceScope,
        validated_data: dict,
    ) -> dict:
        product_ids = decode_uids(
            validated_data["uids"]
        )

        with workspace_context(scope):
            if InventoryRepository.stock_blocks_delete(
                product_ids
            ):
                raise AuthValidationError(
                    {"uids": ["Product still has stock."]},
                    code="PRODUCT_IN_STOCK",
                )

            deleted = (
                InventoryRepository
                .soft_delete_products(product_ids)
            )

            if not deleted:
                raise NotFound("Product not found.")

            return {"deleted": deleted}

    @staticmethod
    def _insert(
        scope: WorkspaceScope,
        validated_data: dict,
    ) -> Product:
        sku = (
            validated_data.get("sku") or ""
        ).strip().upper()

        if sku:
            if InventoryRepository.sku_exists(sku):
                raise _sku_exists()
        else:
            sku = InventoryRepository.next_sku(
                company_code(scope.company_id)
            )

        tax_rate_id, tax_percent = ProductService._tax(
            validated_data
        )

        cost_price = money(
            validated_data.get("cost_price") or 0
        )

        unit_cost = validated_data.get("unit_cost")

        if unit_cost is not None:
            cost_price = money(unit_cost)

        selling_price = validated_data.get("selling_price")

        if selling_price is None:
            selling_price = cost_price
        else:
            selling_price = money(selling_price)

        try:
            return Product.objects.create(
                company_id=scope.company_id,
                sku=sku,
                name=validated_data["name"].strip(),
                name_key=name_key(
                    validated_data["name"]
                ),
                uom_code=normalize_unit(
                    validated_data.get("uom_code")
                ),
                hsn_code=(
                    validated_data.get("hsn_code") or ""
                ).strip(),
                tax_rate_id=tax_rate_id,
                tax_percent=tax_percent,
                cost_price=cost_price,
                selling_price=selling_price,
                track_stock=validated_data.get(
                    "track_stock",
                    True,
                ),
                is_active=validated_data.get(
                    "is_active",
                    True,
                ),
            )
        except IntegrityError:
            raise _sku_exists() from None

    @staticmethod
    def _master_values(
        validated_data: dict,
        *,
        current: Product | None,
    ) -> dict:
        values = {}

        if (
            "name" in validated_data
            and validated_data.get("name")
        ):
            name = validated_data["name"].strip()

            values["name"] = name
            values["name_key"] = name_key(name)

        if validated_data.get("sku"):
            values["sku"] = (
                validated_data["sku"]
                .strip()
                .upper()
            )

        if validated_data.get("uom_code"):
            values["uom_code"] = normalize_unit(
                validated_data["uom_code"]
            )

        if (
            "hsn_code" in validated_data
            and validated_data.get("hsn_code") is not None
        ):
            values["hsn_code"] = (
                validated_data["hsn_code"]
                .strip()
            )

        if (
            "cost_price" in validated_data
            and validated_data.get("cost_price") is not None
        ):
            values["cost_price"] = money(
                validated_data["cost_price"]
            )

        if (
            "selling_price" in validated_data
            and validated_data.get("selling_price") is not None
        ):
            values["selling_price"] = money(
                validated_data["selling_price"]
            )

        if (
            "track_stock" in validated_data
            and validated_data.get("track_stock") is not None
        ):
            values["track_stock"] = (
                validated_data["track_stock"]
            )

        if (
            "is_active" in validated_data
            and validated_data.get("is_active") is not None
        ):
            values["is_active"] = (
                validated_data["is_active"]
            )

        if validated_data.get("tax_rate_uid"):
            tax_rate_id, tax_percent = tax_snapshot(
                decode_uid(
                    validated_data["tax_rate_uid"],
                    field="tax_rate_uid",
                )
            )

            values["tax_rate_id"] = tax_rate_id
            values["tax_percent"] = tax_percent

        return values

    @staticmethod
    def _tax(
        validated_data: dict,
    ) -> tuple[int | None, Decimal]:
        tax_rate_uid = validated_data.get(
            "tax_rate_uid"
        )

        if not tax_rate_uid:
            return None, _ZERO

        return tax_snapshot(
            decode_uid(
                tax_rate_uid,
                field="tax_rate_uid",
            )
        )
