from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated

from apps.tenant.schema import GetTenantsApiSchema
from apps.tenant.serializer import (
    ActivateSiloTenantSerializer,
    CreateTenantSerializer,
    GetMyTenantQuerySerializer,
    GetTenantsQuerySerializer,
    TenantUidsSerializer,
    UpdateTenantSerializer,
)
from apps.tenant.services.silo_activation_service import SiloActivationService
from apps.tenant.services.tenant_service import TenantService
from core.pagination import RestPagination
from core.permissions import HasMembershipAccess, IsAppAuthenticated, IsPlatformAdmin
from core.responses import ResponseInfo
from core.utils.exceptions import ExceptionHandler


class TenantBaseApiView:
    response_schema = GetTenantsApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(
            exc,
            request=request,
            view=self,
        )


class GetTenantsApiView(TenantBaseApiView, generics.ListAPIView):

    serializer_class       = GetTenantsApiSchema
    query_serializer_class = GetTenantsQuerySerializer
    pagination_class       = RestPagination
    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]

    @swagger_auto_schema(
        tags=["Tenants"],
        manual_parameters=[
            openapi.Parameter(
                "uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "slug",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "name",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "tenant_type",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "db_alias",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "is_active",
                openapi.IN_QUERY,
                type=openapi.TYPE_BOOLEAN,
            ),
            openapi.Parameter(
                "provisioning_status",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
            ),
        ],
        operation_summary="Get tenants",
    )
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(
            data=self.request.query_params
        )
        query.is_valid(raise_exception=True)

        return TenantService.get_tenants(
            validated_data=query.validated_data
        )


class CreateTenantApiView(TenantBaseApiView, generics.CreateAPIView):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    membership_uid_source = "data"
    membership_company_field = "company"
    serializer_class = CreateTenantSerializer

    @swagger_auto_schema(
        request_body=CreateTenantSerializer,
        tags=["Tenants"],
        operation_summary="Create tenant",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            tenant = TenantService.create_tenant(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.created(
                self.response_schema(tenant).data,
                message="Tenant created successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class MyTenantApiView(TenantBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
    ]
    serializer_class = GetMyTenantQuerySerializer

    @swagger_auto_schema(
        tags=["Tenants"],
        manual_parameters=[
            openapi.Parameter(
                "company_uid",
                openapi.IN_QUERY,
                type=openapi.TYPE_STRING,
                required=True,
            ),
        ],
        operation_summary="Get the tenant for a company",
    )
    def get(self, request, *args, **kwargs):
        try:
            query = self.serializer_class(data=request.query_params)
            if not query.is_valid():
                return ResponseInfo.validation_error(query.errors)
            
            tenant = TenantService.get_tenant_for_company(
                user=request.user,
                company_uid=query.validated_data["company_uid"],
            )
            payload = self.response_schema(tenant).data
            payload["status"] = tenant.provisioning_status
            if not request.user.is_admin:
                payload.pop("db_alias", None)
            return ResponseInfo.ok(
                payload,
                message="Tenant retrieved successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateTenantApiView(TenantBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
    ]
    serializer_class = UpdateTenantSerializer

    @swagger_auto_schema(
        request_body=UpdateTenantSerializer,
        tags=["Tenants"],
        operation_summary="Update tenant",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            tenant = TenantService.update_tenant(
                validated_data=serializer.validated_data,
                user=request.user,
            )

            return ResponseInfo.ok(
                self.response_schema(tenant).data,
                message="Tenant updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteTenantsApiView(TenantBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = TenantUidsSerializer

    @swagger_auto_schema(
        request_body=TenantUidsSerializer,
        tags=["Tenants"],
        operation_summary="Delete tenants",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            payload = TenantService.delete_tenants(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                payload,
                message="Tenant(s) deleted successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class ToggleTenantStatusApiView(
    TenantBaseApiView,
    generics.GenericAPIView,
):

    permission_classes = [
        IsAuthenticated,
        IsAppAuthenticated,
        IsPlatformAdmin,
    ]
    serializer_class = TenantUidsSerializer

    @swagger_auto_schema(
        request_body=TenantUidsSerializer,
        tags=["Tenants"],
        operation_summary="Toggle tenant active status",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            tenants = TenantService.toggle_tenants(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(tenants, many=True).data,
                message="Tenant status updated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)


class ActivateSiloTenantApiView(TenantBaseApiView, generics.GenericAPIView):

    permission_classes = [
        IsAuthenticated,
        HasMembershipAccess,
    ]
    serializer_class = ActivateSiloTenantSerializer

    @swagger_auto_schema(
        request_body=ActivateSiloTenantSerializer,
        tags=["Tenants"],
        operation_summary="Activate SILO tenant after DevOps setup",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)

            if not serializer.is_valid():
                return ResponseInfo.validation_error(
                    serializer.errors
                )

            tenant = SiloActivationService.activate(
                validated_data=serializer.validated_data
            )

            return ResponseInfo.ok(
                self.response_schema(tenant).data,
                message="SILO tenant activated successfully.",
            )

        except Exception as exc:
            return self.handle_exception_response(exc, request)
