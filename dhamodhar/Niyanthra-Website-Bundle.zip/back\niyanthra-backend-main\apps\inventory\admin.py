from django.contrib import admin

from apps.inventory.models import (
    Product,
    StockDocument,
    StockLedger,
    StockSummary,
    Warehouse,
)


@admin.register(Warehouse)
class WarehouseAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "branch_id", "company_id", "status", "deleted_at")
    search_fields = ("name", "code")
    readonly_fields = ("public_id", "tenant_id", "company_id", "created_at", "updated_at")


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("sku", "name", "uom_code", "cost_price", "is_active", "deleted_at")
    search_fields = ("sku", "name")
    readonly_fields = ("public_id", "tenant_id", "company_id", "created_at", "updated_at")


@admin.register(StockDocument)
class StockDocumentAdmin(admin.ModelAdmin):
    list_display = ("doc_number", "doc_type", "doc_date", "company_id", "status")
    list_filter = ("doc_type", "status")
    readonly_fields = ("public_id", "tenant_id", "company_id", "created_at", "updated_at")


@admin.register(StockSummary)
class StockSummaryAdmin(admin.ModelAdmin):
    list_display = ("product", "warehouse", "qty_on_hand", "qty_reserved", "company_id")
    readonly_fields = ("public_id", "tenant_id", "company_id", "created_at", "updated_at")


@admin.register(StockLedger)
class StockLedgerAdmin(admin.ModelAdmin):
    list_display = ("movement", "product", "warehouse", "qty_delta", "occurred_at")
    readonly_fields = ("public_id", "tenant_id", "company_id", "created_at", "updated_at")
