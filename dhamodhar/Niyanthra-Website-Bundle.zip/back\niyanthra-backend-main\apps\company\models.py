from django.conf import settings
from django.db import models
from django.utils.translation import gettext_lazy as _

from apps.organization.models import (
    Organization
)

from core.database import (
    AllObjectsManager,
    BaseModel,
    SoftDeleteManager,
    alive_unique,
)




class CompanyType(BaseModel):

    name          = models.CharField(_("name"), max_length=100,blank=True, null=True)
    code          = models.CharField(_("code"), max_length=50, unique=True,blank=True, null=True)
    is_active     = models.BooleanField(_("is active"), default=True)

    class Meta:
        db_table = "company_types"
        ordering = ("id",)
        indexes = [
            models.Index(fields=["is_active"]),
        ]

    def __str__(self):
        return self.name






class Company(BaseModel):

    organization = models.ForeignKey(
        Organization,
        on_delete=models.CASCADE,
        related_name="companies",
        verbose_name=_("organization"),
    )

    name          = models.CharField(_("name"), max_length=254, blank=True, null=True)
    code          = models.CharField(_("code"), max_length=100, blank=True, null=True)
    legal_name    = models.CharField(_("legal name"), max_length=254, blank=True, null=True)
    is_active     = models.BooleanField(_("is active"), default=True)
    website       = models.URLField(_("website"), max_length=255,blank=True, null=True)
    logo          = models.ImageField(upload_to="companies/logos/",blank=True,null=True,)

    timezone      = models.ForeignKey(
        "users.Timezone",
        on_delete=models.SET_NULL,
        related_name="companies_timezone",
        blank=True,
        null=True,
    )

    registration_number = models.CharField(_("registration number"),
                                           max_length=100,blank=True, null=True,)



    tenant        = models.ForeignKey(
        "tenant.Tenant",
        on_delete=models.SET_NULL,
        related_name="companies",
        verbose_name=_("tenant"),
        blank=True,
        null=True,
    )



    company_type = models.ForeignKey(
        CompanyType,
        on_delete=models.PROTECT,
        related_name="companies",
        blank=True,
        null=True,
    )

    objects     = SoftDeleteManager()
    all_objects = AllObjectsManager()

    class Meta:
        db_table              = "companies"
        verbose_name          = _("company")
        verbose_name_plural   = _("companies")
        ordering              = ("id",)
        default_manager_name  = "objects"
        base_manager_name     = "all_objects"
        constraints           = [
                        alive_unique(
                            ["organization", "code"], 
                            "company_org_code_alive_uniq")
                            ]
        indexes = [
            models.Index(
                fields    = ("organization", "is_active"),
                name      = "company_org_active_idx",
            ),
        ]


    def save(self, *args, **kwargs):
        if self.code:
            self.code = self.code.strip().upper()
        if self.name:
            self.name = self.name.strip()
        if self.legal_name == "":
            self.legal_name = None
        super().save(*args, **kwargs)

    def __str__(self) -> str:
        return f"{self.name}" or f"{self.code}"





class CompanyMembership(BaseModel):

    class Role(models.TextChoices):
        OWNER       = "owner", _("Owner")
        ADMIN       = "admin", _("Admin")
        EMPLOYEE    = "employee", _("Employee")

    company = models.ForeignKey(
        "company.Company",
        on_delete=models.CASCADE,
        related_name="memberships",
        verbose_name=_("company"),
    )

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="company_memberships",
        verbose_name=_("user"),
    )

    role = models.CharField(
            _("role"),
            max_length=20,
            choices=Role.choices,
            default=Role.EMPLOYEE
        )

    is_active = models.BooleanField( _("is active"), default=True,)

    class Meta:
        db_table              = "company_memberships"
        verbose_name          = _("company membership")
        verbose_name_plural   = _("company memberships")
        ordering              = ("-id",)
        constraints           = [
                            models.UniqueConstraint(
                                fields=("company", "user"),
                                name="company_user_uniq",
                            ),
                        ]
        indexes = [
            models.Index(
                fields    = ("company", "is_active"),
                name      = "company_membership_active_idx",
            ),
            models.Index(
                fields    = ("user", "is_active"),
                name      = "user_company_active_idx",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.company_id}:{self.user_id}"





class CompanyAddress(BaseModel):

    class AddressType(models.TextChoices):
        REGISTERED    = "registered", "Registered"
        HEAD_OFFICE   = "head_office", "Head Office"
        BILLING       = "billing", "Billing"
        SHIPPING      = "shipping", "Shipping"
        OTHER         = "other", "Other"

    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name="addresses",
    )

    address_type      = models.CharField(_("address type"), max_length=30,choices=AddressType.choices,)
    address_line_1    = models.CharField(_("address line 1"), max_length=255,blank=True, null=True)
    address_line_2    = models.CharField(_("address line 2"),max_length=255,blank=True,null=True,)
    city              = models.CharField(_("city"), max_length=100,blank=True, null=True)
    state_province    = models.CharField(_("state/province"), max_length=100,blank=True, null=True)
    postal_code       = models.CharField(_("postal code"), max_length=20,blank=True, null=True)
    is_primary        = models.BooleanField(default=False)

    country = models.ForeignKey(
        "location.Country",
        on_delete=models.PROTECT,
        related_name="company_addresses",
    )


    class Meta:
        db_table = "company_addresses"
        indexes = [
            models.Index(fields=["company", "address_type"]),
            models.Index(fields=["company", "is_primary"]),
        ]




class BusinessType(BaseModel):

    name          = models.CharField(_("name"), max_length=100,blank=True, null=True)
    code          = models.CharField(_("code"), max_length=50, unique=True)
    is_active     = models.BooleanField(_("is active"), default=True)

    class Meta:
        db_table = "business_types"
        indexes = [
                    models.Index(fields=["name", "code"]),
                    models.Index(fields=["is_active"]),
                ]
        

        ordering = ("id",)

    def __str__(self):
        return f"{self.name}"




class CompanyBusinessType(BaseModel):

    company = models.ForeignKey(
        Company, 
        on_delete=models.CASCADE, 
        related_name="business_types"
        )

    business_type = models.ForeignKey(
        BusinessType,
        on_delete=models.PROTECT,
        related_name="company_business_types",
    )

    is_primary = models.BooleanField(_("is primary"), default=False)

    class Meta:
        db_table = "company_business_types"
        constraints = [
            models.UniqueConstraint(
                fields=["company", "business_type"],
                name="uq_company_business_type",
            ),
        ]


    def __str__(self) -> str:
        return f"{self.company_id}:{self.business_type_id}"




class TaxType(BaseModel):
    """
    Global tax category.

    Examples:
    - GST
    - VAT
    - TDS
    - TCS
    - CESS
    """

    name = models.CharField(_("name"), max_length=100,blank=True, null=True)
    code = models.CharField(_("code"), max_length=50, unique=True,blank=True, null=True)

    class Meta:
        db_table = "tax_types"
        ordering = ["id"]

    def __str__(self):
        return f"{self.name}-({self.code})"


class TaxComponent(BaseModel):
    """
    Individual tax component.

    Examples:
    - CGST
    - SGST
    - IGST
    - UTGST
    - CESS
    """

    tax_type = models.ForeignKey(
        TaxType,
        on_delete=models.PROTECT,
        related_name="components",
    )

    name = models.CharField(_("name"), max_length=100,blank=True, null=True)
    code = models.CharField(_("code"), max_length=50,blank=True, null=True)
    component_type = models.CharField(
        _("component type"),
        max_length=50,
        blank=True,
        null=True,
    )

    class Meta:
        db_table = "tax_components"
        ordering = ["id"]
        constraints = [
            models.UniqueConstraint(
                fields=["tax_type", "code"],
                name="uq_tax_component_type_code",
            ),
        ]

    def __str__(self):
        return f"{self.name}-({self.code})"



class TaxRate(BaseModel):
    """
    Tax rate definition.

    Example:
        GST 5%
        GST 12%
        GST 18%
        GST 28%
    """

    tax_type = models.ForeignKey(
        TaxType,
        on_delete=models.PROTECT,
        related_name="rates",
    )

    name              = models.CharField(_("name"), max_length=100,blank=True, null=True)
    code              = models.CharField(_("code"), max_length=50,blank=True, null=True)
    rate              = models.DecimalField(_("rate"), max_digits=8,decimal_places=4,blank=True, null=True,)
    rate_type         = models.CharField(_("rate type"), max_length=30,default="PERCENTAGE")
    effective_from    = models.DateField(_("effective from"),blank=True, null=True,)
    effective_to      = models.DateField( _("effective to"),null=True,blank=True,)

    class Meta:
        db_table = "tax_rates"
        ordering = ["id"]
        constraints = [
            models.UniqueConstraint(
                fields=["tax_type", "code"],
                name="uq_tax_rate_type_code",
            ),
        ]

    def __str__(self):
        return f"{self.name} ({self.rate}%)"



class TaxRateComponent(BaseModel):
    """
    Defines how a tax rate is split into components.

    Example:

        GST 18%
        ├── CGST 9%
        └── SGST 9%

    or

        IGST 18%
        └── IGST 18%
    """

    tax_rate = models.ForeignKey(
        TaxRate,
        on_delete=models.CASCADE,
        related_name="components",
    )
    tax_component = models.ForeignKey(
        TaxComponent,
        on_delete=models.PROTECT,
        related_name="rate_components",
    )
    rate = models.DecimalField(_("component rate"), max_digits=8, decimal_places=4)
    

    class Meta:
        db_table = "tax_rate_components"
        constraints = [
            models.UniqueConstraint(
                fields=["tax_rate", "tax_component"],
                name="uq_tax_rate_component",
            ),
        ]

    def __str__(self):
        return f"{self.tax_rate} - {self.tax_component}"



class CompanyTaxRegistration(BaseModel):
    """
    Legal tax registration held by a company.

    Example:
        GSTIN
        VAT Number
        TIN
    """

    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name="tax_registrations",
    )

    country = models.ForeignKey(
        "location.Country",
        on_delete=models.PROTECT,
        related_name="company_tax_registrations",
    )

    tax_type = models.ForeignKey(
        TaxType,
        on_delete=models.PROTECT,
        related_name="company_registrations",
    )

    registration_number   = models.CharField(_("registration number"),max_length=100,blank=True, null=True,)
    registration_name     = models.CharField(_("registration name"),max_length=200,blank=True,null=True,)
    status                = models.CharField( _("status"),max_length=30,default="ACTIVE",)
    effective_from        = models.DateField(_("effective from"),blank=True, null=True,)
    effective_to          = models.DateField(_("effective to"),null=True,blank=True,)
    is_primary            = models.BooleanField(default=False)

    class Meta:
        db_table = "company_tax_registrations"
        constraints = [
            models.UniqueConstraint(
                fields=[
                    "company",
                    "tax_type",
                    "registration_number",
                ],
                name="uq_company_tax_registration",
            ),
        ]

    def __str__(self):
        return f"{self.registration_number}"




class Branch(BaseModel):

    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name="branches",
    )

    name          = models.CharField(_("name"), max_length=150,blank=True, null=True)
    code          = models.CharField(_("code"), max_length=50,blank=True, null=True)
    branch_type   = models.CharField(_("branch type"), max_length=50, blank=True,null=True,)
    status        = models.CharField(_("status"), max_length=30, default="ACTIVE")
    email         = models.EmailField(_("email"), blank=True, null=True)
    phone         = models.CharField(_("phone"), max_length=30, blank=True, null=True)

    manager = models.ForeignKey(
        "users.Users",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="managed_branches",
    )

    timezone      = models.ForeignKey(
        "users.Timezone",
        on_delete=models.SET_NULL,
        related_name="branch_timezone",
        blank=True,
        null=True,
    )

    created_by = models.ForeignKey(
        "users.Users",
        on_delete=models.SET_NULL,
        null=True,
        related_name="created_branches",
    )

    updated_by = models.ForeignKey(
        "users.Users",
        on_delete=models.SET_NULL,
        null=True,
        related_name="updated_branches",
    )

    class Meta:
        db_table = "branches"
        constraints = [
            models.UniqueConstraint(
                fields=["company", "code"],
                name="uq_branch_company_code",
            ),
        ]
        ordering = ["name"]

    def __str__(self):
        return f"{self.company.name} - {self.name}"


class BranchMembership(BaseModel):

    class Role(models.TextChoices):
        MANAGER = "manager", _("Manager")
        STAFF   = "staff", _("Staff")

    branch = models.ForeignKey(
        Branch,
        on_delete=models.CASCADE,
        related_name="memberships",
        verbose_name=_("branch"),
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="branch_memberships",
        verbose_name=_("user"),
    )
    role = models.CharField(
        _("role"),
        max_length=20,
        choices=Role.choices,
        default=Role.STAFF,
    )
    is_active = models.BooleanField(_("is active"), default=True)

    class Meta:
        db_table = "branch_memberships"
        verbose_name = _("branch membership")
        verbose_name_plural = _("branch memberships")
        ordering = ("-id",)
        constraints = [
            models.UniqueConstraint(
                fields=("branch", "user"),
                name="branch_user_uniq",
            ),
        ]
        indexes = [
            models.Index(
                fields=["branch", "is_active"],
                name="branch_membership_active_idx",
            ),
            models.Index(
                fields=["user", "is_active"],
                name="user_branch_active_idx",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.branch_id}:{self.user_id}"


class BranchTaxRegistration(BaseModel):
    """
    Associates a branch with a company's tax registration.
    """

    branch = models.ForeignKey(
        Branch,
        on_delete=models.CASCADE,
        related_name="tax_registrations",
    )

    tax_registration = models.ForeignKey(
        CompanyTaxRegistration,
        on_delete=models.CASCADE,
        related_name="branches",
    )

    is_primary     = models.BooleanField(default=False)
    effective_from = models.DateField(_("effective from"),blank=True, null=True,)
    effective_to   = models.DateField(_("effective to"),null=True,blank=True,)

    class Meta:
        db_table = "branch_tax_registrations"
        constraints = [
            models.UniqueConstraint(
                fields=["branch", "tax_registration"],
                name="uq_branch_tax_registration",
            ),
        ]


    def __str__(self):
        return f"{self.branch_id}:{self.tax_registration_id}"





class CompanyLocation(BaseModel):

    company = models.ForeignKey(
        "company.Company",
        on_delete=models.CASCADE,
        related_name="locations",
    )

    location = models.ForeignKey(
        "location.Location",
        on_delete=models.PROTECT,
        related_name="company_links",
    )

    location_type   = models.CharField(_("location type"),max_length=30,default="REGISTERED",)

    is_primary      = models.BooleanField(_("is primary"),default=False,)

    class Meta:

        db_table              = "company_locations"
        verbose_name          = _("company location")
        verbose_name_plural   = _("company locations")
        ordering              = ("-is_primary", "id")

        constraints = [
            models.UniqueConstraint(
                fields=("company", "location"),
                name="uq_company_location",
            ),
            models.UniqueConstraint(
                fields=("company",),
                condition=models.Q(is_primary=True),
                name="uq_company_primary_location",
            ),
        ]

        indexes = [
            models.Index(
                fields=("company", "is_primary"),
                name="company_location_primary_idx",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.company} - {self.location}"



class BranchLocation(BaseModel):

    branch = models.OneToOneField(
        "company.Branch",
        on_delete=models.CASCADE,
        related_name="location",
    )

    location = models.OneToOneField(
        "location.Location",
        on_delete=models.PROTECT,
        related_name="branch_link",
    )

    class Meta:

        db_table              = "branch_locations"
        verbose_name          = _("branch location")
        verbose_name_plural   = _("branch locations")

    def __str__(self) -> str:
        return f"{self.branch} - {self.location}"


class Module(BaseModel):

    name      = models.CharField(_("name"), max_length=100)
    code      = models.CharField(_("code"), max_length=50, unique=True)
    is_active = models.BooleanField(_("is active"), default=True)

    class Meta:
        db_table = "modules"
        ordering = ("name", "id")
        indexes = [
            models.Index(fields=["is_active"], name="idx_module_active"),
        ]

    def __str__(self):
        return self.name or ""


class CompanyModule(BaseModel):

    company = models.OneToOneField(
        "company.Company",
        on_delete=models.CASCADE,
        related_name="company_module",
    )

    modules = models.JSONField(_("modules"), default=dict)

    class Meta:
        db_table = "company_modules"
        ordering = ("id",)

    def __str__(self):
        return f"{self.company_id}"