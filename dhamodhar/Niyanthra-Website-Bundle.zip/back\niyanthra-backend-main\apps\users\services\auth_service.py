from django.contrib.auth.hashers import check_password, make_password
from django.db import (
    IntegrityError,
    transaction,
)
from rest_framework_simplejwt.exceptions import TokenError
from rest_framework_simplejwt.tokens import RefreshToken

from apps.users.models import Users
from apps.users.repository import (
    UserRepository,
    integrity_field_errors,
)
from apps.users.services.membership_service import MembershipService
from core.exceptions.auth import (
    AuthFailed,
    AuthValidationError,
)
from core.providers import (
    SocialIdentity,
    verify_social_token,
)
from core.utils.auth_log import log_auth_event
from core.utils.jwt_blacklist import logout_tokens
from core.utils.tokens import (
    refresh_tokens,
    session_for_user,
)


_cached_dummy_password_hash = ""


def _dummy_password_hash() -> str:
    global _cached_dummy_password_hash
    if not _cached_dummy_password_hash:
        _cached_dummy_password_hash = make_password("invalid-login")
    return _cached_dummy_password_hash


def _password_matches(user: Users | None, password: str) -> bool:
    if user is not None and user.has_usable_password():
        return bool(user.check_password(password))
    check_password(password, _dummy_password_hash())
    return False


class AuthService:
    @staticmethod
    def login(*, validated_data: dict) -> tuple[dict, Users]:
        """
        Email and password only.

        Checks the password, records last login, and issues tokens.
        Invite codes, when present, grant membership. Company and organization
        catalogs are not loaded on this path.
        """
        password = validated_data["password"]
        user = UserRepository.get_for_login(validated_data["email"])
        password_ok = _password_matches(user, password)
        if not password_ok or user is None:
            raise AuthFailed("Invalid email or password.", code="INVALID_CREDENTIALS")
        if not user.is_active:
            raise AuthFailed("Account is disabled.", code="ACCOUNT_DISABLED")

        UserRepository.update_last_login(user)

        if MembershipService.has_membership_scope(validated_data=validated_data):
            MembershipService.create_membership(
                validated_data=validated_data,
                user=user,
            )

        tokens = session_for_user(user)
        log_auth_event(
            "login_pending" if not user.profile_completed else "login",
            public_id=str(user.public_id),
        )
        return tokens, user

    @staticmethod
    def logout(*, validated_data: dict, access_token: str | None = None) -> None:
        refresh = validated_data.get("refresh")
        access = validated_data.get("access") or access_token
        try:
            logout_tokens(
                refresh_token=refresh,
                access_token=access,
            )
        except TokenError:
            raise AuthFailed(
                "Refresh token is invalid or already expired.",
                code="INVALID_REFRESH_TOKEN",
            )
        log_auth_event("logout")

    @staticmethod
    def refresh(*, validated_data: dict) -> dict:
        refresh = validated_data["refresh"]
        try:
            parsed = RefreshToken(refresh)
        except TokenError:
            raise AuthFailed(
                "Refresh token is invalid or expired.",
                code="INVALID_REFRESH_TOKEN",
            )

        public_id = parsed.get("public_id")
        if not public_id:
            raise AuthFailed(
                "Refresh token is invalid or expired.",
                code="INVALID_REFRESH_TOKEN",
            )
        user = UserRepository.get_alive_by_public_id(public_id)
        if user is None or not user.is_active:
            raise AuthFailed("Account is disabled.", code="ACCOUNT_DISABLED")
        if not user.profile_completed:
            raise AuthFailed(
                "Complete your profile to continue.",
                code="PROFILE_INCOMPLETE",
            )

        try:
            tokens = refresh_tokens(refresh)
        except TokenError:
            raise AuthFailed(
                "Refresh token is invalid or expired.",
                code="INVALID_REFRESH_TOKEN",
            )
        log_auth_event("token_refresh", public_id=str(user.public_id))
        return tokens

    @staticmethod
    def social_login(*, validated_data: dict) -> tuple[dict, Users]:
        identity = verify_social_token(
            provider    = validated_data["provider"],
            id_token    = validated_data["id_token"],
            nonce       = validated_data.get("nonce"),
        )

        if identity.email and not identity.email_verified:
            raise AuthFailed(
                "Email is not verified with this provider.",
                code="GOOGLE_EMAIL_UNVERIFIED",
            )

        try:
            with transaction.atomic():
                user = AuthService._user_for_identity(identity)

        except IntegrityError:
            user = AuthService._user_after_conflict(identity)

        if not user.is_active:
            raise AuthFailed("Account is disabled.", code="ACCOUNT_DISABLED")

        UserRepository.update_last_login(user)

        if MembershipService.has_membership_scope(validated_data=validated_data):
            MembershipService.create_membership(
                validated_data=validated_data,
                user=user,
            )

        tokens = session_for_user(user)
        log_auth_event(
            "social_login_pending" if not user.profile_completed else "social_login",
            public_id=str(user.public_id),
            provider=identity.provider,
        )
        return tokens, user

    @staticmethod
    def _user_for_identity(identity: SocialIdentity) -> Users:
        linked = UserRepository.get_by_provider_subject(
            provider    = identity.provider,
            subject     = identity.subject,
        )
        if linked is not None:
            return linked.user

        if not identity.email:
            raise AuthFailed(
                "This provider did not return an email address.",
                code="GOOGLE_EMAIL_MISSING",
            )

        user = UserRepository.get_alive_by_email(identity.email)
        if user is None:
            user = UserRepository.create_social_user(
                email    = identity.email,
                username = AuthService._available_username(identity.name),
            )
        else:
            UserRepository.mark_email_verified(user)
            AuthService._apply_provider_name(user, identity.name)

        UserRepository.link_provider(
            user        = user,
            provider    = identity.provider,
            subject     = identity.subject,
            email       = identity.email,
        )
        return user

    @staticmethod
    def _available_username(name: str | None) -> str | None:
        username = (name or "").strip()[:150] or None
        if not username:
            return None
        if UserRepository.get_username_conflict(username=username):
            return None
        return username

    @staticmethod
    def _apply_provider_name(user: Users, name: str | None) -> None:
        if (user.username or "").strip():
            return
        username = AuthService._available_username(name)
        if not username:
            return
        UserRepository.update_user_profile(user=user, username=username)

    @staticmethod
    def _user_after_conflict(identity: SocialIdentity) -> Users:
        linked = UserRepository.get_by_provider_subject(
            provider=identity.provider,
            subject=identity.subject,
        )
        if linked is not None:
            return linked.user
        if identity.email:
            existing = UserRepository.get_alive_by_email(identity.email)
            if existing is not None:
                UserRepository.link_provider(
                    user=existing,
                    provider=identity.provider,
                    subject=identity.subject,
                    email=identity.email,
                )
                return existing
        errors, code = integrity_field_errors(
            IntegrityError("uap_provider_subject_alive_uniq")
        )
        raise AuthValidationError(errors, code=code)
