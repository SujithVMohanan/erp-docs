from django.contrib import admin

from apps.sales.models import Sale


@admin.register(Sale)
class SaleAdmin(admin.ModelAdmin):
    list_display = (
        "invoice_number",
        "customer_name",
        "tenant_id",
        "company_id",
        "sale_date",
        "total_amount",
        "created_at",
        "deleted_at",
    )
    list_filter = ("sale_date",)
    search_fields = (
        "invoice_number",
        "customer_name",
    )
    readonly_fields = (
        "public_id",
        "tenant_id",
        "company_id",
        "created_at",
        "updated_at",
    )
