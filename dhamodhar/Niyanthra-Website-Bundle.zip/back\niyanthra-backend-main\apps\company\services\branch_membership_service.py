from django.db import (
    IntegrityError,
    transaction,
)
from rest_framework.exceptions import (
    NotFound,
    PermissionDenied,
    ValidationError,
)

from apps.company.models import BranchMembership
from apps.company.repository import (
    BranchMembershipRepository,
    BranchRepository,
)
from apps.company.services.company_membership_service import (
    CompanyMembershipService,
)
from apps.users.repository import UserRepository
from core.exceptions.auth import AuthValidationError
from core.utils.ids import decode_id


class BranchMembershipService:

    @staticmethod
    def _decode_uid(uid: str, *, field: str = "uid") -> int:
        try:
            decoded = decode_id(uid)
        except ValueError:
            raise ValidationError({field: ["Invalid id."]})

        if not isinstance(decoded, int):
            raise ValidationError({field: ["Invalid id."]})

        return decoded

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        return list(
            dict.fromkeys(
                BranchMembershipService._decode_uid(uid, field="uids")
                for uid in uids
            )
        )

    @staticmethod
    def _resolve_branch(uid: str) -> int:
        branch_id = BranchMembershipService._decode_uid(
            uid,
            field="branch_uid",
        )
        if BranchRepository.get_by_id(branch_id) is None:
            raise AuthValidationError(
                {"branch_uid": ["Branch not found."]},
                code="BRANCH_NOT_FOUND",
            )
        return branch_id

    @staticmethod
    def _resolve_user(uid: str) -> int:
        user_id = BranchMembershipService._decode_uid(
            uid,
            field="user_uid",
        )
        users = list(UserRepository.list_users(user_id=[user_id]))
        if not users:
            raise AuthValidationError(
                {"user_uid": ["User not found."]},
                code="USER_NOT_FOUND",
            )
        return user_id

    @staticmethod
    def _validate_unique(
        *,
        branch_id: int,
        user_id: int,
        exclude_id: int | None = None,
    ) -> None:
        if BranchMembershipRepository.get_conflict(
            branch_id=branch_id,
            user_id=user_id,
            exclude_id=exclude_id,
        ):
            raise AuthValidationError(
                {
                    "user_uid": [
                        "This user is already a member of the branch.",
                    ]
                },
                code="BRANCH_MEMBERSHIP_EXISTS",
            )

    @staticmethod
    def get_my_branches(*, user, validated_data: dict | None = None):
        from apps.company.models import Branch, Company
        from apps.company.services.workspace_service import WorkspaceService

        if getattr(user, "pk", None) is None:
            raise PermissionDenied("Authentication required.")

        validated_data = validated_data or {}
        company_id = WorkspaceService._resolve_filter_id(
            validated_data.get("company_uid"),
            model=Company,
            field="company_uid",
        )
        branch_id = WorkspaceService._resolve_filter_id(
            validated_data.get("branch_uid"),
            model=Branch,
            field="branch_uid",
        )
        name = validated_data.get("name")
        if user.is_superuser:
            return BranchRepository.superuser_list(
                company_id=company_id,
                branch_id=branch_id,
                name=name,
            )
        return BranchMembershipRepository.list_my_branches(
            user_id=user.pk,
            company_id=company_id,
            branch_id=branch_id,
            name=name,
        )

    @staticmethod
    def get_memberships(*, validated_data: dict):
        membership_id = None
        branch_id = None
        user_id = None
        company_id = None

        if validated_data.get("uid"):
            membership_id = [
                BranchMembershipService._decode_uid(validated_data["uid"])
            ]

        if validated_data.get("branch_uid"):
            branch_id = BranchMembershipService._decode_uid(
                validated_data["branch_uid"],
                field="branch_uid",
            )

        if validated_data.get("user_uid"):
            user_id = BranchMembershipService._decode_uid(
                validated_data["user_uid"],
                field="user_uid",
            )

        if validated_data.get("company_uid"):
            company_id = BranchMembershipService._decode_uid(
                validated_data["company_uid"],
                field="company_uid",
            )

        return BranchMembershipRepository.list_memberships(
            membership_id=membership_id,
            branch_id=branch_id,
            user_id=user_id,
            company_id=company_id,
            role=validated_data.get("role"),
            roles=(
                ["manager"]
                if validated_data.get("audience") == "admin"
                and not validated_data.get("role")
                else (
                    ["staff"]
                    if validated_data.get("audience") == "employee"
                    and not validated_data.get("role")
                    else None
                )
            ),
            is_active=validated_data.get("is_active"),
            email=validated_data.get("email"),
            name=validated_data.get("name"),
        )

    @staticmethod
    def create_membership(*, validated_data: dict) -> BranchMembership:
        branch_id = BranchMembershipService._resolve_branch(
            validated_data["branch_uid"]
        )
        user_id = BranchMembershipService._resolve_user(
            validated_data["user_uid"]
        )
        BranchMembershipService._validate_unique(
            branch_id=branch_id,
            user_id=user_id,
        )

        branch = BranchRepository.get_by_id(branch_id)

        try:
            with transaction.atomic():
                membership = BranchMembershipRepository.create_membership(
                    branch_id=branch_id,
                    user_id=user_id,
                    role=validated_data.get("role") or "staff",
                    is_active=validated_data.get("is_active", True),
                )
                CompanyMembershipService.ensure_membership(
                    company_id=branch.company_id,
                    user_id=user_id,
                    role="employee",
                )
        except IntegrityError:
            raise AuthValidationError(
                {
                    "user_uid": [
                        "This user is already a member of the branch.",
                    ]
                },
                code="BRANCH_MEMBERSHIP_EXISTS",
            ) from None

        return BranchMembershipRepository.get_by_id(membership.pk)

    @staticmethod
    def update_membership(*, validated_data: dict) -> BranchMembership:
        membership_id = BranchMembershipService._decode_uid(
            validated_data["uid"]
        )
        membership = BranchMembershipRepository.get_by_id(membership_id)
        if membership is None:
            raise NotFound("Branch membership not found.")

        branch_id = BranchMembershipService._resolve_branch(
            validated_data["branch_uid"]
        )
        user_id = BranchMembershipService._resolve_user(
            validated_data["user_uid"]
        )
        BranchMembershipService._validate_unique(
            branch_id=branch_id,
            user_id=user_id,
            exclude_id=membership.pk,
        )

        try:
            with transaction.atomic():
                BranchMembershipRepository.update_membership(
                    membership=membership,
                    branch_id=branch_id,
                    user_id=user_id,
                    role=validated_data.get("role") or membership.role,
                    is_active=validated_data.get(
                        "is_active",
                        membership.is_active,
                    ),
                )
                branch = BranchRepository.get_by_id(branch_id)
                CompanyMembershipService.ensure_membership(
                    company_id=branch.company_id,
                    user_id=user_id,
                    role="employee",
                )
        except IntegrityError:
            raise AuthValidationError(
                {
                    "user_uid": [
                        "This user is already a member of the branch.",
                    ]
                },
                code="BRANCH_MEMBERSHIP_EXISTS",
            ) from None

        return BranchMembershipRepository.get_by_id(membership.pk)

    @staticmethod
    def delete_memberships(*, validated_data: dict) -> dict:
        membership_ids = BranchMembershipService._decode_uids(
            validated_data["uids"]
        )
        deleted = BranchMembershipRepository.soft_delete_by_ids(
            membership_ids
        )
        if not deleted:
            raise NotFound("Branch membership not found.")
        return {"deleted": deleted}

    @staticmethod
    def toggle_memberships(*, validated_data: dict):
        membership_ids = BranchMembershipService._decode_uids(
            validated_data["uids"]
        )
        updated = BranchMembershipRepository.toggle_active_by_ids(
            membership_ids
        )
        if not updated:
            raise NotFound("Branch membership not found.")
        return BranchMembershipRepository.list_memberships(
            membership_id=membership_ids
        )
