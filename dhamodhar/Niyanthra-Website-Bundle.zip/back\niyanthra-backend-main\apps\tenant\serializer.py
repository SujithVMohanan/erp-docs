from rest_framework import serializers

from apps.tenant.models import Tenant


class CreateTenantSerializer(serializers.Serializer):
    company      = serializers.CharField(trim_whitespace=True)
    name         = serializers.CharField(max_length=255, trim_whitespace=True)
    slug         = serializers.SlugField(max_length=255, trim_whitespace=True)
    tenant_type  = serializers.ChoiceField(choices=Tenant.TenantType.choices)
    db_alias     = serializers.CharField(max_length=100, trim_whitespace=True)
    celery_queue = serializers.CharField(
        max_length=100,
        required=False,
        default="default",
        trim_whitespace=True,
    )

    def validate_name(self, value):
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        return value

    def validate_db_alias(self, value):
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        if value == "default":
            raise serializers.ValidationError(
                "db_alias cannot be the control database."
            )
        return value

    def validate_celery_queue(self, value):
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        return value


class UpdateTenantSerializer(serializers.Serializer):
    uid          = serializers.CharField(trim_whitespace=True)
    name         = serializers.CharField(
        max_length=255,
        required=False,
        trim_whitespace=True,
    )
    slug         = serializers.SlugField(
        max_length=255,
        required=False,
        trim_whitespace=True,
    )
    tenant_type  = serializers.ChoiceField(
        choices=Tenant.TenantType.choices,
        required=False,
    )
    db_alias     = serializers.CharField(
        max_length=100,
        required=False,
        trim_whitespace=True,
    )
    celery_queue = serializers.CharField(
        max_length=100,
        required=False,
        trim_whitespace=True,
    )

    def validate_name(self, value):
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        return value

    def validate_db_alias(self, value):
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        if value == "default":
            raise serializers.ValidationError(
                "db_alias cannot be the control database."
            )
        return value

    def validate_celery_queue(self, value):
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        return value


class GetTenantsQuerySerializer(serializers.Serializer):
    uid                 = serializers.CharField(required=False, allow_blank=True, trim_whitespace=True)
    slug                = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=255,
        trim_whitespace=True,
    )
    name                = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=255,
        trim_whitespace=True,
    )
    tenant_type         = serializers.ChoiceField(
        required=False,
        allow_blank=True,
        choices=Tenant.TenantType.choices,
    )
    db_alias            = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=100,
        trim_whitespace=True,
    )
    is_active           = serializers.BooleanField(required=False, allow_null=True)
    provisioning_status = serializers.ChoiceField(
        required=False,
        allow_blank=True,
        choices=Tenant.ProvisioningStatus.choices,
    )

    def validate(self, attrs):
        attrs["uid"] = (attrs.get("uid") or "").strip() or None
        attrs["slug"] = (attrs.get("slug") or "").strip() or None
        attrs["name"] = (attrs.get("name") or "").strip() or None
        attrs["tenant_type"] = (attrs.get("tenant_type") or "").strip() or None
        attrs["db_alias"] = (attrs.get("db_alias") or "").strip() or None
        attrs["provisioning_status"] = (
            (attrs.get("provisioning_status") or "").strip() or None
        )
        if "is_active" not in attrs:
            attrs["is_active"] = None
        return attrs


class GetMyTenantQuerySerializer(serializers.Serializer):
    company_uid = serializers.CharField(trim_whitespace=True, required=True)

    def validate_company_uid(self, value):
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        return value


class TenantUidsSerializer(serializers.Serializer):
    uids = serializers.ListField(
        child=serializers.CharField(allow_blank=False, trim_whitespace=True),
        allow_empty=False,
        max_length=100,
    )

    def validate_uids(self, value):
        unique_uids = list(dict.fromkeys(value))

        if not unique_uids:
            raise serializers.ValidationError("Select at least one tenant.")

        return unique_uids


class ActivateSiloTenantSerializer(serializers.Serializer):
    uid             = serializers.CharField(trim_whitespace=True)
    db_name         = serializers.CharField(max_length=100, trim_whitespace=True)
    host            = serializers.CharField(max_length=255, trim_whitespace=True)
    port            = serializers.IntegerField(min_value=1, max_value=65535)
    secret_arn      = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=512,
        trim_whitespace=True,
    )
    secret_name     = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=255,
        trim_whitespace=True,
    )
    run_migrations  = serializers.BooleanField(required=False, default=True)

    def validate_db_name(self, value):
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        return value

    def validate_host(self, value):
        if not value:
            raise serializers.ValidationError("This field may not be blank.")
        return value

    def validate(self, attrs):
        attrs["secret_arn"] = (attrs.get("secret_arn") or "").strip() or None
        attrs["secret_name"] = (attrs.get("secret_name") or "").strip() or None
        return attrs
