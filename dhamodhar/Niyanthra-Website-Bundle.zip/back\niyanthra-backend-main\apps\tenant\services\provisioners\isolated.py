from apps.background.models import BackgroundJob
from apps.background.repository import BackgroundRepository
from apps.tenant.models import (
    Tenant,
    TenantDatabase,
)
from apps.tenant.repository import TenantRepository
from apps.tenant.services.provisioners.base import BaseTenantProvisioner


class IsolatedTenantProvisioner(BaseTenantProvisioner):
    """Enqueue isolated DB provisioning as a BackgroundJob (PENDING)."""

    def provision(self, *, tenant: Tenant) -> Tenant:
        tenant = TenantRepository.set_provisioning_status(
            tenant=tenant,
            status=Tenant.ProvisioningStatus.PROVISIONING,
            error=None,
        )

        TenantRepository.set_current_database_status(
            tenant=tenant,
            status=TenantDatabase.ProvisioningStatus.PROVISIONING,
            error=None,
        )

        periodic = BackgroundRepository.get_periodic_task_by_code(
            BackgroundRepository.DISPATCH_ISOLATED_CODE
        )

        if periodic is None:
            raise ValueError(
                "Periodic task 'dispatch_isolated_jobs' is not configured."
            )

        BackgroundRepository.create_job(
            periodic_task=periodic,
            tenant=tenant,
            job_type=BackgroundJob.JobType.ISOLATED_DB_PROVISION,
            payload={
                "tenant_id": tenant.pk,
                "db_alias": tenant.db_alias,
                "slug": tenant.slug,
            },
        )

        return tenant
