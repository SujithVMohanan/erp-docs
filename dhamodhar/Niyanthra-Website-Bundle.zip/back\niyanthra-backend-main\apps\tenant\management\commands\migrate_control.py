from django.core.management.base import BaseCommand

from infrastructure.database.migration_service import DatabaseMigrationService


class Command(BaseCommand):
    help = "Migrate the control database only (users, organization, company, tenant). No sales tables."

    def add_arguments(self, parser):
        parser.add_argument(
            "--verbosity-level",
            type=int,
            default=1,
            dest="migrate_verbosity",
        )

    def handle(self, *args, **options):
        result = DatabaseMigrationService.migrate_control(
            verbosity=options["migrate_verbosity"],
        )
        self.stdout.write(self.style.SUCCESS(f"migrate_control: {result}"))
