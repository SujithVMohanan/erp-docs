from django.db import transaction
from rest_framework.exceptions import (
    NotFound,
    ValidationError,
)

from apps.tenant.models import (
    Tenant,
    TenantDatabase,
)
from apps.tenant.repository import TenantRepository
from core.utils.ids import decode_id
from infrastructure.database.loader import TenantConnectionLoader
from infrastructure.database.migrator import TenantMigrator


class SiloActivationService:
    """DevOps activates a SILO tenant after dedicated infra is ready."""

    @staticmethod
    def _decode_uid(uid: str) -> int:
        try:
            tenant_id = decode_id(uid)
        except (TypeError, ValueError):
            raise ValidationError({"uid": ["Invalid id."]}) from None

        if not isinstance(tenant_id, int):
            raise ValidationError({"uid": ["Invalid id."]})

        return tenant_id

    @staticmethod
    def activate(*, validated_data: dict) -> Tenant:
        tenant = TenantRepository.get_by_id(
            SiloActivationService._decode_uid(validated_data["uid"])
        )

        if tenant is None:
            raise NotFound("Tenant not found.")

        if tenant.tenant_type != Tenant.TenantType.SILO:
            raise ValidationError(
                {"uid": ["Only SILO tenants can be activated via this API."]}
            )

        if tenant.provisioning_status not in {
            Tenant.ProvisioningStatus.PENDING,
            Tenant.ProvisioningStatus.FAILED,
        }:
            raise ValidationError(
                {
                    "uid": [
                        "SILO tenant must be PENDING or FAILED to activate."
                    ]
                }
            )

        db_name = validated_data["db_name"]
        host = validated_data["host"]
        port = validated_data["port"]
        secret_arn = validated_data.get("secret_arn") or None
        secret_name = validated_data.get("secret_name") or None
        run_migrations = validated_data.get("run_migrations", True)

        TenantRepository.set_provisioning_status(
            tenant=tenant,
            status=Tenant.ProvisioningStatus.PROVISIONING,
            error=None,
        )
        TenantRepository.set_current_database_status(
            tenant=tenant,
            status=TenantDatabase.ProvisioningStatus.PROVISIONING,
            error=None,
        )

        try:
            TenantConnectionLoader.register_tenant_database(
                db_alias=tenant.db_alias,
                db_name=db_name,
                host=host,
                port=port,
                secret_arn=secret_arn,
                secret_name=secret_name,
            )

            if run_migrations:
                TenantMigrator.migrate(alias=tenant.db_alias)

            with transaction.atomic():
                TenantRepository.update_current_database_connection(
                    tenant=tenant,
                    db_name=db_name,
                    host=host,
                    port=port,
                    status=TenantDatabase.ProvisioningStatus.ACTIVE,
                )
                TenantRepository.update_current_database_secrets(
                    tenant=tenant,
                    secret_arn=secret_arn,
                    secret_name=secret_name,
                )
                tenant = TenantRepository.set_provisioning_status(
                    tenant=tenant,
                    status=Tenant.ProvisioningStatus.ACTIVE,
                    error=None,
                )
        except Exception as exc:
            TenantRepository.set_current_database_status(
                tenant=tenant,
                status=TenantDatabase.ProvisioningStatus.FAILED,
                error=str(exc),
            )
            tenant = TenantRepository.set_provisioning_status(
                tenant=tenant,
                status=Tenant.ProvisioningStatus.FAILED,
                error=str(exc),
            )
            raise

        return tenant
