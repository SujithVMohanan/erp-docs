from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

APPEND = '''

class TimeZoneBaseApiView:
    response_schema = GetTimeZonesApiSchema

    def handle_exception_response(self, exc, request):
        return ExceptionHandler.handle(exc, request=request, view=self)


class GetTimeZonesApiView(TimeZoneBaseApiView, generics.ListAPIView):
    serializer_class = GetTimeZonesApiSchema
    query_serializer_class = GetTimeZonesQuerySerializer
    pagination_class = RestPagination
    permission_classes = [IsAuthenticated, IsAppAuthenticated]

    @swagger_auto_schema(tags=["Time Zones"], operation_summary="Get time zones")
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Exception as exc:
            return self.handle_exception_response(exc, request)

    def get_queryset(self):
        query = self.query_serializer_class(data=self.request.query_params)
        query.is_valid(raise_exception=True)
        return TimeZoneService.get_timezones(validated_data=query.validated_data)


class CreateTimeZoneApiView(TimeZoneBaseApiView, generics.CreateAPIView):
    permission_classes = [IsAuthenticated, IsAppAuthenticated, IsPlatformAdmin]
    serializer_class = CreateTimeZoneSerializer

    @swagger_auto_schema(
        request_body=CreateTimeZoneSerializer,
        tags=["Time Zones"],
        operation_summary="Create time zone",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            item = TimeZoneService.create_timezone(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.created(
                self.response_schema(item).data,
                message="Time zone created successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class UpdateTimeZoneApiView(TimeZoneBaseApiView, generics.GenericAPIView):
    permission_classes = [IsAuthenticated, IsAppAuthenticated, IsPlatformAdmin]
    serializer_class = UpdateTimeZoneSerializer

    @swagger_auto_schema(
        request_body=UpdateTimeZoneSerializer,
        tags=["Time Zones"],
        operation_summary="Update time zone",
    )
    def put(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            item = TimeZoneService.update_timezone(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                self.response_schema(item).data,
                message="Time zone updated successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class DeleteTimeZonesApiView(TimeZoneBaseApiView, generics.GenericAPIView):
    permission_classes = [IsAuthenticated, IsAppAuthenticated, IsPlatformAdmin]
    serializer_class = TimeZoneUidsSerializer

    @swagger_auto_schema(
        request_body=TimeZoneUidsSerializer,
        tags=["Time Zones"],
        operation_summary="Delete time zones",
    )
    def delete(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            payload = TimeZoneService.delete_timezones(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                payload,
                message="Time zone(s) deleted successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)


class InactiveActiveTimeZonesApiView(TimeZoneBaseApiView, generics.GenericAPIView):
    permission_classes = [IsAuthenticated, IsAppAuthenticated, IsPlatformAdmin]
    serializer_class = TimeZoneUidsSerializer

    @swagger_auto_schema(
        request_body=TimeZoneUidsSerializer,
        tags=["Time Zones"],
        operation_summary="Toggle time zone active status",
    )
    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            if not serializer.is_valid():
                return ResponseInfo.validation_error(serializer.errors)
            items = TimeZoneService.toggle_timezones(
                validated_data=serializer.validated_data
            )
            return ResponseInfo.ok(
                self.response_schema(items, many=True).data,
                message="Time zone status updated successfully.",
            )
        except Exception as exc:
            return self.handle_exception_response(exc, request)
'''

views = ROOT / "apps/users/views.py"
text = views.read_text(encoding="utf-8")
if "GetTimeZonesApiView" not in text:
    text = text.replace(
        "GetUsersApiSchema,\n    LoginUserResponseSchema,",
        "GetTimeZonesApiSchema,\n    GetUsersApiSchema,\n    LoginUserResponseSchema,",
    )
    text = text.replace(
        "CompleteProfileSerializer,\n    DeleteUsersSerializer,\n    GetUsersQuerySerializer,",
        "CompleteProfileSerializer,\n    CreateTimeZoneSerializer,\n    DeleteUsersSerializer,\n"
        "    GetTimeZonesQuerySerializer,\n    GetUsersQuerySerializer,",
    )
    text = text.replace(
        "RegisterUserSerializer,\n    SocialLoginSerializer,\n)",
        "RegisterUserSerializer,\n    SocialLoginSerializer,\n"
        "    TimeZoneUidsSerializer,\n    UpdateTimeZoneSerializer,\n)",
    )
    text = text.replace(
        "from apps.users.services.user_service import UserService",
        "from apps.users.services.timezone_service import TimeZoneService\n"
        "from apps.users.services.user_service import UserService",
    )
    views.write_text(text.rstrip() + APPEND, encoding="utf-8")
    print("patched views")
else:
    print("views ok")

URLS = '''from django.urls import path

from apps.users.views import (
    CompleteProfileApiView,
    CreateTimeZoneApiView,
    CurrentUserApiView,
    DeleteTimeZonesApiView,
    DeleteUsersApiView,
    GetTimeZonesApiView,
    GetUsersApiView,
    HardDeleteUsersApiView,
    InactiveActiveTimeZonesApiView,
    LoginUserApiView,
    LogoutUserApiView,
    RefreshTokenApiView,
    RegisterUserApiView,
    RegistrationStatusApiView,
    SocialLoginApiView,
    UpdateTimeZoneApiView,
)

app_name = "users"

urlpatterns = [
    path("register/", RegisterUserApiView.as_view(), name="register"),
    path("social-login/", SocialLoginApiView.as_view(), name="social-login"),
    path("login/", LoginUserApiView.as_view(), name="login"),
    path("logout/", LogoutUserApiView.as_view(), name="logout"),
    path("refresh/", RefreshTokenApiView.as_view(), name="refresh"),
    path("me/", CurrentUserApiView.as_view(), name="me"),
    path("complete-profile/", CompleteProfileApiView.as_view(), name="complete-profile"),
    path(
        "registration-status/",
        RegistrationStatusApiView.as_view(),
        name="registration-status",
    ),
    path("get-users/", GetUsersApiView.as_view(), name="get-users"),
    path("delete-users/", DeleteUsersApiView.as_view(), name="delete-users"),
    path("get-time-zones/", GetTimeZonesApiView.as_view(), name="get-time-zones"),
    path("create-time-zone/", CreateTimeZoneApiView.as_view(), name="create-time-zone"),
    path("update-time-zone/", UpdateTimeZoneApiView.as_view(), name="update-time-zone"),
    path("delete-time-zones/", DeleteTimeZonesApiView.as_view(), name="delete-time-zones"),
    path(
        "inactive-active-time-zones/",
        InactiveActiveTimeZonesApiView.as_view(),
        name="inactive-active-time-zones",
    ),
]
'''
(ROOT / "apps/users/urls.py").write_text(URLS, encoding="utf-8")
print("wrote users urls")
