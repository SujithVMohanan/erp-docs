from django.test import TestCase
from rest_framework.test import APIClient

from apps.company.models import (
    Branch,
    BranchMembership,
    Company,
    CompanyMembership,
)
from apps.location.models import Country
from apps.organization.models import Organization
from apps.users.models import Users
from core.utils.ids import encode_id
from core.utils.membership_invite import verify_membership_invite_token
from core.utils.tokens import issue_tokens

PASSWORD = "ValidPassw0rd!"


class MembershipInviteApiTests(TestCase):

    def setUp(self):
        self.client = APIClient()
        self.admin = Users.objects.create_user(
            email="inv-admin@example.com",
            password=PASSWORD,
            username="invadmin",
            phone_number="+15553330001",
            is_admin=True,
            profile_completed=True,
        )
        self.invitee = Users.objects.create_user(
            email="inv-user@example.com",
            password=PASSWORD,
            username="invuser",
            phone_number="+15553330002",
            profile_completed=True,
        )
        self.admin_tokens = issue_tokens(self.admin)
        self.invitee_tokens = issue_tokens(self.invitee)
        self.client.credentials(
            HTTP_AUTHORIZATION=f"Bearer {self.admin_tokens['access']}"
        )

        self.country = Country.objects.create(name="India", code="IN")
        self.organization = Organization.objects.create(
            name="Invite Org",
            code="INVORG",
            legal_name="Invite Org Pvt",
            country=self.country,
        )
        self.company = Company.objects.create(
            name="Invite Co",
            code="INVCO",
            organization=self.organization,
            is_active=True,
        )
        self.branch = Branch.objects.create(
            company=self.company,
            name="Invite HQ",
            code="IHQ",
            status="ACTIVE",
        )
        self.company_uid = encode_id(self.company.pk)
        self.branch_uid = encode_id(self.branch.pk)
        CompanyMembership.objects.create(
            company=self.company,
            user=self.admin,
            role=CompanyMembership.Role.ADMIN,
            is_active=True,
        )

    def test_create_company_invite_is_opaque(self):
        response = self.client.post(
            "/api/company/create-company-membership-invite/",
            {"company_uid": self.company_uid, "role": "employee"},
            format="json",
        )
        self.assertEqual(response.status_code, 201)
        data = response.data["data"]
        self.assertEqual(data["kind"], "company")
        self.assertTrue(data["token"])
        self.assertNotIn("company_id", data["token"])
        self.assertNotIn('"company_id"', data["token"])
        self.assertNotIn("company_id", data)
        self.assertTrue(data["invite_url"].startswith("http"))
        payload = verify_membership_invite_token(data["token"])
        self.assertEqual(payload["company_id"], self.company.pk)
        self.assertEqual(payload["role"], "employee")

    def test_accept_company_invite(self):
        created = self.client.post(
            "/api/company/create-company-membership-invite/",
            {"company_uid": self.company_uid, "audience": "admin", "role": "admin"},
            format="json",
        )
        token = created.data["data"]["token"]

        self.client.credentials(
            HTTP_AUTHORIZATION=f"Bearer {self.invitee_tokens['access']}"
        )
        response = self.client.post(
            "/api/company/accept-membership-invite/",
            {"token": token},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["data"]["kind"], "company")
        self.assertEqual(response.data["data"]["role"], "admin")
        self.assertTrue(
            CompanyMembership.objects.filter(
                company=self.company,
                user=self.invitee,
                role="admin",
                is_active=True,
            ).exists()
        )

    def test_accept_branch_invite_also_ensures_company_membership(self):
        created = self.client.post(
            "/api/company/create-branch-membership-invite/",
            {"branch_uid": self.branch_uid, "audience": "admin", "role": "manager"},
            format="json",
        )
        self.assertEqual(created.status_code, 201)
        token = created.data["data"]["token"]
        self.assertNotIn("branch_id", token)
        self.assertNotIn('"branch_id"', token)

        self.client.credentials(
            HTTP_AUTHORIZATION=f"Bearer {self.invitee_tokens['access']}"
        )
        response = self.client.post(
            "/api/company/accept-membership-invite/",
            {"token": token},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["data"]["kind"], "branch")
        self.assertTrue(
            BranchMembership.objects.filter(
                branch=self.branch,
                user=self.invitee,
                role="manager",
                is_active=True,
            ).exists()
        )
        self.assertTrue(
            CompanyMembership.objects.filter(
                company=self.company,
                user=self.invitee,
                is_active=True,
            ).exists()
        )

    def test_invalid_invite_token(self):
        self.client.credentials(
            HTTP_AUTHORIZATION=f"Bearer {self.invitee_tokens['access']}"
        )
        response = self.client.post(
            "/api/company/accept-membership-invite/",
            {"token": "not-a-valid-token"},
            format="json",
        )
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data.get("code"), "INVALID_INVITE")

    def test_company_only_invite_does_not_grant_branch_access(self):
        from apps.company.repository import CompanyRepository

        created = self.client.post(
            "/api/company/create-company-membership-invite/",
            {"company_uid": self.company_uid, "role": "employee"},
            format="json",
        )
        token = created.data["data"]["token"]
        self.client.credentials(
            HTTP_AUTHORIZATION=f"Bearer {self.invitee_tokens['access']}"
        )
        self.client.post(
            "/api/company/accept-membership-invite/",
            {"token": token},
            format="json",
        )

        self.assertTrue(
            CompanyRepository.user_has_company_access(
                user_id=self.invitee.pk,
                company_id=self.company.pk,
            )
        )
        self.assertFalse(
            BranchMembership.objects.filter(
                user=self.invitee,
                branch__company=self.company,
            ).exists()
        )
        self.assertEqual(
            list(
                CompanyRepository.list_accessible_branches_for_company(
                    user_id=self.invitee.pk,
                    company_id=self.company.pk,
                )
            ),
            [],
        )
        self.assertIsNone(
            CompanyRepository.get_active_branch_for_company(
                user_id=self.invitee.pk,
                company_id=self.company.pk,
                branch_id=self.branch.pk,
            )
        )
