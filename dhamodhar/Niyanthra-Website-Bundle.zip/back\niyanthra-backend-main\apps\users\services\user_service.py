from django.db import (
    IntegrityError,
    transaction,
)
from django.db.models.deletion import ProtectedError
from rest_framework.exceptions import (
    NotFound,
    PermissionDenied,
    ValidationError,
)
from rest_framework_simplejwt.exceptions import TokenError

from apps.company.services.workspace_service import WorkspaceService
from apps.users.models import (
    UserManager,
    Users,
)
from apps.users.repository import (
    UserRepository,
    integrity_field_errors,
)
from apps.users.services.membership_service import MembershipService
from core.exceptions.auth import (
    AuthFailed,
    AuthValidationError,
)
from core.utils.auth_log import log_auth_event
from core.utils.ids import decode_id
from core.utils.jwt_blacklist import blacklist_access_token
from core.utils.normalize import normalize_phone
from core.utils.tokens import (
    issue_tokens,
    session_for_user,
)


class UserService:

    @staticmethod
    def register_user(*, validated_data: dict) -> tuple[dict, Users]:

        email           = UserManager.normalize_email(validated_data["email"])
        password        = validated_data["password"]
        full_name       = validated_data.get("full_name")
        phone_number    = validated_data.get("phone_number")
        

        if UserRepository.get_alive_by_email(email):
            raise AuthValidationError(
                {"email": ["This email is already registered."]},
                code="EMAIL_ALREADY_EXISTS",
            )

        try:
            with transaction.atomic():
                user = UserRepository.create_user(
                    email       = email,
                    password    = password,
                    username    = full_name,
                    phone_number= normalize_phone(phone_number) if phone_number else None,
                )
                if MembershipService.has_membership_scope(validated_data=validated_data):
                    MembershipService.create_membership(
                        validated_data=validated_data,
                        user=user,
                    )

        except IntegrityError as exc:
            errors, code = integrity_field_errors(exc)
            raise AuthValidationError(
                    errors, 
                    code=code
                ) from None

        log_auth_event(
                "register", 
                public_id=str(user.public_id)
            )

        return session_for_user(user), user

    @staticmethod
    def get_users(*, validated_data: dict):
        uid     = validated_data.get("uid")
        user_id = None
        if uid:
            try:
                decoded = decode_id(uid)
            except ValueError:
                raise ValidationError({"uid": ["Invalid user id."]})
            if not isinstance(decoded, int):
                raise ValidationError({"uid": ["Invalid user id."]})
            user_id = [decoded]

        return UserRepository.list_users(
            user_id   = user_id,
            email     = validated_data.get("email"),
            name      = validated_data.get("name"),
        )

    @staticmethod
    def _decode_uids(uids: list[str]) -> list[int]:
        user_ids = []
        for uid in uids:
            try:
                decoded = decode_id(uid)
            except ValueError:
                raise ValidationError({"uids": ["One or more user ids are invalid."]})
            if not isinstance(decoded, int):
                raise ValidationError({"uids": ["One or more user ids are invalid."]})
            user_ids.append(decoded)
        return list(dict.fromkeys(user_ids))

    @staticmethod
    def delete_users(*, validated_data: dict) -> dict:
        user_ids = UserService._decode_uids(validated_data["uids"])
        UserRepository.revoke_outstanding_tokens(user_ids)
        deleted = UserRepository.soft_delete_by_ids(user_ids)
        if not deleted:
            raise NotFound("User not found.")
        return {"deleted": deleted}

    @staticmethod
    def hard_delete_users(*, actor: Users, validated_data: dict) -> dict:
        if not actor.is_admin:
            raise PermissionDenied("You do not have permission to permanently delete users.")

        user_ids = UserService._decode_uids(validated_data["uids"])
        if actor.pk in user_ids:
            raise ValidationError(
                {"uids": ["You cannot permanently delete your own account."]}
            )
        if UserRepository.list_superuser_ids(user_ids):
            raise ValidationError(
                {"uids": ["Superadmin accounts cannot be permanently deleted."]}
            )

        try:
            UserRepository.revoke_outstanding_tokens(user_ids)
            deleted = UserRepository.hard_delete_by_ids(user_ids)
        except ProtectedError:
            raise ValidationError(
                {
                    "uids": [
                        "Cannot permanently delete: related records must be removed first."
                    ]
                }
            ) from None

        if not deleted:
            raise NotFound("User not found.")
        return {"deleted": deleted}

    @staticmethod
    def complete_profile(
        *,
        user: Users,
        validated_data: dict,
        access_token: str | None = None,
    ) -> tuple[dict, Users]:
        if not user.is_active:
            raise AuthFailed("Account is disabled.", code="ACCOUNT_DISABLED")

        username        = validated_data["username"]
        phone_number    = normalize_phone(validated_data["phone_number"])
        errors          = {}
        code            = "VALIDATION_ERROR"

        if UserRepository.get_username_conflict(
            username=username,
            exclude_user_id=user.pk,
        ):
            errors["username"] = ["This username is already taken."]
            code = "USERNAME_ALREADY_TAKEN"
        if UserRepository.get_phone_conflict(
            phone_number=phone_number,
            exclude_user_id=user.pk,
        ):
            errors["phone_number"] = ["This phone number is already registered."]
            code = "PHONE_ALREADY_EXISTS" if "username" not in errors else "VALIDATION_ERROR"
        if errors:
            raise AuthValidationError(errors, code=code)

        try:
            with transaction.atomic():
                locked = UserRepository.lock_alive_by_id(user.pk)
                if not locked.is_active:
                    raise AuthFailed("Account is disabled.", code="ACCOUNT_DISABLED")
                user = UserRepository.update_user_profile(
                    user=locked,
                    username=username,
                    phone_number=phone_number,
                    password=validated_data.get("password"),
                )
        except IntegrityError as exc:
            mapped, mapped_code = integrity_field_errors(exc)
            raise AuthValidationError(mapped, code=mapped_code) from None

        if access_token:
            try:
                blacklist_access_token(access_token)
            except TokenError:
                pass

        UserRepository.update_last_login(user)
        log_auth_event("profile_completed", public_id=str(user.public_id))
        tokens = issue_tokens(user)
        return tokens, user

    @staticmethod
    def registration_status(*, user: Users) -> dict:
        missing = []
        if not (user.username or "").strip():
            missing.append("username")
        if not (user.phone_number or "").strip():
            missing.append("phone_number")
        return {
            "profile_completed": bool(user.profile_completed),
            "missing_fields": missing,
        }
