from django.contrib import admin

from .models import (
    Branch,
    BranchLocation,
    BranchMembership,
    BranchTaxRegistration,
    BusinessType,
    Company,
    CompanyAddress,
    CompanyBusinessType,
    CompanyLocation,
    CompanyMembership,
    CompanyModule,
    Module,
    CompanyTaxRegistration,
    CompanyType,
    TaxComponent,
    TaxRate,
    TaxRateComponent,
    TaxType,
)


@admin.register(Module)
class ModuleAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "is_active", "deleted_at")
    list_filter = ("is_active",)
    search_fields = ("name", "code")


@admin.register(CompanyModule)
class CompanyModuleAdmin(admin.ModelAdmin):
    list_display = ("company", "deleted_at")
    search_fields = ("company__name", "company__code")


@admin.register(CompanyType)
class CompanyTypeAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "is_active", "deleted_at")
    list_filter = ("is_active",)
    search_fields = ("name", "code")


@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "organization", "company_type", "is_active", "deleted_at")
    list_filter = ("is_active", "organization", "company_type")
    search_fields = ("name", "code", "legal_name", "registration_number", "organization__name")


@admin.register(CompanyMembership)
class CompanyMembershipAdmin(admin.ModelAdmin):
    list_display = ("company", "user", "role", "is_active", "created_at", "deleted_at")
    list_filter = ("role", "is_active")
    search_fields = ("company__name", "company__code", "user__email", "user__username")


@admin.register(CompanyAddress)
class CompanyAddressAdmin(admin.ModelAdmin):
    list_display = ("company", "address_type", "city", "country", "is_primary", "deleted_at")
    list_filter = ("address_type", "is_primary", "country")
    search_fields = ("company__name", "company__code", "address_line_1", "city", "postal_code")


@admin.register(BusinessType)
class BusinessTypeAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "is_active", "deleted_at")
    list_filter = ("is_active",)
    search_fields = ("name", "code")


@admin.register(CompanyBusinessType)
class CompanyBusinessTypeAdmin(admin.ModelAdmin):
    list_display = ("company", "business_type", "is_primary", "created_at", "deleted_at")
    list_filter = ("is_primary",)
    search_fields = ("company__name", "company__code", "business_type__name", "business_type__code")


@admin.register(TaxType)
class TaxTypeAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "created_at", "deleted_at")
    search_fields = ("name", "code")


@admin.register(TaxComponent)
class TaxComponentAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "tax_type", "component_type", "deleted_at")
    search_fields = ("name", "code", "component_type", "tax_type__name", "tax_type__code")


@admin.register(TaxRate)
class TaxRateAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "tax_type", "rate", "rate_type", "effective_from", "effective_to", "deleted_at")
    list_filter = ("rate_type", "effective_from", "effective_to")
    search_fields = ("name", "code", "tax_type__name", "tax_type__code")


@admin.register(TaxRateComponent)
class TaxRateComponentAdmin(admin.ModelAdmin):
    list_display = ("tax_rate", "tax_component", "rate", "created_at", "deleted_at")
    search_fields = ("tax_rate__name", "tax_rate__code", "tax_component__name", "tax_component__code")


@admin.register(CompanyTaxRegistration)
class CompanyTaxRegistrationAdmin(admin.ModelAdmin):
    list_display = (
        "company",
        "country",
        "tax_type",
        "registration_number",
        "status",
        "is_primary",
        "deleted_at",
    )
    list_filter = ("status", "is_primary", "country", "tax_type")
    search_fields = ("company__name", "company__code", "registration_number", "registration_name")


@admin.register(Branch)
class BranchAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "company", "branch_type", "status", "email", "deleted_at")
    list_filter = ("branch_type", "status", "company")
    search_fields = ("name", "code", "email", "phone", "company__name", "company__code")


@admin.register(BranchMembership)
class BranchMembershipAdmin(admin.ModelAdmin):
    list_display = ("branch", "user", "role", "is_active", "created_at", "deleted_at")
    list_filter = ("role", "is_active")
    search_fields = ("branch__name", "branch__code", "user__email")


@admin.register(BranchTaxRegistration)
class BranchTaxRegistrationAdmin(admin.ModelAdmin):
    list_display = ("branch", "tax_registration", "is_primary", "effective_from", "effective_to", "deleted_at")
    list_filter = ("is_primary", "effective_from", "effective_to")
    search_fields = ("branch__name", "branch__code", "tax_registration__registration_number")


@admin.register(CompanyLocation)
class CompanyLocationAdmin(admin.ModelAdmin):
    list_display = ("company", "location", "location_type", "is_primary", "deleted_at")
    list_filter = ("location_type", "is_primary")
    search_fields = ("company__name", "company__code", "location__city", "location__postal_code")


@admin.register(BranchLocation)
class BranchLocationAdmin(admin.ModelAdmin):
    list_display = ("branch", "location", "created_at", "deleted_at")
    search_fields = ("branch__name", "branch__code", "location__city", "location__postal_code")
