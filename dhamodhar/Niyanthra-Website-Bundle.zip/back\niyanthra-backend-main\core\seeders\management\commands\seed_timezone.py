from core.seeders.management.commands._seed_base import SeedGroupCommand
from core.seeders.timezone import run


class Command(SeedGroupCommand):
    help = "Seed TimeZone master data. Safe to run multiple times."
    group_label = "TimeZone"
    seeder_run = staticmethod(run)
