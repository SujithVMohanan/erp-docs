UNITS = (
    ("PCS", "Pieces"),
    ("KG", "Kilogram"),
    ("G", "Gram"),
    ("L", "Litre"),
    ("ML", "Millilitre"),
    ("M", "Metre"),
    ("BOX", "Box"),
    ("PACK", "Pack"),
    ("DOZ", "Dozen"),
    ("SET", "Set"),
)

UNIT_CODES = frozenset(code for code, _label in UNITS)
DEFAULT_UNIT = "PCS"
